import { redirect } from "next/navigation";
import { sql } from "drizzle-orm";
import { eq, inArray } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth/session";
import { db } from "@/lib/db/client";
import { files, labs, labFiles, questions } from "@/lib/db/schema";
import { simulations } from "@/lib/portal/simulations";
import { LAB_DOC_SECTIONS, type LabDocKind } from "@/lib/portal/lab-sections";
import { AdminLabsClient, type LabRow, type LibraryFile, type PracticeLabOption } from "./client";

export const dynamic = "force-dynamic";

export default async function AdminLabsPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/admin/labs");
  if (user.role !== "admin") {
    return (
      <div className="col">
        <div className="screen-head">
          <div className="section-label">Restricted</div>
          <h1>Not available</h1>
        </div>
        <div className="callout orange">
          <strong>Admins only.</strong> Your account doesn&apos;t have access to lab module management.
        </div>
      </div>
    );
  }

  const labRows = await db
    .select({
      id: labs.id,
      name: labs.name,
      description: labs.description,
      moduleOrder: labs.moduleOrder,
      hasPrelab: labs.hasPrelab,
      hasPostlab: labs.hasPostlab,
      hasPractice: labs.hasPractice,
      hasSimulation: labs.hasSimulation,
      hasActivity: labs.hasActivity,
      hasAnalysisGuide: labs.hasAnalysisGuide,
      hasVideoTutorial: labs.hasVideoTutorial,
      hasResearchPaper: labs.hasResearchPaper,
      hasStudentGuide: labs.hasStudentGuide,
      hasSelfCheck: labs.hasSelfCheck,
      hasAiGradingPrompt: labs.hasAiGradingPrompt,
      hasInstructorGuide: labs.hasInstructorGuide,
      hasLessonPlan: labs.hasLessonPlan,
      hasSelfCheckAnswerKey: labs.hasSelfCheckAnswerKey,
      simulationId: labs.simulationId,
      practiceLabId: labs.practiceLabId,
      createdAt: labs.createdAt,
    })
    .from(labs)
    .orderBy(sql`${labs.moduleOrder} asc nulls last, ${labs.createdAt} asc, ${labs.id} asc`);

  const practiceLabRows = await db
    .select({
      id: labs.id,
      name: labs.name,
      total: sql<number>`count(${questions.id})`,
    })
    .from(labs)
    .innerJoin(questions, eq(questions.labId, labs.id))
    .groupBy(labs.id, labs.name)
    .orderBy(labs.name);
  const practiceLabOptions: PracticeLabOption[] = practiceLabRows.map((r) => ({
    id: r.id,
    name: r.name,
    total: Number(r.total),
  }));

  const labIds = labRows.map((l) => l.id);
  const lfRows = labIds.length
    ? await db
        .select({
          id: labFiles.id,
          labId: labFiles.labId,
          fileId: labFiles.fileId,
          kind: labFiles.kind,
          position: labFiles.position,
          fileTitle: files.title,
          filename: files.filename,
          contentType: files.contentType,
        })
        .from(labFiles)
        .innerJoin(files, eq(files.id, labFiles.fileId))
        .where(inArray(labFiles.labId, labIds))
        .orderBy(labFiles.position)
    : [];

  // Bucket attached files by kind for every section.
  type LfRow = (typeof lfRows)[number];
  const byLab = new Map<string, Record<LabDocKind, LfRow[]>>();
  const emptyKindBuckets = () =>
    Object.fromEntries(LAB_DOC_SECTIONS.map((s) => [s.kind, [] as LfRow[]])) as Record<
      LabDocKind,
      LfRow[]
    >;
  for (const id of labIds) byLab.set(id, emptyKindBuckets());
  for (const r of lfRows) {
    byLab.get(r.labId)?.[r.kind as LabDocKind]?.push(r);
  }

  const toAttached = (rows: LfRow[]) =>
    rows.map((r) => ({
      labFileId: r.id,
      fileId: r.fileId,
      title: r.fileTitle,
      filename: r.filename,
      contentType: r.contentType,
    }));

  const initialLabs: LabRow[] = labRows.map((l) => {
    const buckets = byLab.get(l.id) ?? emptyKindBuckets();
    const fileFields = Object.fromEntries(
      LAB_DOC_SECTIONS.map((s) => [s.filesKey, toAttached(buckets[s.kind])]),
    );
    return {
      id: l.id,
      name: l.name,
      description: l.description,
      moduleOrder: l.moduleOrder,
      hasPrelab: l.hasPrelab,
      hasPostlab: l.hasPostlab,
      hasPractice: l.hasPractice,
      hasSimulation: l.hasSimulation,
      hasActivity: l.hasActivity,
      hasAnalysisGuide: l.hasAnalysisGuide,
      hasVideoTutorial: l.hasVideoTutorial,
      hasResearchPaper: l.hasResearchPaper,
      hasStudentGuide: l.hasStudentGuide,
      hasSelfCheck: l.hasSelfCheck,
      hasAiGradingPrompt: l.hasAiGradingPrompt,
      hasInstructorGuide: l.hasInstructorGuide,
      hasLessonPlan: l.hasLessonPlan,
      hasSelfCheckAnswerKey: l.hasSelfCheckAnswerKey,
      simulationId: l.simulationId,
      practiceLabId: l.practiceLabId,
      ...fileFields,
    } as LabRow;
  });

  // Library: ready files eligible to attach — PDFs (most sections) and videos
  // (the video tutorial). Both public and faculty (private) files are included;
  // the client picker filters by contentType AND accessLevel, since faculty-only
  // sections (instructor guide, lesson plan, answer key) attach private files
  // while every other section attaches public ones.
  const libraryRows = await db
    .select({
      id: files.id,
      title: files.title,
      filename: files.filename,
      category: files.category,
      accessLevel: files.accessLevel,
      sizeBytes: files.sizeBytes,
      contentType: files.contentType,
      uploadedAt: files.uploadedAt,
    })
    .from(files)
    .where(
      sql`${files.status} = 'ready' and (${files.contentType} = 'application/pdf' or ${files.contentType} like 'video/%')`,
    )
    .orderBy(sql`${files.uploadedAt} desc`);
  const library: LibraryFile[] = libraryRows.map((f) => ({
    ...f,
    uploadedAt: new Date(f.uploadedAt).toISOString(),
  }));

  return (
    <div className="col">
      <div className="screen-head">
        <div className="section-label">Admin</div>
        <h1>Labs</h1>
        <p className="lead muted">
          Create and edit the lab modules students see in the sidebar. Each lab can attach documents
          (prelab, postlab, activity, analysis guide, research paper) and a video tutorial, wire up a
          retrieval practice, and pick a postlab simulation.
        </p>
      </div>
      <AdminLabsClient
        initialLabs={initialLabs}
        library={library}
        simulations={simulations.map((s) => ({ id: s.id, title: s.title }))}
        practiceLabOptions={practiceLabOptions}
      />
    </div>
  );
}
