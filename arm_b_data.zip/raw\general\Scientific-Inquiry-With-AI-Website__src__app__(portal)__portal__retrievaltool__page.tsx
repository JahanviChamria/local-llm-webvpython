import Link from "next/link";
import { getPortalLabs } from "@/lib/portal/data";
import { getAccessibleLabs } from "@/lib/portal/accessible-labs";
import { getCurrentUser } from "@/lib/auth/session";
import { Badge, Card } from "@/components/portal/primitives";

export const dynamic = "force-dynamic";

export default async function RetrievalToolScreen() {
  const [allLabs, user] = await Promise.all([getPortalLabs(), getCurrentUser()]);
  const isStaff = user?.role === "admin" || user?.role === "faculty";

  // Students only see labs they're enrolled in AND that are unlocked; staff see all.
  let labs = allLabs;
  if (!isStaff) {
    if (!user) {
      labs = [];
    } else {
      const accessible = new Set((await getAccessibleLabs(user.id)).map((l) => l.id));
      labs = allLabs.filter((l) => accessible.has(l.id));
    }
  }

  return (
    <div className="col">
      <div className="screen-head">
        <div className="section-label">Retrieval Tool</div>
        <h1>Choose a lab to practice</h1>
        <p className="lead muted">
          Pick a lab below to launch its retrieval-practice session. Each session pulls questions from that lab&apos;s
          spaced-repetition queue.
        </p>
      </div>

      <Card title="Available labs" label={`${labs.length} lab${labs.length === 1 ? "" : "s"}`}>
        {labs.length === 0 ? (
          <p className="muted" style={{ fontSize: 13 }}>
            No labs have questions yet. Once your instructor adds questions, each lab will appear here.
          </p>
        ) : (
          <div className="col" style={{ gap: 10 }}>
            {labs.map((lab, i) => (
              <div key={lab.id} className="doc-row">
                <div className="doc-icon">{i + 1}</div>
                <div className="doc-info">
                  <div className="doc-name">
                    {lab.name}
                    {isStaff && (
                      <>
                        {" "}
                        <Badge kind="progress">Staff view</Badge>
                      </>
                    )}
                  </div>
                  <div className="row center" style={{ gap: 5, marginTop: 6 }}>
                    {lab.easy > 0 && <Badge kind="complete">{lab.easy} easy</Badge>}
                    {lab.medium > 0 && <Badge kind="progress">{lab.medium} medium</Badge>}
                    {lab.hard > 0 && <Badge kind="alert">{lab.hard} hard</Badge>}
                    <span className="muted" style={{ fontSize: 11.5 }}>
                      {lab.total} question{lab.total === 1 ? "" : "s"}
                    </span>
                  </div>
                </div>
                <div className="doc-actions">
                  {isStaff && (
                    <Link className="btn ghost sm" href="/admin/questions">
                      Manage in admin
                    </Link>
                  )}{" "}
                  <Link className="btn primary sm" href={`/portal/practice/session?lab=${lab.id}`}>
                    Launch →
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
