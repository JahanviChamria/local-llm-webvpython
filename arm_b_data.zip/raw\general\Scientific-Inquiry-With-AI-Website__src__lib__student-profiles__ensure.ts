import { eq } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { studentProfiles } from "@/lib/db/schema";
import { generateAlias, generateCode, hashCode } from "./codes";

// Minimal surface both the top-level `db` and a transaction handle satisfy, so
// callers can pass either (e.g. to bootstrap inside the same tx that inserts
// the user row).
type Executor = Pick<typeof db, "select" | "insert">;

/**
 * Idempotently ensure a student_profiles row exists for `userId`.
 *
 * Student accounts get a profile row the moment they're created so GPT
 * writebacks (setTopicMastery / merge*) have somewhere to land — those paths
 * only UPDATE, never INSERT, so a missing row silently swallows every write.
 *
 * Safe to call repeatedly: a fast existence check short-circuits, and the
 * INSERT uses onConflictDoNothing on the user-unique index to absorb races.
 * A fresh login code is generated and hashed (the plaintext is intentionally
 * discarded — faculty can issue a usable code later via regenerate-code).
 *
 * Returns true if a row was created by this call, false if one already existed.
 */
export async function ensureStudentProfile(
  userId: string,
  exec: Executor = db,
): Promise<boolean> {
  const existing = await exec
    .select({ id: studentProfiles.id })
    .from(studentProfiles)
    .where(eq(studentProfiles.userId, userId))
    .limit(1);
  if (existing.length > 0) return false;

  const codeHash = await hashCode(generateCode());

  // Alias collisions (32-bit space) are extremely unlikely but cheap to retry.
  for (let attempt = 0; attempt < 5; attempt++) {
    const alias = generateAlias();
    try {
      const inserted = await exec
        .insert(studentProfiles)
        .values({ userId, alias, codeHash })
        .onConflictDoNothing({ target: studentProfiles.userId })
        .returning({ id: studentProfiles.id });
      // Empty result == the user-unique conflict fired (row already existed).
      return inserted.length > 0;
    } catch (err) {
      const e = err as { code?: string; constraint?: string };
      if (e?.code === "23505" && e.constraint === "student_profiles_alias_uniq") {
        continue; // retry with a fresh alias
      }
      throw err;
    }
  }
  throw new Error("ensureStudentProfile: alias collision after 5 attempts");
}
