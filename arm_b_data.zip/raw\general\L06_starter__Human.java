import java.awt.Color;
import java.awt.event.*;

//A human controlled JavaPong paddle
public class Human extends Paddle{
   
   //Human Paddle attributes
   public static final double HUMAN_PADDLE_LENGTH = 75.0;
   public static final double HUMAN_PADDLE_SPEED = 6.0;
   public static final Color HUMAN_PADDLE_COLOR = Color.green;  
   
   //Key binds for if the Paddle should move up or down
   public static final int KEY_MOVE_UP = KeyEvent.VK_UP;
   public static final int KEY_MOVE_DOWN = KeyEvent.VK_DOWN;   
   
   //the count of times this paddle has successfully deflected the ball
   //resets when a point is scored by either paddle.
   protected int volleys;     
   



   //****************   CONSTRUCTORS  *************
   public Human(){
      this(HUMAN_PADDLE_LENGTH);
   }  

   public Human(double length){
      this(length, HUMAN_PADDLE_SPEED);
   }

   public Human(double length, double speed){
      this(length, speed, HUMAN_PADDLE_COLOR);
   }

   public Human(double length, double speed, Color color){
      super(length, speed, color);
      this.volleys = 0;
   }
   
   
   //called every game update (so 60 times a second) for each key being pressed on the keyboard
   //Returns one of three int values, telling the game, per the key being 
   //pressed, if the paddle should move up, down, or not move at all (neutral)
   //
   //Specifically, -1, 0, and 1 correspond to moving up, neutral, and down respectively
   public int keyReact(int keyPressed){
      if (keyPressed == KEY_MOVE_UP)
         return MOVE_UP;
      else if (keyPressed == KEY_MOVE_DOWN)
         return MOVE_DOWN; 
      else
         return 0;
   }
   
   
   
   //Called automatically whenver the ball collides with this paddle
   public void reactToVolley(){
      volleys++;
   }  
   
   
   //Called automatically whenever EITHER paddle (Human or CPU) scores a point.
   //argument indicates if it was the human who scored (true) or the CPU (false).
   public void reactToScore(boolean didHumanScore){
      if (didHumanScore)
         this.score++;
      volleys=0;
   }


   public int getVolleys(){
      return volleys;
   }       
   
   
   
   
   
   
   
}
