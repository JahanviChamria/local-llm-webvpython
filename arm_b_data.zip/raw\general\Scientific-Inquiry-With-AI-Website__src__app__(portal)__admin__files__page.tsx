import { redirect } from "next/navigation";
import { desc } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { files } from "@/lib/db/schema";
import { getCurrentUser } from "@/lib/auth/session";
import { AdminFilesClient } from "./client";

export const dynamic = "force-dynamic";

export default async function AdminFilesPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/admin/files");
  if (user.role !== "admin" && user.role !== "faculty") {
    return (
      <div className="col">
        <div className="screen-head">
          <div className="section-label">Restricted</div>
          <h1>Not available</h1>
        </div>
        <div className="callout orange">
          <strong>Faculty and admins only.</strong> Your account doesn&apos;t have access to files &amp; materials.
        </div>
      </div>
    );
  }

  const rows = await db.select().from(files).orderBy(desc(files.uploadedAt));
  return (
    <div className="col">
      <div className="screen-head">
        <div className="section-label">Admin</div>
        <h1>Files &amp; materials</h1>
        <p className="lead muted">
          Upload prelab documents, datasets, and resources. Public files appear to students in Prelab &amp; lab work;
          faculty-only files stay restricted.
        </p>
      </div>
      <AdminFilesClient initialFiles={rows} isAdmin={user.role === "admin"} />
    </div>
  );
}
