import { z } from "zod";

// PATCH's omitted -> preserve, explicit null/"" -> clear semantics depend on
// updateSchema being derived via createSchema.partial(). The outer ZodOptional
// that .partial() adds to every field short-circuits absent keys before the
// inner .transform() runs. Do NOT hand-roll an update schema by reusing these
// field defs in a fresh z.object({...}) — without .partial() wrapping, the
// ZodEffects on expectedAnswer becomes outermost and absent keys parse as
// transform(undefined) -> null, silently clearing the column on every PATCH.
const mcOptionSchema = z.object({
  id: z.string().trim().min(1).max(8),
  text: z.string().trim().min(1).max(2000),
});

export const createSchema = z.object({
  labName: z.string().trim().min(1).max(100),
  difficulty: z.enum(["easy", "medium", "hard"]),
  format: z
    .enum(["short_answer", "multiple_choice", "true_false", "calculation"])
    .default("short_answer"),
  role: z
    .enum(["canonical", "isomorph", "transfer", "scaffold", "extension"])
    .default("canonical"),
  prompt: z.string().trim().min(1).max(10_000),
  expectedAnswer: z
    .string()
    .trim()
    .max(50_000)
    .nullable()
    .optional()
    .transform((v) => (v == null || v === "" ? null : v)),
  // MC only: [{ id: "A", text: "..." }]. The cross-field rules (MC needs >=2 options
  // and a matching correctOption; TF needs correctOption True/False) live in the create
  // route, not here, so createSchema stays a plain ZodObject for updateSchema.partial().
  options: z.array(mcOptionSchema).max(12).nullable().optional(),
  correctOption: z
    .string()
    .trim()
    .max(8)
    .nullable()
    .optional()
    .transform((v) => (v == null || v === "" ? null : v)),
  // Optional attached figure: a public, image/* files.id. null clears it.
  figureFileId: z.string().uuid().nullable().optional(),
});

export const updateSchema = createSchema
  .partial()
  .refine((data) => Object.keys(data).length > 0, {
    message: "at least one field is required",
  });

export type CreateInput = z.infer<typeof createSchema>;
export type UpdateInput = z.infer<typeof updateSchema>;

export type QuestionFormat = "short_answer" | "multiple_choice" | "true_false" | "calculation";
export type McOption = z.infer<typeof mcOptionSchema>;

export class ChoiceValidationError extends Error {}

// Normalises + validates the choice-specific columns for a format, shared by the create
// and update routes. MC keeps its options + a matching correctOption; TF keeps a
// True/False correctOption; the text formats carry neither (any stale values are
// cleared). Throws ChoiceValidationError on bad input so both routes return one 400 shape.
export function resolveChoiceFields(
  format: QuestionFormat,
  options: McOption[] | null | undefined,
  correctOption: string | null | undefined,
): { options: McOption[] | null; correctOption: string | null } {
  if (format === "multiple_choice") {
    const opts = options ?? [];
    if (opts.length < 2) throw new ChoiceValidationError("multiple choice needs at least 2 options");
    const ids = opts.map((o) => o.id);
    if (new Set(ids).size !== ids.length) throw new ChoiceValidationError("option ids must be unique");
    if (!correctOption || !ids.includes(correctOption)) {
      throw new ChoiceValidationError("correct option must match one of the options");
    }
    return { options: opts, correctOption };
  }
  if (format === "true_false") {
    if (correctOption !== "True" && correctOption !== "False") {
      throw new ChoiceValidationError("true/false needs a correct answer");
    }
    return { options: null, correctOption };
  }
  return { options: null, correctOption: null };
}
