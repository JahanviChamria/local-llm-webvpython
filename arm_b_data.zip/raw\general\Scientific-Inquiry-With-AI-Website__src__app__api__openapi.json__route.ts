// GET /api/openapi.json — OpenAPI 3.1 spec for the Custom GPT Actions surface.
//
// What the operator pastes into GPT Builder's "Import from URL" field. Lists
// the six /api/actions/* endpoints + an OAuth2 authorizationCode security
// scheme pointing at our /oauth/authorize and /api/oauth/token endpoints.
//
// Schemas (request + response) are GENERATED from the same Zod definitions
// used by the impl functions in tools.ts/resources.ts. Single source of truth —
// adding a Zod field automatically appears in the OpenAPI spec, no
// hand-translation drift. operationIds are stable; renaming any breaks every
// already-registered GPT that imported this spec.

import { NextResponse } from "next/server";
import { zodToJsonSchema } from "zod-to-json-schema";
import { z } from "zod";
import { getBaseUrl } from "@/lib/site-url";
import {
  logStudySessionInput,
  recordConceptStruggleInput,
  submitSelfAssessmentInput,
  logStudySessionOutput,
  recordConceptStruggleOutput,
  submitSelfAssessmentOutput,
} from "@/lib/mcp/tools";
import {
  listPublicFilesOutput,
  downloadPublicFileOutput,
  publicFileListItemSchema,
} from "@/lib/files/public-actions";
import {
  setTopicMasteryInput,
  setTopicMasteryOutput,
  mergeProfileColumnInput,
  mergeProfileColumnOutput,
  getStudentProfileOutput,
} from "@/lib/student-profiles/actions";

export const runtime = "nodejs";

// Resource read endpoints don't take inputs and return a JSON document the
// resource emits as-is; advertise an open object for the response so the GPT
// can introspect arbitrary keys. (The resource impls return JSON-stringified
// objects inside the MCP envelope; the REST helper unwraps to JSON.)
const readResponseSchema = z.object({}).passthrough();

function emit<T extends z.ZodTypeAny>(schema: T) {
  return zodToJsonSchema(schema, { target: "openApi3" });
}

export function GET() {
  const base = getBaseUrl();

  const spec = {
    openapi: "3.1.0",
    info: {
      title: "Sci-AI Custom GPT Actions",
      version: "0.2.0",
      description:
        "Read-only access to a student's Sci-AI study state, and write-back of session summaries, struggle signals, and self-assessments. Authenticate via OAuth 2.0 authorization code; only the signed-in Sci-AI user is touched.",
    },
    servers: [{ url: base }],
    components: {
      securitySchemes: {
        oauth2: {
          type: "oauth2",
          flows: {
            authorizationCode: {
              authorizationUrl: `${base}/oauth/authorize`,
              tokenUrl: `${base}/api/oauth/token`,
              scopes: {
                "study:read": "Read study progress, current labs, retrieval-tool data",
                "study:write":
                  "Log study sessions, record struggle signals, submit self-assessments",
                "profile:read": "Read the student's profile (alias, role, current class)",
              },
            },
          },
        },
      },
      schemas: {
        LogStudySessionInput: emit(logStudySessionInput),
        LogStudySessionOutput: emit(logStudySessionOutput),
        RecordConceptStruggleInput: emit(recordConceptStruggleInput),
        RecordConceptStruggleOutput: emit(recordConceptStruggleOutput),
        SubmitSelfAssessmentInput: emit(submitSelfAssessmentInput),
        SubmitSelfAssessmentOutput: emit(submitSelfAssessmentOutput),
        ReadResponse: emit(readResponseSchema),
        PublicFileListItem: emit(publicFileListItemSchema),
        ListPublicFilesOutput: emit(listPublicFilesOutput),
        DownloadPublicFileOutput: emit(downloadPublicFileOutput),
        SetTopicMasteryInput: emit(setTopicMasteryInput),
        SetTopicMasteryOutput: emit(setTopicMasteryOutput),
        MergeProfileColumnInput: emit(mergeProfileColumnInput),
        MergeProfileColumnOutput: emit(mergeProfileColumnOutput),
        GetStudentProfileOutput: emit(getStudentProfileOutput),
      },
    },
    security: [{ oauth2: ["study:read", "study:write", "profile:read"] }],
    paths: {
      "/api/actions/profile": {
        get: {
          operationId: "getProfile",
          summary: "Get the signed-in student's Sci-AI profile",
          description:
            "Returns the student's alias, role, and current class enrollment so the GPT can ground its replies in who it's talking to.",
          security: [{ oauth2: ["profile:read"] }],
          responses: {
            "200": {
              description: "Profile resource",
              content: { "application/json": { schema: { $ref: "#/components/schemas/ReadResponse" } } },
            },
            "401": { description: "Bearer missing or invalid" },
          },
        },
      },
      "/api/actions/recent-progress": {
        get: {
          operationId: "getRecentProgress",
          summary: "Get the student's recent study progress",
          description:
            "Returns a short summary of recent SRS sessions, lab completions, and self-reported study activity. Use BEFORE logging anything so the GPT knows what's already known.",
          security: [{ oauth2: ["study:read"] }],
          responses: {
            "200": {
              description: "Recent progress",
              content: { "application/json": { schema: { $ref: "#/components/schemas/ReadResponse" } } },
            },
            "401": { description: "Bearer missing or invalid" },
          },
        },
      },
      "/api/actions/current-labs": {
        get: {
          operationId: "getCurrentLabs",
          summary: "Get the student's currently-assigned labs",
          description:
            "Returns the labs the student is enrolled in or has open. Use to pick a labId for logStudySession when the student doesn't say which lab they're working on.",
          security: [{ oauth2: ["study:read"] }],
          responses: {
            "200": {
              description: "Current labs",
              content: { "application/json": { schema: { $ref: "#/components/schemas/ReadResponse" } } },
            },
            "401": { description: "Bearer missing or invalid" },
          },
        },
      },
      "/api/actions/public-files": {
        get: {
          operationId: "listPublicFiles",
          summary: "List public files (course handouts, syllabi, etc.) the student can download",
          description:
            "Returns up to 50 most-recent public files (faculty-only excluded). Call before `downloadPublicFile` to get valid ids. If `truncated` is true, more exist server-side but only the 50 newest are returned — no search filter; send the student to `/portal/files` for older files.",
          security: [{ oauth2: ["study:read"] }],
          responses: {
            "200": {
              description: "Public file list",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ListPublicFilesOutput" },
                },
              },
            },
            "401": { description: "Bearer missing or invalid" },
            "403": { description: "Missing study:read scope" },
          },
        },
      },
      "/api/actions/public-files/{id}/download": {
        get: {
          operationId: "downloadPublicFile",
          summary: "Get a direct download URL for one public file by id",
          description:
            "Returns `{ url, filename, contentType, sizeBytes }`. `url` is a direct download link — mention `filename` in your reply (browser save name may differ). Call `listPublicFiles` first to get a valid id; do not guess UUIDs. 404 means not found/not ready/not public — do not retry.",
          security: [{ oauth2: ["study:read"] }],
          parameters: [
            {
              name: "id",
              in: "path",
              required: true,
              description: "UUID of the file (obtain from listPublicFiles)",
              schema: { type: "string", format: "uuid" },
            },
          ],
          responses: {
            "200": {
              description: "Download URL minted",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/DownloadPublicFileOutput" },
                },
              },
            },
            "400": {
              description: "Path id is not a valid UUID",
              content: {
                "application/json": {
                  example: { error: "id must be a valid uuid" },
                },
              },
            },
            "401": { description: "Bearer missing or invalid" },
            "403": { description: "Missing study:read scope" },
            "404": {
              description: "File not found or not public",
              content: {
                "application/json": {
                  example: { error: "file not found or not public" },
                },
              },
            },
          },
        },
      },
      "/api/actions/log-session": {
        post: {
          operationId: "logStudySession",
          summary: "Log a study session at the end of a conversation",
          description:
            "Call ONCE at the end of an educational conversation with a short summary of what was worked on. Do NOT retry on a 5xx — the server has a 15-second natural-idempotency window and will return the same summaryId for an identical body within that window (deduplicated: true).",
          security: [{ oauth2: ["study:write"] }],
          requestBody: {
            required: true,
            content: { "application/json": { schema: { $ref: "#/components/schemas/LogStudySessionInput" } } },
          },
          responses: {
            "200": {
              description: "Session logged",
              content: { "application/json": { schema: { $ref: "#/components/schemas/LogStudySessionOutput" } } },
            },
            "400": { description: "Invalid input or tool error" },
            "401": { description: "Bearer missing or invalid" },
            "403": { description: "Missing study:write scope" },
          },
        },
      },
      "/api/actions/record-struggle": {
        post: {
          operationId: "recordConceptStruggle",
          summary: "Record an observed struggle with a concept",
          description:
            "Log an instructor-dashboard signal that the student showed a specific kind of difficulty with a topic. Used for teacher visibility, not personalization. Natural-idempotency window applies (15s, same grant + topic + signal).",
          security: [{ oauth2: ["study:write"] }],
          requestBody: {
            required: true,
            content: { "application/json": { schema: { $ref: "#/components/schemas/RecordConceptStruggleInput" } } },
          },
          responses: {
            "200": {
              description: "Signal recorded",
              content: { "application/json": { schema: { $ref: "#/components/schemas/RecordConceptStruggleOutput" } } },
            },
            "400": { description: "Invalid input or tool error" },
            "401": { description: "Bearer missing or invalid" },
            "403": { description: "Missing study:write scope" },
          },
        },
      },
      "/api/actions/submit-self-assessment": {
        post: {
          operationId: "submitSelfAssessment",
          summary: "Submit the student's own assessment of how the session went",
          description:
            "Use when the student explicitly reflects on how they feel about what they studied (e.g. 'I think I get the chain rule now, like a 4/5'). Stored alongside session summaries but tagged as a self-report.",
          security: [{ oauth2: ["study:write"] }],
          requestBody: {
            required: true,
            content: { "application/json": { schema: { $ref: "#/components/schemas/SubmitSelfAssessmentInput" } } },
          },
          responses: {
            "200": {
              description: "Self-assessment submitted",
              content: { "application/json": { schema: { $ref: "#/components/schemas/SubmitSelfAssessmentOutput" } } },
            },
            "400": { description: "Invalid input or tool error" },
            "401": { description: "Bearer missing or invalid" },
            "403": { description: "Missing study:write scope" },
          },
        },
      },
      "/api/actions/topic-mastery": {
        post: {
          operationId: "setTopicMastery",
          summary: "Set the student's mastery level (0-5) for one lab",
          description:
            "Sets the signed-in student's mastery level (0-5) for one LAB. The `topic` field must be a lab id taken from the sciai://labs/current resource (the labs published to the student); the call is rejected if that lab is not currently published to them. Single-statement upsert; concurrent calls for different labs commit independently. Returns the full topicMastery map (keyed by lab id) so you can confirm without a separate read.",
          security: [{ oauth2: ["study:write"] }],
          requestBody: {
            required: true,
            content: { "application/json": { schema: { $ref: "#/components/schemas/SetTopicMasteryInput" } } },
          },
          responses: {
            "200": {
              description: "Mastery level updated",
              content: { "application/json": { schema: { $ref: "#/components/schemas/SetTopicMasteryOutput" } } },
            },
            "400": { description: "Invalid input (topic not a valid lab id, lab not published to the student, level out of range), or profile_not_initialized" },
            "401": { description: "Bearer missing or invalid" },
            "403": { description: "Missing study:write scope" },
          },
        },
      },
      "/api/actions/student-profile": {
        get: {
          operationId: "getStudentProfile",
          summary: "Read the signed-in student's full profile (all five JSONB columns)",
          description:
            "Returns current `topicMastery`, `mindMap`, `personalization`, `learningStyle`, `struggles` for the signed-in student. Call before any merge that needs to extend a nested array — top-level merge replaces whole keys.",
          security: [{ oauth2: ["study:read"] }],
          responses: {
            "200": {
              description: "Profile state",
              content: { "application/json": { schema: { $ref: "#/components/schemas/GetStudentProfileOutput" } } },
            },
            "400": { description: "profile_not_initialized (faculty must create the row first)" },
            "401": { description: "Bearer missing or invalid" },
            "403": { description: "Missing study:read scope" },
          },
        },
      },
      "/api/actions/mind-map": {
        post: {
          operationId: "setMindMap",
          summary: "Patch the student's mind-map column",
          description:
            "Shallow-merges the patch into `mindMap`. Top-level keys you include REPLACE existing values (call getStudentProfile first to extend nested arrays). Use for free-form concept-map notes; the page renders this column as JSON.",
          security: [{ oauth2: ["study:write"] }],
          requestBody: {
            required: true,
            content: { "application/json": { schema: { $ref: "#/components/schemas/MergeProfileColumnInput" } } },
          },
          responses: {
            "200": {
              description: "Mind map updated",
              content: { "application/json": { schema: { $ref: "#/components/schemas/MergeProfileColumnOutput" } } },
            },
            "400": { description: "Invalid input or profile_not_initialized" },
            "401": { description: "Bearer missing or invalid" },
            "403": { description: "Missing study:write scope" },
          },
        },
      },
      "/api/actions/personalization": {
        post: {
          operationId: "setPersonalization",
          summary: "Patch the student's personalization column",
          description:
            "Shallow-merges the patch into `personalization`. Use for student preferences (preferred-format, pace, interests). Top-level merge: keys you include replace existing values.",
          security: [{ oauth2: ["study:write"] }],
          requestBody: {
            required: true,
            content: { "application/json": { schema: { $ref: "#/components/schemas/MergeProfileColumnInput" } } },
          },
          responses: {
            "200": {
              description: "Personalization updated",
              content: { "application/json": { schema: { $ref: "#/components/schemas/MergeProfileColumnOutput" } } },
            },
            "400": { description: "Invalid input or profile_not_initialized" },
            "401": { description: "Bearer missing or invalid" },
            "403": { description: "Missing study:write scope" },
          },
        },
      },
      "/api/actions/learning-style": {
        post: {
          operationId: "setLearningStyle",
          summary: "Patch the student's learning-style column",
          description:
            "Shallow-merges the patch into `learningStyle`. Use for observed learning style (visual / kinesthetic / etc., notes). Top-level merge: keys you include replace existing values.",
          security: [{ oauth2: ["study:write"] }],
          requestBody: {
            required: true,
            content: { "application/json": { schema: { $ref: "#/components/schemas/MergeProfileColumnInput" } } },
          },
          responses: {
            "200": {
              description: "Learning style updated",
              content: { "application/json": { schema: { $ref: "#/components/schemas/MergeProfileColumnOutput" } } },
            },
            "400": { description: "Invalid input or profile_not_initialized" },
            "401": { description: "Bearer missing or invalid" },
            "403": { description: "Missing study:write scope" },
          },
        },
      },
      "/api/actions/struggles": {
        post: {
          operationId: "setStruggles",
          summary: "Patch the student's struggles column",
          description:
            "Shallow-merges the patch into `struggles` (the JSONB column shown on the public profile page). Separate from `recordConceptStruggle` (instructor-only signals). Top-level merge.",
          security: [{ oauth2: ["study:write"] }],
          requestBody: {
            required: true,
            content: { "application/json": { schema: { $ref: "#/components/schemas/MergeProfileColumnInput" } } },
          },
          responses: {
            "200": {
              description: "Struggles updated",
              content: { "application/json": { schema: { $ref: "#/components/schemas/MergeProfileColumnOutput" } } },
            },
            "400": { description: "Invalid input or profile_not_initialized" },
            "401": { description: "Bearer missing or invalid" },
            "403": { description: "Missing study:write scope" },
          },
        },
      },
    },
  };

  return NextResponse.json(spec, {
    headers: { "cache-control": "public, max-age=300" },
  });
}
