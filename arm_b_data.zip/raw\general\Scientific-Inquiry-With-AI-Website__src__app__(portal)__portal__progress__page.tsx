import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
import { getProgressData } from "@/lib/portal/progress";
import { getStudentClassesWithLabs } from "@/lib/portal/classes";
import { getClassLeaderboard } from "@/lib/portal/leaderboard";
import { Badge, Card, MasteryItem } from "@/components/portal/primitives";
import { Leaderboard } from "@/components/portal/leaderboard";
import { ActivityHeat } from "@/components/portal/widgets";

export const dynamic = "force-dynamic";

const infoCards: [string, string, string][] = [
  ["var(--ink)", "What counts", "Any one completed session across the three modules keeps your streak alive. Some days are heavier than others."],
  ["var(--green)", "Streak freeze", 'One automatic freeze per week, used silently: "Your streak was protected today." No guilt.'],
  ["var(--orange)", "Grading", "Engagement, effort, and involvement — not correctness. 5–10% of the course grade."],
];

function masteryState(pct: number): "mastered" | "review" | undefined {
  if (pct >= 80) return "mastered";
  if (pct < 50) return "review";
  return undefined;
}

function levelLabel(level: number): string {
  const word =
    level >= 5 ? "mastered" : level >= 4 ? "strong" : level >= 3 ? "improving" : level >= 1 ? "review" : "new";
  return `Level ${level} · ${word}`;
}

export default async function ProgressScreen() {
  const user = await getCurrentUser();
  // Retrieval progress is a student self-view; staff use the class-facing
  // instructor dashboard instead of tracking their own.
  if (user && (user.role === "admin" || user.role === "faculty")) {
    redirect("/portal/instructor");
  }
  const data = user ? await getProgressData(user.id) : null;

  // Weekly class leaderboards — only for students enrolled in a class.
  const classes = user ? await getStudentClassesWithLabs(user.id) : [];
  const boards = await Promise.all(
    classes.map(async (c) => ({
      id: c.id,
      name: c.name,
      entries: await getClassLeaderboard(c.id),
    })),
  );

  const stats: [string, string, string][] = data
    ? [
        [String(data.dayStreak), "day streak", "var(--green-mid)"],
        [`${data.recallEngagement}%`, "recall engagement", "var(--green-mid)"],
        [String(data.topicsMastered), "topics mastered", "var(--ink)"],
        [String(data.sessionsThisTerm), "sessions this term", "var(--ink)"],
      ]
    : [
        ["—", "day streak", "var(--green-mid)"],
        ["—", "recall engagement", "var(--green-mid)"],
        ["—", "topics mastered", "var(--ink)"],
        ["—", "sessions this term", "var(--ink)"],
      ];

  return (
    <div className="col">
      <div className="screen-head">
        <div className="section-label">Gamification</div>
        <h1>Retrieval progress</h1>
        <p className="lead muted">
          Mastery, badges, and streak — all earned through engagement, never performance. Updated after each session.
        </p>
      </div>

      {!user && (
        <div className="callout">
          <strong>Sign in to track your progress.</strong> Your streak, mastery, and badges build up as you complete
          retrieval sessions.
        </div>
      )}

      <div className="grid g4">
        {stats.map(([n, l, c], i) => (
          <div className="stat-card" key={i}>
            <div className="stat-label">{l}</div>
            <div className="stat-num" style={{ color: c }}>{n}</div>
          </div>
        ))}
      </div>

      {boards.length > 0 && (
        <div className="col" style={{ gap: 14 }}>
          {boards.map((b) => (
            <Leaderboard
              key={b.id}
              title={`Leaderboard · ${b.name}`}
              periodLabel="This week"
              entries={b.entries}
              highlightUserId={user?.id}
            />
          ))}
        </div>
      )}

      <div className="row" style={{ gap: 18, alignItems: "flex-start" }}>
        <Card className="grow" title="Mastery by topic" label="0–5 scale">
          {!data || data.mastery.length === 0 ? (
            <p className="muted" style={{ fontSize: 12.5 }}>
              {user
                ? "Complete a session to start building mastery across your labs."
                : "Sign in to see your mastery across labs."}
            </p>
          ) : (
            data.mastery.map((m) => (
              <MasteryItem
                key={m.labId}
                label={m.name}
                level={levelLabel(m.level)}
                pct={m.pct}
                state={masteryState(m.pct)}
              />
            ))
          )}
        </Card>

        <div className="col" style={{ width: 300, flex: "0 0 300px" }}>
          <Card title="Activity" label={`last ${5} weeks`}>
            <ActivityHeat data={data?.activity} />
          </Card>
          <Card title="Focus next" label="adaptive">
            {data && data.focusNext.length > 0 ? (
              <>
                <p className="muted" style={{ fontSize: 12.5, marginBottom: 9 }}>
                  Your queue will lean on these until they&apos;re solid:
                </p>
                <div className="row wrap" style={{ gap: 7 }}>
                  {data.focusNext.map((m) => (
                    <Badge key={m.labId} kind="progress">{m.name}</Badge>
                  ))}
                </div>
              </>
            ) : (
              <p className="muted" style={{ fontSize: 12.5, marginBottom: 9 }}>
                {data ? "Nothing flagged — your topics are holding steady." : "Sign in to get adaptive focus suggestions."}
              </p>
            )}
            <Link className="btn primary sm" href="/portal" style={{ marginTop: 13 }}>
              Open a lab module →
            </Link>
          </Card>
        </div>
      </div>

      <Card title="Badges" label="earned through engagement">
        <div className="badge-grid">
          {(data?.badges ?? []).map((b, i) => (
            <div key={i} className={"badge-tile " + (b.earned ? "earned" : "locked")}>
              <div className="bt-icon">{b.icon}</div>
              <div className="bt-name">{b.name}</div>
            </div>
          ))}
        </div>
      </Card>

      <div className="grid g3">
        {infoCards.map(([c, t, d], i) => (
          <div className="info-card" key={i}>
            <div className="ic-top" style={{ background: c }} />
            <div className="ic-title">{t}</div>
            <div className="ic-body">{d}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
