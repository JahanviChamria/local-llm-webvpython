import { and, eq, gte, sql } from "drizzle-orm";
import { db } from "@/lib/db/client";
import {
  labDocumentCompletions,
  labs,
  questions,
  simulationCompletions,
  srsCards,
  srsSessions,
  users,
} from "@/lib/db/schema";

export type ClassConcept = {
  labId: string;
  name: string;
  pct: number; // 0-100 class-average mastery
  hasData: boolean;
  label: "Strong" | "Mixed" | "Weak" | "No data";
};

export type InstructorFlag = {
  severity: "high" | "medium" | "positive";
  name: string;
  module: string;
  detail: string;
};

export type InstructorDashboard = {
  totalStudents: number;
  prelabDone: number; // students who marked ≥1 prelab done
  simDone: number; // students who completed ≥1 simulation
  recallEngagementPct: number; // % of students active in retrieval in the last 7 days
  concepts: ClassConcept[];
  flags: InstructorFlag[];
};

// Shared 0..1 card-strength expression (mirrors getLabMastery in srs/queue.ts).
const strengthExpr = sql<number>`coalesce(avg(
  least(1.0,
    (least(${srsCards.reps}, 5) / 5.0) * 0.6
    + (greatest(0.0, least(1.0, (${srsCards.ease} - 1.3) / 1.2))) * 0.4
  )
) filter (where ${srsCards.reps} > 0), 0)`;

function conceptLabel(pct: number, hasData: boolean): ClassConcept["label"] {
  if (!hasData) return "No data";
  if (pct >= 70) return "Strong";
  if (pct >= 40) return "Mixed";
  return "Weak";
}

export async function getInstructorDashboard(): Promise<InstructorDashboard> {
  const now = new Date();
  const weekAgo = new Date(now.getTime() - 7 * 86_400_000);

  const [
    studentRows,
    activeRows,
    docCompletionRows,
    simRows,
    conceptRows,
    sessionByUser,
    masteryByUserLab,
  ] = await Promise.all([
    db.select({ id: users.id, displayName: users.displayName, username: users.username })
      .from(users)
      .where(eq(users.role, "student")),
    // Students with a finished lab-scope session in the last 7 days.
    // Instructor analytics describe course-linked practice only.
    db.select({ n: sql<number>`count(distinct ${srsSessions.userId})` })
      .from(srsSessions)
      .innerJoin(users, eq(users.id, srsSessions.userId))
      .where(and(eq(users.role, "student"), eq(srsSessions.scope, "lab"), sql`${srsSessions.finishedAt} is not null`, gte(srsSessions.finishedAt, weekAgo))),
    db.select({ n: sql<number>`count(distinct ${labDocumentCompletions.userId})` })
      .from(labDocumentCompletions)
      .innerJoin(users, eq(users.id, labDocumentCompletions.userId))
      .where(eq(users.role, "student")),
    db.select({ n: sql<number>`count(distinct ${simulationCompletions.userId})` })
      .from(simulationCompletions)
      .innerJoin(users, eq(users.id, simulationCompletions.userId))
      .where(eq(users.role, "student")),
    // Class-average mastery per lab.
    db.select({
      labId: labs.id,
      name: labs.name,
      pct: strengthExpr,
      reviewed: sql<number>`count(${srsCards.id}) filter (where ${srsCards.reps} > 0)`,
    })
      .from(labs)
      .innerJoin(questions, eq(questions.labId, labs.id))
      .leftJoin(
        srsCards,
        and(eq(srsCards.questionId, questions.id), eq(srsCards.scope, "lab")),
      )
      .groupBy(labs.id, labs.name)
      .orderBy(labs.name),
    // Per-student session activity.
    db.select({
      userId: srsSessions.userId,
      finished: sql<number>`count(*) filter (where ${srsSessions.finishedAt} is not null)`,
      lastAt: sql<string | null>`max(${srsSessions.finishedAt})`,
    })
      .from(srsSessions)
      .where(eq(srsSessions.scope, "lab"))
      .groupBy(srsSessions.userId),
    // Per-student, per-lab mastery (for weakest-topic flags).
    db.select({
      userId: srsCards.userId,
      labId: labs.id,
      name: labs.name,
      pct: strengthExpr,
      reviewed: sql<number>`count(${srsCards.id}) filter (where ${srsCards.reps} > 0)`,
    })
      .from(srsCards)
      .innerJoin(questions, eq(questions.id, srsCards.questionId))
      .innerJoin(labs, eq(labs.id, questions.labId))
      .where(eq(srsCards.scope, "lab"))
      .groupBy(srsCards.userId, labs.id, labs.name),
  ]);

  const totalStudents = studentRows.length;
  const concepts: ClassConcept[] = conceptRows.map((r) => {
    const pct = Math.round(Number(r.pct) * 100);
    const hasData = Number(r.reviewed) > 0;
    return { labId: r.labId, name: r.name, pct, hasData, label: conceptLabel(pct, hasData) };
  });

  // Index per-student signals.
  const sessions = new Map(sessionByUser.map((r) => [r.userId, { finished: Number(r.finished), lastAt: r.lastAt ? new Date(r.lastAt) : null }]));
  const weakestLab = new Map<string, { name: string; pct: number }>();
  const masteredCount = new Map<string, number>();
  for (const r of masteryByUserLab) {
    if (Number(r.reviewed) === 0) continue;
    const pct = Math.round(Number(r.pct) * 100);
    const cur = weakestLab.get(r.userId);
    if (!cur || pct < cur.pct) weakestLab.set(r.userId, { name: r.name, pct });
    if (pct >= 80) masteredCount.set(r.userId, (masteredCount.get(r.userId) ?? 0) + 1);
  }
  // Build one prioritized flag per student.
  const flags: InstructorFlag[] = [];
  for (const s of studentRows) {
    const name = s.displayName?.trim() || s.username;
    const sess = sessions.get(s.id);
    const finished = sess?.finished ?? 0;
    const lastAt = sess?.lastAt ?? null;
    const weak = weakestLab.get(s.id);
    const mastered = masteredCount.get(s.id) ?? 0;

    if (finished === 0) {
      flags.push({ severity: "high", name, module: "Recall", detail: "Hasn't started retrieval practice yet — no sessions on record." });
    } else if (lastAt && lastAt < weekAgo) {
      const days = Math.floor((now.getTime() - lastAt.getTime()) / 86_400_000);
      flags.push({ severity: "medium", name, module: "Engagement", detail: `No practice in ${days} days. Worth a nudge before the next lab.` });
    } else if (weak && weak.pct < 40) {
      flags.push({ severity: "high", name, module: "Recall", detail: `Weakest on ${weak.name} (${weak.pct}%). Suggest a focused session on this topic.` });
    } else if (mastered >= 2) {
      flags.push({ severity: "positive", name, module: "All modules", detail: `Strong across ${mastered} topics and practicing consistently. Positive flag.` });
    }
  }

  // Negatives first (high, then medium), positives last; cap the list.
  const order = { high: 0, medium: 1, positive: 2 } as const;
  flags.sort((a, b) => order[a.severity] - order[b.severity]);

  return {
    totalStudents,
    prelabDone: Number(docCompletionRows[0]?.n ?? 0),
    simDone: Number(simRows[0]?.n ?? 0),
    recallEngagementPct: totalStudents === 0 ? 0 : Math.round((Number(activeRows[0]?.n ?? 0) / totalStudents) * 100),
    concepts,
    flags: flags.slice(0, 6),
  };
}
