JavaScript 3.2

// Gyroscope sitting on a pedestal

// The analysis is in terms of Lagrangian mechanics.
// The Lagrangian variables are polar angle theta,
// azimuthal angle phi, and spin angle psi.

scene.width = 800
scene.height = 600
scene.range = 1.2
scene.title = "A precessing, nutating gyroscope"

let Lshaft = 1 // length of gyroscope shaft
let r = Lshaft/2 // distance from support to center of mass
let Rshaft = 0.03 // radius of gyroscope shaft
let M = 1 // mass of gyroscope (massless shaft)
let Rrotor = 0.4 // radius of gyroscope rotor
let Drotor = 0.1 // thickness of gyroscope rotor
let I3 = 0.5*M*Rrotor*Rrotor // moment of inertia of gyroscope about its own axis
let I1 = M*r*r + .5*I3 // moment of inertia about a line through the support, perpendicular to the axis
let hpedestal = Lshaft // height of pedestal
let wpedestal = 0.1 // width of pedestal
let tbase = 0.05 // thickness of base
let wbase = 3*wpedestal // width of base
let g = 9.8
let Fgrav = vec(0,-M*g,0)
let top = vec(0,0,0) // top of pedestal

let shaft = cylinder({length:Lshaft, size:vec(Lshaft,2*Rshaft,2*Rshaft), color:color.orange})
let rotor = cylinder({pos:vec(Lshaft/2-Drotor/2,0,0), 
                 size:vec(Drotor,2*Rrotor,2*Rrotor), color:color.gray(0.9)})
let base = sphere({color:shaft.color, size:2*Rshaft*vec(1,1,1)})
let end = sphere({pos:vec(Lshaft,0,0), color:shaft.color, size:2*Rshaft*vec(1,1,1)})
let gyro = compound([shaft, rotor, base, end])
let gyro_center = gyro.pos
gyro.texture = textures.metal
let tip = sphere({pos:shaft.axis, size:Rshaft*vec(1,1,1),  make_trail:true, retain:250})
tip.trail_color = color.green
tip.trail_radius = 0.15*Rshaft

let pedestal = box({pos:top-vec(0,hpedestal/2+Rshaft/2,0), 
               size:vec(wpedestal, hpedestal-Rshaft, wpedestal), texture:textures.wood})
let pedestal_base = box({pos:top-vec(0,hpedestal+tbase/2,0), 
                    size:vec(wbase,tbase,wbase), texture:textures.wood})

let theta = 0
let thetadot = 0
let psi = 0
let psidot = 0
let phi = 0
let phidot = 0
let pureprecession = false

function reset() {
    theta = 0.3*pi // initial polar angle of shaft (from vertical)
    thetadot = 0 // initial rate of change of polar angle
    psi = 0 // initial spin angle
    psidot = 30 // initial rate of change of spin angle (spin ang. velocity)
    phi = -pi/2 // initial azimuthal angle
    phidot = 0 // initial rate of change of azimuthal angle
    if (pureprecession) { // Set to True if you want pure precession, without nutation
        let a = (1-I3/I1)*sin(theta)*cos(theta)
        let b = -(I3/I1)*psidot*sin(theta)
        let c = M*g*r*sin(theta)/I1
        phidot = (-b+sqrt(b*b-4*a*c))/(2*a)
    }
    gyro.axis = vec(sin(theta)*sin(phi),cos(theta),sin(theta)*cos(phi))
    let A = norm(gyro.axis)
    gyro.pos = 0.5*Lshaft*A
    tip.pos = Lshaft*A
    tip.clear_trail()
}

reset()
await scene.waitfor('textures')

let dt = 0.0001
let t = 0
let Nsteps = 20 // number of calculational steps between graphics updates

while (true) {
    await rate(200)
    for (let step=0; step<Nsteps; step++) { // multiple calculation steps for accuracy
        // Calculate accelerations of the Lagrangian coordinates:
        let atheta = sin(theta)*cos(theta)*phidot*phidot+( M*g*r*sin(theta)-I3*(psidot+phidot*cos(theta))*phidot*sin(theta))/I1
        let aphi = (I3/I1)*(psidot+phidot*cos(theta))*thetadot/sin(theta)-2*cos(theta)*thetadot*phidot/sin(theta)
        let apsi = phidot*thetadot*sin(theta)-aphi*cos(theta)
        // Update velocities of the Lagrangian coordinates:
        thetadot += atheta*dt
        phidot += aphi*dt
        psidot += apsi*dt
        // Update Lagrangian coordinates:
        theta += thetadot*dt
        phi += phidot*dt
        psi += psidot*dt
    }

    gyro.axis = vec(sin(theta)*sin(phi),cos(theta),sin(theta)*cos(phi))
    // Display approximate rotation of rotor and shaft:
    gyro.rotate({angle:psidot*dt*Nsteps})
    let A = norm(gyro.axis)
    gyro.pos = 0.5*Lshaft*A
    tip.pos = Lshaft*A
    t = t+dt*Nsteps
}