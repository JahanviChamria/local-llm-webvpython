//Test your Warmup and SpeedReadingTrainer implementations here!
public class Lab10Client {
 

     public static void main(String[] args){

          testReverseBottomElements();
          testInsertAllAtIndex();
          testSRT();

     }
     

     public static void testReverseBottomElements(){
         //*****  2.1 Tests  *****
       
         System.out.println("\n\n*** Reverse Bottom Elements ***");
         int count = 0;

         LabStack<Integer> s = new LabStack<Integer>();
         s.push(7);
         s.push(8);
         s.push(1);
         s.push(3);
         s.push(19);
         s.push(4);
         s.push(12);
         count = 4;
         System.out.println("Stack before:\n\t" + s);
         System.out.print("after reversing bottom " + count + ":\n\t" );
         Lab10Warmup.reverseBottomElements(s, count);
         System.out.println(s + "\n");
         s = new LabStack<Integer>();

         s.push(9);
         s.push(0);
         s.push(1);
         s.push(7);
         count = -1;                        //invalid count provided
         System.out.println("Stack before:\n\t" + s);
         System.out.print("after reversing bottom " + count + ":\n\t" );
         Lab10Warmup.reverseBottomElements(s, count);
         System.out.println(s + "\n");
         s = new LabStack<Integer>();

         s.push(6);
         s.push(5);
         s.push(2);
         count = 4;                         //invalid count provided
         System.out.println("Stack before:\n\t" + s);
         System.out.print("after reversing bottom " + count + ":\n\t" );
         Lab10Warmup.reverseBottomElements(s, count);
         System.out.println(s + "\n");
         s = new LabStack<Integer>();

         s.push(10);
         s.push(6);
         s.push(1);
         s.push(0);
         s.push(11);
         s.push(42);
         s.push(52);
         count = 5;
         System.out.println("Stack before:\n\t" + s);
         System.out.print("after reversing bottom " + count + ":\n\t" );
         Lab10Warmup.reverseBottomElements(s, count);
         System.out.println(s + "\n");
         s = new LabStack<Integer>();

         s.push(5);
         s.push(8);
         s.push(9);
         count = 3;
         System.out.println("Stack before:\n\t" + s);
         System.out.print("after reversing bottom " + count + ":\n\t" );
         Lab10Warmup.reverseBottomElements(s, count);
         System.out.println(s + "\n");
         s = new LabStack<Integer>();

     }
     

     
     public static void testInsertAllAtIndex(){
         //*****  2.2 Tests  *****

          System.out.println("\n\n*** Insert All at Index ***");
          int idx = 0;

          LabQueue<String> q1 = new LabQueue<String>();
          q1.enqueue("a");
          q1.enqueue("b");
          q1.enqueue("c");
          q1.enqueue("d");
          q1.enqueue("e");
          LabQueue<String> q2 = new LabQueue<String>();
          q2.enqueue("x");
          q2.enqueue("y");
          q2.enqueue("z");

          idx = 3;
          System.out.println("Queues before:");
          System.out.println("\tq1 = " + q1);
          System.out.println("\tq2 = " + q2);
          System.out.println("after inserting at index: " + idx);
          Lab10Warmup.insertAllAtIndex(q1, q2, idx);
          System.out.println("\tq1 = " + q1);
          System.out.println("\tq2 = " + q2 + "\n");

          q1 = new LabQueue<String>();
          q1.enqueue("a");
          q1.enqueue("b");
          q1.enqueue("c");
          q2 = new LabQueue<String>();
          q2.enqueue("x");
          q2.enqueue("y");
          q2.enqueue("z");

          idx = -1;                   //invalid index
          System.out.println("Queues before:");
          System.out.println("\tq1 = " + q1);
          System.out.println("\tq2 = " + q2);
          System.out.println("after inserting at index: " + idx);
          Lab10Warmup.insertAllAtIndex(q1, q2, idx);
          System.out.println("\tq1 = " + q1);
          System.out.println("\tq2 = " + q2 + "\n");

          q1 = new LabQueue<String>();
          q1.enqueue("p");
          q1.enqueue("q");
          q1.enqueue("r");
          q1.enqueue("s");
          q1.enqueue("t");
          q2 = new LabQueue<String>();
          q2.enqueue("1");
          q2.enqueue("2");
          q2.enqueue("3");

          idx = 6;                      //invalid index
          System.out.println("Queues before:");
          System.out.println("\tq1 = " + q1);
          System.out.println("\tq2 = " + q2);
          System.out.println("after inserting at index: " + idx);
          Lab10Warmup.insertAllAtIndex(q1, q2, idx);
          System.out.println("\tq1 = " + q1);
          System.out.println("\tq2 = " + q2 + "\n");

          q1 = new LabQueue<String>();
          q1.enqueue("cat");
          q2 = new LabQueue<String>();
          q2.enqueue("mat");
          q2.enqueue("rat");
          q2.enqueue("dog");

          idx = 1;
          System.out.println("Queues before:");
          System.out.println("\tq1 = " + q1);
          System.out.println("\tq2 = " + q2);
          System.out.println("after inserting at index: " + idx);
          Lab10Warmup.insertAllAtIndex(q1, q2, idx);
          System.out.println("\tq1 = " + q1);
          System.out.println("\tq2 = " + q2 + "\n");

          q1 = new LabQueue<String>();
          q1.enqueue("a");
          q1.enqueue("b");
          q1.enqueue("c");
          q1.enqueue("d");
          q1.enqueue("e");
          q1.enqueue("f");
          q1.enqueue("g");
          q2 = new LabQueue<String>();
          q2.enqueue("10");
          q2.enqueue("11");
          q2.enqueue("12");

          idx = 0;
          System.out.println("Queues before:");
          System.out.println("\tq1 = " + q1);
          System.out.println("\tq2 = " + q2);
          System.out.println("after inserting at index: " + idx);
          Lab10Warmup.insertAllAtIndex(q1, q2, idx);
          System.out.println("\tq1 = " + q1);
          System.out.println("\tq2 = " + q2 + "\n");
     }



     public static void testSRT(){          
          //Arguments are source text file to read, and how many
          //"words per minute" to display when in "autorun" mode (press spacebar)     
          SpeedReadingTrainer srt = new SpeedReadingTrainer("text_files/feste.txt", 120);
          srt.launchTrainer();
     }
     
}

