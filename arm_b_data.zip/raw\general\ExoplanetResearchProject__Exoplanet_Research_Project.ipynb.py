from urllib.request import urlretrieve
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

import warnings
warnings.filterwarnings('ignore')

import torch
import torch.nn as nn
import torch.nn.functional as F

from sklearn.neural_network import MLPClassifier

from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.metrics import mean_squared_error, precision_score, confusion_matrix, accuracy_score
from sklearn.cluster import KMeans
from sklearn import  metrics
from sklearn import tree
from sklearn.model_selection import train_test_split
from imblearn.over_sampling import SMOTE
from scipy.signal import savgol_filter
from sklearn.metrics import classification_report
from sklearn.metrics import accuracy_score,ConfusionMatrixDisplay,precision_score,recall_score,f1_score
from sklearn.preprocessing import MinMaxScaler, StandardScaler, RobustScaler, normalize
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split, GridSearchCV

!pip install keras
!pip install tensorflow
from tensorflow.keras import Sequential
import tensorflow as tf
import keras
from keras.models import Sequential
from keras.layers import Activation, Dropout, Flatten, Dense
from keras import optimizers
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.optimizers import Adam, SGD
from keras.layers import Dense, Dropout, Activation, Flatten
from keras.layers import Conv1D, Conv2D, MaxPooling2D, BatchNormalization, MaxPooling1D
from keras.losses import categorical_crossentropy
from keras.regularizers import l2
from keras.callbacks import EarlyStopping, ModelCheckpoint
from keras.models import load_model
from keras import backend as K
from keras import activations, initializers, regularizers, constraints, metrics
from keras.datasets import cifar10
from keras.preprocessing.image import ImageDataGenerator
from keras.models import Sequential, Model
from keras.layers import (Dense, Dropout, Activation, Flatten, Reshape, Layer,
                          BatchNormalization, LocallyConnected2D,
                          ZeroPadding2D, Conv2D, MaxPooling2D, Conv2DTranspose,
                          GaussianNoise, UpSampling2D, Input)
from keras.layers import Lambda

pd.set_option('display.max_columns', None)

import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)

df2=pd.read_csv("https://raw.githubusercontent.com/JahanviChamria/Dataset/main/cumulative_2023.10.01_06.22.52.csv")
df=pd.read_csv("https://raw.githubusercontent.com/JahanviChamria/NASADataset/main/cumulative_2023.10.22_03.05.36.csv")

print(df)

df.info()

df = df.rename(columns={'kepid':'KepID',
'kepoi_name':'KOIName',
'kepler_name':'KeplerName',
'koi_disposition':'ExoplanetArchiveDisposition',
'koi_pdisposition':'DispositionUsingKeplerData',
'koi_score':'DispositionScore',
'koi_fpflag_nt':'NotTransit-LikeFalsePositiveFlag',
'koi_fpflag_ss':'koi_fpflag_ss',
'koi_fpflag_co':'CentroidOffsetFalsePositiveFlag',
'koi_fpflag_ec':'EphemerisMatchIndicatesContaminationFalsePositiveFlag',
'koi_period':'OrbitalPeriod[days',
'koi_period_err1':'OrbitalPeriodUpperUnc.[days',
'koi_period_err2':'OrbitalPeriodLowerUnc.[days',
'koi_time0bk':'TransitEpoch[BKJD',
'koi_time0bk_err1':'TransitEpochUpperUnc.[BKJD',
'koi_time0bk_err2':'TransitEpochLowerUnc.[BKJD',
'koi_impact':'ImpactParamete',
'koi_impact_err1':'ImpactParameterUpperUnc',
'koi_impact_err2':'ImpactParameterLowerUnc',
'koi_duration':'TransitDuration[hrs',
'koi_duration_err1':'TransitDurationUpperUnc.[hrs',
'koi_duration_err2':'TransitDurationLowerUnc.[hrs',
'koi_depth':'TransitDepth[ppm',
'koi_depth_err1':'TransitDepthUpperUnc.[ppm',
'koi_depth_err2':'TransitDepthLowerUnc.[ppm',
'koi_prad':'PlanetaryRadius[Earthradii',
'koi_prad_err1':'PlanetaryRadiusUpperUnc.[Earthradii',
'koi_prad_err2':'PlanetaryRadiusLowerUnc.[Earthradii',
'koi_teq':'EquilibriumTemperature[K',
'koi_teq_err1':'EquilibriumTemperatureUpperUnc.[K',
'koi_teq_err2':'EquilibriumTemperatureLowerUnc.[K',
'koi_insol':'InsolationFlux[Earthflux',
'koi_insol_err1':'InsolationFluxUpperUnc.[Earthflux',
'koi_insol_err2':'InsolationFluxLowerUnc.[Earthflux',
'koi_model_snr':'TransitSignal-to-Nois',
'koi_tce_plnt_num':'TCEPlanetNumbe',
'koi_tce_delivname':'TCEDeliver',
'koi_steff':'StellarEffectiveTemperature[K',
'koi_steff_err1':'StellarEffectiveTemperatureUpperUnc.[K',
'koi_steff_err2':'StellarEffectiveTemperatureLowerUnc.[K',
'koi_slogg':'StellarSurfaceGravity[log10(cm/s**2)',
'koi_slogg_err1':'StellarSurfaceGravityUpperUnc.[log10(cm/s**2)',
'koi_slogg_err2':'StellarSurfaceGravityLowerUnc.[log10(cm/s**2)',
'koi_srad':'StellarRadius[Solarradii',
'koi_srad_err1':'StellarRadiusUpperUnc.[Solarradii',
'koi_srad_err2':'StellarRadiusLowerUnc.[Solarradii',
'ra':'RA[decimaldegrees',
'dec':'Dec[decimaldegrees',
'koi_kepmag':'Kepler-band[mag]'
})
df.head()

df.drop(columns=['KeplerName','KOIName','EquilibriumTemperatureUpperUnc.[K',
                 'ExoplanetArchiveDisposition','DispositionUsingKeplerData',
                 'NotTransit-LikeFalsePositiveFlag','koi_fpflag_ss','CentroidOffsetFalsePositiveFlag',
                 'EphemerisMatchIndicatesContaminationFalsePositiveFlag','TCEDeliver',
                 'EquilibriumTemperatureLowerUnc.[K'])

df['ExoplanetConfirmed'] = df['ExoplanetArchiveDisposition'].apply(lambda x: 1 if x == 'CONFIRMED' else 1 if x == 'CANDIDATE' else 0 )

df.head()

df.shape

df.drop(columns=['KeplerName','KOIName','EquilibriumTemperatureUpperUnc.[K',
                 'ExoplanetArchiveDisposition','DispositionUsingKeplerData',
                 'NotTransit-LikeFalsePositiveFlag','koi_fpflag_ss','CentroidOffsetFalsePositiveFlag',
                 'EphemerisMatchIndicatesContaminationFalsePositiveFlag','TCEDeliver',
                 'EquilibriumTemperatureLowerUnc.[K'], inplace=True)

df.shape

df.isna().any()

df.dropna(inplace=True)

df.shape

df.head()

def clean_dataset(df):
    assert isinstance(df, pd.DataFrame), "df needs to be a pd.DataFrame"
    df.dropna(inplace=True)
    indices_to_keep = ~df.isin([np.nan, np.inf, -np.inf]).any(1)
    return df[indices_to_keep].astype(np.float64)

clean_dataset(df.drop(columns=['KepID']))

df.head()

# Evaluation function

def evaluation(y_true, y_pred):

# Print Accuracy, Recall, F1 Score, and Precision metrics.
    print('Evaluation Metrics:')
    accuracy=accuracy_score(y_test, y_pred)
    precision=precision_score(y_test, y_pred)
    print('Accuracy: ' + str(accuracy_score(y_test, y_pred)))
    print('Recall: ' + str(recall_score(y_test, y_pred)))
    print('F1 Score: ' + str(f1_score(y_test, y_pred)))
    print('Precision: ' + str(precision_score(y_test, y_pred)))

# Print Confusion Matrix
    print('\nConfusion Matrix:')
    print(' TN,  FP, FN, TP')
    print(confusion_matrix(y_true, y_pred).ravel())
    cm=confusion_matrix(y_true,y_pred)
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=True)

    return accuracy, precision

# Function Prints best parameters for GridSearchCV
def print_results(results):
    print('Best Parameters: {}\n'.format(results.best_params_))

features = df.drop(columns=['ExoplanetConfirmed','KepID'])
target = df.ExoplanetConfirmed

X_train, X_test, y_train, y_test = train_test_split(features, target, random_state=1, test_size=.60)

# Checking if train test split ran correclty
for dataset in [y_train, y_test]:
    print(round(len(dataset)/len(target), 2))

# Logistic Regression Model
lr = LogisticRegression(C=100, max_iter=200, class_weight='balanced')

# Fitting Model to the train set
lr.fit(X_train, y_train)

# Predicting on the test set
y_pred = lr.predict(X_test)

# Evaluating model
alr,plr=evaluation(y_test, y_pred)

knn = KNeighborsClassifier(leaf_size=8, metric='manhattan',weights='uniform')

# Fitting Model to the train set
knn.fit(X_train, y_train)

# Predicting on the test set
y_pred = knn.predict(X_test)

# Evaluating model
ak,pk=evaluation(y_test, y_pred)

tree = DecisionTreeClassifier()

# Fitting Model to the train set
tree.fit(X_train, y_train)

# Predicting on the test set
y_pred = tree.predict(X_test)

# Evaluating model
at,pt=evaluation(y_test, y_pred)

# Instantiate model
forest1 = RandomForestClassifier(n_estimators=100, criterion='gini')
# Fitting Model to the train set
forest1.fit(X_train, y_train)
# Predicting on the test set
y_pred = forest1.predict(X_test)

# Evaluating model
af,pf=evaluation(y_test, y_pred)

print('Accuracy: ' + str(af*100))
print('Precision: ' + str(pf*100))

acc=[alr,ak,at,af]
pr=[plr,pk,pt,pf]
categories = ['Logistic Regression', 'KNN', 'Tree', 'Forest']
plt.bar(categories, acc, color='skyblue')
plt.xlabel('Models')
plt.ylabel('Accuracy')
plt.title('Accuracy of Different Models')
plt.ylim(0, 1)  # Set the y-axis limits (0 to 1 for accuracy)
plt.show()

acc=[alr,ak,at,af]
pr=[plr,pk,pt,pf]
categories = ['Logistic Regression', 'KNN', 'Tree', 'Forest']
plt.bar(categories, pr)
plt.xlabel('Models')
plt.ylabel('Precision')
plt.title('Precision of Different Models')
plt.ylim(0, 1)  # Set the y-axis limits (0 to 1 for accuracy)
plt.show()

numpl=[7803, 4068]
categories=['Total number of planets','Exoplanets confirmed']
plt.bar(categories, numpl)
plt.ylabel('Number of Exoplanets')
plt.show()

df2.info()

df2 = df2.rename(columns={'kepid':'KepID',
'koi_score':'DispositionScore',
'koi_prad':'PlanetaryRadius[Earthradii',
'koi_teq':'EquilibriumTemperature[K',
'koi_insol':'InsolationFlux[Earthflux',
'koi_steff':'StellarEffectiveTemperature[K',
'koi_slogg':'StellarSurfaceGravity[log10(cm/s**2)',
})

cn=df2.columns.values.tolist()

print(cn)

df2=df2[['KepID','DispositionScore','PlanetaryRadius[Earthradii','EquilibriumTemperature[K','koi_sma','InsolationFlux[Earthflux','StellarEffectiveTemperature[K','StellarSurfaceGravity[log10(cm/s**2)','koi_srad','koi_eccen','koi_incl','koi_dor']]

def habitability_score(exoplanet):
    import math
    score = 0

    # Planetary radius
    min_planetary_radius = 0.8  #Minimum radius as a factor of Earth's radius
    max_planetary_radius = 1.5  #Maximum radius as a factor of Earth's radius
    #Assuming 'PlanetaryRadius[Earthradii]' is the column with radius data relative to Earth's radius
    if min_planetary_radius <= exoplanet['PlanetaryRadius[Earthradii'] <= max_planetary_radius:
      score += 1

    # Orbit sem-major axis
    #helper function to check if the exoplanet is in the habitable zone depending on the host star type
    def is_in_habitable_zone(stellar_temp, semi_major_axis):
        if 0.1 <= semi_major_axis <= 5:
             return 1
        else:
             return 0

       #checking if exoplanet is in the habitable zone
    if is_in_habitable_zone(exoplanet['StellarEffectiveTemperature[K'], exoplanet['koi_sma']):
        score += 1

    # Stellar surface gravity
    if 4.0 <= exoplanet['StellarSurfaceGravity[log10(cm/s**2)'] <= 4.9:
        score += 1

    # Equilibrium temperature
    if 273 <= exoplanet['EquilibriumTemperature[K'] <= 373:
        score += 1

    #Type of planet (Planetary density)
    if exoplanet['PlanetaryRadius[Earthradii']<=1.5:
      score +=1
    elif 1.5<exoplanet['PlanetaryRadius[Earthradii']<=2.5:
      score +=0.5

    # Radiative flux/insolation/HZ
    fmax=(5.670374419*math.pow(10,-8)*math.pow(exoplanet['StellarEffectiveTemperature[K'],4))/(4*math.pi*(exoplanet['koi_dor']*exoplanet['koi_srad']))
    if 67 <= exoplanet['InsolationFlux[Earthflux'] <= fmax:
        score += 1

    #Eccentricity
    if exoplanet['koi_eccen'] <= 0.2:
        score += 1

    # Obliquity
    if (90-exoplanet['koi_incl']) <= 45:
        score += 1

    return score

# Filtering the dataset for confirmed exoplanets only
confirmed_exoplanets = df[df['ExoplanetConfirmed'] == 1]
ce=confirmed_exoplanets['KepID']
print(ce)

data =[]
df3 = pd.DataFrame(data, index=[], columns=['KepID','DispositionScore','PlanetaryRadius[Earthradii','EquilibriumTemperature[K','koi_sma','InsolationFlux[Earthflux','StellarEffectiveTemperature[K','StellarSurfaceGravity[log10(cm/s**2)','koi_srad','koi_eccen','koi_incl','koi_dor'])

df3 = df2[df2['KepID'].isin(ce)]

# Reset the index of df3
df3.reset_index(drop=True, inplace=True)

# Now df3 contains the rows from df2 with matching KepID values for confirmed exoplanets
print(df3)

df3.dropna(inplace=True)

df3['HabitabilityScore'] = df3.apply(habitability_score, axis=1)

habitability_scores = df3['HabitabilityScore']
count_per_score = habitability_scores.value_counts().sort_index()

# Create a bar chart
plt.bar(count_per_score.index, count_per_score.values, width=0.35)

# Label the axes and add a title
plt.xlabel('Habitability Score')
plt.ylabel('Number of Exoplanets')
plt.title('Number of Exoplanets for Each Habitability Score')

# Show the plot
plt.show()

df3['HabitabilityScore']

#checking the habitable radius and counting
radius_count = (df3['PlanetaryRadius[Earthradii'].between(0.8, 1.5)).value_counts()

#renaming index for clarity
radius_count.index = ['Outside Habitable Range', 'Within Habitable Range']

#plotting
radius_count.plot(kind='bar', color='indianred', title='Distribution of Exoplanets by Planetary Radius')
plt.xlabel('Planetary Radius Category')
plt.ylabel('Number of Exoplanets')
plt.show()

#counting the number of exoplanets in and out of the habitable zone based on semi-major axis
in_habitable_zone = 0
out_of_habitable_zone = 0

for index, exoplanet in df3.iterrows():
    if 0.1 <= exoplanet['koi_sma'] <= 5:
        in_habitable_zone += 1
    else:
        out_of_habitable_zone += 1

#creating a series for plotting
sma_count = pd.Series([in_habitable_zone, out_of_habitable_zone], index=['Within Habitable Zone', 'Outside Habitable Zone'])

#plotting
sma_count.plot(kind='bar', color='lightcoral', title='Distribution of Exoplanets by Orbit Semi-Major Axis')
plt.xlabel('Orbit Semi-Major Axis Category')
plt.ylabel('Number of Exoplanets')
plt.show()

#checking the stellar surface gravity and counting
radius_count = (df3['StellarSurfaceGravity[log10(cm/s**2)'].between(4.0, 4.9)).value_counts()

#renaming index for clarity
radius_count.index = ['Outside Habitable Range', 'Within Habitable Range']

#plotting
radius_count.plot(kind='bar', color='lightpink', title='Distribution of Exoplanets by Stellar Surface Gravity')
plt.xlabel('Stellar Surface Gravity Category')
plt.ylabel('Number of Exoplanets')
plt.show()

#checking the equilibrium and counting
radius_count = (df3['EquilibriumTemperature[K'].between(273, 373)).value_counts()

#renaming index for clarity
radius_count.index = ['Outside Habitable Range', 'Within Habitable Range']

#plotting
radius_count.plot(kind='bar', color='thistle', title='Distribution of Exoplanets by Equilibrium Temp')
plt.xlabel('Equilibrium Temp Category')
plt.ylabel('Number of Exoplanets')
plt.show()

#counting the number of exoplanets in each category
within_full_range = (df3['PlanetaryRadius[Earthradii'] <= 1.5).sum()
within_partial_range = ((df3['PlanetaryRadius[Earthradii'] > 1.5) & (df3['PlanetaryRadius[Earthradii'] <= 2.5)).sum()
outside_range = (df3['PlanetaryRadius[Earthradii'] > 2.5).sum()

#creating a series for plotting
type_count = pd.Series([within_full_range, within_partial_range, outside_range], index=['Within Full Range', 'Within Partial Range', 'Outside Range'])

#plotting
type_count.plot(kind='bar', color='plum', title='Distribution of Exoplanets by type')
plt.xlabel('Planet Type Category')
plt.ylabel('Number of Exoplanets')
plt.show()

import math
#counting the number of exoplanets in and out of the habitable zone based on radiative flux
in_habitable_range = 0
out_of_habitable_range = 0

for index, exoplanet in df3.iterrows():
    fmax = (5.670374419 * math.pow(10, -8) * math.pow(exoplanet['StellarEffectiveTemperature[K'], 4)) / (4 * math.pi * (exoplanet['koi_dor'] * exoplanet['koi_srad']))
    if 67 <= exoplanet['InsolationFlux[Earthflux'] <= fmax:
        in_habitable_range += 1
    else:
        out_of_habitable_range += 1

#creating a series for plotting
radiative_flux_count = pd.Series([in_habitable_range, out_of_habitable_range], index=['Within Habitable Range', 'Outside Habitable Range'])

#plotting
radiative_flux_count.plot(kind='bar', color='mediumorchid', title='Distribution of Exoplanets by Radiative Flux')
plt.xlabel('Radiative Flux Category')
plt.ylabel('Number of Exoplanets')
plt.show()

#counting the number of exoplanets in and out of the habitable zone based on eccentricity
in_habitable_zone = 0
out_of_habitable_zone = 0

for index, exoplanet in df3.iterrows():
    if exoplanet['koi_eccen'] <= 0.2:
        in_habitable_zone += 1
    else:
        out_of_habitable_zone += 1

#creating a series for plotting
ecount = pd.Series([in_habitable_zone, out_of_habitable_zone], index=['Within Habitable Zone', 'Outside Habitable Zone'])

#plotting
ecount.plot(kind='bar', color='blueviolet', title='Distribution of Exoplanets by Eccentricity')
plt.xlabel('Eccentricity Category')
plt.ylabel('Number of Exoplanets')
plt.show()

#counting the number of exoplanets in and out of the habitable zone based on obliquity
in_habitable_zone = 0
out_of_habitable_zone = 0

for index, exoplanet in df3.iterrows():
    if (90-exoplanet['koi_incl']) <= 45:
        in_habitable_zone += 1
    else:
        out_of_habitable_zone += 1

#creating a series for plotting
ocount = pd.Series([in_habitable_zone, out_of_habitable_zone], index=['Within Habitable Zone', 'Outside Habitable Zone'])

#plotting
ocount.plot(kind='bar', color='indigo', title='Distribution of Exoplanets by Obliquity')
plt.xlabel('Obliquity Category')
plt.ylabel('Number of Exoplanets')
plt.show()

print(df3)

features = df3.drop(columns=['HabitabilityScore','KepID'])
target = df3.HabitabilityScore

X_train, X_test, y_train, y_test = train_test_split(features, target, random_state=16, test_size=.60)

# Checking if train test split ran correctly
for dataset in [y_train, y_test]:
    print(round(len(dataset)/len(target), 2))

#instantiating the KNN model
knn = KNeighborsClassifier(leaf_size=8, metric='manhattan', weights='uniform')

#converting y_train to integer if it's binary/categorical
y_train = y_train.astype('int')
#ensuring y_test is categorical
y_test = y_test.astype('int')

#fitting the model to the training set
knn.fit(X_train, y_train)

#predicting the habitability scores on the test set
y_pred = knn.predict(X_test)

#evaluating the model using the evaluation function or directly with metrics
print("KNN Model Evaluation:")

#calculating and printing the accuracy
accuracy_knn = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy_knn:.2f}")

#generating and print the confusion matrix
conf_matrix = confusion_matrix(y_test, y_pred)
print("\nConfusion Matrix:\n", conf_matrix)

#generating a classification report
class_report = classification_report(y_test, y_pred)
print("\nClassification Report:\n", class_report)

#instantiating the Random Forest model
forest = RandomForestClassifier(n_estimators=100, criterion='gini')

#fitting the model to the training set
forest.fit(X_train, y_train)

#predicting the habitability scores on the test set
y_pred = forest.predict(X_test)

#evaluting the model
print("Random Forest Model Evaluation:")

#calculating and printing the accuracy
accuracy_forest = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy_forest:.2f}")

#generate and print the confusion matrix
conf_matrix = confusion_matrix(y_test, y_pred)
print("\nConfusion Matrix:\n", conf_matrix)

#generating a classification report
class_report = classification_report(y_test, y_pred)
print("\nClassification Report:\n", class_report)

acc=[accuracy_knn,accuracy_forest]
categories = ['KNN', 'Forest']
plt.bar(categories, acc)
plt.xlabel('Models')
plt.ylabel('Accuracy')
plt.title('Accuracy of the Models')
plt.ylim(0, 1)  # Set the y-axis limits (0 to 1 for accuracy)
plt.show()

def exoplanetprediction(iv):
  #defining the feature names for which we'll take inputs
  input_features = [
    'DispositionScore', 'OrbitalPeriod[days', 'TransitEpoch[BKJD', 'ImpactParamete',
    'TransitDuration[hrs', 'TransitDepth[ppm', 'PlanetaryRadius[Earthradii',
    'EquilibriumTemperature[K', 'InsolationFlux[Earthflux', 'TransitSignal-to-Nois',
    'TCEPlanetNumbe', 'StellarEffectiveTemperature[K', 'StellarSurfaceGravity[log10(cm/s**2)',
    'StellarRadius[Solarradii', 'RA[decimaldegrees', 'Dec[decimaldegrees', 'Kepler-band[mag]'
  ]

  #setting default values (0) for other features
  default_features = [
    'OrbitalPeriodUpperUnc.[days', 'OrbitalPeriodLowerUnc.[days', 'TransitEpochUpperUnc.[BKJD',
    'TransitEpochLowerUnc.[BKJD', 'ImpactParameterUpperUnc', 'ImpactParameterLowerUnc',
    'TransitDurationUpperUnc.[hrs', 'TransitDurationLowerUnc.[hrs', 'TransitDepthUpperUnc.[ppm',
    'TransitDepthLowerUnc.[ppm', 'PlanetaryRadiusUpperUnc.[Earthradii', 'PlanetaryRadiusLowerUnc.[Earthradii',
    'InsolationFluxUpperUnc.[Earthflux', 'InsolationFluxLowerUnc.[Earthflux', 'StellarEffectiveTemperatureUpperUnc.[K',
    'StellarEffectiveTemperatureLowerUnc.[K', 'StellarSurfaceGravityUpperUnc.[log10(cm/s**2)',
    'StellarSurfaceGravityLowerUnc.[log10(cm/s**2)', 'StellarRadiusUpperUnc.[Solarradii',
    'StellarRadiusLowerUnc.[Solarradii'
  ]


  allfeatures=['DispositionScore', 'OrbitalPeriod[days',
       'OrbitalPeriodUpperUnc.[days', 'OrbitalPeriodLowerUnc.[days',
       'TransitEpoch[BKJD', 'TransitEpochUpperUnc.[BKJD',
       'TransitEpochLowerUnc.[BKJD', 'ImpactParamete',
       'ImpactParameterUpperUnc', 'ImpactParameterLowerUnc',
       'TransitDuration[hrs', 'TransitDurationUpperUnc.[hrs',
       'TransitDurationLowerUnc.[hrs', 'TransitDepth[ppm',
       'TransitDepthUpperUnc.[ppm', 'TransitDepthLowerUnc.[ppm',
       'PlanetaryRadius[Earthradii', 'PlanetaryRadiusUpperUnc.[Earthradii',
       'PlanetaryRadiusLowerUnc.[Earthradii', 'EquilibriumTemperature[K',
       'InsolationFlux[Earthflux', 'InsolationFluxUpperUnc.[Earthflux',
       'InsolationFluxLowerUnc.[Earthflux', 'TransitSignal-to-Nois',
       'TCEPlanetNumbe', 'StellarEffectiveTemperature[K',
       'StellarEffectiveTemperatureUpperUnc.[K',
       'StellarEffectiveTemperatureLowerUnc.[K',
       'StellarSurfaceGravity[log10(cm/s**2)',
       'StellarSurfaceGravityUpperUnc.[log10(cm/s**2)',
       'StellarSurfaceGravityLowerUnc.[log10(cm/s**2)',
       'StellarRadius[Solarradii', 'StellarRadiusUpperUnc.[Solarradii',
       'StellarRadiusLowerUnc.[Solarradii', 'RA[decimaldegrees',
       'Dec[decimaldegrees', 'Kepler-band[mag]']

  input_data = {}
  c=0
  for feature in allfeatures:
    if feature in default_features:
        input_data[feature] = [0]
    else:
      if len(iv)==0:
      #taking inputs for each feature
        value = float(input(f"{feature}: "))
        input_data[feature] = [value]
      else:
        if len(iv)==17:
          value = float(iv[c])
          input_data[feature] = [value]
          c+=1


  #converting the input data into a DataFrame
  input_df = pd.DataFrame(input_data)

  #making a prediction using the trained Forest model
  predicted_label = forest1.predict(input_df)

  #output the prediction result
  if predicted_label[0] == 1:
      print("The celestial object is an exoplanet.")
  else:
      print("The celestial object is not an exoplanet.")

#A confirmed exoplanet
kepler12b=[0.76, 4.43, 171, 0.069, 4.69, 16387.6, 18.05, 1338, 757.65, 3535.6, 1, 5953, 4.175, 1.415, 286.24, 50.04, 13.438]
exoplanetprediction(kepler12b)

#A confirmed exoplanet in the Habitable Zone
kepler441b=[0.975, 207.24, 213.03, 0.21, 6.159, 809.2, 1.56, 189, 0.3, 13.2, 1, 4339, 4.711, 0.553, 284.56, 49.01, 15.14]
exoplanetprediction(kepler441b)

#A confirmed non-exoplanet
k07622=[0, 36.26, 155.08, 0.214, 2.065, 627.1, 1.5, 347, 3.44, 10, 1, 4264, 4.637, 0.62, 291.02, 36.91, 15.544]
exoplanetprediction(k07622)

def habitabilityprediction(inputdata):
  if len(inputdata)==0:
    #Taking inputs
    print("Enter the details of the exoplanet candidate:")
    planetary_radius = float(input("Planetary Radius (in Earth radii): "))
    orbit_semi_major_axis = float(input("Orbit Semi-Major Axis (in AU): "))
    stellar_surface_gravity = float(input("Stellar Surface Gravity (log10(cm/s^2)): "))
    equilibrium_temperature = float(input("Equilibrium Temperature (in K): "))
    planetary_density = float(input("Planetary Density (Type of Planet, in Earth radii): "))
    radiative_flux = float(input("Radiative Flux (Earth flux): "))
    eccentricity = float(input("Eccentricity: "))
    obliquity = 90-float(input("Obliquity (degrees): "))
    koi_dor = float(input("Distance to Star (AU): "))
    koi_srad = float(input("Stellar Radius (Solar radii): "))
    stellartemp=float(input("Stellar Effective Temperature (in K):"))
  else:
    planetary_radius = float(inputdata[0])
    orbit_semi_major_axis = float(inputdata[1])
    stellar_surface_gravity = float(inputdata[2])
    equilibrium_temperature = float(inputdata[3])
    planetary_density = float(inputdata[4])
    radiative_flux = float(inputdata[5])
    eccentricity = float(inputdata[6])
    obliquity = 90-float(inputdata[7])
    koi_dor = float(inputdata[8])
    koi_srad = float(inputdata[9])
    stellartemp=float(inputdata[10])
  #creating a dataframe with the given exoplanet candidate values
  data = {
    'PlanetaryRadius[Earthradii': [planetary_radius],
    'koi_sma': [orbit_semi_major_axis],
    'StellarSurfaceGravity[log10(cm/s**2)': [stellar_surface_gravity],
    'EquilibriumTemperature[K': [equilibrium_temperature],
    'PlanetaryDensity': [planetary_density],
    'InsolationFlux[Earthflux': [radiative_flux],
    'koi_eccen': [eccentricity],
    'koi_incl': [obliquity],  #converting obliquity to inclination
    'koi_dor': [koi_dor],
    'koi_srad': [koi_srad],
    'StellarEffectiveTemperature[K':[stellartemp]
  }
  candidate_df = pd.DataFrame(data)

  #calculating the habitability score
  candidate_df['HabitabilityScore'] = candidate_df.apply(habitability_score, axis=1)
  print(f"The exoplanet has a {int(100*candidate_df['HabitabilityScore'].iloc[0]/8)}% potential of being habitable.")

#A confirmed exoplanet in the habitable zone
kep296e=[1.06, 0.169, 4.866, 248, 4.1, 0.89, 0.33, 0.11, 136.2, 0.118, 3526]
habitabilityprediction(kep296e)

#A confirmed exoplanet
kepler186f=[1.18, 0.35, 4.8, 177, 1.18, 0.23, 0.04, 0.04, 0.43, 0.443, 3751]
habitabilityprediction(kepler186f)