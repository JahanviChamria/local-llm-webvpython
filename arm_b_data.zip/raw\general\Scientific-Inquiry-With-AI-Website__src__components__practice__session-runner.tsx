"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Btn } from "@/components/portal/primitives";

type Card = {
  attemptId: string;
  cardId: string;
  questionId: string;
  prompt: string;
  difficulty: string;
  format: "true_false" | "multiple_choice" | "short_answer" | "calculation";
  options: Array<{ id: string; text: string }> | null;
  figureUrl: string | null;
};
type Reveal = {
  expectedAnswer: string | null;
  correctOption: string | null;
  wasCorrect: boolean | null;
  feedback: string | null;
  intervals: Record<string, string> | null;
  autoRating?: string | null;
  gradedBy?: "ai" | "keyword" | null;
  nextDueLabel?: string | null;
  alreadyRated?: boolean;
};
type Phase = "loading" | "answer" | "revealed" | "done" | "empty" | "error" | "locked";

const RATING_META: [string, string][] = [
  ["again", "var(--orange)"],
  ["hard", ""],
  ["good", ""],
  ["easy", "var(--green)"],
];

export function SessionRunner({
  labId,
  scope = "lab",
  exitHref = "/portal",
}: {
  labId: string;
  scope?: "lab" | "external";
  exitHref?: string;
}) {
  const router = useRouter();
  const [phase, setPhase] = useState<Phase>("loading");
  const [cards, setCards] = useState<Card[]>([]);
  const [idx, setIdx] = useState(0);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [answer, setAnswer] = useState("");
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [reveal, setReveal] = useState<Reveal | null>(null);
  const [busy, setBusy] = useState(false);
  const started = useRef(false);
  const shownAt = useRef(0);

  useEffect(() => {
    if (phase === "answer") shownAt.current = performance.now();
  }, [phase, idx]);

  useEffect(() => {
    if (started.current) return;
    started.current = true;
    (async () => {
      try {
        const res = await fetch("/api/portal/practice/start", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ labId, scope }),
        });
        if (res.status === 401) return setPhase("error");
        if (res.status === 403) return setPhase("locked");
        const data = await res.json();
        if (!data.cards || data.cards.length === 0) return setPhase("empty");
        setCards(data.cards);
        setSessionId(data.sessionId);
        setPhase("answer");
      } catch {
        setPhase("error");
      }
    })();
  }, [labId, scope]);

  const card = cards[idx];

  async function submit() {
    if (!card || busy) return;
    setBusy(true);
    try {
      const body: Record<string, unknown> = {
        attemptId: card.attemptId,
        sessionId,
        elapsedMs: Math.round(performance.now() - shownAt.current),
      };
      if (card.format === "multiple_choice" || card.format === "true_false") {
        if (!selectedOption) {
          setBusy(false);
          return;
        }
        body.selectedOption = selectedOption;
      } else {
        body.answerText = answer;
      }
      const res = await fetch("/api/portal/practice/reveal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      setReveal(await res.json());
      setPhase("revealed");
    } finally {
      setBusy(false);
    }
  }

  async function advance() {
    const isLast = idx + 1 >= cards.length;
    if (isLast) {
      if (sessionId) {
        await fetch("/api/portal/practice/finish", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ sessionId }),
        });
      }
      setPhase("done");
    } else {
      setIdx((i) => i + 1);
      setAnswer("");
      setSelectedOption(null);
      setReveal(null);
      setPhase("answer");
    }
  }

  // Choice formats are auto-rated server-side at reveal — just move on.
  async function next() {
    if (busy) return;
    setBusy(true);
    try {
      await advance();
    } finally {
      setBusy(false);
    }
  }

  async function rate(rating: string) {
    if (!card || busy) return;
    setBusy(true);
    try {
      const body: Record<string, unknown> = {
        attemptId: card.attemptId,
        sessionId,
        rating,
      };
      if (answer) body.answerText = answer;
      await fetch("/api/portal/practice/rate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      await advance();
    } finally {
      setBusy(false);
    }
  }

  if (phase === "loading") {
    return <p className="muted" style={{ fontSize: 13 }}>Loading your session…</p>;
  }
  if (phase === "error") {
    return (
      <div className="callout orange">
        <strong>Sign in required.</strong> Log in as a student to start a retrieval session.
      </div>
    );
  }
  if (phase === "locked") {
    return (
      <div className="col" style={{ alignItems: "center", gap: 14 }}>
        <div className="callout orange" style={{ maxWidth: 520 }}>
          <strong>This lab is locked.</strong> Retrieval practice opens once your instructor unlocks
          it{scope === "lab" ? " for your class" : ""}.
        </div>
        <Btn onClick={() => router.push(exitHref)}>← Back to practice</Btn>
      </div>
    );
  }
  if (phase === "empty") {
    return (
      <div className="col" style={{ alignItems: "center", gap: 14 }}>
        <div className="callout green" style={{ maxWidth: 520 }}>
          <strong>Nothing due right now.</strong> You&apos;ve cleared this lab&apos;s queue — come back when cards are
          scheduled to resurface.
        </div>
        <Btn onClick={() => router.push(exitHref)}>← Back to practice</Btn>
      </div>
    );
  }
  if (phase === "done") {
    return (
      <div className="col" style={{ alignItems: "center", gap: 16 }}>
        <h1 style={{ fontSize: 24 }}>Session complete 🎉</h1>
        <p className="muted" style={{ fontSize: 14 }}>
          You answered {cards.length} question{cards.length === 1 ? "" : "s"}. Your spaced intervals are updated.
        </p>
        {scope === "lab" ? (
          <div className="callout green" style={{ maxWidth: 520 }}>
            <strong>Graded on engagement, not correctness.</strong> Completing your weekly sessions earns full credit.
          </div>
        ) : (
          <div className="callout green" style={{ maxWidth: 520 }}>
            <strong>Nice work.</strong> Come back when cards are due again to keep the material fresh.
          </div>
        )}
        <Btn variant="primary" onClick={() => router.push(exitHref)}>Back to practice hub</Btn>
      </div>
    );
  }

  const progressPct = (idx / cards.length) * 100;
  const isChoice = card.format === "multiple_choice" || card.format === "true_false";
  const canSubmit = isChoice ? selectedOption !== null : true;

  return (
    <div className="col" style={{ alignItems: "center" }}>
      <div className="row between center" style={{ width: "100%", maxWidth: 760 }}>
        <Btn sm onClick={() => router.push(exitHref)}>← Exit</Btn>
        <div className="row center grow" style={{ gap: 10, margin: "0 18px" }}>
          <div className="track grow" style={{ height: 5 }}>
            <span style={{ width: `${progressPct}%` }} />
          </div>
          <span className="muted" style={{ fontSize: 12 }}>
            {idx + 1} / {cards.length}
          </span>
        </div>
        <span className="label">{card.difficulty}</span>
      </div>

      <div className="question-card" style={{ width: "100%", maxWidth: 760, marginTop: 16 }}>
        <div className="question-header">
          <div className="question-label">
            {scope === "lab" ? "Retrieval · Lab practice" : "Retrieval · Practice"}
          </div>
          {card.figureUrl && (
            <div style={{ margin: "10px 0" }}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={card.figureUrl}
                alt="Question figure"
                style={{
                  maxWidth: "100%",
                  borderRadius: "var(--radius)",
                  border: "1px solid var(--border)",
                }}
              />
            </div>
          )}
          <div className="question-text" style={{ whiteSpace: "pre-wrap" }}>
            {card.prompt}
          </div>
        </div>
        <div className="question-body">
          {phase === "answer" ? (
            <div>
              {card.format === "true_false" ? (
                <div className="row" style={{ gap: 9 }}>
                  {["True", "False"].map((v) => (
                    <button
                      key={v}
                      type="button"
                      className="btn"
                      onClick={() => setSelectedOption(v)}
                      style={
                        selectedOption === v
                          ? { borderColor: "var(--green)", color: "var(--green-mid)" }
                          : undefined
                      }
                    >
                      {v}
                    </button>
                  ))}
                </div>
              ) : card.format === "multiple_choice" && card.options ? (
                <div className="col" style={{ gap: 6 }}>
                  {card.options.map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      className="btn"
                      onClick={() => setSelectedOption(opt.id)}
                      style={{
                        textAlign: "left",
                        whiteSpace: "normal",
                        ...(selectedOption === opt.id
                          ? { borderColor: "var(--green)", color: "var(--green-mid)" }
                          : {}),
                      }}
                    >
                      <strong>{opt.id}.</strong> {opt.text}
                    </button>
                  ))}
                </div>
              ) : (
                <textarea
                  className="field"
                  rows={4}
                  value={answer}
                  onChange={(e) => setAnswer(e.target.value)}
                  placeholder="Explain your reasoning in full sentences — recall before you reveal…"
                />
              )}
              <div className="row between center" style={{ marginTop: 10 }}>
                <span className="light" style={{ fontSize: 11.5 }}>
                  {isChoice
                    ? "Pick your answer — you can change it before submitting"
                    : busy
                      ? "Checking your answer — this takes a couple of seconds"
                      : "Answer in your own words — articulate the reasoning"}
                </span>
                <Btn
                  variant="primary"
                  onClick={submit}
                  style={!canSubmit || busy ? { opacity: 0.5 } : undefined}
                >
                  {busy && !isChoice ? "Grading…" : "Submit →"}
                </Btn>
              </div>
            </div>
          ) : (
            <div className="col" style={{ gap: 12 }}>
              {reveal?.wasCorrect != null && (
                <div
                  className="callout"
                  style={
                    reveal.wasCorrect
                      ? { borderColor: "var(--green)", color: "var(--green-mid)" }
                      : { borderColor: "var(--orange)", color: "var(--orange)" }
                  }
                >
                  <strong>
                    {reveal.wasCorrect ? "Correct" : "Not quite"} — your answer: {selectedOption}.{" "}
                  </strong>
                  {!reveal.wasCorrect && reveal.correctOption && (
                    <span>Correct option: {reveal.correctOption}.</span>
                  )}
                </div>
              )}
              {reveal?.expectedAnswer && (
                <div className="reveal-answer">
                  <div className="label green-text" style={{ color: "var(--green-mid)" }}>Answer</div>
                  <p
                    style={{
                      fontSize: 14,
                      marginTop: 5,
                      color: "var(--green-mid)",
                      whiteSpace: "pre-wrap",
                    }}
                  >
                    {reveal.expectedAnswer}
                  </p>
                </div>
              )}
              {!isChoice && reveal?.feedback && (
                <div className="reveal-feedback">
                  <div className="label">{reveal.gradedBy === "ai" ? "Feedback" : "Auto-check"}</div>
                  <p className="muted" style={{ fontSize: 13, marginTop: 6, whiteSpace: "pre-wrap" }}>
                    {reveal.feedback}
                  </p>
                </div>
              )}
              {reveal?.intervals && reveal?.autoRating == null && !reveal?.alreadyRated ? (
                // Fallback: an old server (or in-flight pre-deploy reveal) that
                // didn't auto-rate still gets the self-rating buttons.
                <div>
                  <div className="label" style={{ margin: "6px 0 8px" }}>
                    How well did you know it? — sets the next review interval
                  </div>
                  <div className="row" style={{ gap: 9 }}>
                    {RATING_META.map(([r, c]) => (
                      <button
                        key={r}
                        className="btn rate-btn"
                        onClick={() => rate(r)}
                        style={c ? { borderColor: c, color: c } : {}}
                      >
                        <span style={{ fontWeight: 600, textTransform: "capitalize" }}>{r}</span>
                        <span className="light" style={{ fontSize: 10 }}>{reveal?.intervals?.[r] ?? ""}</span>
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="row between center">
                  <span
                    className="muted"
                    style={{
                      fontSize: 12.5,
                      ...(reveal?.wasCorrect === false || reveal?.autoRating === "again"
                        ? { color: "var(--orange)" }
                        : {}),
                    }}
                  >
                    {reveal?.wasCorrect === false || reveal?.autoRating === "again"
                      ? `You'll see this question again in ${reveal?.nextDueLabel ?? "<10m"}.`
                      : reveal?.autoRating
                        ? `Rated ${reveal.autoRating} automatically from your answer${isChoice ? " and speed" : ""} — next review in ${reveal?.nextDueLabel ?? "soon"}.`
                        : `Next review in ${reveal?.nextDueLabel ?? "soon"}.`}
                  </span>
                  <Btn variant="primary" onClick={next} style={busy ? { opacity: 0.5 } : undefined}>
                    Next →
                  </Btn>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      <div className="callout" style={{ width: "100%", maxWidth: 760, marginTop: 14 }}>
        <strong>Flow:</strong> multiple-choice and true/false are graded automatically from your answer and
        speed; written questions are graded automatically with feedback on your specific answer — read →
        recall → submit → review.
      </div>
    </div>
  );
}
