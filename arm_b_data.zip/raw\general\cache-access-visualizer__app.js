// app.js — Blocks 3-5: tick loop, live counters, controls, pattern picker,
// A/B compare, paused-frame tooltip.
// Loads after sim.js in the browser; in node it requires sim.js so the
// harness can drive the exact Stepper and tooltip the page uses.

const Sim =
  typeof module !== "undefined" && typeof DirectMappedCache === "undefined"
    ? require("./sim.js")
    : { DirectMappedCache, MissClassifier, rowMajor, colMajor, strided, INT };

const APP_CFG = { numSets: 16, blockSize: 16 };
const APP_N = 16;

const hex = (a) => "0x" + a.toString(16).toUpperCase().padStart(3, "0");

// One memory access per step(). Deterministic: reset() + k steps always
// yields the same k states (bet 3: every transition reproducible from reset).
class Stepper {
  constructor(addrs, config = APP_CFG) {
    this.addrs = addrs;
    this.cache = new Sim.DirectMappedCache(config);
    this.clf = new Sim.MissClassifier({ numLines: config.numSets });
    this.reset();
  }
  reset() {
    this.cache.reset();
    this.clf.reset();
    this.i = 0;
    this.last = null;
    this.touched = new Set();
    this.missLog = [];
  }
  setSequence(addrs) {
    this.addrs = addrs;
    this.reset();
  }
  get done() {
    return this.i >= this.addrs.length;
  }
  get tally() {
    return this.clf.tally;
  }
  step() {
    if (this.done) return null;
    const ev = this.cache.access(this.addrs[this.i++]);
    ev.missType = this.clf.classify(ev);
    if (ev.missType) {
      this.missLog.push({ n: this.i, addr: ev.addr, set: ev.set, type: ev.missType });
    }
    this.last = ev;
    this.touched.add(ev.addr / Sim.INT);
    return ev;
  }
}

// Paused-frame explanation: addr, block, set, tag comparison, outcome.
// e.g. "addr 0x3C8 → block 60 → set 12 → tag 3 vs resident tag 2 →
//       mismatch → MISS (conflict), evict tag 2"
function frameTooltip(ev) {
  if (!ev) return "no access yet — press Step or Play";
  const head = `addr ${hex(ev.addr)} → block ${ev.block} → set ${ev.set} → tag ${ev.tag}`;
  if (ev.hit) return `${head} vs resident tag ${ev.tag} → match → HIT`;
  if (ev.evictedTag !== null) {
    return (
      `${head} vs resident tag ${ev.evictedTag} → mismatch → ` +
      `MISS (${ev.missType}), evict tag ${ev.evictedTag}`
    );
  }
  return `${head} → line empty (V=0) → MISS (${ev.missType}), fill`;
}

if (typeof module !== "undefined") {
  module.exports = { Stepper, APP_CFG, APP_N, frameTooltip };
}

// ---- DOM wiring (browser only) ----
if (typeof document !== "undefined") {
  const $ = (id) => document.getElementById(id);
  const STATE_LABEL = { empty: "empty", resident: "resident", hit: "hit-flash", evict: "evict-flash" };
  const PATTERN_NAMES = ["row-major", "column-major", "strided"];

  const params = new URLSearchParams(location.search);
  let patName = PATTERN_NAMES.includes(params.get("pattern")) ? params.get("pattern") : "row-major";
  let stride = Math.min(32, Math.max(1, Number(params.get("stride")) || 8));

  function buildAddrs() {
    if (patName === "strided") return [...Sim.strided(APP_N, stride)];
    return [...(patName === "row-major" ? Sim.rowMajor(APP_N) : Sim.colMajor(APP_N))];
  }
  const patLabel = () => (patName === "strided" ? `strided(${stride})` : patName);

  const st = new Stepper(buildAddrs());

  // Cache table: one row per line, built once, updated in place.
  const tbl = $("cacheTable");
  tbl.innerHTML =
    "<tr><th>set</th><th>V</th><th>tag</th><th>state</th></tr>" +
    Array.from({ length: APP_CFG.numSets }, (_, s) =>
      `<tr><td class="meta">${s}</td><td class="meta"></td><td class="meta"></td><td class="state"></td></tr>`
    ).join("");
  const rows = [...tbl.querySelectorAll("tr")].slice(1);
  const vC = rows.map((r) => r.cells[1]);
  const tagC = rows.map((r) => r.cells[2]);
  const stC = rows.map((r) => r.cells[3]);

  // Array heatmap: built once.
  const heat = $("heat");
  heat.innerHTML = Array.from({ length: APP_N * APP_N }, (_, i) => {
    const r = Math.floor(i / APP_N);
    const c = i % APP_N;
    return `<span class="cell" title="a[${r}][${c}] @ ${hex(i * Sim.INT)}"></span>`;
  }).join("");
  const heatCells = [...heat.children];

  let logLen = -1;

  function render() {
    const last = st.last;
    const tip = frameTooltip(last);
    for (let s = 0; s < APP_CFG.numSets; s++) {
      const valid = st.cache.valid[s];
      vC[s].textContent = valid ? 1 : 0;
      tagC[s].textContent = valid ? st.cache.tags[s] : "-";
      const isCur = !!last && s === last.set;
      let state = valid ? "resident" : "empty";
      if (isCur) state = last.hit ? "hit" : last.evictedTag !== null ? "evict" : "resident";
      stC[s].className = "state " + state;
      stC[s].textContent = STATE_LABEL[state];
      rows[s].className = isCur ? "accessed" : "";
      rows[s].title = isCur ? tip : "";
    }

    for (let i = 0; i < heatCells.length; i++) {
      heatCells[i].className = "cell" + (st.touched.has(i) ? " touched" : "");
    }
    if (last) {
      heatCells[last.addr / Sim.INT].className = `cell cur ${last.hit ? "hit" : "miss"}`;
    }

    const { accesses, hits, misses } = st.cache.stats;
    $("cAccesses").textContent = accesses;
    $("cHits").textContent = hits;
    $("cMisses").textContent = misses;
    $("cRate").textContent = (st.cache.hitRate() * 100).toFixed(1) + "%";
    $("cComp").textContent = st.tally.compulsory;
    $("cConf").textContent = st.tally.conflict;
    $("cCap").textContent = st.tally.capacity;

    if (st.missLog.length !== logLen) {
      logLen = st.missLog.length;
      $("mlog").innerHTML = logLen
        ? st.missLog
            .map((m) => `<div>#${m.n} ${hex(m.addr)} → set ${m.set} · ${m.type}</div>`)
            .reverse()
            .join("")
        : '<div class="none">no misses yet</div>';
    }

    $("progress").textContent = `access ${st.i} / ${st.addrs.length} · ${patLabel()}`;
    $("detail").textContent = tip;
  }

  // Discrete per-tick flashes, no tweening (bet 3 prefers stepping; also the
  // Block 3 cut-bait path taken up front).
  let timer = null;
  function pause() {
    clearInterval(timer);
    timer = null;
    $("play").disabled = false;
    $("pause").disabled = true;
  }
  function play() {
    if (timer || st.done) return;
    timer = setInterval(() => {
      st.step();
      render();
      if (st.done) pause();
    }, 1000 / Number($("speed").value));
    $("play").disabled = true;
    $("pause").disabled = false;
  }

  $("play").addEventListener("click", play);
  $("pause").addEventListener("click", pause);
  $("step").addEventListener("click", () => {
    pause();
    if (!st.done) {
      st.step();
      render();
    }
  });
  $("reset").addEventListener("click", () => {
    pause();
    st.reset();
    render();
  });
  $("speed").addEventListener("input", () => {
    $("speedVal").textContent = $("speed").value + " ticks/s";
    if (timer) {
      pause();
      play();
    }
  });

  // Pattern picker + stride slider: any change resets the run.
  for (const radio of document.querySelectorAll('input[name="pattern"]')) {
    radio.checked = radio.value === patName;
    radio.addEventListener("change", () => {
      pause();
      patName = radio.value;
      $("stride").disabled = patName !== "strided";
      st.setSequence(buildAddrs());
      render();
    });
  }
  $("stride").value = stride;
  $("stride").disabled = patName !== "strided";
  $("strideVal").textContent = stride + " ints";
  $("stride").addEventListener("input", () => {
    stride = Number($("stride").value);
    $("strideVal").textContent = stride + " ints";
    if (patName === "strided") {
      pause();
      st.setSequence(buildAddrs());
      render();
    }
  });

  // A/B: both loop orders' final stats side by side (computed headless).
  function finalStats(gen) {
    const cache = new Sim.DirectMappedCache(APP_CFG);
    const clf = new Sim.MissClassifier({ numLines: APP_CFG.numSets });
    for (const a of gen) clf.classify(cache.access(a));
    return { ...cache.stats, rate: (cache.hitRate() * 100).toFixed(1) + "%", ...clf.tally };
  }
  function toggleAB(force) {
    const p = $("abPanel");
    const show = force !== undefined ? force : p.style.display === "none";
    if (show) {
      const r = finalStats(Sim.rowMajor(APP_N));
      const c = finalStats(Sim.colMajor(APP_N));
      $("abTable").innerHTML =
        "<tr><th></th><th>row-major</th><th>column-major</th></tr>" +
        [
          ["hit rate", r.rate, c.rate],
          ["accesses", r.accesses, c.accesses],
          ["hits", r.hits, c.hits],
          ["misses", r.misses, c.misses],
          ["compulsory", r.compulsory, c.compulsory],
          ["conflict", r.conflict, c.conflict],
          ["capacity", r.capacity, c.capacity],
        ]
          .map(
            ([k, a, b], idx) =>
              `<tr${idx === 0 ? ' class="headline"' : ""}><td class="metric">${k}</td>` +
              `<td>${a}</td><td>${b}</td></tr>`
          )
          .join("");
    }
    p.style.display = show ? "" : "none";
  }
  $("abToggle").addEventListener("click", () => toggleAB());
  if (params.get("ab") === "1") toggleAB(true);

  $("config").textContent =
    `${APP_CFG.numSets} sets x ${APP_CFG.blockSize} B blocks = ` +
    `${APP_CFG.numSets * APP_CFG.blockSize} B direct-mapped cache; ` +
    `array ${APP_N}x${APP_N} x ${Sim.INT} B = ${APP_N * APP_N * Sim.INT} B.`;

  // Test harness hook: ?pattern=&stride=&steps=N replays N steps from reset.
  const p = Number(params.get("steps"));
  for (let k = 0; k < p; k++) st.step();
  render();
}
