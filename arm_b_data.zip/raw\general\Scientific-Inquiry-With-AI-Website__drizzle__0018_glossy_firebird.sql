ALTER TYPE "public"."lab_file_kind" ADD VALUE 'self_check';--> statement-breakpoint
ALTER TABLE "labs" ADD COLUMN "has_self_check" boolean DEFAULT false NOT NULL;