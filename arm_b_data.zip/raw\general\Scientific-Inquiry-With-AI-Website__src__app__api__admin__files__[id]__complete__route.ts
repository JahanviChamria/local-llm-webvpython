import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { files, extractionJobs } from "@/lib/db/schema";
import { requireAdmin, checkOrigin } from "@/lib/auth/guards";
import { headObject, bestEffortDelete, bucketFor } from "@/lib/r2";
import { MAX_UPLOAD_BYTES } from "@/lib/file-types";

export const runtime = "nodejs";

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const csrf = checkOrigin(req);
  if (csrf) return csrf;
  const g = await requireAdmin();
  if (g instanceof NextResponse) return g;

  const { id } = await ctx.params;
  const row = (
    await db.select().from(files).where(and(eq(files.id, id), eq(files.status, "pending"))).limit(1)
  )[0];
  if (!row) return NextResponse.json({ error: "not found or already complete" }, { status: 404 });

  const bucket = bucketFor(row.accessLevel);

  // Load-bearing size + existence + content-type gate.
  let head: { contentLength: number | null; contentType: string | null };
  try {
    head = await headObject(bucket, row.r2Key);
  } catch {
    // R2 object never appeared. Tear down the row.
    await db.delete(files).where(eq(files.id, id));
    return NextResponse.json({ error: "object not found in R2" }, { status: 422 });
  }

  const lenOk =
    head.contentLength !== null &&
    head.contentLength === row.sizeBytes &&
    head.contentLength <= MAX_UPLOAD_BYTES;
  const typeOk = head.contentType === row.contentType;

  if (!lenOk || !typeOk) {
    await bestEffortDelete(bucket, row.r2Key);
    await db.delete(files).where(eq(files.id, id));
    return NextResponse.json(
      {
        error: "uploaded object did not match declared metadata",
        actual: head,
        expected: { contentLength: row.sizeBytes, contentType: row.contentType, maxBytes: MAX_UPLOAD_BYTES },
      },
      { status: 422 },
    );
  }

  await db.update(files).set({ status: "ready" }).where(eq(files.id, id));

  // Public files get a pending extraction job. The cron-driven worker picks it up
  // and writes to file_texts on success. Faculty files don't get extracted —
  // their text would never be public anyway.
  if (row.accessLevel === "public") {
    await db
      .insert(extractionJobs)
      .values({ fileId: id, status: "pending" })
      .onConflictDoUpdate({
        target: extractionJobs.fileId,
        set: { status: "pending", enqueuedAt: new Date(), finishedAt: null, error: null },
      });
  }

  return NextResponse.json({ ok: true, file_id: id });
}
