// Us Two — a long-distance couple's game night.
// Four mini-games: Know Me quiz, This or That, Sketch & Guess, Love Libs.
// Pure rules module: no imports, no timers, state survives JSON round-trips.

export const meta = { game: "us-two", minPlayers: 2, maxPlayers: 2 };

// ---------------------------------------------------------------- decks ---
// Question templates: {N} = subject ("you" for the subject), {P} = subject's
// possessive ("your"), {Y} = the subject's partner ("you" for the partner).

const KNOW = [
  "What is {P} go-to comfort food?",
  "What is {P} most-played song right now?",
  "What does {N} do first thing after waking up?",
  "What is {P} dream vacation spot?",
  "What snack could {N} eat every single day?",
  "What is {P} biggest little fear (spiders, heights…)?",
  "What movie could {N} rewatch forever?",
  "What is {P} most used emoji?",
  "What was {P} first impression of {Y}?",
  "What is {P} hidden talent?",
  "What TV show is {N} secretly obsessed with?",
  "What is {P} ideal lazy Sunday?",
  "What food would {N} never share, even with {Y}?",
  "What is {P} karaoke song?",
  "What did {N} want to be when {N} was little?",
  "What is {P} coffee or tea order?",
  "What app does {N} open the most?",
  "What is {P} love language?",
  "What smell instantly makes {N} happy?",
  "What is {P} guilty-pleasure purchase?",
  "Which fictional character is {N} basically?",
  "What is {P} favourite thing about {Y}?",
  "What tiny thing annoys {N} way more than it should?",
  "What is {P} go-to excuse for staying home?",
  "What would {N} grab first if the house was on fire (after people and pets)?",
  "What is {P} weirdest food combination?",
  "What song makes {N} think of {Y}?",
  "What is {P} proudest flex?",
  "What does {N} always forget to do?",
  "What would {N} do with a totally free day, no obligations?",
  "What is {P} comfort movie after a bad day?",
  "What superpower would {N} pick?",
  "What is {P} most irrational strong opinion?",
  "Where does {N} want to travel with {Y} next?",
  "What is {P} favourite memory of the two of you so far?",
  "What outfit does {N} feel unstoppable in?",
  "What is {P} idea of a perfect date night?",
  "What compliment makes {N} melt?",
  "What is the first thing {N} noticed about {Y}?",
  "What does {N} miss most about {Y} right now?",
  "What is {P} favourite season?",
  "What does {N} order when feeling fancy?",
  "What is {P} biggest pet peeve in public places?",
  "Which emoji does {N} spam the most when excited?",
  "What is {P} usual bedtime, honestly?",
  "What food does {N} refuse to try?",
  "What is {P} favourite dessert?",
  "What chore does {N} avoid the longest?",
  "What is {P} dream job, money aside?",
  "What animal would {N} be?",
  "What is {P} favourite childhood cartoon?",
  "What does {N} do when nobody is watching?",
  "What is {P} go-to dance move?",
  "What phrase does {N} say way too often?",
  "What is {P} biggest kitchen fail so far?",
  "What would {N} buy first with a million dollars?",
  "What is {P} favourite holiday?",
  "What does {N} take way too seriously?",
  "What is {P} hidden guilty-pleasure song?",
  "What was {P} most embarrassing moment?",
  "What does {N} always steal from {Y}?",
  "What is {P} favourite thing to do on a video call with {Y}?",
  "What does {N} think {P} best feature is?",
  "What is {P} typical 3am thought?",
  "What sport would {N} medal in, if watching counted?",
  "What is {P} airport style: hours early or sprinting to the gate?",
  "What was {P} favourite subject at school?",
  "What is {P} signature dish?",
  "What does {N} always lose?",
  "What is {P} caffeine limit before chaos?",
  "What movie made {N} cry the hardest?",
  "What is {P} weirdest habit?",
  "What would {N} name a pet dog?",
  "What is {P} favourite ice cream flavour?",
  "What does {N} hum without noticing?",
  "What is {P} favourite photo of {Y}?",
  "What small gift would make {N} melt?",
  "What is {P} morning mood: sunshine or thundercloud?",
  "What does {N} want to be remembered for?",
  "What is {P} comfort outfit?",
];

// k:"p" = preference (answer for yourself); k:"w" = who's-more-likely.
const TOT = [
  { k: "p", a: "\u{1F3D6}️ Beach", b: "\u{1F3D4}️ Mountains" },
  { k: "p", a: "\u{1F319} Night owl", b: "\u{1F305} Early bird" },
  { k: "p", a: "\u{1F355} Pizza", b: "\u{1F363} Sushi" },
  { k: "p", a: "\u{1F3AC} Movie night in", b: "\u{1F389} Night out" },
  { k: "p", a: "☕ Coffee", b: "\u{1F375} Tea" },
  { k: "p", a: "\u{1F436} Dogs", b: "\u{1F431} Cats" },
  { k: "p", a: "\u{1F327}️ Rainy day cozy", b: "☀️ Sunny day out" },
  { k: "p", a: "\u{1F36B} Sweet", b: "\u{1F9C2} Salty" },
  { k: "p", a: "✈️ Spontaneous trip", b: "\u{1F5D3}️ Planned itinerary" },
  { k: "p", a: "\u{1F4DA} Book", b: "\u{1F3AE} Video game" },
  { k: "p", a: "\u{1F3D9}️ City life", b: "\u{1F33E} Countryside" },
  { k: "p", a: "\u{1F3A4} Karaoke", b: "\u{1F483} Dancing" },
  { k: "p", a: "\u{1F95E} Breakfast food forever", b: "\u{1F35D} Dinner food forever" },
  { k: "p", a: "❄️ Winter", b: "☀️ Summer" },
  { k: "p", a: "\u{1F6CB}️ Rewatch a favourite", b: "\u{1F195} Try something new" },
  { k: "p", a: "\u{1F4DE} Call", b: "\u{1F4AC} Text" },
  { k: "p", a: "\u{1F37F} Salty popcorn", b: "\u{1F36C} Cinema candy" },
  { k: "p", a: "\u{1F697} Road trip", b: "✈️ Fly there" },
  { k: "p", a: "\u{1F336}️ Spicy food", b: "\u{1F60C} Mild food" },
  { k: "p", a: "\u{1F381} Surprise gifts", b: "\u{1F4DD} Wishlist gifts" },
  { k: "p", a: "\u{1F579}️ Retro", b: "\u{1F916} Futuristic" },
  { k: "p", a: "\u{1F368} Ice cream", b: "\u{1F370} Cake" },
  { k: "p", a: "\u{1F3CA} Pool", b: "\u{1F30A} Ocean" },
  { k: "p", a: "\u{1F47B} Horror movie", b: "\u{1F602} Comedy movie" },
  { k: "p", a: "\u{1F354} Burger", b: "\u{1F32E} Tacos" },
  { k: "p", a: "\u{1F3A7} Music", b: "\u{1F399}️ Podcast" },
  { k: "p", a: "\u{1F4AA} Gym date", b: "\u{1F6B6} Long walk date" },
  { k: "p", a: "\u{1F30C} Stargazing", b: "\u{1F525} Bonfire" },
  { k: "p", a: "\u{1F6CC} Sleep in", b: "⏰ Up early on holiday" },
  { k: "p", a: "\u{1F35C} Ramen", b: "\u{1F35B} Curry" },
  { k: "w", q: "Who's more likely to cry during a movie?" },
  { k: "w", q: "Who's more likely to get lost even with GPS?" },
  { k: "w", q: "Who's more likely to laugh at their own joke before finishing it?" },
  { k: "w", q: "Who's more likely to survive a zombie apocalypse?" },
  { k: "w", q: "Who's more likely to forget an anniversary?" },
  { k: "w", q: "Who's more likely to become famous?" },
  { k: "w", q: "Who's more likely to text back within 10 seconds?" },
  { k: "w", q: "Who's more likely to fall asleep on a video call?" },
  { k: "w", q: "Who's more likely to spend the whole paycheck in one weekend?" },
  { k: "w", q: "Who's more likely to win a cooking show?" },
  { k: "w", q: "Who's more likely to talk to strangers on a plane?" },
  { k: "w", q: "Who's more likely to adopt a random animal without asking?" },
  { k: "w", q: "Who's more likely to double-text when the other doesn't reply?" },
  { k: "w", q: "Who's more likely to plan the whole wedding on a napkin?" },
  { k: "w", q: "Who's more likely to rage-quit a game?" },
  { k: "w", q: "Who's more likely to miss a flight?" },
  { k: "p", a: "\u{1F32E} Street food", b: "\u{1F37D}️ Fancy dinner" },
  { k: "p", a: "\u{1F3DD}️ Island resort", b: "\u{1F3D5}️ Forest cabin" },
  { k: "p", a: "\u{1F3A2} Theme park", b: "\u{1F5BC}️ Museum day" },
  { k: "p", a: "\u{1F422} Slow morning", b: "⚡ Productive morning" },
  { k: "p", a: "\u{1F366} Cone", b: "\u{1F964} Cup" },
  { k: "p", a: "\u{1F4FA} Series binge", b: "\u{1F3AC} One great film" },
  { k: "p", a: "\u{1F9E3} Overdressed", b: "\u{1FA73} Underdressed" },
  { k: "p", a: "\u{1F6BF} Morning shower", b: "\u{1F6C1} Night shower" },
  { k: "p", a: "\u{1F382} Chocolate cake", b: "\u{1F370} Vanilla cake" },
  { k: "p", a: "\u{1F57A} Party with friends", b: "\u{1F942} Dinner for two" },
  { k: "p", a: "\u{1F9C0} Extra cheese", b: "\u{1F336}️ Extra spice" },
  { k: "p", a: "⛰️ Sunrise hike", b: "\u{1F307} Sunset walk" },
  { k: "p", a: "\u{1F3AE} Co-op games", b: "\u{1F0CF} Card games" },
  { k: "p", a: "\u{1F35C} Cook together", b: "\u{1F6F5} Order in" },
  { k: "p", a: "\u{1F48C} Handwritten letter", b: "\u{1F381} Surprise package" },
  { k: "p", a: "\u{1F3E0} Stay-home Saturday", b: "\u{1F697} Day-trip Saturday" },
  { k: "p", a: "\u{1F468}‍\u{1F373} Big breakfast", b: "\u{1F950} Coffee and pastry" },
  { k: "p", a: "\u{1F3A7} Lo-fi", b: "\u{1F3B8} Rock" },
  { k: "p", a: "\u{1F30A} Swim", b: "\u{1F3D6}️ Tan" },
  { k: "p", a: "\u{1F35F} Fries", b: "\u{1F9C5} Onion rings" },
  { k: "p", a: "\u{1F9CA} AC blasting", b: "\u{1FA9F} Windows open" },
  { k: "p", a: "\u{1F5FA}️ New city every trip", b: "\u{1F3E1} Familiar favourite spot" },
  { k: "p", a: "\u{1F570}️ Early to everything", b: "\u{1F3C3} Fashionably late" },
  { k: "p", a: "\u{1F36B} Milk chocolate", b: "\u{1F36B} Dark chocolate" },
  { k: "p", a: "\u{1F31F} Big celebration", b: "\u{1F56F}️ Quiet anniversary" },
  { k: "w", q: "Who's more likely to become a millionaire?" },
  { k: "w", q: "Who's more likely to trip over nothing?" },
  { k: "w", q: "Who's more likely to eat dessert before dinner?" },
  { k: "w", q: "Who's more likely to cry at your wedding?" },
  { k: "w", q: "Who's more likely to lock themselves out?" },
  { k: "w", q: "Who's more likely to talk during a movie?" },
  { k: "w", q: "Who's more likely to win an argument with pure stubbornness?" },
  { k: "w", q: "Who's more likely to send a 3am 'you up?' text?" },
  { k: "w", q: "Who's more likely to get a tattoo on a whim?" },
  { k: "w", q: "Who's more likely to befriend the waiter?" },
  { k: "w", q: "Who's more likely to keep a secret?" },
  { k: "w", q: "Who's more likely to plan a surprise party?" },
  { k: "w", q: "Who's more likely to stalk a celebrity's feed?" },
  { k: "w", q: "Who's more likely to fall asleep mid-text?" },
  { k: "w", q: "Who's more likely to burn instant noodles?" },
  { k: "w", q: "Who's more likely to say sorry first after a fight?" },
];

const DRAW = [
  "our first date", "a long-distance hug", "your morning hair", "my laugh",
  "our dream house", "a jealous penguin", "a very angry croissant",
  "love at first sight", "a cat doing yoga", "our future pet",
  "blowing a kiss", "your happy dance", "a romantic dinner",
  "a heart with wifi", "time zones", "your good-morning text",
  "airport reunion", "a love letter", "a dragon in love",
  "cupid missing the shot", "a potato in love", "slow dancing", "our song",
  "a bear eating noodles", "a video call date", "a mermaid taking a selfie",
  "my worst habit", "a unicorn on a scooter", "our first photo together",
  "a sleepy koala", "a forehead kiss", "a robot falling in love",
  "a midnight snack run", "a crab at a wedding", "holding hands",
  "your dream car", "a llama in pajamas", "butterflies in the stomach",
  "a snail marathon", "our next vacation", "a dinosaur making pancakes",
  "the distance between us", "our inside joke", "breakfast in bed",
  "a proposal", "our wedding", "grandma driving a sports car",
  "a shy vampire", "sunday morning cuddles", "your work face",
  "a penguin waiter", "the moment we met", "a giraffe in a phone booth",
  "my phone addiction", "a superhero doing laundry", "our favourite meal",
  "a ghost on a date", "your victory dance", "a sloth in a hurry",
  "carrying all the groceries in one trip", "a dramatic movie kiss",
  "your alter ego", "a pigeon detective", "the face you make at my jokes",
  "a shark brushing its teeth", "our retirement plan",
  "a knight afraid of ducks", "your spirit vegetable", "double texting",
  "a wizard doing dishes", "the friday feeling", "a t-rex making the bed",
  "your camera roll", "an octopus juggling",
  "the last thing that made us laugh", "a cactus hug", "your happy place",
  "a frog prince", "monday vs friday", "a raccoon in a tuxedo",
  "the way you sleep", "a dumpling in love", "your signature pose",
  "an alien trying coffee", "us in 50 years", "a hamster bodybuilder",
  "the perfect pillow fort", "your loudest sneeze", "a duck in high heels",
];

const LIBS = [
  "The weirdest thing about you that I secretly love is ___.",
  "If we had a reality show it would be called ___.",
  "Your superpower is definitely ___.",
  "The first thing I'd do if I teleported to you right now is ___.",
  "Our love story in three words: ___.",
  "You + hunger = ___.",
  "If you were a snack you'd be ___.",
  "If we got arrested together it would be for ___.",
  "Your most-used phrase is ___.",
  "If you were a smell, you'd be ___.",
  "Our couple theme song should be ___.",
  "The award you deserve most: World's Best ___.",
  "Dating you is like ___ but with more snacks.",
  "In our zombie-apocalypse team, your job is ___.",
  "Your spirit animal is 100% ___.",
  "The cutest thing you do without realizing is ___.",
  "If I could shrink you and keep you in my pocket, I'd feed you ___.",
  "Our first date could be summarized as ___.",
  "You think you're great at ___, and honestly… sure.",
  "The emoji that describes you in the morning is ___.",
  "If you were a weather forecast: ___.",
  "I knew I liked you when ___.",
  "Your villain origin story would start with ___.",
  "The thing you'd bring to a deserted island is obviously ___.",
  "If distance were a person, I'd tell them ___.",
  "Your kiss rating comes with the note: ___.",
  "When you wear ___, I forget what I was saying.",
  "Our next date should absolutely involve ___.",
  "You're the only person who can make ___ look adorable.",
  "If we opened a shop together, we'd sell ___.",
  "Your phone is 90% ___.",
  "The sound you make when you laugh is basically ___.",
  "In a past life you were definitely ___.",
  "The best gift you ever gave me was ___ (feel free to lie).",
  "My heart does a little ___ when you call.",
  "One thing I'll never let you live down: ___.",
  "Your toxic trait is ___, and I say that with love.",
  "The government should study your ability to ___.",
  "Our couple costume this year: ___.",
  "You could sell out a stadium teaching people to ___.",
  "The romance novel about us would be titled ___.",
  "Your last brain cell spends most of its time ___.",
  "I'd trade my snacks for your ___ any day.",
  "Your morning voice sounds like ___.",
  "If cuddling were a sport, you'd be ___.",
  "The wifi gods gave us lag during ___, and I'll never forgive them.",
  "Your camera roll is mostly ___.",
  "In the museum of us, the main exhibit is ___.",
  "If I wrote your dating profile it would just say ___.",
  "Your superpower origin: bitten by a radioactive ___.",
  "The sequel to our first date would be rated ___.",
  "You'd survive exactly ___ minutes in a horror movie.",
  "My favourite notification is ___.",
  "If your hugs were a product, the warning label would say ___.",
  "Your energy today is very ___.",
  "Long distance taught me that ___.",
  "You dance like ___ and I love it.",
  "If we had a mascot, it would be ___.",
  "The smell of ___ is basically you in perfume form.",
  "Your most unhinged 3am message was about ___.",
  "If loving you burned calories, I'd have abs like ___.",
  "Our future pet's name will obviously be ___.",
  "You + a free afternoon = ___.",
  "The biggest scandal in our relationship: ___.",
  "Your laugh could power ___.",
  "When you call me ___, my brain stops working.",
  "If we robbed a bank, our getaway plan would be ___.",
  "Someday we'll look back at ___ and laugh.",
  "My favourite place in the world is ___ (hint: it's wherever you are, but be funnier).",
  "Your phone autocorrects 'love' to ___ because of us.",
];

// Truth or Dare — long-distance edition, addressed to the player on the spot.
const TRUTHS = [
  "What's the most attractive thing your partner does without realizing it?",
  "What did you really think the first time you saw your partner?",
  "What's one thing your partner does that you pretend to find annoying but secretly love?",
  "Describe your partner using only three words.",
  "What's the last thing you googled?",
  "What's a secret talent you've never shown your partner?",
  "When did you last cry, and why?",
  "What's the most trouble you got into as a kid?",
  "Which of your partner's outfits is your favourite?",
  "What song do you play when you miss your partner?",
  "What's the first thing you'd do if you woke up next to your partner tomorrow?",
  "What's one fear about the future you've never said out loud?",
  "What's the weirdest thing you've done while home alone?",
  "Who said 'I love you' first — and how scared were they?",
  "What's your favourite physical feature of your partner?",
  "What habit of yours does your partner tolerate heroically?",
  "What's the cheesiest thing you've ever done for love?",
  "If you could re-live one day with your partner, which one?",
  "What's something new you want to try together?",
  "What was your first impression of your partner's texting style?",
  "What's the pettiest reason you've ever been annoyed at your partner?",
  "What do you brag about your partner to other people?",
  "What's one thing you're still shy to ask for?",
  "Which fictional couple are you two?",
  "What's the best compliment your partner ever gave you?",
  "What's in your search history that you'd rather not explain?",
  "What do you daydream about when you miss your partner?",
  "What's one white lie you've told your partner? Come clean!",
  "What part of your daily routine is secretly all about your partner?",
  "What's the most romantic thing you've imagined for when you reunite?",
  "If your partner could read your mind for one hour, which hour would worry you?",
  "What nickname do you have for your partner in your head?",
  "What tiny detail about your partner do you hope never changes?",
  "What's the silliest thing that made you fall a little more in love?",
  "On a scale of 1-10, how good is your partner at flirting? Explain.",
  "What's one question you've always wanted to ask your partner? Ask it now.",
];

const DARES = [
  "Send a voice note singing the chorus of your song.",
  "Do your best impression of your partner right now.",
  "Text your partner a compliment using only emoji.",
  "Show the last five photos in your camera roll.",
  "Do 10 jumping jacks while saying your partner's name.",
  "Speak in an accent of your partner's choosing until your next turn.",
  "Send the most dramatic 'I miss you' voice note you can.",
  "Show your partner the view from your window right now.",
  "Draw a portrait of your partner in 30 seconds and show it.",
  "Dance with no music for 15 seconds.",
  "Write a two-line love poem on the spot.",
  "Let your partner pick your phone wallpaper for the next week.",
  "Send a selfie making the ugliest face you can.",
  "Reenact the moment you two met — playing both parts.",
  "Give a 30-second speech about why your partner is the best, infomercial style.",
  "Show the oldest photo of the two of you that you can find.",
  "Whisper something sweet like it's a big secret.",
  "Balance something on your head until your next turn.",
  "Send your partner the last meme you saved.",
  "Say 'I love you' in three different languages. Google fast!",
  "Do your best evil-villain laugh, full commitment.",
  "Show your partner today's outfit, head to toe, catwalk included.",
  "Blow your partner the most theatrical kiss possible.",
  "Read your last text out loud in a dramatic movie-trailer voice.",
  "Make up a 15-second song about how you met.",
  "Show the most chaotic corner of your room. No cleaning first.",
  "Try to lick your elbow. Really try.",
  "Set a reminder to send your partner something sweet tomorrow — show proof.",
  "Do your partner's most common gesture until they laugh.",
  "Narrate your next three actions like a nature documentary.",
  "Show your screen time report for today.",
  "Give your phone a tour of your fridge with commentary.",
  "Wink at the camera in slow motion, dead serious.",
  "Recreate your partner's profile picture and send the photo.",
  "Tell your best joke — if your partner doesn't laugh, tell another.",
  "Stand up and stretch dramatically like a rom-com morning scene.",
];

// Emoji Charades — things you can tell in emoji.
const EMOJI = [
  "Titanic", "Harry Potter", "Frozen", "The Lion King", "Finding Nemo",
  "Jurassic Park", "Spider-Man", "Batman", "Star Wars", "Shrek",
  "Squid Game", "Cinderella", "pizza delivery", "morning coffee",
  "beach vacation", "road trip", "first kiss", "wedding day",
  "grocery shopping", "gym workout", "karaoke night", "camping trip",
  "rainy day", "snowball fight", "birthday cake", "movie night",
  "video call", "airport reunion", "breakfast in bed", "midnight snack",
  "love letter", "online shopping", "traffic jam", "monday morning",
  "dance party", "ice cream date", "haircut disaster", "cooking together",
  "stargazing", "bubble bath", "laundry day", "food coma",
  "brain freeze", "butterflies in the stomach", "long distance",
  "honeymoon", "sleepover", "power nap",
];

const ROUNDS = { know: 8, tot: 10, draw: 4, libs: 5, ttl: 4, emoji: 5, tod: 6 };
const GAMES = ["know", "tot", "draw", "libs", "ttl", "emoji", "tod"];
const MAX_STROKES = 250;
const MAX_STROKE_PTS = 128; // flattened x,y pairs => 64 points
const MAX_GUESSES = 60;

// -------------------------------------------------------------- helpers ---

function other(state, pid) {
  return state.players[0] === pid ? state.players[1] : state.players[0];
}

// Rooms created before a deck existed have no used-list for it — default it.
function usedOf(state, key) {
  return (state.used && state.used[key]) || [];
}

function pickIdx(used, len) {
  let avail = [];
  for (let i = 0; i < len; i++) if (!used.includes(i)) avail.push(i);
  if (avail.length === 0) {
    used = [];
    for (let i = 0; i < len; i++) avail.push(i);
  }
  const idx = avail[Math.floor(Math.random() * avail.length)];
  return { idx, used: [...used, idx] };
}

// Personalize a KNOW template for one viewer.
function qFor(tpl, viewer, subject, state) {
  const partner = other(state, subject);
  const partnerName = viewer === partner ? "you" : (state.names[partner] || "them");
  if (viewer === subject) {
    return tpl
      .replace(/does \{N\}/g, "do you")
      .replace(/is \{N\}/g, "are you")
      .replace(/was \{N\}/g, "were you")
      .replace(/has \{N\}/g, "have you")
      .replace(/\{N\} was/g, "you were")
      .replace(/\{P\}/g, "your")
      .replace(/\{N\}/g, "you")
      .replace(/\{Y\}/g, partnerName);
  }
  const n = state.names[subject] || "them";
  return tpl
    .replace(/\{P\}/g, n + "'s")
    .replace(/\{N\}/g, n)
    .replace(/\{Y\}/g, partnerName);
}

function norm(s) {
  return String(s).toLowerCase().replace(/[^a-z0-9À-ɏऀ-ॿ]/g, "");
}

function startRound(state, round) {
  const s = { ...state, round, last: state.last };
  if (s.game === "know") {
    const { idx, used } = pickIdx(s.used.know, KNOW.length);
    s.used = { ...s.used, know: used };
    s.phase = "know_answer";
    s.g = { qi: idx, subject: s.players[(round - 1) % 2], answers: {} };
  } else if (s.game === "tot") {
    const { idx, used } = pickIdx(s.used.tot, TOT.length);
    s.used = { ...s.used, tot: used };
    s.phase = "tot_pick";
    s.g = { qi: idx, picks: {} };
  } else if (s.game === "draw") {
    let used = s.used.draw;
    const options = [];
    for (let i = 0; i < 3; i++) {
      const r = pickIdx(used, DRAW.length);
      used = r.used;
      options.push(r.idx);
    }
    s.used = { ...s.used, draw: used };
    s.phase = "draw_pick";
    s.g = { drawer: s.players[(round - 1) % 2], options };
  } else if (s.game === "libs") {
    const { idx, used } = pickIdx(s.used.libs, LIBS.length);
    s.used = { ...s.used, libs: used };
    s.phase = "libs_write";
    s.g = { qi: idx, texts: {} };
  } else if (s.game === "ttl") {
    s.phase = "ttl_write";
    s.g = { writer: s.players[(round - 1) % 2] };
  } else if (s.game === "emoji") {
    let used = usedOf(s, "emoji");
    const options = [];
    for (let i = 0; i < 3; i++) {
      const r = pickIdx(used, EMOJI.length);
      used = r.used;
      options.push(r.idx);
    }
    s.used = { ...s.used, emoji: used };
    s.phase = "emoji_pick";
    s.g = { typist: s.players[(round - 1) % 2], options };
  } else if (s.game === "tod") {
    s.phase = "tod_choose";
    s.g = { who: s.players[(round - 1) % 2] };
  }
  return s;
}

function addScore(state, pid, pts) {
  return {
    scores: { ...state.scores, [pid]: state.scores[pid] + pts },
    earned: { ...state.earned, [pid]: (state.earned[pid] || 0) + pts },
  };
}

function finishDraw(state, playerId, outcome, matchedGuess) {
  const drawer = state.g.drawer;
  const guesser = other(state, drawer);
  let s = { ...state };
  if (outcome !== "skipped") {
    s = { ...s, ...addScore(s, guesser, 3) };
    s = { ...s, ...addScore(s, drawer, 2) };
    s.sync = s.sync + 2;
    s.esync = s.esync + 2;
  }
  s.last = {
    game: "draw",
    word: DRAW[state.g.wordIdx],
    outcome,
    matchedGuess: matchedGuess || null,
    strokes: state.g.strokes,
    drawer,
  };
  s.phase = "draw_result";
  s.g = { drawer };
  return s;
}

function finishEmoji(state, outcome, matchedGuess) {
  const typist = state.g.typist;
  const guesser = other(state, typist);
  let s = { ...state };
  if (outcome !== "skipped") {
    s = { ...s, ...addScore(s, guesser, 3) };
    s = { ...s, ...addScore(s, typist, 2) };
    s.sync = s.sync + 2;
    s.esync = s.esync + 2;
  }
  s.last = {
    game: "emoji",
    word: EMOJI[state.g.wordIdx],
    outcome,
    matchedGuess: matchedGuess || null,
    emoji: state.g.emoji,
    typist,
  };
  s.phase = "emoji_result";
  s.g = { typist };
  return s;
}

// ------------------------------------------------------------- contract ---

export function setup(players) {
  return {
    players: [...players],
    names: {},
    scores: { [players[0]]: 0, [players[1]]: 0 },
    sync: 0,
    hearts: 0,
    phase: "names",
    game: null,
    round: 0,
    roundsTotal: 0,
    earned: {},
    esync: 0,
    used: { know: [], tot: [], draw: [], libs: [], emoji: [], truth: [], dare: [] },
    g: {},
    last: null,
  };
}

export function validateAction(state, playerId, action) {
  if (!action || typeof action.type !== "string") {
    return { ok: false, error: "That didn't work — try again." };
  }
  if (!state.players.includes(playerId)) {
    return { ok: false, error: "You're spectating — the lovebirds have both seats." };
  }
  const t = action.type;
  const ph = state.phase;

  if (t === "name") {
    if (ph !== "names") return { ok: false, error: "Names are already set." };
    const n = typeof action.name === "string" ? action.name.trim() : "";
    if (!n) return { ok: false, error: "Type a name first!" };
    if (n.length > 20) return { ok: false, error: "Keep your name under 20 characters." };
    return { ok: true };
  }
  if (ph === "names") return { ok: false, error: "Pick your names first!" };

  if (t === "menu") return { ok: true };

  if (t === "pick") {
    if (ph !== "menu") return { ok: false, error: "You're already in a game." };
    if (!GAMES.includes(action.game)) return { ok: false, error: "Pick one of the four games." };
    return { ok: true };
  }

  if (t === "next") {
    const okPhases = ["know_result", "tot_reveal", "draw_result", "libs_result",
      "ttl_result", "emoji_result", "tod_result", "gameend"];
    if (!okPhases.includes(ph)) return { ok: false, error: "Nothing to skip right now." };
    return { ok: true };
  }

  if (t === "more") {
    if (ph !== "gameend") return { ok: false, error: "Finish the game first!" };
    return { ok: true };
  }

  if (t === "answer") {
    if (ph !== "know_answer") return { ok: false, error: "No question is open right now." };
    if (state.g.answers[playerId] !== undefined) return { ok: false, error: "You already answered — waiting for your partner." };
    const txt = typeof action.text === "string" ? action.text.trim() : "";
    if (!txt) return { ok: false, error: "Write something first!" };
    if (txt.length > 120) return { ok: false, error: "Keep it under 120 characters." };
    return { ok: true };
  }

  if (t === "verdict") {
    if (ph !== "know_judge") return { ok: false, error: "Nothing to judge right now." };
    if (playerId !== state.g.subject) return { ok: false, error: "Only the person the question is about can judge." };
    if (!["spot", "close", "nope"].includes(action.v)) return { ok: false, error: "Pick a verdict." };
    return { ok: true };
  }

  if (t === "choose") {
    if (ph !== "tot_pick") return { ok: false, error: "Nothing to choose right now." };
    if (state.g.picks[playerId] !== undefined) return { ok: false, error: "Locked in — waiting for your partner." };
    if (action.side !== "a" && action.side !== "b") return { ok: false, error: "Pick a side." };
    return { ok: true };
  }

  if (t === "pickPrompt") {
    if (ph !== "draw_pick" && ph !== "emoji_pick") return { ok: false, error: "No prompts to pick right now." };
    const owner = ph === "draw_pick" ? state.g.drawer : state.g.typist;
    if (playerId !== owner) return { ok: false, error: "Your partner picks this one." };
    if (![0, 1, 2].includes(action.i)) return { ok: false, error: "Pick one of the three prompts." };
    return { ok: true };
  }

  if (t === "stroke") {
    if (ph !== "draw_play") return { ok: false, error: "No drawing in progress." };
    if (playerId !== state.g.drawer) return { ok: false, error: "Only the artist can draw." };
    if (state.g.strokes.length >= MAX_STROKES) return { ok: false, error: "The canvas is full — time to reveal!" };
    const p = action.pts;
    if (!Array.isArray(p) || p.length < 4 || p.length > MAX_STROKE_PTS || p.length % 2 !== 0) {
      return { ok: false, error: "Bad stroke." };
    }
    for (const v of p) {
      if (!Number.isInteger(v) || v < 0 || v > 1000) return { ok: false, error: "Bad stroke." };
    }
    if (![0, 1, 2, 3, 4, 5].includes(action.c)) return { ok: false, error: "Bad colour." };
    if (![0, 1, 2].includes(action.w)) return { ok: false, error: "Bad brush." };
    return { ok: true };
  }

  if (t === "undo" || t === "clearCanvas") {
    if (ph !== "draw_play") return { ok: false, error: "No drawing in progress." };
    if (playerId !== state.g.drawer) return { ok: false, error: "Only the artist can edit the drawing." };
    return { ok: true };
  }

  if (t === "guess") {
    if (ph !== "draw_play" && ph !== "emoji_play") return { ok: false, error: "Nothing to guess right now." };
    const owner = ph === "draw_play" ? state.g.drawer : state.g.typist;
    if (playerId === owner) return { ok: false, error: "No guessing your own puzzle!" };
    const txt = typeof action.text === "string" ? action.text.trim() : "";
    if (!txt) return { ok: false, error: "Type a guess first!" };
    if (txt.length > 60) return { ok: false, error: "Keep guesses short." };
    if (state.g.guesses.length >= MAX_GUESSES) return { ok: false, error: "So many guesses! Maybe tap 'they got it' or 'give up'." };
    return { ok: true };
  }

  if (t === "reveal" || t === "skip") {
    if (ph !== "draw_play" && ph !== "emoji_play") return { ok: false, error: "No round in progress." };
    const owner = ph === "draw_play" ? state.g.drawer : state.g.typist;
    if (playerId !== owner) return { ok: false, error: "Only the clue-giver can end the round." };
    return { ok: true };
  }

  if (t === "emojiSet") {
    if (ph !== "emoji_play") return { ok: false, error: "No emoji round in progress." };
    if (playerId !== state.g.typist) return { ok: false, error: "Only the storyteller types emoji." };
    const txt = typeof action.text === "string" ? action.text.trim() : "";
    if (txt.length > 80) return { ok: false, error: "Keep it under 80 characters of emoji." };
    if (/[a-zA-Z0-9]/.test(txt)) return { ok: false, error: "Emoji only — no letters or numbers, sneaky!" };
    return { ok: true };
  }

  if (t === "ttl") {
    if (ph !== "ttl_write") return { ok: false, error: "No statements to write right now." };
    if (playerId !== state.g.writer) return { ok: false, error: "Your partner writes this round — get ready to spot the lie." };
    const arr = action.t;
    if (!Array.isArray(arr) || arr.length !== 3) return { ok: false, error: "Write all three statements." };
    for (const s of arr) {
      if (typeof s !== "string" || !s.trim()) return { ok: false, error: "Write all three statements." };
      if (s.trim().length > 100) return { ok: false, error: "Keep each statement under 100 characters." };
    }
    if (![0, 1, 2].includes(action.lie)) return { ok: false, error: "Mark which one is the lie." };
    return { ok: true };
  }

  if (t === "ttlPick") {
    if (ph !== "ttl_guess") return { ok: false, error: "Nothing to pick right now." };
    if (playerId === state.g.writer) return { ok: false, error: "You wrote them — no picking!" };
    if (![0, 1, 2].includes(action.i)) return { ok: false, error: "Pick one of the three." };
    return { ok: true };
  }

  if (t === "todKind") {
    if (ph !== "tod_choose") return { ok: false, error: "Not your moment to choose." };
    if (playerId !== state.g.who) return { ok: false, error: "It's your partner's turn on the hot seat." };
    if (action.k !== "truth" && action.k !== "dare") return { ok: false, error: "Truth or dare?" };
    return { ok: true };
  }

  if (t === "todJudge") {
    if (ph !== "tod_do") return { ok: false, error: "Nothing to judge right now." };
    if (playerId === state.g.who) return { ok: false, error: "Your partner decides if you did it!" };
    if (typeof action.did !== "boolean") return { ok: false, error: "Did they do it or not?" };
    return { ok: true };
  }

  if (t === "write") {
    if (ph !== "libs_write") return { ok: false, error: "No blank to fill right now." };
    if (state.g.texts[playerId] !== undefined) return { ok: false, error: "Submitted — waiting for your partner." };
    const txt = typeof action.text === "string" ? action.text.trim() : "";
    if (!txt) return { ok: false, error: "Fill in the blank first!" };
    if (txt.length > 140) return { ok: false, error: "Keep it under 140 characters." };
    return { ok: true };
  }

  if (t === "rate") {
    if (ph !== "libs_rate") return { ok: false, error: "Nothing to rate right now." };
    if (state.g.rates && state.g.rates[playerId] !== undefined) return { ok: false, error: "Rated — waiting for your partner." };
    if (![1, 2, 3].includes(action.n)) return { ok: false, error: "Give 1 to 3 hearts." };
    return { ok: true };
  }

  return { ok: false, error: "Unknown move." };
}

export function applyAction(state, playerId, action) {
  const t = action.type;

  if (t === "name") {
    const names = { ...state.names, [playerId]: action.name.trim() };
    const both = state.players.every((p) => names[p]);
    return { ...state, names, phase: both ? "menu" : "names" };
  }

  if (t === "menu") {
    return { ...state, phase: "menu", game: null, round: 0, roundsTotal: 0, g: {}, last: null, earned: {}, esync: 0 };
  }

  if (t === "pick") {
    const s = {
      ...state,
      game: action.game,
      roundsTotal: ROUNDS[action.game],
      earned: { [state.players[0]]: 0, [state.players[1]]: 0 },
      esync: 0,
      last: null,
    };
    return startRound(s, 1);
  }

  if (t === "next") {
    if (state.phase === "gameend") {
      return { ...state, phase: "menu", game: null, round: 0, roundsTotal: 0, g: {}, last: null };
    }
    if (state.round < state.roundsTotal) {
      return startRound({ ...state, last: null }, state.round + 1);
    }
    return { ...state, phase: "gameend", g: {}, last: null };
  }

  if (t === "more") {
    const extra = ROUNDS[state.game] || 4;
    return startRound(
      { ...state, roundsTotal: state.roundsTotal + extra, last: null },
      state.round + 1,
    );
  }

  if (t === "answer") {
    const answers = { ...state.g.answers, [playerId]: action.text.trim() };
    const both = state.players.every((p) => answers[p] !== undefined);
    return { ...state, g: { ...state.g, answers }, phase: both ? "know_judge" : "know_answer" };
  }

  if (t === "verdict") {
    const subject = state.g.subject;
    const guesser = other(state, subject);
    const pts = action.v === "spot" ? 3 : action.v === "close" ? 1 : 0;
    const syncPts = action.v === "spot" ? 2 : action.v === "close" ? 1 : 0;
    let s = { ...state };
    s = { ...s, ...addScore(s, guesser, pts) };
    s.sync += syncPts;
    s.esync += syncPts;
    s.last = {
      game: "know",
      qi: state.g.qi,
      subject,
      truth: state.g.answers[subject],
      guess: state.g.answers[guesser],
      verdict: action.v,
      pts,
    };
    return { ...s, phase: "know_result", g: {} };
  }

  if (t === "choose") {
    const picks = { ...state.g.picks, [playerId]: action.side };
    const [p1, p2] = state.players;
    if (picks[p1] === undefined || picks[p2] === undefined) {
      return { ...state, g: { ...state.g, picks } };
    }
    const match = picks[p1] === picks[p2];
    let s = { ...state };
    if (match) {
      s = { ...s, ...addScore(s, p1, 1) };
      s = { ...s, ...addScore(s, p2, 1) };
      s.sync += 2;
      s.esync += 2;
    }
    s.last = { game: "tot", qi: state.g.qi, picks, match };
    return { ...s, phase: "tot_reveal", g: {} };
  }

  if (t === "pickPrompt") {
    if (state.phase === "emoji_pick") {
      return {
        ...state,
        phase: "emoji_play",
        g: { typist: state.g.typist, wordIdx: state.g.options[action.i], emoji: "", guesses: [] },
      };
    }
    return {
      ...state,
      phase: "draw_play",
      g: { drawer: state.g.drawer, wordIdx: state.g.options[action.i], strokes: [], guesses: [] },
    };
  }

  if (t === "emojiSet") {
    return { ...state, g: { ...state.g, emoji: action.text.trim() } };
  }

  if (t === "stroke") {
    const strokes = [...state.g.strokes, { p: action.pts, c: action.c, w: action.w }];
    return { ...state, g: { ...state.g, strokes } };
  }

  if (t === "undo") {
    return { ...state, g: { ...state.g, strokes: state.g.strokes.slice(0, -1) } };
  }

  if (t === "clearCanvas") {
    return { ...state, g: { ...state.g, strokes: [] } };
  }

  if (t === "guess") {
    const isEmoji = state.phase === "emoji_play";
    const txt = action.text.trim();
    const guesses = [...state.g.guesses, txt].slice(-MAX_GUESSES);
    const target = norm((isEmoji ? EMOJI : DRAW)[state.g.wordIdx]);
    const g = norm(txt);
    const hit = g.length > 0 && (g === target || (g.length >= 4 && g.includes(target)) || (target.length >= 4 && target.includes(g) && g.length >= target.length - 1));
    const s = { ...state, g: { ...state.g, guesses } };
    if (hit) return isEmoji ? finishEmoji(s, "guessed", txt) : finishDraw(s, playerId, "guessed", txt);
    return s;
  }

  if (t === "reveal" || t === "skip") {
    const outcome = t === "reveal" ? "confirmed" : "skipped";
    if (state.phase === "emoji_play") return finishEmoji(state, outcome, null);
    return finishDraw(state, playerId, outcome, null);
  }

  if (t === "ttl") {
    return {
      ...state,
      phase: "ttl_guess",
      g: { writer: state.g.writer, t: action.t.map((x) => x.trim()), lie: action.lie },
    };
  }

  if (t === "ttlPick") {
    const writer = state.g.writer;
    const guesser = other(state, writer);
    const correct = action.i === state.g.lie;
    let s = { ...state };
    if (correct) {
      s = { ...s, ...addScore(s, guesser, 3) };
      s.sync += 1;
      s.esync += 1;
    } else {
      s = { ...s, ...addScore(s, writer, 2) };
    }
    s.last = { game: "ttl", t: state.g.t, lie: state.g.lie, pick: action.i, correct, writer };
    return { ...s, phase: "ttl_result", g: {} };
  }

  if (t === "todKind") {
    const deckKey = action.k; // "truth" | "dare"
    const deck = deckKey === "truth" ? TRUTHS : DARES;
    const { idx, used } = pickIdx(usedOf(state, deckKey), deck.length);
    return {
      ...state,
      used: { ...state.used, [deckKey]: used },
      phase: "tod_do",
      g: { who: state.g.who, kind: deckKey, qi: idx },
    };
  }

  if (t === "todJudge") {
    const who = state.g.who;
    let s = { ...state };
    if (action.did) {
      s = { ...s, ...addScore(s, who, 2) };
      s.sync += 1;
      s.esync += 1;
    }
    s.last = { game: "tod", kind: state.g.kind, qi: state.g.qi, who, did: action.did };
    return { ...s, phase: "tod_result", g: {} };
  }

  if (t === "write") {
    const texts = { ...state.g.texts, [playerId]: action.text.trim() };
    const both = state.players.every((p) => texts[p] !== undefined);
    if (!both) return { ...state, g: { ...state.g, texts } };
    return { ...state, phase: "libs_rate", g: { qi: state.g.qi, texts, rates: {} } };
  }

  if (t === "rate") {
    const rates = { ...state.g.rates, [playerId]: action.n };
    const [p1, p2] = state.players;
    if (rates[p1] === undefined || rates[p2] === undefined) {
      return { ...state, g: { ...state.g, rates } };
    }
    // Each player earns the hearts the OTHER gave them.
    let s = { ...state };
    s = { ...s, ...addScore(s, p1, rates[p2]) };
    s = { ...s, ...addScore(s, p2, rates[p1]) };
    s.hearts += rates[p1] + rates[p2];
    s.last = { game: "libs", qi: state.g.qi, texts: state.g.texts, rates };
    return { ...s, phase: "libs_result", g: {} };
  }

  return state;
}

export function isGameOver(_state) {
  // The room is a hangout: mini-games end internally, the session never does.
  return { over: false };
}

export function viewFor(state, pid) {
  const seated = state.players.includes(pid);
  const v = {
    phase: state.phase,
    game: state.game,
    round: state.round,
    roundsTotal: state.roundsTotal,
    players: state.players,
    names: state.names,
    scores: state.scores,
    sync: state.sync,
    hearts: state.hearts,
    earned: state.earned,
    esync: state.esync,
  };

  // Resolved last-round summary — personalize KNOW question text per viewer.
  if (state.last) {
    v.last = { ...state.last };
    if (v.last.game === "know") {
      v.last.q = qFor(KNOW[v.last.qi], pid, v.last.subject, state);
      delete v.last.qi;
    } else if (v.last.game === "tot") {
      const e = TOT[v.last.qi];
      v.last.kind = e.k;
      if (e.k === "p") { v.last.a = e.a; v.last.b = e.b; }
      else {
        v.last.q = e.q;
        v.last.a = state.names[state.players[0]] || "Player 1";
        v.last.b = state.names[state.players[1]] || "Player 2";
      }
      delete v.last.qi;
    } else if (v.last.game === "libs") {
      v.last.prompt = LIBS[v.last.qi];
      delete v.last.qi;
    } else if (v.last.game === "tod") {
      v.last.prompt = (v.last.kind === "truth" ? TRUTHS : DARES)[v.last.qi];
      delete v.last.qi;
    }
  } else {
    v.last = null;
  }

  const ph = state.phase;

  if (ph === "names") {
    v.named = {};
    for (const p of state.players) v.named[p] = !!state.names[p];
  }

  if (ph === "know_answer") {
    v.subject = state.g.subject;
    v.q = qFor(KNOW[state.g.qi], pid, state.g.subject, state);
    v.submitted = {};
    for (const p of state.players) v.submitted[p] = state.g.answers[p] !== undefined;
    if (seated && state.g.answers[pid] !== undefined) v.myAnswer = state.g.answers[pid];
  }

  if (ph === "know_judge") {
    v.subject = state.g.subject;
    v.q = qFor(KNOW[state.g.qi], pid, state.g.subject, state);
    v.answers = state.g.answers; // both submitted: reveal to everyone
  }

  if (ph === "tot_pick") {
    const e = TOT[state.g.qi];
    v.kind = e.k;
    if (e.k === "p") { v.a = e.a; v.b = e.b; }
    else {
      v.q = e.q;
      v.a = state.names[state.players[0]] || "Player 1";
      v.b = state.names[state.players[1]] || "Player 2";
    }
    v.submitted = {};
    for (const p of state.players) v.submitted[p] = state.g.picks[p] !== undefined;
    if (seated && state.g.picks[pid] !== undefined) v.myPick = state.g.picks[pid];
  }

  if (ph === "draw_pick") {
    v.drawer = state.g.drawer;
    if (pid === state.g.drawer) v.options = state.g.options.map((i) => DRAW[i]);
  }

  if (ph === "draw_play") {
    v.drawer = state.g.drawer;
    v.strokes = state.g.strokes;
    v.guesses = state.g.guesses;
    if (pid === state.g.drawer) v.word = DRAW[state.g.wordIdx];
    else v.hint = DRAW[state.g.wordIdx].replace(/[^ ]/g, "•");
  }

  if (ph === "libs_write") {
    v.prompt = LIBS[state.g.qi];
    v.submitted = {};
    for (const p of state.players) v.submitted[p] = state.g.texts[p] !== undefined;
    if (seated && state.g.texts[pid] !== undefined) v.myText = state.g.texts[pid];
  }

  if (ph === "ttl_write") {
    v.writer = state.g.writer;
  }

  if (ph === "ttl_guess") {
    v.writer = state.g.writer;
    v.statements = state.g.t;
    if (pid === state.g.writer) v.lie = state.g.lie; // guesser must never see this
  }

  if (ph === "emoji_pick") {
    v.typist = state.g.typist;
    if (pid === state.g.typist) v.options = state.g.options.map((i) => EMOJI[i]);
  }

  if (ph === "emoji_play") {
    v.typist = state.g.typist;
    v.emoji = state.g.emoji;
    v.guesses = state.g.guesses;
    if (pid === state.g.typist) v.word = EMOJI[state.g.wordIdx];
    else v.hint = EMOJI[state.g.wordIdx].replace(/[^ ]/g, "•");
  }

  if (ph === "tod_choose") {
    v.who = state.g.who;
  }

  if (ph === "tod_do") {
    v.who = state.g.who;
    v.kind = state.g.kind;
    v.prompt = (state.g.kind === "truth" ? TRUTHS : DARES)[state.g.qi];
  }

  if (ph === "libs_rate") {
    v.prompt = LIBS[state.g.qi];
    v.texts = state.g.texts;
    v.rated = {};
    for (const p of state.players) v.rated[p] = state.g.rates[p] !== undefined;
    if (seated && state.g.rates[pid] !== undefined) v.myRate = state.g.rates[pid];
  }

  return v;
}
