import java.awt.Color;
//Your personal creative design CPU paddle, which incorporates
//some unique AI behaviors and/or mechanics.
//You will outline the details of this Paddle in your submitted readme file!

public class CPUCreative extends CPUStandard{//This can extend CPUStandard, CPUSmart, or CPUPaddle...
                                             // you decide what's best per your design!
   


   //a reference to the Human paddle opponent this paddle is facing off against 
   //Your creative CPU paddle may or may not use this depending on the design of 
   //your paddle... its up to you!                         
   private Human opponent;
   private int count;

   public static final Color[] CPU_CREATIVE_PADDLE_COLORS = {Color.yellow, Color.blue};
   
               
   //****************   CONSTRUCTORS  *************   
   public CPUCreative(){
      this(null);
   }


   public CPUCreative(Human opponent){
      super();
      this.opponent = opponent;
      count=0;
   }



   //Called automatically whenever EITHER paddle (Human or CPU) scores a point.
   //argument indicates if it was the CPU who scored (true) or the human (false).
   public void reactToScore(boolean didCPUScore){
         if(didCPUScore)
            this.score++;
         else
            this.setSpeed(CPU_STAND_PADDLE_SPEED);
   }


   //Called automatically whenver the ball collides with this paddle
   public void reactToVolley(){
      this.setSpeed(opponent.getSpeed()+0.5);
      if(count<=CPU_CREATIVE_PADDLE_COLORS.length-2)
            count++;
         else
            count=0;
         this.setColor(CPU_CREATIVE_PADDLE_COLORS[count]);
   }





   //******************************************************************************
   //Determine how the paddle should move when the ball is moving left or right with
   //the argument coordinates/velocities.
   //Returns -1, 0, or 1 if paddle should move up, neutral, or down, respectively.
   //
   //arguments include (in order):
   //bX, bY: the ball's current x and y coordinates
   //bXVel, bYVel: the ball's current x and y velocities
   protected int decideMoveBallGoingLeft(double bX, double bY, double bXVel, double bYVel){

      double paddleY=this.getY();
      double windowHeight=this.getWindowHeight();

      if(Math.abs((windowHeight/2.0)-paddleY)<MOVE_THRESHOLD)
            return MOVE_NEUTRAL;
      else if(paddleY<bY)
            return MOVE_DOWN;
      return MOVE_UP;
   }


   protected int decideMoveBallGoingRight(double bX, double bY, double bXVel, double bYVel){

      //**  This method has a bug... find and fix it!  **

      double paddleY = this.getY();

      if (Math.abs(bY - paddleY) < MOVE_THRESHOLD)
         return MOVE_NEUTRAL;
      else if (paddleY < bY)
         return MOVE_DOWN;
      return MOVE_UP;
   }
   //******************************************************************************

 
   
}
