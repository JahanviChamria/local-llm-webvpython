   // Each DinnerReservation object represents a party's reservation at 
   // a restaurant

   public class DinnerReservation {
      
     
     
      //Name on the reservation; must be at least 5 chars long w/ 1 space
      private String name;
      //Hour the reservation is for, PM. We only take reservations on the hour; no minutes
      private int hour;
      //Number of adults and children in the party. 
      //All Reservations must have at least 1 adult and 10 total people max
      private int adults, children;

      public static final int MIN_NAME_LENGTH=5;
      public static final String DEFAULT_NAME="Unknown Guest";
      public static final int MAX_GUESTS=10;
      public static final int DEFAULT_ADULTS=2;
      public static final int MIN_HOUR=4;
      public static final int MAX_HOUR=9;
      public static final int START_MIN=75;
      public static final int CHILD_MIN=10;
      public static final int ADULT_MIN=15;
      


      public DinnerReservation(String name, int hour, int adults, int children){       
            if(name.length()<MIN_NAME_LENGTH || name.indexOf(' ')==-1)
                  this.name = DEFAULT_NAME;
            else
                  this.name=name;
            if(adults<=0 || children<0 || (adults+children)>MAX_GUESTS){
                  this.adults=DEFAULT_ADULTS;
                  this.children=0;
            }
            else{
                  this.adults = adults;
                  this.children = children;
            }
            if(hour<MIN_HOUR || hour>MAX_HOUR)
                  this.hour=MIN_HOUR;
            else
                  this.hour = hour;
      }
      

      //Implement me for Part 3.2.2!
      public int estimateDiningTime(){
            int minutes=(START_MIN+(CHILD_MIN*children)+(ADULT_MIN*(adults-2)));
            if(children>adults)
                  minutes+=ADULT_MIN;
            return minutes;
      }


      //Implement me for Part 3.2.4!
      public boolean overlapsWith(DinnerReservation other){
         DinnerReservation earlier;
         DinnerReservation later;
         if(this.hour<other.hour){
            earlier=this;
            later=other;
         }
         else if(this.hour>other.hour){
            earlier=other;
            later=this;
         }
         else
            return true; //reservation at the same time
         int differenceMin=(later.hour-earlier.hour)*60;
         if(differenceMin>=earlier.estimateDiningTime())
            return false;
         else
            return true;
      }








   //Accessor methods------------
      public String getName(){
         return this.name;
   }
      
   public int getHour(){
         return this.hour;
   }

   public int getAdults(){
         return this.adults;      
   }

   public int getChildren(){
         return this.children;
   }
   //----------------------------

      public String toString(){
         return "Reservation for " + this.name + " at " + this.hour + ":00PM (" +  
                this.adults + " adults, " + this.children + " children)";
      }




   }
