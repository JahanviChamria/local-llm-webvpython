class Post:
    pass