import { Badge, Card, MasteryItem } from "@/components/portal/primitives";
import type { StudentProfile } from "@/lib/portal/profile";
import type { AccessibleLab } from "@/lib/portal/accessible-labs";

function levelLabel(level: number): string {
  if (level >= 5) return "Level 5 · mastered";
  if (level >= 4) return "Level 4 · strong";
  if (level >= 3) return "Level 3 · improving";
  if (level >= 1) return `Level ${level} · review`;
  return "Level 0 · new";
}

function masteryState(level: number): "mastered" | "review" | undefined {
  if (level >= 4) return "mastered";
  if (level < 2) return "review";
  return undefined;
}

function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

// "root_concepts" / "primaryMode" → "Root concepts". Field keys come straight
// from the GPT JSON, so normalize snake_case and camelCase into one readable
// label rather than hard-coding a lookup that drifts as the schema grows.
function humanizeKey(key: string): string {
  const spaced = key.replace(/[_-]+/g, " ").replace(/([a-z0-9])([A-Z])/g, "$1 $2");
  return spaced.charAt(0).toUpperCase() + spaced.slice(1).toLowerCase();
}

function Chips({ items }: { items: Array<string | number> }) {
  return (
    <div className="row wrap" style={{ gap: 6 }}>
      {items.map((it, i) => (
        <Badge key={i}>{String(it)}</Badge>
      ))}
    </div>
  );
}

// Longer, sentence-like array items (e.g. struggles) render as a bulleted list
// rather than non-wrapping pills that would overflow.
function BulletList({ items }: { items: Array<string | number> }) {
  return (
    <ul style={{ margin: 0, paddingLeft: 18, fontSize: 13, lineHeight: 1.5 }}>
      {items.map((it, i) => (
        <li key={i}>{String(it)}</li>
      ))}
    </ul>
  );
}

// Mind-map edges look like { from, to, relationship }. Render them as a compact
// "a → b · relationship" line instead of a nested object dump.
function ConnectionRow({ c }: { c: Record<string, unknown> }) {
  const from = c.from ?? c.source;
  const to = c.to ?? c.target;
  const rel = c.relationship ?? c.type ?? c.label;
  return (
    <div style={{ fontSize: 13 }}>
      <span>{String(from ?? "?")}</span>
      <span className="muted"> → </span>
      <span>{String(to ?? "?")}</span>
      {rel != null && rel !== "" && (
        <span className="muted" style={{ fontSize: 12 }}> · {String(rel)}</span>
      )}
    </div>
  );
}

const isConnection = (v: unknown): v is Record<string, unknown> =>
  isRecord(v) && ("from" in v || "to" in v || "source" in v || "target" in v);

function ProfileValue({ value }: { value: unknown }) {
  if (value === null || value === undefined || value === "") {
    return <span className="muted" style={{ fontSize: 13 }}>—</span>;
  }
  if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
    return <span style={{ fontSize: 13, lineHeight: 1.5 }}>{String(value)}</span>;
  }
  if (Array.isArray(value)) {
    if (value.length === 0) return <span className="muted" style={{ fontSize: 13 }}>none</span>;
    if (value.every((v) => typeof v === "string" || typeof v === "number")) {
      const items = value as Array<string | number>;
      // Short tokens → chips; sentence-length items → bulleted list.
      const allShort = items.every((v) => typeof v === "number" || v.length <= 28);
      return allShort ? <Chips items={items} /> : <BulletList items={items} />;
    }
    if (value.every(isConnection)) {
      return (
        <div className="col" style={{ gap: 4 }}>
          {value.map((c, i) => (
            <ConnectionRow key={i} c={c as Record<string, unknown>} />
          ))}
        </div>
      );
    }
    return (
      <div className="col" style={{ gap: 10 }}>
        {value.map((v, i) => (
          <ProfileValue key={i} value={v} />
        ))}
      </div>
    );
  }
  if (isRecord(value)) return <ProfileFields obj={value} />;
  return <span style={{ fontSize: 13 }}>{String(value)}</span>;
}

function ProfileFields({ obj }: { obj: Record<string, unknown> }) {
  const entries = Object.entries(obj);
  if (entries.length === 0) {
    return <p className="muted" style={{ fontSize: 13, margin: 0 }}>Nothing here yet.</p>;
  }
  return (
    <div className="col" style={{ gap: 12 }}>
      {entries.map(([key, val]) => (
        <div key={key}>
          <div className="label" style={{ marginBottom: 5 }}>{humanizeKey(key)}</div>
          <ProfileValue value={val} />
        </div>
      ))}
    </div>
  );
}

// Structured render of one GPT JSONB column: labeled fields, string arrays as
// chips, mind-map connections as "a → b" rows, with the raw JSON tucked behind a
// toggle for debugging.
function JsonBlock({ value }: { value: Record<string, unknown> }) {
  const isEmpty = !value || Object.keys(value).length === 0;
  if (isEmpty) {
    return <p className="muted" style={{ fontSize: 13, margin: 0 }}>Nothing here yet.</p>;
  }
  return (
    <div className="col" style={{ gap: 12 }}>
      <ProfileFields obj={value} />
      <details>
        <summary className="muted" style={{ cursor: "pointer", fontSize: 12 }}>
          Show raw JSON
        </summary>
        <pre
          className="mono"
          style={{
            fontSize: 12.5,
            lineHeight: 1.55,
            maxHeight: "30vh",
            overflow: "auto",
            whiteSpace: "pre-wrap",
            wordBreak: "break-word",
            background: "var(--surface)",
            border: "1px solid var(--border)",
            borderRadius: "var(--radius-sm)",
            padding: 12,
            marginTop: 8,
          }}
        >
          {JSON.stringify(value, null, 2)}
        </pre>
      </details>
    </div>
  );
}

// Renders the five GPT-writeback JSONB columns + alias for one student. Used by
// both /portal/profile (student viewing themselves) and /portal/history/[userId]
// (admin/faculty drill-down). The AI tutor writes these columns via MCP tools;
// this component is the read view.
export function ProfileSection({
  profile,
  labs,
  emptyMessage,
}: {
  profile: StudentProfile | null;
  // Labs published to this student — one mastery row each. Mastery is keyed by
  // lab id in profile.topicMastery; labs the student can't (any longer) access
  // are never shown, even if a stale level lingers in the column.
  labs: AccessibleLab[];
  emptyMessage: React.ReactNode;
}) {
  if (!profile) {
    return <div className="callout">{emptyMessage}</div>;
  }

  return (
    <>
      <Card title="Topic mastery" label="0–5 per lab">
        {labs.length === 0 ? (
          <p className="muted" style={{ fontSize: 13, margin: 0 }}>
            No labs are currently published to this student. Mastery rows appear
            once a class assigns and unlocks a lab.
          </p>
        ) : (
          labs.map((lab) => {
            const level = profile.topicMastery[lab.id] ?? 0;
            return (
              <MasteryItem
                key={lab.id}
                label={lab.name}
                level={levelLabel(level)}
                pct={level * 20}
                state={masteryState(level)}
              />
            );
          })
        )}
      </Card>

      <Card title="Mind map" label="freeform JSON">
        <JsonBlock value={profile.mindMap} />
      </Card>

      <Card title="Personalization" label="preferences">
        <JsonBlock value={profile.personalization} />
      </Card>

      <Card title="Learning style" label="observed">
        <JsonBlock value={profile.learningStyle} />
      </Card>

      <Card title="Struggles" label="public column">
        <JsonBlock value={profile.struggles} />
      </Card>

      <p className="muted" style={{ fontSize: 13, marginTop: 14 }}>
        Anonymous alias: <code className="mono">{profile.alias}</code> · Updated{" "}
        <time dateTime={profile.updatedAt.toISOString()}>
          {profile.updatedAt.toLocaleString()}
        </time>
      </p>
    </>
  );
}
