import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
import {
  canViewStudentHistory,
  getStudentSubject,
  type StudentListRow,
} from "@/lib/portal/history";
import { getStudentProfile } from "@/lib/portal/profile";
import { getAccessibleLabs } from "@/lib/portal/accessible-labs";
import { isUuid } from "@/lib/ids";
import { Card } from "@/components/portal/primitives";
import { ProfileSection } from "@/components/portal/profile-section";
import type { User } from "@/lib/db/schema";

export const dynamic = "force-dynamic";

type Params = { userId: string };
type SearchParams = { from_class?: string; from_q?: string };

export default async function StudentHistoryDrillDown({
  params,
  searchParams,
}: {
  params: Promise<Params>;
  searchParams: Promise<SearchParams>;
}) {
  // (portal)/layout.tsx already redirects anonymous users to /login.
  const viewer = (await getCurrentUser())!;
  const { userId } = await params;
  const sp = await searchParams;

  // UUID guard: users.id is a Postgres uuid column. A malformed string would
  // surface as 22P02 → 500. Runs before the role branch so every role gets a
  // clean notFound() rather than a stack trace.
  if (!isUuid(userId)) notFound();

  // Build the back href from from_class / from_q. These are pure display state
  // — NEVER passed to redirect() (open-redirect vector) or used as authz input.
  const backHref = buildBackHref(sp);

  if (viewer.role === "student") {
    if (viewer.id === userId) redirect("/portal/history");
    return <NoAccessScreen backHref={backHref} />;
  }

  if (viewer.role === "admin") {
    const subject = await getStudentSubject(userId);
    if (!subject) notFound(); // clean 404 for missing UUIDs / faculty UUIDs
    return (
      <SubjectHistory viewer={viewer} subject={subject} backHref={backHref} />
    );
  }

  if (viewer.role === "faculty") {
    // Identical "no access" screen for every probe (missing UUID, faculty UUID,
    // non-enrolled student, archived-class student). Defense-in-depth — UUIDs
    // aren't enumerable, so this is hardening, not a security boundary.
    const allowed = await canViewStudentHistory(viewer, userId);
    if (!allowed) return <NoAccessScreen backHref={backHref} />;
    const subject = await getStudentSubject(userId);
    if (!subject) return <NoAccessScreen backHref={backHref} />;
    return (
      <SubjectHistory viewer={viewer} subject={subject} backHref={backHref} />
    );
  }

  return <NoAccessScreen backHref={backHref} />;
}

function buildBackHref(sp: SearchParams): string {
  const fromClass = typeof sp.from_class === "string" ? sp.from_class : null;
  const fromQ = typeof sp.from_q === "string" ? sp.from_q : null;
  const params = new URLSearchParams();
  if (fromClass) params.set("class", fromClass);
  if (fromQ) params.set("q", fromQ);
  const qs = params.toString();
  return qs ? `/portal/history?${qs}` : "/portal/history";
}

async function SubjectHistory({
  viewer,
  subject,
  backHref,
}: {
  viewer: User;
  subject: StudentListRow;
  backHref: string;
}) {
  // Fetch the AI-derived profile and the student's published labs in parallel.
  // Both are unguarded fetchers — authorization happens in the caller before
  // this point.
  const [profile, labs] = await Promise.all([
    getStudentProfile(subject.id),
    getAccessibleLabs(subject.id),
  ]);

  return (
    <div className="col" style={{ maxWidth: 920 }}>
      <div className="screen-head">
        <div className="section-label">
          {viewer.role === "admin" ? "Admin" : "Teaching"} · Prelab progress
        </div>
        <h1>{subject.displayName ?? subject.username}</h1>
        <p className="lead muted">
          <code className="mono">{subject.username}</code>
          {subject.email ? <> · {subject.email}</> : null}
          {profile ? (
            <>
              {" · alias "}
              <code className="mono">{profile.alias}</code>
            </>
          ) : null}
        </p>
      </div>

      <p>
        <Link href={backHref}>← Back to students</Link>
      </p>

      <Card>
        <p className="muted" style={{ fontSize: 12.5, margin: 0 }}>
          Read-only view. The five JSONB columns below are written by the AI
          tutor.
        </p>
      </Card>

      <h2 style={{ marginTop: 8 }}>AI profile</h2>
      <ProfileSection
        profile={profile}
        labs={labs}
        emptyMessage={
          <>
            <strong>No AI profile yet for this student.</strong> The studentProfiles
            row hasn&apos;t been initialized. GPT writebacks land here once the row
            exists.
          </>
        }
      />
    </div>
  );
}

function NoAccessScreen({ backHref }: { backHref: string }) {
  return (
    <div className="col">
      <div className="screen-head">
        <div className="section-label">Restricted</div>
        <h1>Not available</h1>
      </div>
      <div className="callout orange">
        <strong>You don&apos;t have access to this student&apos;s history.</strong>
      </div>
      <p>
        <Link href={backHref}>← Back to students</Link>
      </p>
    </div>
  );
}
