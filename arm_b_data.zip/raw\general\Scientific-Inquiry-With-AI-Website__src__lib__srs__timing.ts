/**
 * Response-time signal for the SRS scheduler. Pure & deterministic.
 *
 * The client reports display→submit time (elapsedMs); the server clamps it,
 * compares it to a per-question rolling baseline, and turns it into either an
 * auto-rating (choice formats) or a bounded time factor that nudges the SM-2
 * interval/ease math (all formats).
 */

import type { SrsRating } from "./scheduler";

export type QuestionFormat = "true_false" | "multiple_choice" | "short_answer" | "calculation";

export const MIN_ANSWER_MS = 1_000;
export const MAX_ANSWER_MS = 240_000;
/** Baseline samples needed before the stored EWMA fully replaces the prior. */
export const BASELINE_WARMUP = 8;
export const TIME_FACTOR_MIN = 0.8;
export const TIME_FACTOR_MAX = 1.2;
/** correct & t < 0.6×baseline → easy */
export const FAST_RATIO = 0.6;
/** correct & t ≤ 1.5×baseline → good (wide band — hesitation isn't punished) */
export const SLOW_RATIO = 1.5;

/** Fixed orienting cost before reading starts. */
export const READ_BASE_MS = 800;
/** ~50 ms/char ≈ 240 wpm at ~5 chars/word — near the adult non-fiction mean. */
export const READ_MS_PER_CHAR = 50;
/** Reading may claim at most this fraction of the baseline, so the remaining
 *  thinking time stays positive even for very long prompts. */
export const READ_BASELINE_CAP = 0.7;
/** Floor for post-reading thinking time, so ratios stay well-defined. */
export const THINK_FLOOR_MS = 500;

function clamp(v: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, v));
}

/**
 * Sanitize a client-reported elapsed time. The wall-clock span since the
 * attempt was served (session start) is a server-observable upper bound; the
 * [1s, 4min] clamp bounds gaming and paused tabs. Garbage → null (neutral).
 */
export function clampElapsedMs(raw: unknown, startedAt: Date, now: Date): number | null {
  if (typeof raw !== "number" || !Number.isFinite(raw) || raw <= 0) return null;
  const serverBound = Math.max(0, now.getTime() - startedAt.getTime());
  return Math.round(clamp(Math.min(raw, serverBound), MIN_ANSWER_MS, MAX_ANSWER_MS));
}

/** Cold-start estimate of a typical answer time from format + prompt length. */
export function baselinePrior(format: QuestionFormat, promptChars: number): number {
  switch (format) {
    case "true_false":
      return clamp(8_000 + 30 * promptChars, 8_000, 45_000);
    case "multiple_choice":
      return clamp(12_000 + 40 * promptChars, 12_000, 60_000);
    case "short_answer":
      return 45_000;
    case "calculation":
      return 90_000;
  }
}

/** Stored EWMA blended with the prior until enough samples accumulate. */
export function effectiveBaseline(
  stored: number | null,
  count: number,
  format: QuestionFormat,
  promptChars: number,
): number {
  const prior = baselinePrior(format, promptChars);
  if (stored == null || count <= 0) return prior;
  if (count >= BASELINE_WARMUP) return stored;
  return (prior * (BASELINE_WARMUP - count) + stored * count) / BASELINE_WARMUP;
}

/**
 * Clamped-EWMA baseline update: one sample can move the baseline at most 15%,
 * so a single outlier (distraction, lucky instant click) can't drag it far.
 */
export function nextBaseline(
  stored: number | null,
  count: number,
  t: number,
): { baseline: number; count: number } {
  if (stored == null || count <= 0) return { baseline: t, count: 1 };
  const delta = clamp(t - stored, -0.15 * stored, 0.15 * stored);
  return { baseline: stored + delta, count: count + 1 };
}

/** Rating for choice formats: correctness decides pass/fail, time picks the tier. */
export function deriveAutoRating(
  wasCorrect: boolean,
  t: number | null,
  baseline: number,
): SrsRating {
  if (!wasCorrect) return "again";
  if (t == null) return "good";
  if (t < FAST_RATIO * baseline) return "easy";
  if (t <= SLOW_RATIO * baseline) return "good";
  return "hard";
}

/** Bounded multiplier: fast answers strengthen slightly more, slow ones less. */
export function computeTimeFactor(t: number | null, baseline: number): number {
  if (t == null || t <= 0 || baseline <= 0) return 1;
  return clamp(baseline / t, TIME_FACTOR_MIN, TIME_FACTOR_MAX);
}

/**
 * Estimated time to *read* a prompt before any recall begins. Reading is a
 * roughly fixed per-question cost that grows with prompt length, not with how
 * hard the recall is. Callers subtract it from both the measured time and the
 * baseline (see `thinkingMs`) so a long question isn't rated "hard" just because
 * it took longer to read. Capped to a fraction of the baseline so a very long
 * prompt can't swallow the whole thinking budget.
 */
export function estimateReadMs(promptChars: number, baseline: number): number {
  const raw = READ_BASE_MS + READ_MS_PER_CHAR * Math.max(0, promptChars);
  return Math.round(clamp(raw, 0, READ_BASELINE_CAP * baseline));
}

/** A duration minus reading time, floored so thinking time stays positive.
 *  Apply the same `readMs` to both the measured time and the baseline before
 *  taking ratios. */
export function thinkingMs(ms: number, readMs: number): number {
  return Math.max(ms - readMs, THINK_FLOOR_MS);
}
