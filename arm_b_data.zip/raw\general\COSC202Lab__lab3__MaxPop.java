import java.util.*;
public class MaxPop {

    public static PopOutput maxpop(HashMap<Integer, LifeYears> data) {

        if (data == null || data.isEmpty()) {
            return null;
        }

        //net changes per year
        HashMap<Integer, Integer> netChange = new HashMap<>();
        for (LifeYears person : data.values()) {
            int birth = person.getBirth();
            int death = person.getDeath();

            //birth year +1
            if (!netChange.containsKey(birth)) {
                netChange.put(birth, 0);
            }
            netChange.put(birth, netChange.get(birth) + 1);

            //year after death -1
            int yearAfterDeath = death + 1;
            if (!netChange.containsKey(yearAfterDeath)) {
                netChange.put(yearAfterDeath, 0);
            }
            netChange.put(yearAfterDeath, netChange.get(yearAfterDeath) - 1);
        }

        //process years in chronological order
        List<Integer> years = new ArrayList<>(netChange.keySet());
        Collections.sort(years);

        int maxPopulation = 0;
        int maxYear = years.get(0);
        int currentPopulation = 0;

        for (int year : years) {
            currentPopulation += netChange.get(year);
            if (currentPopulation > maxPopulation) {
                maxPopulation = currentPopulation;
                maxYear = year;
            }
        }

        return new PopOutput(maxYear, maxPopulation);

    }

    public static void main(String[] args) {
        HashMap<Integer, LifeYears> data = new HashMap<>();
        int nextId = 0;

        data.put(nextId++, new LifeYears(1900, 1950));
        data.put(nextId++, new LifeYears(1920, 1980));
        data.put(nextId++, new LifeYears(1945, 2000));
        data.put(nextId++, new LifeYears(1960, 1990));
        data.put(nextId++, new LifeYears(1975, 2010));
        data.put(nextId++, new LifeYears(1980, 1995));

        //test another person with birth and death in the same year
        data.put(nextId++, new LifeYears(1950, 1950));

        PopOutput result = maxpop(data);
        System.out.println("Maximum population year: " + result.getYear());
        System.out.println("Population: " + result.getPopulation());
    }
}

