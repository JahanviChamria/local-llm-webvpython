import java.awt.Color;
//Your personal creative design CPU paddle, which incorporates
//some unique AI behaviors and/or mechanics.
//You will outline the details of this Paddle in your submitted readme file!
public class HumanCreative extends Human{
 
   //Human Creative Paddle attributes
   public static final double HUMAN_CREATIVE_PADDLE_LENGTH_DEC = 12.5;
   public static final double HUMAN_CREATIVE_PADDLE_LENGTH_MIN = 50;
   public static final double HUMAN_CREATIVE_PADDLE_SPEED_INC = 1;
   public static final Color[] HUMAN_CREATIVE_PADDLE_COLORS = {Color.green, Color.yellow, Color.red};

   private int count;


   //****************   CONSTRUCTORS  *************
   public HumanCreative(){
      this(Human.HUMAN_PADDLE_LENGTH);
   }

   public HumanCreative(double length){
      this(length, Human.HUMAN_PADDLE_SPEED);
   }

   public HumanCreative(double length, double speed){
      this(length, speed, HUMAN_CREATIVE_PADDLE_COLORS[0]);
   }

   public HumanCreative(double length, double speed, Color color){
      super(length, speed, color);
      count=0;
   }


   public void reactToVolley(){
      super.reactToVolley();
      if(this.getLength()>HUMAN_CREATIVE_PADDLE_LENGTH_MIN){
         this.setLength(this.getLength()-HUMAN_CREATIVE_PADDLE_LENGTH_DEC);
         if(count<=HUMAN_CREATIVE_PADDLE_COLORS.length-2)
            count++;
         else
            count=0;
         this.setColor(HUMAN_CREATIVE_PADDLE_COLORS[count]);
         this.setSpeed(this.getSpeed()+HUMAN_CREATIVE_PADDLE_SPEED_INC);
      }
   }


   public void reactToScore(boolean didHumanScore){
      if (didHumanScore)
         this.score++;
      volleys=0;
      count=0;
      this.setColor(HUMAN_CREATIVE_PADDLE_COLORS[count]);
      this.setLength(HUMAN_PADDLE_LENGTH);
      this.setSpeed(HUMAN_PADDLE_SPEED);
   }

   public int getVolleys(){
      return volleys;
   }

   
}
