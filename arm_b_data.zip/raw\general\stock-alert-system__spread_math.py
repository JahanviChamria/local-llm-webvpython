import logging
import pandas as pd

logger = logging.getLogger(__name__)


def calculate_spreads(
    ticker: str,
    df: pd.DataFrame,
    min_otm_pct: float,
    max_dte: int,
    min_net_credit: float,
    min_return_on_margin: float,
    max_short_delta: float | None = None,
) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame()

    current_price = df["current_price"].iloc[0]
    if not current_price or current_price <= 0:
        logger.warning(f"{ticker}: current_price is 0 or missing, skipping spread math")
        return pd.DataFrame()
    results = []

    for expiration, group in df.groupby("expiration"):
        group = group.sort_values("strike").reset_index(drop=True)
        dte = group["dte"].iloc[0]

        if dte > max_dte or dte < 0:
            continue

        for i in range(1, len(group)):
            short = group.iloc[i]   # higher strike (short put)
            long = group.iloc[i - 1]  # lower strike (long put)

            net_credit = short["bid"] - long["ask"]
            spread_width = short["strike"] - long["strike"]

            if spread_width <= 0:
                continue

            # A credit spread's credit can never reach its width (max ROM = 100%).
            # Anything at/above width is a bad-quote artifact (crossed/None NBBO),
            # so drop it instead of letting it sort to the top of the email.
            if net_credit >= spread_width:
                continue

            margin = spread_width * 100
            # net_credit is per-share; actual credit collected is net_credit * 100
            # (1 contract = 100 shares), matching the per-contract margin.
            credit_per_contract = net_credit * 100
            return_on_margin = (credit_per_contract / margin) * 100 if margin > 0 else 0
            otm_pct = (current_price - short["strike"]) / current_price * 100
            phantom_flag = short["bid"] == 0 and net_credit > 0

            # Short-put delta drives the risk filter. Put deltas are negative;
            # closer to 0 = safer. Keep only trades at least as safe as the
            # threshold (e.g. -0.05): skip anything more negative than it.
            # Rows with no delta available (API gap / unauth) are not filtered out.
            short_delta = short.get("delta")
            if (
                max_short_delta is not None
                and short_delta is not None
                and not pd.isna(short_delta)
                and short_delta < max_short_delta
            ):
                continue

            if (
                net_credit < min_net_credit
                or return_on_margin < min_return_on_margin
                or otm_pct < min_otm_pct
            ):
                continue

            # Earnings risk: expiration falls on/after the next earnings date.
            # Flagged (not dropped) here so the UI can toggle visibility without rescanning.
            next_earnings = short.get("next_earnings_date")
            earnings_risk = bool(
                next_earnings is not None
                and not pd.isna(next_earnings)
                and expiration >= next_earnings
            )

            results.append({
                "ticker": ticker,
                "short_strike": short["strike"],
                "long_strike": long["strike"],
                "net_credit": round(net_credit, 2),
                "margin": round(margin, 2),
                "return_pct": round(return_on_margin, 2),
                "otm_pct": round(otm_pct, 2),
                "short_delta": round(float(short_delta), 3) if short_delta is not None and not pd.isna(short_delta) else None,
                "dte": dte,
                "expiration": expiration,
                "earnings_risk": earnings_risk,
                "next_earnings_date": next_earnings,
                "phantom_flag": phantom_flag,
            })

    if not results:
        return pd.DataFrame()

    out = pd.DataFrame(results)
    return out.sort_values("return_pct", ascending=False).reset_index(drop=True)


def run_all_spreads(
    chain_data: dict,
    min_otm_pct: float,
    max_dte: int,
    min_net_credit: float,
    min_return_on_margin: float,
    max_short_delta: float | None = None,
) -> pd.DataFrame:
    frames = []
    for ticker, df in chain_data.items():
        result = calculate_spreads(
            ticker, df,
            min_otm_pct=min_otm_pct,
            max_dte=max_dte,
            min_net_credit=min_net_credit,
            min_return_on_margin=min_return_on_margin,
            max_short_delta=max_short_delta,
        )
        if not result.empty:
            frames.append(result)

    if not frames:
        return pd.DataFrame()

    combined = pd.concat(frames, ignore_index=True)
    return combined.sort_values("return_pct", ascending=False).reset_index(drop=True)
