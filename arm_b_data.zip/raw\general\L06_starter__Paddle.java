import java.awt.Color;

//A JavaPong Paddle
public abstract class Paddle{
   
   //Minimums
   public static final double MIN_PADDLE_LENGTH = 5;
   public static final double MIN_PADDLE_SPEED = 1;  
   
   //Helpful values for the various CPU paddles' keyReact(...) and decideMove(...) methods
   protected static final int MOVE_THRESHOLD = 10;  
   protected static final int MOVE_UP = -1;
   protected static final int MOVE_DOWN = 1;
   protected static final int MOVE_NEUTRAL = 0;
   
   
   
   //tracks if this Paddle has been initialized
   private boolean initialized = false;   
   
   //the height and width of the window this Paddle is contained inside
   private double windowWidth, windowHeight;   


   //Color to draw the Paddle  
   private Color color;
   
   //Length (i.e. height) of the Paddle in pixels
   private double length;
   
   //The number of pixels this paddle moves as a result of  
   //keyReact(...) or decideMove(...) returning UP or DOWN.
   private double speed;   
   
   //The location of the centermost point of this Paddle
   private double x, y;
   
   //The number points this paddle has scored
   protected int score;    

   
   //****************   CONSTRUCTORS  *************
   public Paddle(double length, double speed, Color color){    
      this.score = 0;
      this.color = color;
      this.length = Math.max(length, MIN_PADDLE_LENGTH);
      this.speed = Math.max(speed, MIN_PADDLE_SPEED);
   }  
   
   
   
   
   //called once at the very start of the game
   //relays the dimensions of the containing window, and also sets the Paddle's initial position
   public void init(double windowWidth, double windowHeight, double startingX){
      
      if (!this.initialized){//can only be called once, at the start of the game...
         this.windowWidth = windowWidth;
         this.windowHeight = windowHeight;
         this.x = startingX;
         this.y = windowHeight/2.0;     
         this.initialized = true;//init(...) can't be called again
      }
   }
   
   
   //Moves the paddle up, down, or not at all, per the int arg passed.
   //Specifically, -1, 0, and 1 correspond to moving up, neutral, and down respectively
   public void movePaddle(int direction){
      if (direction > 1 || direction < -1)
         throw new IllegalArgumentException("movePaddle(...) requires a direction arg between -1 and 1 inclusive! (got: " + direction + ")");
      this.y += this.speed * direction; 
      this.y = Math.max(this.length/2.0, Math.min(this.windowHeight-this.length/2.0, this.y));
   }
   
   

   //Given a ball at the specified coordinates/velocity, this function returns
   //the y coordinate that the ball will be at when it reaches the CPUPaddle
   //DOES NOT ACCOUNT FOR WALL BOUNCES.  If the ball would bounce before it reaches the
   //paddle's x, this function will return a y < 0 or > window height
   //
   //arguments include (in order):
   //bX, bY: the ball's current x and y coordinates
   //bXVel, bYVel: the ball's current x and y velocities
   //paddleX: the x coordinate of the CPU paddle
   //
   //*** You do not need to modify (or totally understand the math) of this function ***
   public double getProjectedY(double bX, double bY, double bXVel, double bYVel){
      double expectY = ((this.x - bX) / bXVel) * bYVel;    
      expectY = bY + expectY;
      return expectY;
   }    
   
   
   
   
   //****************   ABSTRACT METHODS  *************
   
   //Called automatically whenver the ball collides with this paddle
   public abstract void reactToVolley();
   
   
   //Called automatically whenever EITHER paddle scores a point.
   //argument boolean indicates if it was the human who scored (true) or
   //the CPU (false).
   public abstract void reactToScore(boolean didThisPaddleScore);
   
   
   
   
   
   
   //****************   ACCESSOR METHODS  *************
   
   
   public double getWindowHeight(){
      return this.windowHeight;
   }
   
   public double getWindowWidth(){
      return this.windowWidth;
   }
   
   public double getX(){
      return this.x;
   }  
   
   //Gets the y coordinate of the centermost point of the Paddle
   public double getY(){
      return this.y;
   } 
   
   //Gets the y coordinate of the topmost point of the Paddle  
   public double getTopY(){
      return this.y - this.length / 2;
   }  
   
   //Gets the y coordinate of the bottommost point of the Paddle
   public double getBottomY(){
      return this.y + this.length / 2;
   }       
   
   public int getScore(){
      return this.score;
   }  
   
   public Color getColor(){   
      return this.color;
   }
   
   public double getLength(){
      return this.length;    
   }  

   public double getSpeed(){
      return this.speed;    
   }     
   
 

   
   
   //****************   MUTATOR METHODS  *************
     
   public void setSpeed(double newSpeed){
      if (newSpeed < MIN_PADDLE_SPEED)
         throw new IllegalArgumentException("Invalid paddle speed argument (min: " + MIN_PADDLE_SPEED + ", got: " + newSpeed + ")");
      this.speed = newSpeed;
   }

   public void setLength(double newLength){
      if (newLength < MIN_PADDLE_SPEED)
         throw new IllegalArgumentException("Invalid paddle length argument (min: " + MIN_PADDLE_LENGTH + ", got: " + newLength + ")");      
      this.length = newLength;
   }   
   
   public void setColor(Color newColor){
      if (newColor == null)
         throw new IllegalArgumentException("Invalid paddle color argument (got: null)");       
      this.color = newColor;
   }
   
   
}
