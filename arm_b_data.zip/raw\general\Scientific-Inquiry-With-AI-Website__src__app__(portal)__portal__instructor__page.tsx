import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
import { getInstructorDashboard, type ClassConcept, type InstructorFlag } from "@/lib/portal/instructor";
import { getInstructorLeaderboards } from "@/lib/portal/leaderboard";
import { Card } from "@/components/portal/primitives";
import { Leaderboard } from "@/components/portal/leaderboard";

export const dynamic = "force-dynamic";

const conceptColor: Record<ClassConcept["label"], [string, string]> = {
  Strong: ["#0F6E56", "#fff"],
  Mixed: ["#9FE1CB", "#085041"],
  Weak: ["#FDE2D2", "#854F0B"],
  "No data": ["#eeece8", "#6b6b65"],
};

const flagColor: Record<InstructorFlag["severity"], string> = {
  high: "var(--orange)",
  medium: "var(--orange-mid)",
  positive: "var(--blue)",
};

export default async function InstructorScreen() {
  const user = await getCurrentUser();
  if (!user || (user.role !== "faculty" && user.role !== "admin")) {
    redirect("/portal");
  }

  const d = await getInstructorDashboard();
  const boards = await getInstructorLeaderboards(user);

  const stats: { label: string; value: string; sub: string; warn?: boolean }[] = [
    { label: "Prelab completion", value: `${d.prelabDone}/${d.totalStudents}`, sub: "marked done" },
    { label: "Recall engagement", value: `${d.recallEngagementPct}%`, sub: "active this week" },
    { label: "Sim completion", value: `${d.simDone}/${d.totalStudents}`, sub: "completed ≥1 sim" },
    {
      label: "Flagged students",
      value: String(d.flags.length),
      sub: "need attention",
      warn: d.flags.some((f) => f.severity !== "positive"),
    },
  ];

  return (
    <div className="col">
      <div className="screen-head">
        <div className="section-label">Teaching</div>
        <h1>Retrieval progress</h1>
        <p className="lead muted">
          {d.totalStudents} student{d.totalStudents === 1 ? "" : "s"} · class-wide mastery, completion, and rule-based
          flags at a glance.
        </p>
      </div>

      <div className="grid g4">
        {stats.map((s, i) => (
          <div className="stat-card" key={i}>
            <div className="stat-label">{s.label}</div>
            <div className="stat-num" style={s.warn ? { color: "var(--orange)" } : {}}>{s.value}</div>
            <div className={"stat-delta" + (s.warn ? " warn" : "")}>{s.sub}</div>
          </div>
        ))}
      </div>

      {boards.length > 0 ? (
        <div className="col" style={{ gap: 14 }}>
          {boards.map((b) => (
            <Leaderboard
              key={b.classId}
              title={`Leaderboard · ${b.className}`}
              periodLabel="This week"
              entries={b.entries}
            />
          ))}
        </div>
      ) : (
        <Card title="Class leaderboards" label="this week · resets Monday">
          <p className="muted" style={{ fontSize: 13 }}>
            No classes yet. Create a class and enroll students to see weekly leaderboards here.
          </p>
        </Card>
      )}

      <Card title="Mastery heatmap" label="class average · 0–100 by lab">
        {d.concepts.length === 0 ? (
          <p className="muted" style={{ fontSize: 13 }}>
            No labs with questions yet. Once questions are published and students practice, per-lab mastery appears here.
          </p>
        ) : (
          <>
            <div className="heat-row" style={{ marginBottom: 6 }}>
              {d.concepts.map((c) => {
                const [bg, fg] = conceptColor[c.label];
                return (
                  <div className="heat-cell" key={c.labId} style={{ background: bg, color: fg }}>
                    {c.label === "No data" ? "—" : `${c.label} · ${c.pct}%`}
                  </div>
                );
              })}
            </div>
            <div className="row" style={{ gap: 4 }}>
              {d.concepts.map((c) => (
                <div key={c.labId} style={{ flex: 1, textAlign: "center", fontSize: 10, color: "var(--light)" }}>
                  {c.name}
                </div>
              ))}
            </div>
            {(() => {
              const weakest = d.concepts.filter((c) => c.hasData).sort((a, b) => a.pct - b.pct)[0];
              if (!weakest || weakest.pct >= 40) return null;
              return (
                <div className="callout orange" style={{ marginTop: 14 }}>
                  <strong>Class-wide signal:</strong> {weakest.name} is the weakest concept right now ({weakest.pct}%).
                  Consider opening the next session with it.
                </div>
              );
            })()}
          </>
        )}
      </Card>

      <Card title="Flagged students" label="rule-based · all modules">
        {d.flags.length === 0 ? (
          <p className="muted" style={{ fontSize: 13 }}>
            No students flagged — engagement is healthy across the class.
          </p>
        ) : (
          <div style={{ margin: "-18px -18px 0" }}>
            {d.flags.map((f, i) => (
              <div className="flag-item" key={i}>
                <span className="flag-dot" style={{ background: flagColor[f.severity] }} />
                <div>
                  <div className="flag-name">
                    {f.name} <span className="muted" style={{ fontWeight: 400 }}>· {f.module}</span>
                  </div>
                  <div className="flag-detail">{f.detail}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <div className="callout">
        <strong>Upload flow:</strong> instructors publish prelab documents, materials, and simulation seeds from a separate
        view. The student platform is read-only for course materials — you publish, students access.
      </div>
    </div>
  );
}
