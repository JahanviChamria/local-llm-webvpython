"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { Badge, Card } from "@/components/portal/primitives";

type Role = "admin" | "faculty" | "student" | "guest";
type CreateRole = Role;
type Tab = "create" | Role;

const TAB_TITLE: Record<Role, string> = {
  admin: "Admins",
  faculty: "Teachers",
  student: "Students",
  guest: "Guests",
};

type UserRow = {
  id: string;
  username: string;
  role: Role;
  displayName: string | null;
  email: string | null;
  emailVerifiedAt: Date | string | null;
  createdAt: Date | string;
  lastLoginAt: Date | string | null;
  expiresAt: Date | string | null;
};

function isUcMercedEmail(email: string | null | undefined): boolean {
  if (!email) return false;
  return email.toLowerCase().endsWith("@ucmerced.edu");
}

// Readable URL-safe alphabet — excludes look-alikes (0/O/o, 1/I/l) so an admin
// reading the password aloud to a student isn't fighting their own font.
const READABLE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";

function generatePassword(len = 16): string {
  const buf = new Uint8Array(len);
  crypto.getRandomValues(buf);
  let out = "";
  for (let i = 0; i < len; i++) {
    out += READABLE_ALPHABET[buf[i] % READABLE_ALPHABET.length];
  }
  return out;
}

export function AdminUsersClient({
  initialUsers,
  currentUserId,
}: {
  initialUsers: UserRow[];
  currentUserId: string;
}) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [resetRowId, setResetRowId] = useState<string | null>(null);
  const [resetSuccess, setResetSuccess] = useState<{ label: string } | null>(null);
  const [tab, setTab] = useState<Tab>("create");

  const byRole: Record<Role, UserRow[]> = {
    admin: initialUsers.filter((u) => u.role === "admin"),
    faculty: initialUsers.filter((u) => u.role === "faculty"),
    student: initialUsers.filter((u) => u.role === "student"),
    guest: initialUsers.filter((u) => u.role === "guest"),
  };

  async function del(u: UserRow) {
    if (u.id === currentUserId) return;
    const detachWarning =
      u.role === "faculty" || u.role === "admin"
        ? " Any files they uploaded will lose attribution but will not be removed."
        : "";
    if (!confirm(`Delete ${u.displayName || u.username}? This cannot be undone.${detachWarning}`)) return;
    start(async () => {
      const res = await fetch(`/api/admin/users/${u.id}`, { method: "DELETE" });
      if (!res.ok) alert("Delete failed.");
      router.refresh();
    });
  }

  async function changeRole(u: UserRow, nextRole: "student" | "guest") {
    if (u.id === currentUserId) return;
    if (u.role === nextRole) return;
    const label = u.displayName || u.username;
    if (!confirm(`Change ${label}'s role from "${u.role}" to "${nextRole}"?`)) return;
    start(async () => {
      const res = await fetch(`/api/admin/users/${u.id}/role`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ role: nextRole }),
      });
      if (!res.ok) {
        const j = (await res.json().catch(() => ({}))) as { error?: string };
        const msg =
          j.error === "promotion_requires_verified_ucm_email"
            ? "Promotion to student requires a verified @ucmerced.edu email on this account."
            : j.error === "role_locked"
              ? "This role cannot be changed here."
              : j.error === "self_role_change_forbidden"
                ? "You cannot change your own role."
                : "Role change failed.";
        alert(msg);
      }
      router.refresh();
    });
  }

  return (
    <div className="col" style={{ gap: 18 }}>
      {resetSuccess && (
        <div className="callout green">
          <strong>Password updated for {resetSuccess.label}.</strong> Share it now — it won&apos;t be shown again.{" "}
          <button type="button" onClick={() => setResetSuccess(null)} className="btn ghost sm" style={{ marginLeft: 6 }}>
            Dismiss
          </button>
        </div>
      )}

      <div className="files-tabs" role="tablist">
        <button
          type="button"
          role="tab"
          aria-selected={tab === "create"}
          className={tab === "create" ? "on" : ""}
          onClick={() => setTab("create")}
        >
          <span>Create user</span>
        </button>
        {(["admin", "faculty", "student", "guest"] as const).map((r) => (
          <button
            key={r}
            type="button"
            role="tab"
            aria-selected={tab === r}
            className={tab === r ? "on" : ""}
            onClick={() => setTab(r)}
          >
            <span>{r === "faculty" ? "Teacher" : r[0].toUpperCase() + r.slice(1)}</span>
          </button>
        ))}
      </div>

      {tab === "create" && <CreateUserForm onCreated={() => router.refresh()} />}

      {tab !== "create" && (
        <UserListCard
          role={tab}
          users={byRole[tab]}
          currentUserId={currentUserId}
          pending={pending}
          resetRowId={resetRowId}
          onToggleReset={(id) => setResetRowId(resetRowId === id ? null : id)}
          onChangeRole={changeRole}
          onDelete={del}
          onResetSuccess={(label) => {
            setResetRowId(null);
            setResetSuccess({ label });
            router.refresh();
          }}
        />
      )}
    </div>
  );
}

function UserListCard({
  role,
  users,
  currentUserId,
  pending,
  resetRowId,
  onToggleReset,
  onChangeRole,
  onDelete,
  onResetSuccess,
}: {
  role: Role;
  users: UserRow[];
  currentUserId: string;
  pending: boolean;
  resetRowId: string | null;
  onToggleReset: (id: string) => void;
  onChangeRole: (u: UserRow, nextRole: "student" | "guest") => void;
  onDelete: (u: UserRow) => void;
  onResetSuccess: (label: string) => void;
}) {
  return (
    <Card title={TAB_TITLE[role]} label={`${users.length} total`}>
      {users.length === 0 ? (
        <p className="muted" style={{ fontSize: 13 }}>
          No {role === "faculty" ? "teacher" : role}s yet.
        </p>
      ) : (
        <div className="col" style={{ gap: 0 }}>
          {users.map((u, i) => (
            <div
              key={u.id}
              className="col"
              style={{ gap: 10, padding: "13px 0", borderTop: i === 0 ? "none" : "1px solid var(--border)" }}
            >
              <div className="row between center" style={{ gap: 12 }}>
                <div className="grow" style={{ minWidth: 0 }}>
                  <div className="row center wrap" style={{ gap: 7 }}>
                    <span style={{ fontWeight: 600, fontSize: 14 }}>{u.displayName || u.username}</span>
                    <Badge>{u.role}</Badge>
                    {u.id === currentUserId && <Badge kind="new">you</Badge>}
                  </div>
                  <div className="doc-meta">
                    {u.username}
                    {" · created "}
                    {new Date(u.createdAt).toLocaleDateString()}
                    {u.lastLoginAt && ` · last login ${new Date(u.lastLoginAt).toLocaleDateString()}`}
                    {u.expiresAt && ` · expires ${new Date(u.expiresAt).toLocaleDateString()}`}
                  </div>
                </div>
                <div className="row center" style={{ gap: 7, flexShrink: 0 }}>
                  {u.id !== currentUserId &&
                    (u.role === "student" || u.role === "guest") &&
                    (() => {
                      const promotable = isUcMercedEmail(u.email) && !!u.emailVerifiedAt;
                      const studentDisabled = u.role === "guest" && !promotable;
                      return (
                        <select
                          className="field sm"
                          value={u.role}
                          onChange={(e) => onChangeRole(u, e.target.value as "student" | "guest")}
                          disabled={pending}
                          title={
                            studentDisabled
                              ? "Promotion to student requires a verified @ucmerced.edu email on this account."
                              : "Change role"
                          }
                          style={{ width: "auto" }}
                        >
                          <option value="guest">guest</option>
                          <option value="student" disabled={studentDisabled}>
                            student
                          </option>
                        </select>
                      );
                    })()}
                  {u.id !== currentUserId && (
                    <button
                      type="button"
                      onClick={() => onToggleReset(u.id)}
                      disabled={pending}
                      className="btn sm"
                    >
                      {resetRowId === u.id ? "Cancel" : "Reset password"}
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => onDelete(u)}
                    disabled={pending || u.id === currentUserId}
                    className="btn danger sm"
                  >
                    Delete
                  </button>
                </div>
              </div>
              {resetRowId === u.id && (
                <ResetPasswordForm
                  userId={u.id}
                  label={u.displayName || u.username}
                  onSuccess={onResetSuccess}
                />
              )}
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}

function CreateUserForm({ onCreated }: { onCreated: () => void }) {
  const [role, setRole] = useState<CreateRole>("admin");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const body: Record<string, unknown> = {
        role,
        username: username.trim().toLowerCase(),
        password,
        display_name: displayName.trim() || undefined,
      };
      const res = await fetch("/api/admin/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j.error ?? "Create failed.");
      }
      setUsername("");
      setPassword("");
      setDisplayName("");
      onCreated();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Create failed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit}>
      <Card title="Create user" label="student / teacher / admin / guest">
        <div className="row" style={{ gap: 7, marginBottom: 14 }}>
          {(["admin", "faculty", "student", "guest"] as const).map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setRole(r)}
              className={"btn sm" + (role === r ? " primary" : "")}
            >
              {r === "faculty" ? "Teacher" : r[0].toUpperCase() + r.slice(1)}
            </button>
          ))}
        </div>

        <label className="field-label">
          <span>Display name{role === "admin" ? " (optional)" : ""}</span>
          <input
            className="field"
            type="text"
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
            required={role !== "admin"}
          />
        </label>

        <label className="field-label" style={{ marginTop: 14 }}>
          <span>Username</span>
          <input
            className="field"
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value.toLowerCase())}
            required
            pattern="[a-z0-9._\-]{3,64}"
            title="3–64 chars: lowercase letters, digits, dot, underscore, hyphen"
          />
          <span className="light" style={{ fontSize: 11.5, marginTop: 5, display: "block" }}>
            Stored lowercase. Letters, digits, dot, underscore, hyphen.
          </span>
        </label>

        <div className="field-label" style={{ marginTop: 14 }}>
          <div className="row between center" style={{ gap: 8 }}>
            <span style={{ fontSize: 12, fontWeight: 600, color: "var(--muted)" }}>Password</span>
            <button type="button" onClick={() => setPassword(generatePassword())} className="btn ghost sm">
              Generate strong password
            </button>
          </div>
          <input
            className="field mono"
            type="text"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="new-password"
            required
            minLength={8}
            style={{ marginTop: 6, fontFamily: "var(--mono)" }}
          />
          <span className="light" style={{ fontSize: 11.5, marginTop: 5, display: "block" }}>
            Min 8 chars. Use Generate, then copy &amp; share out-of-band.
          </span>
        </div>


        {error && <p style={{ color: "var(--orange)", fontSize: 13, marginTop: 10 }}>{error}</p>}
        <div style={{ marginTop: 16 }}>
          <button type="submit" disabled={busy} className="btn primary">
            {busy ? "Creating…" : "Create"}
          </button>
        </div>
      </Card>
    </form>
  );
}

function ResetPasswordForm({
  userId,
  label,
  onSuccess,
}: {
  userId: string;
  label: string;
  onSuccess: (label: string) => void;
}) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const res = await fetch(`/api/admin/users/${userId}/password`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j.error ?? "Reset failed.");
      }
      setPassword("");
      onSuccess(label);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Reset failed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form
      onSubmit={submit}
      className="col"
      style={{ gap: 8, background: "var(--surface2)", borderRadius: "var(--radius-sm)", padding: 12 }}
    >
      <div className="row between center" style={{ gap: 8 }}>
        <span style={{ fontSize: 12.5, fontWeight: 600 }}>New password for {label}</span>
        <button type="button" onClick={() => setPassword(generatePassword())} className="btn ghost sm">
          Generate strong password
        </button>
      </div>
      <input
        className="field"
        type="text"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        autoComplete="new-password"
        required
        minLength={8}
        style={{ fontFamily: "var(--mono)" }}
      />
      {error && <p style={{ color: "var(--orange)", fontSize: 13 }}>{error}</p>}
      <div>
        <button type="submit" disabled={busy} className="btn primary sm">
          {busy ? "Saving…" : "Save new password"}
        </button>
      </div>
    </form>
  );
}
