import { LabRetrievalView } from "@/components/portal/lab-retrieval-view";
import { guardStudentGlobalLab } from "@/lib/portal/global-lab-guard";

export const dynamic = "force-dynamic";

export default async function LabRetrievalPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  await guardStudentGlobalLab(id);
  return <LabRetrievalView labId={id} basePath={`/portal/labs/${id}`} />;
}
