ALTER TYPE "public"."lab_file_kind" ADD VALUE 'student_guide';--> statement-breakpoint
ALTER TABLE "labs" ADD COLUMN "has_student_guide" boolean DEFAULT false NOT NULL;