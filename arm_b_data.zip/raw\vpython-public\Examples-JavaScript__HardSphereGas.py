JavaScript 3.2

// Hard-sphere gas.
// Bruce Sherwood

let win=500

let Natoms = 200  // change this to have more or fewer atoms

// Typical values
let L = 1 // container is a cube L on a side
let gray = color.gray(0.7) // color of edges of container
let Matom = 4E-3/6E23 // helium mass
let Ratom = 0.03 // wildly exaggerated size of helium atom
let k = 1.4E-23 // Boltzmann constant
let T = 300 // around room temperature
let dt = 1E-5

let animation = canvas( {width:win, height:win, align:'left'} )
animation.range = L

let d = L/2+Ratom
let r = 0.005*L
let boxbottom = curve({color:gray, radius:r})
boxbottom.push(vec(-d,-d,-d), vec(-d,-d,d), vec(d,-d,d), vec(d,-d,-d), vec(-d,-d,-d))
let boxtop = curve({color:gray, radius:r})
boxtop.push(vec(-d,d,-d), vec(-d,d,d), vec(d,d,d), vec(d,d,-d), vec(-d,d,-d))
let vert1 = curve({color:gray, radius:r})
let vert2 = curve({color:gray, radius:r})
let vert3 = curve({color:gray, radius:r})
let vert4 = curve({color:gray, radius:r})
vert1.push(vec(-d,-d,-d), vec(-d,d,-d))
vert2.push(vec(-d,-d,d), vec(-d,d,d))
vert3.push(vec(d,-d,d), vec(d,d,d))
vert4.push(vec(d,-d,-d), vec(d,d,-d))

let Atoms = []
let apos = []
let p = []
let mass = Matom*pow(Ratom,3)/pow(Ratom,3)
let pavg = sqrt(2*mass*1.5*k*T) // average kinetic energy p**2/(2mass) = (3/2)kT
    
for (let i=0; i<Natoms; i++) {
    let x = L*Math.random()-L/2
    let y = L*Math.random()-L/2
    let z = L*Math.random()-L/2
    Atoms.push(sphere( {pos:vec(x,y,z), color:color.gray(0.7), size:2*Ratom*vec(1,1,1)} ) )
    apos.push(vec(x,y,z))
    let theta = pi*Math.random()
    let phi = 2*pi*Math.random()
    let px = pavg*sin(theta)*cos(phi)
    let py = pavg*sin(theta)*sin(phi)
    let pz = pavg*cos(theta)
    p.push(vec(px,py,pz))
}
Atoms[0].color = color.cyan
attach_trail(Atoms[0], {retain:100, color:color.cyan})

animation.title = 'A "hard-sphere" gas'
let s = '  Theoretical and averaged speed distributions (meters/sec).\n'
s += '  Initially all atoms have the same speed, but collisions\n'
s += '  change the speeds of the colliding atoms. One of the atoms is\n'
s += '  marked and leaves a trail so you can follow its path.\n\n'
animation.caption = s

let deltav = 100 // binning for v histogram

function barx(v) {
    return Math.floor(v/deltav) // index into bars array
}

let histo = new Array(4000/deltav)
for (let i=0; i<histo.length; i++) histo[i] = 0
histo[barx(pavg/mass)] = Natoms

graph( {width:win, height:0.4*win, xmax:3000, ymax:Natoms*deltav/1000, align:'left',
        xtitle:'speed, m/s', ytitle:'Number of atoms'})

let theory = series( {color:color.cyan} )
let dv = 10
for (let v=0; v<3001+dv; v+=dv)  // theoretical prediction
    theory.plot( v, (deltav/dv)*Natoms*4*pi*pow(Matom/(2*pi*k*T),1.5) *exp(-0.5*Matom*pow(v,2)/(k*T))*pow(v,2)*dv )


let accum = new Array(3000/deltav)
for (let i=0; i<accum.length; i++) accum[i] = [deltav*(i+.5),0]
let vdist = series( {type:'bar', color:color.red, delta:deltav} )

function interchange(v1, v2) { // remove from v1 bar, add to v2 bar
    let barx1 = barx(v1)
    let barx2 = barx(v2)
    if (barx1 == barx2) { return }
    if (barx1 >= histo.length || barx2 >= histo.length) { return }
    histo[barx1] -= 1
    histo[barx2] += 1
}

function checkCollisions(apos) {
    let hitlist = []
    let Natoms = apos.length
    let r2 = 2*Ratom
    r2 *= r2
    for (let i=0; i<Natoms; i++) {
        let ai = apos[i]
        for (let j=0; j<i; j++) {
            let aj = apos[j]
            let dr = ai - aj
            if (mag2(dr) < r2) hitlist.push([i,j])
        }
    }
    return hitlist
}

let nhisto = 0 // number of histogram snapshots to average

while(true) {
    await rate(300)
    // Accumulate and average histogram snapshots
    for (let i=0; i<accum.length; i++) accum[i][1] = (nhisto*accum[i][1] + histo[i])/(nhisto+1)
    if (nhisto % 10 === 0) vdist.data = accum // update graph every 10th iteration
    nhisto += 1

    // Update all positions
    for (let i=0; i<Natoms; i++) Atoms[i].pos = apos[i] = apos[i] + (p[i]/mass)*dt
    
    // Check for collisions
    let hitlist = checkCollisions(apos)

    // If any collisions took place, update momenta of the two atoms
    for (let id1 in hitlist) {
        let ij = hitlist[id1]
        let i = ij[0]
        let j = ij[1]
        let ptot = p[i]+p[j]
        let vi = p[i]/mass
        let vj = p[j]/mass
        let vrel = vj-vi
        let a = vrel.mag2
        if (a === 0) continue;  // exactly same velocities
        let rrel = apos[i]-apos[j]
        if (rrel.mag > Ratom) continue // one atom went all the way through another
    
        // theta is the angle between vrel and rrel:
        let dx = dot(rrel, vrel.hat)       // rrel.mag*cos(theta)
        let dy = cross(rrel, vrel.hat).mag // rrel.mag*sin(theta)
        // alpha is the angle of the triangle composed of rrel, path of atom j, and a line
        //   from the center of atom i to the center of atom j where atome j hits atom i:
        let alpha = asin(dy/(2*Ratom)) 
        d = (2*Ratom)*cos(alpha)-dx // distance traveled into the atom from first contact
        let deltat = d/vrel.mag         // time spent moving from first contact to position inside atom
        
        apos[i] = apos[i]-vi*deltat // back up to contact configuration
        apos[j] = apos[j]-vj*deltat
        let mtot = 2*mass
        let pcmi = p[i]-ptot*mass/mtot // transform momenta to cm frame
        let pcmj = p[j]-ptot*mass/mtot
        rrel = norm(rrel)
        pcmi = pcmi-2*pcmi.dot(rrel)*rrel // bounce in cm frame
        pcmj = pcmj-2*pcmj.dot(rrel)*rrel
        p[i] = pcmi+ptot*mass/mtot // transform momenta back to lab frame
        p[j] = pcmj+ptot*mass/mtot
        apos[i] = apos[i]+(p[i]/mass)*deltat // move forward deltat in time
        apos[j] = apos[j]+(p[j]/mass)*deltat
        interchange(vi.mag, p[i].mag/mass)
        interchange(vj.mag, p[j].mag/mass)
    }
    
    for (let i=0; i<Natoms; i++) {
        let loc = apos[i]
        if (abs(loc.x) > L/2) {
            if (loc.x < 0) p[i].x =  abs(p[i].x)
            else p[i].x =  -abs(p[i].x)
        }
        if (abs(loc.y) > L/2) {
            if (loc.y < 0) p[i].y =  abs(p[i].y)
            else p[i].y =  -abs(p[i].y)
        }
        if (abs(loc.z) > L/2) {
            if (loc.z < 0) p[i].z =  abs(p[i].z)
            else p[i].z =  -abs(p[i].z)
        }
    }
}
