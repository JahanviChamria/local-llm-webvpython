Web VPython 3.2
scene.width = 600
scene.height = 300
scene.center = vec(0,2,0)
scene.fov = .1
scene.background = color.white
scene.forward = vec(-0.3,-0.2,-1)

r = ring(radius=1, thickness=0.2, color=color.black, axis=vec(0,0,1))
c1 = cylinder(pos=vec(-1,0,0), axis=vec(2,0,0), radius=0.1)
c2 = c1.clone()
c2.rotate(angle=pi/3, axis=vec(0,0,1), origin=vec(0,0,0))
c3 = c1.clone()
c3.rotate(angle=-pi/3, axis=vec(0,0,1), origin=vec(0,0,0))
w = compound([r,c1,c2,c3])

g = group()
wheel1 = w.clone(pos=vec( 4,0, 0), group=g)
wheel2 = w.clone(pos=vec(-4,0, 0), group=g)
wheel3 = w.clone(pos=vec( 4,0,-4), group=g)
wheel4 = w.clone(pos=vec(-4,0,-4), group=g)
wheels = [wheel1, wheel2, wheel3, wheel4]
w.visible = False

body1 = box(group=g, pos=vec(0,0,-2), size=vec(8,2,3.5), color=color.red)
body2 = box(group=g, pos=vec(-1,2,-2), size=vec(3,2,3.5), color=color.red)
T = text(group=g, text='Car', pos=body2.pos+vec(-1,1,-0.6), depth=1, color=color.green)

road = box(pos=vec(0,-1.3,-2), size=vec(30.6,0.2,7), color=color.gray(.95))
wall1 = box(pos=vec(-15.4,1.85,-2), size=vec(0.2,6.5,7), color=color.gray(.95))
wall2 = box(pos=vec(15.4,1.85,-2), size=vec(0.2,6.5,7), color=color.gray(.95))
g.pos = vec(-10,0,0)

run = True
def running(b):
    global run
    run = not run
    if run: b.text = 'Pause'
    else: b.text = 'Run'
    
button(text='Pause', bind=running)    

x = -10
dx = .05
dtheta = .5
while True:
    rate(100)
    if not run: continue
    g.pos.x = x
    for w in wheels:
        w.rotate(angle=-dtheta*dx, axis=vec(0,0,1))
    x += dx
    if x > 10 or x < -10:
        dx = -dx
        
        
    
        
    