//A bank of words to be cycled through by a SpeedReadingTrainer
public class WordBank {



     //****  You may add as many primitive instance variables as you like.  However, you  ****  
     //**** may ONLY add LabStack, LabQueue, and String non-primtiive instance  variables ****
     private LabQueue<String> wordsQueue;
     private LabQueue<String> tempQueue;
     private String currentWord;
     

     //At instantiation, a Queue of all the words to be displayed is passed
     public WordBank(LabQueue<String> words){
        this.wordsQueue=new LabQueue<>();
        this.tempQueue=new LabQueue<>();
        while(words.size()!=0){
            String word=words.dequeue();
            wordsQueue.enqueue(word);
            tempQueue.enqueue(word);
        }
        this.currentWord=null;
     }


     //Returns the next word the SpeedReadingTrainer should display (i.e., moving forward)
     //Returns null if there is no next word (i.e. at the end of the file)
     public String nextWord(){
          if(tempQueue.size()==0) {
            return null;
        }
        currentWord=tempQueue.dequeue();
        return currentWord;
     }


     //Returns the next word the SpeedReadingTrainer should display (i.e., moving forward)
     //Returns null if there is no next word (i.e. at the end of the file)     
     public String prevWord(){
          if(currentWord==null||wordsQueue.size()==0) {
            return null;
          }
          LabQueue<String> oldQueue=new LabQueue<>();
          String prevWord=null;
          while(wordsQueue.size()!=0){
               String temp=wordsQueue.dequeue();
               if(temp.equals(currentWord)){
                    break;
               }
               oldQueue.enqueue(temp);
               prevWord=temp;
          }
          while(oldQueue.size()!=0){
               wordsQueue.enqueue(oldQueue.dequeue());
          }
          currentWord=prevWord;
          return prevWord;
     }

     
     //Resets the word bank back to the beginning of the file
     //After resetting, the a call to nextWord() would return the first word in the file
     public void reset(){
          tempQueue=new LabQueue<>();
          LabQueue<String> copyQueue=new LabQueue<>();
          while(wordsQueue.size()!=0){
            String word=wordsQueue.dequeue();
            tempQueue.enqueue(word);
            copyQueue.enqueue(word);
          }
          while(copyQueue.size()!=0){
            wordsQueue.enqueue(copyQueue.dequeue());
          }
          currentWord = null;
     }
}
