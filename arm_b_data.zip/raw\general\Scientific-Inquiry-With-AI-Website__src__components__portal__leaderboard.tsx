import { Card } from "@/components/portal/primitives";
import type { LeaderboardEntry } from "@/lib/portal/leaderboard";

const MEDALS = ["🥇", "🥈", "🥉"];
const MAX_ROWS = 25;

export function Leaderboard({
  title,
  periodLabel,
  entries,
  highlightUserId,
  emptyHint,
}: {
  title: string;
  periodLabel: string;
  entries: LeaderboardEntry[];
  highlightUserId?: string;
  emptyHint?: string;
}) {
  const active = entries.filter((e) => e.score > 0);

  // Top rows, plus the viewer's own row appended if they fell outside the cap.
  let shown = active.slice(0, MAX_ROWS);
  if (highlightUserId) {
    const me = entries.find((e) => e.userId === highlightUserId);
    if (me && me.score > 0 && !shown.some((e) => e.userId === me.userId)) {
      shown = [...shown, me];
    }
  }

  return (
    <Card title={title} label={`${periodLabel} · resets Monday`}>
      {entries.length === 0 ? (
        <p className="muted" style={{ fontSize: 13 }}>
          {emptyHint ?? "No students enrolled yet."}
        </p>
      ) : active.length === 0 ? (
        <p className="muted" style={{ fontSize: 13 }}>
          No practice points yet this week — be the first on the board.
        </p>
      ) : (
        <div className="table-wrap">
          <table className="p-table">
            <thead>
              <tr>
                <th style={{ width: 48 }}>#</th>
                <th>Student</th>
                <th style={{ textAlign: "right" }}>Score</th>
              </tr>
            </thead>
            <tbody>
              {shown.map((e) => {
                const you = e.userId === highlightUserId;
                return (
                  <tr
                    key={e.userId}
                    style={you ? { background: "var(--surface2)", fontWeight: 600 } : undefined}
                  >
                    <td style={{ fontSize: e.rank <= 3 ? 16 : 13 }}>
                      {e.rank <= 3 ? MEDALS[e.rank - 1] : e.rank}
                    </td>
                    <td>{you ? "You" : e.name}</td>
                    <td style={{ textAlign: "right", whiteSpace: "nowrap" }}>
                      <b>{e.score}</b>
                      <span className="muted" style={{ fontSize: 11.5, marginLeft: 7, fontWeight: 400 }}>
                        {e.practicePoints} pts
                        {e.streak > 0 && <> · 🔥{e.streak}</>}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          <p className="muted" style={{ fontSize: 11, marginTop: 8 }}>
            Score = practice points (easy 3 · good 2 · hard 1) + 3 per day of your current streak.
          </p>
        </div>
      )}
    </Card>
  );
}
