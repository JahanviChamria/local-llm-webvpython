JavaScript 3.2

scene.title = "Binary Star"
let s = 'To rotate "camera", drag with right button or Ctrl-drag.\n'
s += "To zoom, drag with middle button or Alt/Option depressed, or use scroll wheel.\n"
s += "  On a two-button mouse, middle is left + right.\n"
s += "To pan left/right and up/down, Shift-drag.\n"
s += "Touch screen: pinch/extend to zoom, swipe or two-finger rotate.\n"
scene.caption = s

scene.forward = vec(0,-.3,-1)

let G = 6.7e-11

let giant = sphere( {pos:vec(-1e11,0,0), size:4e10*vec(1,1,1), color:color.red} )
giant.mass = 2e30
giant.p = vec(0, 0, -1e4) * giant.mass
attach_trail(giant, {color:giant.color, retain:50})

let dwarf = sphere( {pos:vec(1.5e11,0,0), size:2e10*vec(1,1,1), color:color.yellow} )
dwarf.mass = 1e30
dwarf.p = -giant.p
attach_trail(dwarf, {type:"spheres", pps:20, color:dwarf.color, retain:20})

let dt = 1e5
while (true) { 
    await rate(200)
    let r = dwarf.pos - giant.pos
    let force = G * giant.mass * dwarf.mass * r.hat / pow(mag(r),2)
    giant.p = giant.p + force*dt
    dwarf.p = dwarf.p - force*dt
    giant.pos = giant.pos + (giant.p/giant.mass) * dt
    dwarf.pos = dwarf.pos + (dwarf.p/dwarf.mass) * dt
}