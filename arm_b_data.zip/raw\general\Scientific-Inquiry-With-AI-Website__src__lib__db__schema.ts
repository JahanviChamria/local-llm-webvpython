import { sql } from "drizzle-orm";
import {
  pgTable,
  pgEnum,
  uuid,
  text,
  timestamp,
  bigint,
  bigserial,
  integer,
  real,
  jsonb,
  boolean,
  index,
  uniqueIndex,
  type AnyPgColumn,
} from "drizzle-orm/pg-core";

export const roleEnum = pgEnum("role", ["admin", "faculty", "student", "guest"]);
export const accessLevelEnum = pgEnum("access_level", ["public", "faculty"]);
export const fileStatusEnum = pgEnum("file_status", ["pending", "ready"]);
export const extractionJobStatusEnum = pgEnum("extraction_job_status", [
  "pending",
  "running",
  "done",
  "skipped",
  "failed",
]);
export const loginAttemptKindEnum = pgEnum("login_attempt_kind", ["fail", "success"]);
export const difficultyEnum = pgEnum("difficulty", ["easy", "medium", "hard"]);
export const srsRatingEnum = pgEnum("srs_rating", ["again", "hard", "good", "easy"]);
export const srsRatingSourceEnum = pgEnum("srs_rating_source", ["self", "auto", "ai"]);
export const srsCardStateEnum = pgEnum("srs_card_state", ["new", "learning", "review"]);
export const practiceScopeEnum = pgEnum("practice_scope", ["lab", "external"]);
export const labFileKindEnum = pgEnum("lab_file_kind", [
  "prelab",
  "postlab",
  "activity",
  "analysis_guide",
  "video_tutorial",
  "research_paper",
  "student_guide",
  "self_check",
  "ai_grading_prompt",
  "instructor_guide",
  "lesson_plan",
  "self_check_answer_key",
]);
export const questionFormatEnum = pgEnum("question_format", [
  "true_false",
  "multiple_choice",
  "short_answer",
  "calculation",
]);
export const questionCategoryEnum = pgEnum("question_category", [
  "phenomena",
  "experimental_practices",
  "habits_of_mind",
]);
export const variantRoleEnum = pgEnum("variant_role", [
  "canonical",
  "isomorph",
  "transfer",
  "scaffold",
  "extension",
]);
export const oauthRegistrationSourceEnum = pgEnum("oauth_registration_source", [
  "static",
  "cimd",
  "dcr",
]);
export const aiChatSourceEnum = pgEnum("ai_chat_source", ["claude", "chatgpt", "other"]);

export const users = pgTable(
  "users",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    username: text("username").notNull(),
    passwordHash: text("password_hash"),
    role: roleEnum("role").notNull(),
    displayName: text("display_name"),
    email: text("email"),
    emailVerifiedAt: timestamp("email_verified_at", { withTimezone: true }),
    googleSub: text("google_sub"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
    expiresAt: timestamp("expires_at", { withTimezone: true }),
  },
  (t) => ({
    usernameUniq: uniqueIndex("users_username_uniq").on(t.username),
    emailUniq: uniqueIndex("users_email_uniq")
      .on(t.email)
      .where(sql`${t.email} is not null`),
    googleSubUniq: uniqueIndex("users_google_sub_uniq")
      .on(t.googleSub)
      .where(sql`${t.googleSub} is not null`),
  }),
);

export const emailVerifications = pgTable(
  "email_verifications",
  {
    tokenHash: text("token_hash").primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    userIdx: index("email_verifications_user_idx").on(t.userId),
  }),
);

export const authAudit = pgTable("auth_audit", {
  id: bigserial("id", { mode: "number" }).primaryKey(),
  at: timestamp("at", { withTimezone: true }).notNull().defaultNow(),
  event: text("event").notNull(),
  userId: uuid("user_id"),
  emailHash: text("email_hash"),
  detail: text("detail"),
});

export const files = pgTable(
  "files",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    title: text("title").notNull(),
    description: text("description"),
    category: text("category"),
    accessLevel: accessLevelEnum("access_level").notNull(),
    status: fileStatusEnum("status").notNull().default("pending"),
    r2Key: text("r2_key").notNull(),
    filename: text("filename").notNull(),
    sizeBytes: bigint("size_bytes", { mode: "number" }).notNull(),
    contentType: text("content_type").notNull(),
    uploadedBy: uuid("uploaded_by").references(() => users.id, { onDelete: "set null" }),
    uploadedAt: timestamp("uploaded_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    listingIdx: index("files_listing_idx").on(t.status, t.accessLevel, t.uploadedAt),
    pendingSweepIdx: index("files_pending_sweep_idx").on(t.status, t.uploadedAt),
  }),
);

export const sessions = pgTable(
  "sessions",
  {
    id: text("id").primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    userIdx: index("sessions_user_idx").on(t.userId),
  }),
);

export const loginAttempts = pgTable(
  "login_attempts",
  {
    id: bigserial("id", { mode: "number" }).primaryKey(),
    ipHash: text("ip_hash").notNull(),
    kind: loginAttemptKindEnum("kind").notNull().default("fail"),
    attemptedAt: timestamp("attempted_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    ipTimeIdx: index("login_attempts_ip_time_idx").on(t.ipHash, t.attemptedAt),
  }),
);

export const fileTexts = pgTable("file_texts", {
  fileId: uuid("file_id")
    .primaryKey()
    .references(() => files.id, { onDelete: "cascade" }),
  extractedText: text("extracted_text").notNull(),
  extractedAt: timestamp("extracted_at", { withTimezone: true }).notNull().defaultNow(),
  extractorVersion: text("extractor_version").notNull(),
});

export const extractionJobs = pgTable(
  "extraction_jobs",
  {
    fileId: uuid("file_id")
      .primaryKey()
      .references(() => files.id, { onDelete: "cascade" }),
    status: extractionJobStatusEnum("status").notNull().default("pending"),
    enqueuedAt: timestamp("enqueued_at", { withTimezone: true }).notNull().defaultNow(),
    finishedAt: timestamp("finished_at", { withTimezone: true }),
    error: text("error"),
  },
  (t) => ({
    pendingIdx: index("extraction_jobs_pending_idx").on(t.status, t.enqueuedAt),
  }),
);

export const studentProfiles = pgTable(
  "student_profiles",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    alias: text("alias").notNull(),
    codeHash: text("code_hash").notNull(),
    topicMastery: jsonb("topic_mastery").notNull().default(sql`'{}'::jsonb`),
    mindMap: jsonb("mind_map").notNull().default(sql`'{}'::jsonb`),
    personalization: jsonb("personalization").notNull().default(sql`'{}'::jsonb`),
    learningStyle: jsonb("learning_style").notNull().default(sql`'{}'::jsonb`),
    struggles: jsonb("struggles").notNull().default(sql`'{}'::jsonb`),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    aliasUniq: uniqueIndex("student_profiles_alias_uniq").on(t.alias),
    userUniq: uniqueIndex("student_profiles_user_uniq").on(t.userId),
  }),
);

export const labs = pgTable(
  "labs",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    name: text("name").notNull(),
    description: text("description"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    moduleOrder: integer("module_order"),
    hasPrelab: boolean("has_prelab").notNull().default(false),
    hasPostlab: boolean("has_postlab").notNull().default(false),
    hasPractice: boolean("has_practice").notNull().default(false),
    hasSimulation: boolean("has_simulation").notNull().default(false),
    hasActivity: boolean("has_activity").notNull().default(false),
    hasAnalysisGuide: boolean("has_analysis_guide").notNull().default(false),
    hasVideoTutorial: boolean("has_video_tutorial").notNull().default(false),
    hasResearchPaper: boolean("has_research_paper").notNull().default(false),
    hasStudentGuide: boolean("has_student_guide").notNull().default(false),
    hasSelfCheck: boolean("has_self_check").notNull().default(false),
    hasAiGradingPrompt: boolean("has_ai_grading_prompt").notNull().default(false),
    hasInstructorGuide: boolean("has_instructor_guide").notNull().default(false),
    hasLessonPlan: boolean("has_lesson_plan").notNull().default(false),
    hasSelfCheckAnswerKey: boolean("has_self_check_answer_key").notNull().default(false),
    simulationId: text("simulation_id"),
    practiceLabId: uuid("practice_lab_id").references((): AnyPgColumn => labs.id, {
      onDelete: "set null",
    }),
  },
  (t) => ({
    nameLowerUniq: uniqueIndex("labs_name_lower_uniq").on(sql`lower(${t.name})`),
    moduleOrderIdx: index("labs_module_order_idx").on(t.moduleOrder),
  }),
);

export const labFiles = pgTable(
  "lab_files",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    labId: uuid("lab_id")
      .notNull()
      .references(() => labs.id, { onDelete: "cascade" }),
    fileId: uuid("file_id")
      .notNull()
      .references(() => files.id, { onDelete: "cascade" }),
    kind: labFileKindEnum("kind").notNull(),
    position: integer("position").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    labFileUniq: uniqueIndex("lab_files_lab_file_uniq").on(t.labId, t.fileId),
    listingIdx: index("lab_files_listing_idx").on(t.labId, t.kind, t.position),
  }),
);

// One row per item family from a bank (e.g. "COLL-01"). Holds the bank-level metadata
// that's identical across the variants under it. Variants live in `questions`.
export const questionFamilies = pgTable(
  "question_families",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    labId: uuid("lab_id")
      .notNull()
      .references(() => labs.id, { onDelete: "cascade" }),
    // Human-readable, e.g. "inelastic-collisions:COLL-01". Lets the importer
    // upsert idempotently by name instead of relying on UUIDs round-tripping.
    bankKey: text("bank_key").notNull(),
    concept: text("concept").notNull(),
    category: questionCategoryEnum("category").notNull(),
    answerCore: text("answer_core").notNull(),
    failureModes: jsonb("failure_modes").notNull().default(sql`'[]'::jsonb`),
    // Bank-level grader prompt (same template across all families in a bank;
    // duplicated per family for query convenience). Phase-5 AI grading reads this.
    graderPromptTemplate: text("grader_prompt_template"),
    // Raw `parameterization` block from the JSON; null for non-parameterized families.
    parameterization: jsonb("parameterization"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    bankKeyUniq: uniqueIndex("question_families_bank_key_uniq").on(t.bankKey),
    labIdx: index("question_families_lab_idx").on(t.labId),
  }),
);

export const questions = pgTable(
  "questions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    labId: uuid("lab_id")
      .notNull()
      .references(() => labs.id, { onDelete: "cascade" }),
    difficulty: difficultyEnum("difficulty").notNull(),
    prompt: text("prompt").notNull(),
    expectedAnswer: text("expected_answer"),
    createdBy: uuid("created_by").references(() => users.id, { onDelete: "set null" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
    // All NULLable / defaulted so the existing /admin/questions create form keeps
    // working without knowing about any of these. Set by the bank importer.
    familyId: uuid("family_id").references(() => questionFamilies.id, {
      onDelete: "set null",
    }),
    variantKey: text("variant_key"),
    format: questionFormatEnum("format").notNull().default("short_answer"),
    role: variantRoleEnum("role").notNull().default("canonical"),
    // When true, prompt + expectedAnswer contain {placeholder} tokens that get
    // rendered per-attempt by the parameterizer in practice/start.
    promptIsTemplate: boolean("prompt_is_template").notNull().default(false),
    options: jsonb("options"), // [{ id: "A", text: "..." }, ...] for MC
    correctOption: text("correct_option"), // "B" for MC, "True"/"False" for TF
    variantAnswerNotes: text("variant_answer_notes"),
    figureFileId: uuid("figure_file_id").references(() => files.id, {
      onDelete: "set null",
    }),
    // Rolling typical answer time (clamped EWMA over correct answers, all users).
    // Shared across parameterized variants by design — keyed per question row.
    baselineAnswerMs: real("baseline_answer_ms"),
    baselineSampleCount: integer("baseline_sample_count").notNull().default(0),
  },
  (t) => ({
    labDifficultyIdx: index("questions_lab_difficulty_idx").on(t.labId, t.difficulty),
    updatedIdx: index("questions_updated_idx").on(t.updatedAt),
    familyIdx: index("questions_family_idx").on(t.familyId),
    // Partial unique: hand-created rows have NULL variantKey and must not collide.
    variantKeyUniq: uniqueIndex("questions_variant_key_uniq")
      .on(t.variantKey)
      .where(sql`${t.variantKey} is not null`),
  }),
);

// One spaced-repetition scheduling row per (student, question, scope). The "lab"
// and "external" practice tools keep independent scheduling state so practicing
// in one never changes what's due in the other.
export const srsCards = pgTable(
  "srs_cards",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    questionId: uuid("question_id")
      .notNull()
      .references(() => questions.id, { onDelete: "cascade" }),
    scope: practiceScopeEnum("scope").notNull().default("lab"),
    state: srsCardStateEnum("state").notNull().default("new"),
    reps: integer("reps").notNull().default(0),
    lapses: integer("lapses").notNull().default(0),
    ease: real("ease").notNull().default(2.5),
    intervalDays: real("interval_days").notNull().default(0),
    due: timestamp("due", { withTimezone: true }).notNull().defaultNow(),
    lastReviewedAt: timestamp("last_reviewed_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    userQuestionScopeUniq: uniqueIndex("srs_cards_user_question_scope_uniq").on(
      t.userId,
      t.questionId,
      t.scope,
    ),
    dueIdx: index("srs_cards_due_idx").on(t.userId, t.due),
  }),
);

// One row per "card served to the student" — snapshots the literal prompt, expected
// answer, options, correct option, and figure shown, so reveal and rate read the
// instance the student actually saw rather than re-rendering against current question
// rows that may have been edited or re-imported. Created at /practice serve-card time,
// stamped at reveal and rate, then retained as forensic state.
export const srsAttempts = pgTable(
  "srs_attempts",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    cardId: uuid("card_id")
      .notNull()
      .references(() => srsCards.id, { onDelete: "cascade" }),
    questionId: uuid("question_id")
      .notNull()
      .references(() => questions.id, { onDelete: "cascade" }),
    sessionId: uuid("session_id").references((): AnyPgColumn => srsSessions.id, {
      onDelete: "set null",
    }),
    // Parameterized draw + the seed that produced it. The draw is the load-bearing
    // audit field; the seed is a nice-to-have for "generate a similar one."
    draw: jsonb("draw"),
    seed: integer("seed"),
    // Snapshots of what was rendered at serve time. promptSnapshot is mandatory;
    // the rest are null for non-parameterized free-response cards.
    promptSnapshot: text("prompt_snapshot").notNull(),
    expectedAnswerSnapshot: text("expected_answer_snapshot"),
    optionsSnapshot: jsonb("options_snapshot"),
    correctOptionSnapshot: text("correct_option_snapshot"),
    figureFileIdSnapshot: uuid("figure_file_id_snapshot"),
    // Student's submitted answer or selectedOption — set at reveal so rate can copy it.
    answerText: text("answer_text"),
    // Server-clamped display→submit time; null when the client didn't report one.
    answerMs: integer("answer_ms"),
    // Set at reveal for choice formats (objective), null for free response.
    wasCorrect: boolean("was_correct"),
    startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
    revealedAt: timestamp("revealed_at", { withTimezone: true }),
    ratedAt: timestamp("rated_at", { withTimezone: true }),
  },
  (t) => ({
    userCardIdx: index("srs_attempts_user_card_idx").on(t.userId, t.cardId, t.startedAt),
    sessionIdx: index("srs_attempts_session_idx").on(t.sessionId),
  }),
);

// Immutable log of every answer + rating; also the engagement/streak audit trail.
export const srsReviews = pgTable(
  "srs_reviews",
  {
    id: bigserial("id", { mode: "number" }).primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    cardId: uuid("card_id")
      .notNull()
      .references(() => srsCards.id, { onDelete: "cascade" }),
    questionId: uuid("question_id")
      .notNull()
      .references(() => questions.id, { onDelete: "cascade" }),
    rating: srsRatingEnum("rating").notNull(),
    // "auto" = server derived the rating from correctness + response time (choice
    // formats) or from keyword matching (free-response fallback); "ai" = Claude
    // graded the free response; "self" = the student picked it (legacy flow).
    ratingSource: srsRatingSourceEnum("rating_source").notNull().default("self"),
    answerMs: integer("answer_ms"),
    timeFactor: real("time_factor"),
    // Denormalized from the card at rate time — keeps leaderboard/heatmap queries
    // join-free on this self-contained log.
    scope: practiceScopeEnum("scope").notNull().default("lab"),
    answerText: text("answer_text"),
    aiFeedback: text("ai_feedback"),
    intervalBefore: real("interval_before"),
    intervalAfter: real("interval_after"),
    reviewedAt: timestamp("reviewed_at", { withTimezone: true }).notNull().defaultNow(),
    // The concrete draw the student saw, copied from srs_attempts.draw at rate time.
    // Self-contained record — survives later edits to the parameterization block.
    parameterDraw: jsonb("parameter_draw"),
    // Back-link to the originating attempt row for forensic queries.
    attemptId: uuid("attempt_id").references((): AnyPgColumn => srsAttempts.id, {
      onDelete: "set null",
    }),
  },
  (t) => ({
    userTimeIdx: index("srs_reviews_user_time_idx").on(t.userId, t.reviewedAt),
    cardIdx: index("srs_reviews_card_idx").on(t.cardId),
  }),
);

// A practice session — powers "2 sessions/week", streaks, and engagement %.
export const srsSessions = pgTable(
  "srs_sessions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    labId: uuid("lab_id").references(() => labs.id, { onDelete: "set null" }),
    scope: practiceScopeEnum("scope").notNull().default("lab"),
    startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
    finishedAt: timestamp("finished_at", { withTimezone: true }),
    reviewedCount: integer("reviewed_count").notNull().default(0),
  },
  (t) => ({
    userStartedIdx: index("srs_sessions_user_started_idx").on(t.userId, t.startedAt),
  }),
);

// Self-reported per-lab document completion ("Mark done"). One row per (student, lab_file).
// Keyed on lab_file_id rather than file_id so the same PDF attached to two labs (or two kinds
// on different labs) tracks completion independently per placement.
export const labDocumentCompletions = pgTable(
  "lab_document_completions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    labFileId: uuid("lab_file_id")
      .notNull()
      .references(() => labFiles.id, { onDelete: "cascade" }),
    completedAt: timestamp("completed_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    userLabFileUniq: uniqueIndex("lab_document_completions_user_lab_file_uniq").on(
      t.userId,
      t.labFileId,
    ),
    userIdx: index("lab_document_completions_user_idx").on(t.userId),
  }),
);

// Download audit log — an engagement signal; many rows per (student, file).
export const fileDownloads = pgTable(
  "file_downloads",
  {
    id: bigserial("id", { mode: "number" }).primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    fileId: uuid("file_id")
      .notNull()
      .references(() => files.id, { onDelete: "cascade" }),
    downloadedAt: timestamp("downloaded_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    fileIdx: index("file_downloads_file_idx").on(t.fileId),
    userTimeIdx: index("file_downloads_user_time_idx").on(t.userId, t.downloadedAt),
  }),
);

// Self-reported simulation completion. Scoped per (student, lab, sim) so a sim attached to
// two different labs tracks completion independently. simId is the registry slug (no FK).
export const simulationCompletions = pgTable(
  "simulation_completions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    labId: uuid("lab_id")
      .notNull()
      .references(() => labs.id, { onDelete: "cascade" }),
    simId: text("sim_id").notNull(),
    completedAt: timestamp("completed_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    userLabSimUniq: uniqueIndex("simulation_completions_user_lab_sim_uniq").on(
      t.userId,
      t.labId,
      t.simId,
    ),
  }),
);

// A teacher-owned class/group. owner_id is RESTRICT so deleting a user with classes
// errors at the user delete handler (which surfaces a 409 listing the owned class ids).
// archived_at is the soft-delete marker; hard-delete is a separate, deliberate action.
export const classes = pgTable(
  "classes",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    name: text("name").notNull(),
    ownerId: uuid("owner_id")
      .notNull()
      .references(() => users.id, { onDelete: "restrict" }),
    archivedAt: timestamp("archived_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    ownerIdx: index("classes_owner_idx").on(t.ownerId),
    activeIdx: index("classes_active_idx").on(t.ownerId).where(sql`${t.archivedAt} is null`),
  }),
);

export const classEnrollments = pgTable(
  "class_enrollments",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    classId: uuid("class_id")
      .notNull()
      .references(() => classes.id, { onDelete: "cascade" }),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    enrolledAt: timestamp("enrolled_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    classUserUniq: uniqueIndex("class_enrollments_class_user_uniq").on(t.classId, t.userId),
    userIdx: index("class_enrollments_user_idx").on(t.userId),
  }),
);

// Per-class ordering and lock state live on the join row, so each class can sequence
// and pause its own labs independently. Invariant: order_index values within a class
// are contiguous 1..N with no duplicates, enforced by class_labs_class_order_uniq
// (DEFERRABLE INITIALLY DEFERRED — added in raw SQL in migration 0012 because
// drizzle's uniqueIndex helper doesn't expose deferrability).
export const classLabs = pgTable(
  "class_labs",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    classId: uuid("class_id")
      .notNull()
      .references(() => classes.id, { onDelete: "cascade" }),
    labId: uuid("lab_id")
      .notNull()
      .references(() => labs.id, { onDelete: "cascade" }),
    assignedAt: timestamp("assigned_at", { withTimezone: true }).notNull().defaultNow(),
    orderIndex: integer("order_index").notNull(),
    isLocked: boolean("is_locked").notNull().default(false),
  },
  (t) => ({
    classLabUniq: uniqueIndex("class_labs_class_lab_uniq").on(t.classId, t.labId),
    classOrderIdx: index("class_labs_order_idx").on(t.classId, t.orderIndex),
  }),
);

// Audit log for global history resets. Every name field is denormalized at write time
// so rows stay legible after the referenced user or class is later deleted.
export const historyResets = pgTable(
  "history_resets",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").references(() => users.id, { onDelete: "set null" }),
    userUsername: text("user_username").notNull(),
    resetByUserId: uuid("reset_by_user_id").references(() => users.id, { onDelete: "set null" }),
    resetByUsername: text("reset_by_username").notNull(),
    source: text("source").notNull(),
    sourceClassId: uuid("source_class_id").references(() => classes.id, { onDelete: "set null" }),
    sourceClassName: text("source_class_name"),
    resetAt: timestamp("reset_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    userIdx: index("history_resets_user_idx").on(t.userId),
    actorIdx: index("history_resets_actor_idx").on(t.resetByUserId),
  }),
);

// Audit log for class ownership transfers. Same denormalize-at-write pattern.
export const classOwnershipTransfers = pgTable("class_ownership_transfers", {
  id: uuid("id").primaryKey().defaultRandom(),
  classId: uuid("class_id").references(() => classes.id, { onDelete: "set null" }),
  className: text("class_name").notNull(),
  fromUserId: uuid("from_user_id").references(() => users.id, { onDelete: "set null" }),
  fromUsername: text("from_username").notNull(),
  toUserId: uuid("to_user_id").references(() => users.id, { onDelete: "set null" }),
  toUsername: text("to_username").notNull(),
  actorUserId: uuid("actor_user_id").references(() => users.id, { onDelete: "set null" }),
  actorUsername: text("actor_username").notNull(),
  transferredAt: timestamp("transferred_at", { withTimezone: true }).notNull().defaultNow(),
});

// -----------------------------------------------------------------------------
// OAuth 2.1 authorization-server tables + AI session summaries.
//
// Sci-AI acts as an OAuth provider so external AI hosts (Claude, ChatGPT) can
// call /api/mcp with a resource-bound bearer token. CIMD-first: oauthClients is
// a runtime cache of client metadata fetched from CIMD URLs, not a hand-seeded
// allowlist. registrationSource = 'cimd' is the launch path; 'static' kept for
// the Claude Team Owner-pasted-credentials fallback; 'dcr' reserved.
//
// Lifecycle:
//   1. Discover     → /.well-known/oauth-{protected-resource,authorization-server}
//   2. Authorize    → /oauth/authorize page (requires sciai_session) → auth code
//   3. Token        → /api/oauth/token (PKCE S256 + resource binding) → grant + tokens
//   4. MCP          → /api/mcp with Authorization: Bearer <token>
//   5. Revoke       → grant.revokedAt set; cascades to all derived tokens
//
// Resource binding is mandatory (canonicalized at validate time, not stored
// pre-canonicalized — that lives in src/lib/oauth/validate-bearer.ts).
// Hash-at-rest for every token: SHA-256(token) → tokenHash. Raw tokens are
// returned once in the token response and never persisted.
// -----------------------------------------------------------------------------

export const oauthClients = pgTable(
  "oauth_clients",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    // For CIMD: the client_id IS the metadata URL. For static: an opaque ID we mint.
    clientId: text("client_id").notNull(),
    // For confidential clients only (none at launch — token_endpoint_auth_methods = ["none"]).
    clientSecretHash: text("client_secret_hash"),
    clientName: text("client_name").notNull(),
    redirectUris: text("redirect_uris").array().notNull(),
    isPublic: boolean("is_public").notNull().default(true),
    registrationSource: oauthRegistrationSourceEnum("registration_source").notNull(),
    // For CIMD-registered clients: the metadata document URL (same as clientId for CIMD).
    clientMetadataUrl: text("client_metadata_url"),
    // CIMD docs are cached; when this is in the past, refetch.
    cimdFetchedAt: timestamp("cimd_fetched_at", { withTimezone: true }),
    cimdExpiresAt: timestamp("cimd_expires_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    clientIdUniq: uniqueIndex("oauth_clients_client_id_uniq").on(t.clientId),
    cimdExpiryIdx: index("oauth_clients_cimd_expiry_idx").on(t.cimdExpiresAt),
  }),
);

// One grant per (user, client, resource). Tokens cascade off this row; setting
// revokedAt is the kill switch (cheaper than per-token bookkeeping). The unique
// constraint means a second /authorize for the same triple reuses the grant
// rather than creating duplicates.
export const oauthGrants = pgTable(
  "oauth_grants",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    clientId: uuid("client_id")
      .notNull()
      .references(() => oauthClients.id, { onDelete: "cascade" }),
    // Canonical resource URL (lowercase scheme/host, no trailing slash).
    resource: text("resource").notNull(),
    scopes: text("scopes").array().notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    revokedAt: timestamp("revoked_at", { withTimezone: true }),
  },
  (t) => ({
    userClientResourceUniq: uniqueIndex("oauth_grants_user_client_resource_uniq").on(
      t.userId,
      t.clientId,
      t.resource,
    ),
    userActiveIdx: index("oauth_grants_user_active_idx")
      .on(t.userId)
      .where(sql`${t.revokedAt} is null`),
    clientActiveIdx: index("oauth_grants_client_active_idx")
      .on(t.clientId)
      .where(sql`${t.revokedAt} is null`),
  }),
);

// Single-use auth codes. Stored hashed; consumedAt set on successful exchange so
// replay is detectable. resource is captured at /authorize and must match the
// /token request exactly.
export const oauthAuthorizationCodes = pgTable(
  "oauth_authorization_codes",
  {
    codeHash: text("code_hash").primaryKey(),
    clientId: uuid("client_id")
      .notNull()
      .references(() => oauthClients.id, { onDelete: "cascade" }),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    redirectUri: text("redirect_uri").notNull(),
    resource: text("resource").notNull(),
    scopes: text("scopes").array().notNull(),
    // Nullable: PKCE applies to public clients (CIMD path) but not to confidential
    // clients (GPT Builder Actions OAuth, which doesn't speak PKCE). NULL on both
    // columns is the "PKCE not used for this auth code" signal.
    codeChallenge: text("code_challenge"),
    codeChallengeMethod: text("code_challenge_method"),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    consumedAt: timestamp("consumed_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    expiresIdx: index("oauth_authorization_codes_expires_idx").on(t.expiresAt),
  }),
);

export const oauthAccessTokens = pgTable(
  "oauth_access_tokens",
  {
    tokenHash: text("token_hash").primaryKey(),
    grantId: uuid("grant_id")
      .notNull()
      .references(() => oauthGrants.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    lastUsedAt: timestamp("last_used_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    grantIdx: index("oauth_access_tokens_grant_idx").on(t.grantId),
    // Plain index, not partial — cleanup job needs all rows past expiry, and
    // partial-with-now() is not immutable.
    expiresIdx: index("oauth_access_tokens_expires_idx").on(t.expiresAt),
  }),
);

// rotatedToHash being non-null means we've already rotated past this refresh
// token. If it's re-presented at /token, treat as a replay: revoke the entire
// grant family. The legit client only ever holds the latest refresh.
export const oauthRefreshTokens = pgTable(
  "oauth_refresh_tokens",
  {
    tokenHash: text("token_hash").primaryKey(),
    grantId: uuid("grant_id")
      .notNull()
      .references(() => oauthGrants.id, { onDelete: "cascade" }),
    // The access token this refresh was issued alongside. Set null when its access
    // token is cleaned up after expiry; refresh outlives access.
    accessTokenHash: text("access_token_hash").references(() => oauthAccessTokens.tokenHash, {
      onDelete: "set null",
    }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    rotatedToHash: text("rotated_to_hash"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    grantIdx: index("oauth_refresh_tokens_grant_idx").on(t.grantId),
    expiresIdx: index("oauth_refresh_tokens_expires_idx").on(t.expiresAt),
  }),
);

// Append-only audit for the OAuth surface. event is text (not enum) to mirror
// authAudit and let us add new event types without migrations: 'granted',
// 'revoked', 'token_issued', 'token_used', 'refresh_replay_detected', etc.
// Only first-8-char token-hash prefix lands in detail; never the raw token.
export const oauthConsentAudit = pgTable(
  "oauth_consent_audit",
  {
    id: bigserial("id", { mode: "number" }).primaryKey(),
    at: timestamp("at", { withTimezone: true }).notNull().defaultNow(),
    event: text("event").notNull(),
    userId: uuid("user_id").references(() => users.id, { onDelete: "set null" }),
    clientId: uuid("client_id").references(() => oauthClients.id, { onDelete: "set null" }),
    grantId: uuid("grant_id").references(() => oauthGrants.id, { onDelete: "set null" }),
    ipHash: text("ip_hash"),
    userAgent: text("user_agent"),
    detail: text("detail"),
  },
  (t) => ({
    userTimeIdx: index("oauth_consent_audit_user_time_idx").on(t.userId, t.at),
    eventTimeIdx: index("oauth_consent_audit_event_time_idx").on(t.event, t.at),
  }),
);

// What the AI host wrote about a study session. userId + source are derived from
// the validated bearer (never accepted from tool input). source is keyed off
// oauthClients.clientId via a runtime lookup, not clientName (display names drift).
//
// IMPORTANT — see "Data minimization & retention" in the plan: summary/raw hold
// raw student tutoring content and need a 12-month TTL cleanup job, size caps at
// the tool boundary, PII scrub, and de-enrollment cascade. The schema cap of
// "text" is unbounded; enforce caps in the handler.
//
// grantId is set null on grant deletion so summaries survive token revocation —
// student-export and student-delete actions are the lifecycle path for content,
// not OAuth revocation.
export const aiChatSummaries = pgTable(
  "ai_chat_summaries",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    source: aiChatSourceEnum("source").notNull(),
    labId: uuid("lab_id").references(() => labs.id, { onDelete: "set null" }),
    classId: uuid("class_id").references(() => classes.id, { onDelete: "set null" }),
    summary: text("summary").notNull(),
    topics: jsonb("topics").notNull().default(sql`'[]'::jsonb`),
    raw: jsonb("raw"),
    grantId: uuid("grant_id").references(() => oauthGrants.id, { onDelete: "set null" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    userTimeIdx: index("ai_chat_summaries_user_time_idx").on(t.userId, t.createdAt),
    classTimeIdx: index("ai_chat_summaries_class_time_idx").on(t.classId, t.createdAt),
    // Cleanup job sweeps by createdAt; plain index for the same non-immutable reason as tokens.
    createdAtIdx: index("ai_chat_summaries_created_at_idx").on(t.createdAt),
    // Supports the natural-idempotency window in tools.ts impls (advisory-lock
    // protected check-then-insert per grant). Plain btree, no expression index —
    // those drift the Drizzle snapshot.
    grantTimeIdx: index("ai_chat_summaries_grant_time_idx").on(t.grantId, t.createdAt),
  }),
);

// Append-only observational signals from MCP tools. Per the validity section in
// the plan, this is the same non-ignorable-missingness pipe as aiChatSummaries
// and MUST NOT be folded into studentProfiles. Instructor dashboards only.
export const studentProfileSignals = pgTable(
  "student_profile_signals",
  {
    id: bigserial("id", { mode: "number" }).primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    recordedAt: timestamp("recorded_at", { withTimezone: true }).notNull().defaultNow(),
    topic: text("topic").notNull(),
    signal: text("signal").notNull(),
    detail: text("detail"),
    source: aiChatSourceEnum("source").notNull(),
    grantId: uuid("grant_id").references(() => oauthGrants.id, { onDelete: "set null" }),
  },
  (t) => ({
    userTopicTimeIdx: index("student_profile_signals_user_topic_time_idx").on(
      t.userId,
      t.topic,
      t.recordedAt,
    ),
    topicTimeIdx: index("student_profile_signals_topic_time_idx").on(t.topic, t.recordedAt),
    // Supports the natural-idempotency window in recordConceptStruggleImpl.
    grantTimeIdx: index("student_profile_signals_grant_time_idx").on(t.grantId, t.recordedAt),
  }),
);

export type User = typeof users.$inferSelect;
export type NewUser = typeof users.$inferInsert;
export type FileRow = typeof files.$inferSelect;
export type NewFile = typeof files.$inferInsert;
export type Session = typeof sessions.$inferSelect;
export type FileText = typeof fileTexts.$inferSelect;
export type ExtractionJob = typeof extractionJobs.$inferSelect;
export type EmailVerification = typeof emailVerifications.$inferSelect;
export type AuthAudit = typeof authAudit.$inferSelect;
export type StudentProfile = typeof studentProfiles.$inferSelect;
export type NewStudentProfile = typeof studentProfiles.$inferInsert;
export type Lab = typeof labs.$inferSelect;
export type NewLab = typeof labs.$inferInsert;
export type Question = typeof questions.$inferSelect;
export type NewQuestion = typeof questions.$inferInsert;
export type SrsCard = typeof srsCards.$inferSelect;
export type NewSrsCard = typeof srsCards.$inferInsert;
export type SrsReview = typeof srsReviews.$inferSelect;
export type NewSrsReview = typeof srsReviews.$inferInsert;
export type SrsSession = typeof srsSessions.$inferSelect;
export type NewSrsSession = typeof srsSessions.$inferInsert;
export type LabFile = typeof labFiles.$inferSelect;
export type NewLabFile = typeof labFiles.$inferInsert;
export type LabDocumentCompletion = typeof labDocumentCompletions.$inferSelect;
export type NewLabDocumentCompletion = typeof labDocumentCompletions.$inferInsert;
export type FileDownload = typeof fileDownloads.$inferSelect;
export type SimulationCompletion = typeof simulationCompletions.$inferSelect;
export type NewSimulationCompletion = typeof simulationCompletions.$inferInsert;
export type QuestionFamily = typeof questionFamilies.$inferSelect;
export type NewQuestionFamily = typeof questionFamilies.$inferInsert;
export type SrsAttempt = typeof srsAttempts.$inferSelect;
export type NewSrsAttempt = typeof srsAttempts.$inferInsert;
export type ClassRow = typeof classes.$inferSelect;
export type NewClassRow = typeof classes.$inferInsert;
export type ClassEnrollment = typeof classEnrollments.$inferSelect;
export type NewClassEnrollment = typeof classEnrollments.$inferInsert;
export type ClassLab = typeof classLabs.$inferSelect;
export type NewClassLab = typeof classLabs.$inferInsert;
export type HistoryReset = typeof historyResets.$inferSelect;
export type NewHistoryReset = typeof historyResets.$inferInsert;
export type ClassOwnershipTransfer = typeof classOwnershipTransfers.$inferSelect;
export type NewClassOwnershipTransfer = typeof classOwnershipTransfers.$inferInsert;
export type OauthClient = typeof oauthClients.$inferSelect;
export type NewOauthClient = typeof oauthClients.$inferInsert;
export type OauthGrant = typeof oauthGrants.$inferSelect;
export type NewOauthGrant = typeof oauthGrants.$inferInsert;
export type OauthAuthorizationCode = typeof oauthAuthorizationCodes.$inferSelect;
export type NewOauthAuthorizationCode = typeof oauthAuthorizationCodes.$inferInsert;
export type OauthAccessToken = typeof oauthAccessTokens.$inferSelect;
export type NewOauthAccessToken = typeof oauthAccessTokens.$inferInsert;
export type OauthRefreshToken = typeof oauthRefreshTokens.$inferSelect;
export type NewOauthRefreshToken = typeof oauthRefreshTokens.$inferInsert;
export type OauthConsentAudit = typeof oauthConsentAudit.$inferSelect;
export type NewOauthConsentAudit = typeof oauthConsentAudit.$inferInsert;
export type AiChatSummary = typeof aiChatSummaries.$inferSelect;
export type NewAiChatSummary = typeof aiChatSummaries.$inferInsert;
export type StudentProfileSignal = typeof studentProfileSignals.$inferSelect;
export type NewStudentProfileSignal = typeof studentProfileSignals.$inferInsert;
