import java.util.LinkedList;

public class MyBST<K extends Comparable<? super K>, V> extends RedBlackBST<K, V> {

    public LinkedList<V> values() {
        LinkedList<V> list = new LinkedList<>();
        values(root, list);
        return list;
    }

    // Performs an in-order traversal to add values to the list
    private void values(Node<K, V> x, LinkedList<V> list) {
        if (x == null) return;
        values(x.getLeft(), list);
        list.add(x.getValue());
        values(x.getRight(), list);
    }
}
