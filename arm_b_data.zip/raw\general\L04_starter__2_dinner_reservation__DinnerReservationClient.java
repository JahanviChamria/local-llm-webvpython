/*
 Lab 04
 
 This client program uses DinnerReservation objects.
*/

public class DinnerReservationClient {
     
    //create a main method with test cases here!
     public static void main(String[] args){

        DinnerReservation janeD=new DinnerReservation("Jane Doe", 6, 3, 2);
        System.out.println(janeD);
        System.out.println("Estimated dining time:"+ janeD.estimateDiningTime()+" minutes");
        DinnerReservation williamR=new DinnerReservation("William Ricks", 4, 4, 3);
        System.out.println(williamR);
        System.out.println("Estimated dining time:"+ williamR.estimateDiningTime()+" minutes");

        DinnerReservation kateM=new DinnerReservation("Kate Moreira", 5, 2, 7);
        System.out.println(kateM);
        System.out.println("Estimated dining time:"+ kateM.estimateDiningTime()+" minutes");

        DinnerReservation rachelL=new DinnerReservation("Rachel Lee", 7, 2, 2);
        System.out.println(rachelL);
        System.out.println("Estimated dining time:"+ rachelL.estimateDiningTime()+" minutes");

        DinnerReservation miaN=new DinnerReservation("Mia Nolan", 5, 4, 0);
        System.out.println(miaN);
        System.out.println("Estimated dining time:"+ miaN.estimateDiningTime()+" minutes");

        System.out.println("Reservation of Jane Doe overlaps with that of William Ricks?: "+janeD.overlapsWith(williamR));
        System.out.println("Reservation of Kate Moreira overlaps with that of William Ricks?: "+kateM.overlapsWith(williamR));
        System.out.println("Reservation of Jane Doe overlaps with that of Kate Moreira?: "+janeD.overlapsWith(kateM));
        System.out.println("Reservation of Rachel Lee overlaps with that of Mia Nolan?: "+rachelL.overlapsWith(miaN));
        System.out.println("Reservation of Rachel Lee overlaps with that of William Ricks?: "+rachelL.overlapsWith(williamR));


     }

}
