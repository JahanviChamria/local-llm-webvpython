JavaScript 3.2
scene.width = scene.height = 500
scene.background = color.gray(0.8)
scene.range = 2.2
scene.caption = "Click to pick an object and make it red."
scene.append_to_caption("\nNote picking of individual curve segments.")
box({pos:vec(-1,0,0), color:color.cyan, opacity:1})
box({pos:vec(1,-1,0), color:color.green})
arrow({pos:vec(-1,-1.3,0), color:color.orange})
cone({pos:vec(2,0,0), axis:vec(0,1,-.3), color:color.blue, size:vec(2,1,1)})
sphere({pos:vec(-1.5,1.5,0), color:color.white, size:.4*vec(3,2,1)})
let square = curve( {color:color.yellow, radius:.05} )
square.push(vec(0,0,0))
square.push({pos:vec(0,1,0), color:color.cyan, radius:.1})
square.push(vec(1,1,0))
square.push({pos:vec(1,0,0), radius:.1})
square.push(vec(0.3,-.3,0) )
let v0 = vertex({pos:vec(-.5,1.2,0), color:color.green})
let v1 = vertex({pos:vec(1,1.2,0), color:color.red})
let v2 = vertex({pos:vec(1,2,0), color:color.blue})
let v3 = vertex({pos:vec(-.5,2,0), color:color.yellow})
quad({v0:v0, v1:v1, v2:v2, v3:v3})
ring({pos:vec(-0.6,-1.3,0), size:vec(0.2,1,1), color:color.green})
extrusion({path:[vec(-1.8,-1.3,0), vec(-1.4,-1.3,0)],
            shape:shapes.circle({radius:.5, thickness:0.4}), color:color.yellow})

let lasthit = null
let lastpick = null
let lastcolor
function getevent() {
    if (lasthit !== null) {
        if (lastpick !== null) lasthit.modify(lastpick, {color:lastcolor})
        else lasthit.color = vec(lastcolor)
        lasthit = lastpick = null
    }
    let hit = scene.mouse.pick()
    if (hit !== null) {
        lasthit = hit
        lastpick = null
        if (hit.constructor == curve) { // pick individual point of curve
            lastpick = hit.segment
            lastcolor = hit.point(lastpick)['color']
            hit.modify(lastpick, {color:color.red})
        } else if (hit.constructor == quad) {
            lasthit = hit.v0
            lastcolor = vec(lasthit.color) // make a copy
            lasthit.color = color.red
        } else {
            lastcolor = vec(hit.color) // make a copy
            hit.color = color.red
        }
    }
}

scene.bind("mousedown", getevent)
