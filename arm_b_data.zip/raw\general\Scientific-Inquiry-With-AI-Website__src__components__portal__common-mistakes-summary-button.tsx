"use client";

import { useState } from "react";

type Status =
  | { kind: "idle" }
  | { kind: "working" }
  | { kind: "ok"; summary: string }
  | { kind: "error"; message: string };

// Calls POST /api/portal/common-mistakes/summary and renders the returned AI
// summary. The scope is carried as an optional classId; the server re-derives
// the real scope from the session, so this is display state only. Admins pass
// no classId (global); faculty pass the class they're viewing.
export function CommonMistakesSummaryButton({ classId }: { classId?: string }) {
  const [status, setStatus] = useState<Status>({ kind: "idle" });

  async function generate() {
    setStatus({ kind: "working" });
    try {
      const res = await fetch("/api/portal/common-mistakes/summary", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(classId ? { classId } : {}),
      });
      const data = (await res.json().catch(() => ({}))) as {
        summary?: string;
        error?: string;
        detail?: string;
      };
      if (!res.ok || !data.summary) {
        setStatus({
          kind: "error",
          message: data.detail ?? data.error ?? `Couldn't generate a summary (${res.status}).`,
        });
        return;
      }
      setStatus({ kind: "ok", summary: data.summary });
    } catch {
      setStatus({ kind: "error", message: "Network error while generating the summary." });
    }
  }

  return (
    <div className="col" style={{ gap: 10 }}>
      <div className="row" style={{ gap: 10, alignItems: "center", flexWrap: "wrap" }}>
        <button
          type="button"
          className="btn primary sm"
          onClick={() => void generate()}
          disabled={status.kind === "working"}
        >
          {status.kind === "working"
            ? "Generating…"
            : status.kind === "ok"
              ? "Regenerate AI summary"
              : "Generate AI summary"}
        </button>
        <span className="muted" style={{ fontSize: 12.5 }}>
          Sends the anonymized compilation above to Claude for a short briefing.
        </span>
      </div>

      {status.kind === "ok" && (
        <div className="callout">
          <div
            style={{ fontSize: 13.5, lineHeight: 1.55, whiteSpace: "pre-wrap" }}
          >
            {status.summary}
          </div>
        </div>
      )}

      {status.kind === "error" && (
        <div className="callout orange">
          <strong>Summary failed.</strong> {status.message}
        </div>
      )}
    </div>
  );
}
