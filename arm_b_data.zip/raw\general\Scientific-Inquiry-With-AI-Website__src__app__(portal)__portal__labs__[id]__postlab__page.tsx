import { LabPostlabView } from "@/components/portal/lab-postlab-view";
import { guardStudentGlobalLab } from "@/lib/portal/global-lab-guard";

export const dynamic = "force-dynamic";

export default async function LabPostlabPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  await guardStudentGlobalLab(id);
  return <LabPostlabView labId={id} basePath={`/portal/labs/${id}`} />;
}
