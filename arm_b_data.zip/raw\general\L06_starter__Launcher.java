
public class Launcher{
  
 
  

   
  //Run this to launch the JavaPong Game!
  public static void main(String[] args){
         
    //Change these two values to test your different paddles!
    Human p1 = new HumanCreative();
    CPU p2 = new CPUCreative(p1);
    //*******************************************************
        
    JavaPong game = new JavaPong(p1, p2);
    
    game.playGame();
  }
  

  
  
}
