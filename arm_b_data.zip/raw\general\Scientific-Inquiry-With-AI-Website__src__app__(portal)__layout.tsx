import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
import { getSidebarLabs } from "@/lib/portal/data";
import { getStudentClassesWithLabs } from "@/lib/portal/classes";
import { getDayStreak } from "@/lib/portal/progress";
import {
  PortalShell,
  type ClassNavItem,
  type ModuleNavItem,
} from "@/components/portal/shell";

function initialsFrom(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "?";
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

export default async function PortalLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser();
  // The portal requires sign-in: send anonymous visitors to the login flow.
  if (!user) redirect("/login?next=/portal");

  const [sidebarLabs, classesWithLabs, dayStreak] = await Promise.all([
    getSidebarLabs(),
    getStudentClassesWithLabs(user.id),
    getDayStreak(user.id),
  ]);

  // Only students get the class-scoped list. Everyone else (admin, faculty, guest) gets
  // the full published-lab list — staff to preview, guests to browse. Students get the
  // published labs from classes they're enrolled in, so the global /portal/labs sidebar
  // can't surface labs outside their classes.
  const studentScoped = user.role === "student";
  let modules: ModuleNavItem[];
  if (!studentScoped) {
    modules = sidebarLabs.map((l) => ({
      id: l.id,
      label: l.name,
      href: `/portal/labs/${l.id}`,
      num: String(l.moduleOrder).padStart(2, "0"),
    }));
  } else {
    const seen = new Set<string>();
    modules = [];
    for (const c of classesWithLabs) {
      for (const l of c.labs) {
        if (l.moduleOrder == null || seen.has(l.id)) continue;
        seen.add(l.id);
        modules.push({
          id: l.id,
          label: l.name,
          href: `/portal/labs/${l.id}`,
          num: String(l.moduleOrder).padStart(2, "0"),
        });
      }
    }
  }

  // Embed each class's lab list so the client shell can swap the Modules group
  // synchronously on soft navigation — no flash, no client fetch. getStudentClassesWithLabs
  // already returns labs in per-class orderIndex order, so no client-side sort.
  const enrolledClasses: ClassNavItem[] = classesWithLabs.map((c) => ({
    id: c.id,
    name: c.name,
    labs: c.labs.map((l, i) => ({
      id: l.id,
      label: l.name,
      href: `/portal/classes/${c.id}/labs/${l.id}`,
      num: String(i + 1).padStart(2, "0"),
      locked: l.isLocked,
    })),
  }));

  const name = user.displayName ?? user.username;

  return (
    <div className="portal-root" data-density="regular">
      <PortalShell
        user={{ name, initials: initialsFrom(name) }}
        role={user.role}
        signedIn
        streak={dayStreak}
        modules={modules}
        enrolledClasses={enrolledClasses}
      >
        {children}
      </PortalShell>
    </div>
  );
}
