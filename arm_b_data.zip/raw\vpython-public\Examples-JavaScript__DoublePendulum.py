JavaScript 3.2

// Double pendulum

//The analysis is in terms of Lagrangian mechanics.
//The Lagrangian variables are angle of upper bar, angle of lower bar,
//measured from the vertical.

//Bruce Sherwood

// Corrections to the Lagrangian calculations by Owen Long, UC. Riverside

scene.width = scene.height = 600
scene.range = 1.8

// Display text below the 3D graphics:
scene.title = "A double pendulum"
let s = 'To rotate "camera", drag with right button or Ctrl-drag.\n'
s += "To zoom, drag with middle button or Alt/Option depressed, or use scroll wheel.\n"
s += "  On a two-button mouse, middle is left + right.\n"
s += "To pan left/right and up/down, Shift-drag.\n"
s += "Touch screen: pinch/extend to zoom, swipe or two-finger rotate.\n"
scene.caption = s


let g = 9.8
let M1 = 2.0
let M2 = 1.0
let d = 0.05 // thickness of each bar
let gap = 2*d // distance between two parts of upper, U-shaped assembly
let L1 = 0.5 // physical length of upper assembly; distance between axles
let L1display = L1+d // show upper assembly a bit longer than physical, to overlap axle
let L2 = 1 // physical length of lower bar
let L2display = L2+d/2 // show lower bar a bit longer than physical, to overlap axle
// Coefficients used in Lagrangian calculation
let A = (1/4)*M1*Math.pow(L1,2)+(1/12)*M1*Math.pow(L1,2)+M2*Math.pow(L1,2)
let B = (1/2)*M2*L1*L2
let C = g*L1*(M1/2+M2)
let D = M2*L1*L2/2
let E = (1/12)*M2*Math.pow(L2,2)+(1/4)*M2*Math.pow(L2,2)
let F = g*L2*M2/2

let hpedestal = 1.3*(L1+L2) // height of pedestal
let wpedestal = 0.1 // width of pedestal
let tbase = 0.05 // thickness of base
let wbase = 8*gap // width of base
let offset = 2*gap // from center of pedestal to center of U-shaped upper assembly
let pedestal_top = vec(0,hpedestal/2,0) // top of inner bar of U-shaped upper assembly

let theta1 = 1.3*pi/2 // initial upper angle (from vertical)
let theta1dot = 0 // initial rate of change of theta1
let theta2 = 0 // initial lower angle (from vertical)
let theta2dot = 0 // initial rate of change of theta2

let pedestal = box( {pos:pedestal_top-vec(0,hpedestal/2,offset),
                size:vec(wpedestal,1.1*hpedestal,wpedestal),
                color:vec(0.4,0.4,0.5)} )
let base = box( {pos:pedestal_top-vec(0,hpedestal+tbase/2,offset),
                 size:vec(wbase,tbase,wbase),
                 color:pedestal.color} )
let axle1 = cylinder( {pos:pedestal_top-vec(0,0,gap/2-d/4), axis:vec(0,0,-1),
                 size:vec(offset,d/4,d/4), color:color.yellow} )

let bar1 = box( {pos:pedestal_top+vec(L1display/2-d/2,0,-(gap+d)/2), 
                 size:vec(L1display,d,d), color:color.red} )
bar1.rotate( {angle:-pi/2, axis:vec(0,0,1), origin:vec(axle1.pos.x, axle1.pos.y, bar1.pos.z)} )
bar1.rotate( {angle:theta1, axis:vec(0,0,1), origin:vec(axle1.pos.x, axle1.pos.y, bar1.pos.z)} )

let bar1b = box( {pos:pedestal_top+vec(L1display/2-d/2,0,(gap+d)/2), 
                 size:vec(L1display,d,d), color:bar1.color} )
bar1b.rotate( {angle:-pi/2, axis:vec(0,0,1), origin:vec(axle1.pos.x, axle1.pos.y, bar1b.pos.z)} )
bar1b.rotate( {angle:theta1, axis:vec(0,0,1), origin:vec(axle1.pos.x, axle1.pos.y, bar1b.pos.z)} )

let pivot1 = vec(axle1.pos.x, axle1.pos.y, 0)

let axle2 = cylinder( {pos:pedestal_top+vec(L1,0,-(gap+d)/2), axis:vec(0,0,1), 
                size:vec(gap+d,axle1.size.y/2,axle1.size.y/2), color:axle1.color} )
axle2.rotate( {angle:-pi/2, axis:vec(0,0,1), origin:vec(axle1.pos.x, axle1.pos.y, axle2.pos.z)} )
axle2.rotate( {angle:theta1, axis:vec(0,0,1), origin:vec(axle1.pos.x, axle1.pos.y, axle2.pos.z)} )

let bar2 = box( {pos:axle2.pos+vec(L2display/2-d/2,0,(gap+d)/2), 
        size:vec(L2display,d,d), color:color.green} )

bar2.rotate( {angle:-pi/2,  axis:vec(0,0,1), origin:vec(axle2.pos.x, axle2.pos.y, bar2.pos.z)} )
bar2.rotate( {angle:theta2,  axis:vec(0,0,1), origin:vec(axle2.pos.x, axle2.pos.y, bar2.pos.z)} )

let dt = 0.0002
let t = 0

while (true) {
    await rate(1/dt) 
    // Calculate accelerations of the Lagrangian coordinates:
    let atheta1 = ((E*C/B)*sin(theta1)-F*sin(theta2))/(D-E*A/B)
    let atheta2 = -(A*atheta1+C*sin(theta1))/B
    // Update velocities of the Lagrangian coordinates:
    theta1dot = theta1dot+atheta1*dt
    theta2dot = theta2dot+atheta2*dt
    // Update Lagrangian coordinates:
    let dtheta1 = theta1dot*dt
    let dtheta2 = theta2dot*dt
    theta1 = theta1+dtheta1
    theta2 = theta2+dtheta2
    
    bar1.rotate( {angle:dtheta1, axis:vec(0,0,1), origin:pivot1} )
    bar1b.rotate( {angle:dtheta1, axis:vec(0,0,1), origin:pivot1} )
    let pivot2 = vec(axle2.pos.x, axle2.pos.y, pivot1.z)
    axle2.rotate( {angle:dtheta1, axis:vec(0,0,1), origin:pivot1} )
    bar2.rotate( {angle:dtheta2, axis:vec(0,0,1), origin:pivot2} )
    pivot2 = vec(axle2.pos.x, axle2.pos.y, pivot1.z)
    bar2.pos = pivot2 + bar2.axis/2
	
    t = t+dt
}
