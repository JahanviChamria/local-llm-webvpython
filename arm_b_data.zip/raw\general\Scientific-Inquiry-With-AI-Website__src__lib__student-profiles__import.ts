// Transport-agnostic prelab-progress import: validate → gate to published labs →
// shallow-merge into student_profiles. Called by the manual-upload REST route and
// by the sync_prelab_progress MCP tool, so the two paths can never drift.
//
// Identity (userId) is always supplied by the caller from an authenticated
// session or OAuth grant — never from the payload. This function does NO auth,
// CSRF, or size-cap work; the transport owns that before calling.

import { eq, sql } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { studentProfiles } from "@/lib/db/schema";
import { getAccessibleLabs } from "@/lib/portal/accessible-labs";
import { bodySchema, extractEngagement, normalizeImport } from "./import-normalize";

export type ProfileImportOutcome =
  | { ok: true; applied: string[]; topicSkipped: number }
  | { ok: false; code: "invalid_body"; detail: string }
  | { ok: false; code: "profile_not_initialized" }
  | { ok: false; code: "nothing_applicable"; topicSkipped: number };

/**
 * Apply a student's prelab-progress payload to their profile row.
 *
 * `payload` is the raw object a chatbot produced (tolerant of snake_case aliases
 * and an `engagement_scoring` block). Returns a discriminated outcome the caller
 * maps to its own response shape (HTTP status codes / MCP tool errors).
 */
export async function applyProfileImport(
  userId: string,
  payload: unknown,
  opts?: { routeLabId?: string; fallbackToSoleAccessibleLab?: boolean },
): Promise<ProfileImportOutcome> {
  const parsed = bodySchema.safeParse(normalizeImport(payload));
  if (!parsed.success) {
    return { ok: false, code: "invalid_body", detail: parsed.error.message };
  }
  const body = parsed.data;
  const engagement = extractEngagement(payload);

  // A profile row must already exist (auto-created for students; staff and
  // uninitialized accounts have none).
  const profile = (
    await db
      .select({ id: studentProfiles.id })
      .from(studentProfiles)
      .where(eq(studentProfiles.userId, userId))
      .limit(1)
  )[0];
  if (!profile) {
    return { ok: false, code: "profile_not_initialized" };
  }

  // Gate topicMastery to published labs + integer 0..5. Skip everything else.
  // Two sources feed the map: a canonical id-keyed topicMastery object (the
  // export round-trip) and a single engagement_scoring entry resolved by lab
  // name (the chatbot path). Both share the same accessible-lab + range gate.
  let topicMasteryClean: Record<string, number> | undefined;
  let topicSkipped = 0;
  if (body.topicMastery || engagement) {
    const accessibleLabs = await getAccessibleLabs(userId);
    const accessibleIds = new Set(accessibleLabs.map((l) => l.id));
    // name (trimmed, lowercased) → lab ids, so we can detect ambiguous matches.
    const nameToIds = new Map<string, string[]>();
    for (const l of accessibleLabs) {
      const key = l.name.trim().toLowerCase();
      nameToIds.set(key, [...(nameToIds.get(key) ?? []), l.id]);
    }
    const inRange = (n: number) => Number.isInteger(n) && n >= 0 && n <= 5;
    // Resolve one reference — a lab id UUID or a lab name — to a published lab
    // id. Returns undefined when it matches no lab or an ambiguous name.
    const resolveRef = (ref: string): string | undefined => {
      if (accessibleIds.has(ref)) return ref;
      const ids = nameToIds.get(ref.trim().toLowerCase());
      return ids && ids.length === 1 ? ids[0] : undefined;
    };

    const clean: Record<string, number> = {};
    if (body.topicMastery) {
      // Canonical map keys may be lab ids (export round-trip) or lab names.
      for (const [ref, level] of Object.entries(body.topicMastery)) {
        const id = resolveRef(ref);
        if (id && inRange(level)) clean[id] = level;
        else topicSkipped++;
      }
    }
    if (engagement) {
      // Where the engagement score lands, in precedence order:
      //   1. routeLabId — the lab the student is actually doing, passed by the
      //      caller (the MCP tool) from sciai://labs/current. Authoritative,
      //      because the tutor doc tags its JSON with a generic title
      //      ("Inelastic Collisions Chat History") that rarely matches the real
      //      lab name, so name-based routing silently drops the score.
      //   2. a lab id the JSON itself carried, if published to the student.
      //   3. a lab name from the JSON, resolved against published labs.
      //   4. fallback: if still unresolved and the student has exactly one
      //      published lab, attribute it there instead of dropping the score.
      let id: string | undefined;
      if (opts?.routeLabId && accessibleIds.has(opts.routeLabId)) {
        id = opts.routeLabId;
      } else if (engagement.labId && accessibleIds.has(engagement.labId)) {
        id = engagement.labId;
      } else if (engagement.labName) {
        id = resolveRef(engagement.labName);
      }
      if (!id && opts?.fallbackToSoleAccessibleLab && accessibleLabs.length === 1) {
        id = accessibleLabs[0].id;
      }
      if (id && inRange(engagement.level)) clean[id] = engagement.level;
      else topicSkipped++;
    }
    if (Object.keys(clean).length > 0) topicMasteryClean = clean;
  }

  // Shallow merge each provided section via `||`, mirroring the AI/manual write
  // path so concurrent writes don't clobber the whole column.
  const updateSet: Record<string, unknown> = { updatedAt: new Date() };
  const applied: string[] = [];
  if (topicMasteryClean) {
    updateSet.topicMastery = sql`${studentProfiles.topicMastery} || ${JSON.stringify(topicMasteryClean)}::jsonb`;
    applied.push("topicMastery");
  }
  if (body.mindMap !== undefined) {
    updateSet.mindMap = sql`${studentProfiles.mindMap} || ${JSON.stringify(body.mindMap)}::jsonb`;
    applied.push("mindMap");
  }
  if (body.personalization !== undefined) {
    updateSet.personalization = sql`${studentProfiles.personalization} || ${JSON.stringify(body.personalization)}::jsonb`;
    applied.push("personalization");
  }
  if (body.learningStyle !== undefined) {
    updateSet.learningStyle = sql`${studentProfiles.learningStyle} || ${JSON.stringify(body.learningStyle)}::jsonb`;
    applied.push("learningStyle");
  }
  if (body.struggles !== undefined) {
    updateSet.struggles = sql`${studentProfiles.struggles} || ${JSON.stringify(body.struggles)}::jsonb`;
    applied.push("struggles");
  }

  if (applied.length === 0) {
    return { ok: false, code: "nothing_applicable", topicSkipped };
  }

  await db.update(studentProfiles).set(updateSet).where(eq(studentProfiles.id, profile.id));

  return { ok: true, applied, topicSkipped };
}
