import sqlite3
import pandas as pd
from datetime import datetime

DB_PATH = "scanner.db"

CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS scan_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT,
    ticker TEXT,
    short_strike REAL,
    long_strike REAL,
    net_credit REAL,
    margin REAL,
    return_pct REAL,
    otm_pct REAL,
    short_delta REAL,
    dte INTEGER,
    expiration TEXT,
    phantom_flag INTEGER
)
"""


def _conn():
    return sqlite3.connect(DB_PATH)


def _init():
    with _conn() as con:
        con.execute(CREATE_TABLE)
        # Migrate older DBs that predate the short_delta column.
        cols = [r[1] for r in con.execute("PRAGMA table_info(scan_runs)").fetchall()]
        if "short_delta" not in cols:
            con.execute("ALTER TABLE scan_runs ADD COLUMN short_delta REAL")


def save_scan_results(df: pd.DataFrame):
    _init()
    if df.empty:
        return
    ts = datetime.now().isoformat()
    rows = []
    for _, row in df.iterrows():
        rows.append((
            ts,
            row.get("ticker"),
            row.get("short_strike"),
            row.get("long_strike"),
            row.get("net_credit"),
            row.get("margin"),
            row.get("return_pct"),
            row.get("otm_pct"),
            row.get("short_delta"),
            row.get("dte"),
            str(row.get("expiration", "")),
            int(bool(row.get("phantom_flag", False))),
        ))
    with _conn() as con:
        con.executemany(
            """INSERT INTO scan_runs
               (timestamp, ticker, short_strike, long_strike, net_credit,
                margin, return_pct, otm_pct, short_delta, dte, expiration, phantom_flag)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
            rows,
        )


def load_scan_history() -> pd.DataFrame:
    _init()
    with _conn() as con:
        return pd.read_sql_query(
            "SELECT * FROM scan_runs ORDER BY timestamp DESC", con
        )


def get_best_by_ticker(ticker: str) -> pd.DataFrame:
    _init()
    with _conn() as con:
        return pd.read_sql_query(
            "SELECT * FROM scan_runs WHERE ticker=? ORDER BY return_pct DESC LIMIT 1",
            con,
            params=(ticker,),
        )
