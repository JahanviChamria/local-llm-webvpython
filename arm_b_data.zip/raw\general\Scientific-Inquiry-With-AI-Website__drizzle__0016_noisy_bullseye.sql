ALTER TYPE "public"."lab_file_kind" ADD VALUE 'activity';--> statement-breakpoint
ALTER TYPE "public"."lab_file_kind" ADD VALUE 'analysis_guide';--> statement-breakpoint
ALTER TYPE "public"."lab_file_kind" ADD VALUE 'video_tutorial';--> statement-breakpoint
ALTER TYPE "public"."lab_file_kind" ADD VALUE 'research_paper';--> statement-breakpoint
ALTER TABLE "labs" ADD COLUMN "has_activity" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "labs" ADD COLUMN "has_analysis_guide" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "labs" ADD COLUMN "has_video_tutorial" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "labs" ADD COLUMN "has_research_paper" boolean DEFAULT false NOT NULL;