import numpy as np
import matplotlib.pyplot as plt

 m = 1 ### Mass - SI unit: [m] = kg

 r = 1 ### Radius - [r] = m

 omega = 1 ### Angular velocity - [omega] = 1/s

t_array = np.linspace(0, 2*np.pi, 100)
x_array = r*np.cos(omega*t_array)
y_array = r*np.sin(omega*t_array)

fig = plt.figure()
ax = fig.add_subplot(1,1,1)
ax.set_aspect(1)

plt.xlabel('x coordinate')
plt.ylabel('y coordinate')
plt.plot(x_array,y_array)

plt3D = plt.axes(projection='3d')

plt3D.set_xlabel('x coordinate [m]')
plt3D.set_ylabel('y coordinate [m]')
plt3D.set_zlabel('time [s]')
plt3D.scatter3D(x_array, y_array, t_array)

period = 2*np.pi / omega

path = 2*np.pi * r

# velocity = path / period
velocity = r*omega

# m/2 * velocity**2
m/2 * omega**2 * r**2

s = 1### Length - Unit [s] = m

num_points = 1000
r_list = np.linspace(0,s,num_points)

fig = plt.figure()
ax = fig.add_subplot(1,1,1)
ax.set_aspect(1)

plt.xlabel('x coordinate')
plt.ylabel('y coordinate')
plt.xlim([-1.2*s,1.2*s])
plt.ylim([-1.2*s,1.2*s])
plt.plot(r_list, np.zeros(num_points))

1/3*m*s**2 / 2 * omega**2

(m/num_points)/2 * omega**2 * np.sum(r_list**2)

num_points = 1000
r_list = np.linspace(-s/2,s/2,num_points)

fig = plt.figure()
ax = fig.add_subplot(1,1,1)
ax.set_aspect(1)

plt.xlabel('x coordinate')
plt.ylabel('y coordinate')
plt.xlim([-1.2*s,1.2*s])
plt.ylim([-1.2*s,1.2*s])
plt.plot(r_list, np.zeros(num_points))

1/12*m*s**2 / 2 * omega**2

(m/num_points)/2 * omega**2 * np.sum(r_list**2)

2/5*m*r**2 / 2 * omega**2

num_points = 30

30*30*30

coord_list = [] ### just for plotting
counter = 0
contribution = 0

for x in np.linspace(-r,r,num_points):
    for y in np.linspace(-r,r,num_points):
        for z in np.linspace(-r,r,num_points):
            if(np.linalg.norm([x,y,z]) <= r ):
                coord_list.append([x,y,z]) ### just for plotting
                counter = counter +1
                contribution = contribution + np.linalg.norm([x,y,0])**2

counter

coord_list = np.transpose(coord_list)

plt3D = plt.axes(projection='3d')

plt3D.set_xlabel('x coordinate [m]')
plt3D.set_ylabel('y coordinate [m]')
plt3D.set_zlabel('z coordinate [m]')
plt3D.scatter3D(coord_list[0],coord_list[1],coord_list[2],s=0.1)

(m/counter) * contribution / 2 * omega**2

r1 = 1
r2 = 0.8

1/2 * omega**2 * 2/5 * m * (r1**5 - r2**5)/(r1**3 - r2**3)

num_points = 40

coord_list = [] ### just for plotting
counter = 0
contribution = 0

for x in np.linspace(-r,r,num_points):
    for y in np.linspace(-r,r,num_points):
        for z in np.linspace(-r,r,num_points):
            if(r2 <= np.linalg.norm([x,y,z]) <= r1 ):
                coord_list.append([x,y,z]) ### just for plotting
                counter = counter +1
                contribution = contribution + np.linalg.norm([x,y,0])**2

coord_list = np.transpose(coord_list)

plt3D = plt.axes(projection='3d')

plt3D.set_xlabel('x coordinate [m]')
plt3D.set_ylabel('y coordinate [m]')
plt3D.set_zlabel('z coordinate [m]')
plt3D.scatter3D(coord_list[0],coord_list[1],coord_list[2],s=0.1)

(m/counter) * contribution / 2 * omega**2