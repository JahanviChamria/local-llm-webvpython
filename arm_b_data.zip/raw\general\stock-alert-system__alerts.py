import resend
from datetime import date
import logging

import pandas as pd

import config

logger = logging.getLogger(__name__)

FROM_EMAIL = "onboarding@resend.dev"


def _build_html(df: pd.DataFrame) -> str:
    total = len(df)
    top50 = df.head(50)
    shown = len(top50)

    best_rom = df.iloc[0] if not df.empty else None
    safest = df.loc[df["otm_pct"].idxmax()] if not df.empty else None
    phantom = df[df["phantom_flag"] == True]
    best_phantom = phantom.iloc[0] if not phantom.empty else None

    summary_lines = []
    if best_rom is not None:
        summary_lines.append(
            f"<b>Best ROM:</b> {best_rom['ticker']} "
            f"{best_rom['short_strike']}/{best_rom['long_strike']} "
            f"@ {best_rom['return_pct']}%"
        )
    if safest is not None:
        summary_lines.append(
            f"<b>Safest (highest % OTM):</b> {safest['ticker']} "
            f"{safest['short_strike']}/{safest['long_strike']} "
            f"@ {safest['otm_pct']}% OTM"
        )
    if best_phantom is not None:
        summary_lines.append(
            f"<b>Best Phantom:</b> {best_phantom['ticker']} "
            f"{best_phantom['short_strike']}/{best_phantom['long_strike']}"
        )

    summary_html = "<br>".join(summary_lines)

    rows_html = ""
    for _, row in top50.iterrows():
        rows_html += f"""
        <tr>
          <td>{row['ticker']}</td>
          <td>{row['short_strike']}</td>
          <td>{row['long_strike']}</td>
          <td>${row['net_credit']:.2f}</td>
          <td>${row['margin']:.0f}</td>
          <td>{row['return_pct']:.2f}%</td>
          <td>{row['otm_pct']:.2f}%</td>
          <td>{row['dte']}</td>
          <td>{row['expiration']}</td>
          <td>{'Yes' if row['phantom_flag'] else 'No'}</td>
        </tr>"""

    return f"""
    <html><body>
    <p>{summary_html}</p>
    <p style="font-family:Arial,sans-serif;font-size:13px;color:#555;">Showing top {shown} of {total} opportunities.</p>
    <table border="1" cellpadding="4" cellspacing="0" style="border-collapse:collapse;font-family:Arial,sans-serif;font-size:13px;">
      <thead style="background:#1a1a2e;color:white;">
        <tr>
          <th>Ticker</th><th>Short Strike</th><th>Long Strike</th>
          <th>Net Credit</th><th>Margin</th><th>ROM %</th>
          <th>% OTM</th><th>DTE</th><th>Expiration</th><th>Phantom</th>
        </tr>
      </thead>
      <tbody>{rows_html}</tbody>
    </table>
    </body></html>
    """


def send_alert(df: pd.DataFrame, recipient_email: str):
    if not config.RESEND_API_KEY:
        logger.error("RESEND_API_KEY not configured in .env")
        return

    resend.api_key = config.RESEND_API_KEY

    n = len(df)
    today = date.today().strftime("%Y-%m-%d")
    subject = f"Bull Put Scanner — {n} opportunities found — {today}"

    try:
        resend.Emails.send({
            "from": FROM_EMAIL,
            "to": recipient_email,
            "subject": subject,
            "html": _build_html(df),
        })
        logger.info(f"Alert sent to {recipient_email}")
    except Exception as e:
        logger.error(f"Failed to send alert: {e}")
