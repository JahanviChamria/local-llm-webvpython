public class Lab02Code{
     


    //Start with Problem 2.1 here!
    
    public static int getOrder(int num){
        int num1=Math.abs(num);
        int order=0;
        if(num1==0){
            return 1;
        }
        while(num1>0){
            order+=1;
            num1/=10;
        }
        return order;
    }

    public static boolean isArmstrong(int num){
        if(num<0){
            return false;
        }
        else {
            int order=getOrder(num);
            int digit, sum=0;
            int num1=num;
            while(num1>0){
                digit=num1%10;
                sum+=Math.pow(digit,order);
                num1/=10;
            }
            return (sum==num);
        }
    }

    public static int findArmstrongCount(int bound1, int bound2, boolean verboseMode){
        int lowerLim=Math.min(bound1, bound2);
        int upperLim=Math.max(bound1, bound2);
        int count=0;
        for(int j=lowerLim; j<=upperLim; j++){
            if(isArmstrong(j)){
                count+=1;
                if(verboseMode){
                    System.out.print(j+" ");
                }
            }
        }
        return count;
    }

    public static char advanceLetter(char ch, int offset){
        if(ch<'A' || ch>'Z'){
            return ch;
        }
        else {
            int newChar=ch;
            if(offset>0){
                for(int i=1; i<=offset; i++){
                    newChar+=1;
                    if(newChar>'Z'){
                        newChar='A';
                    }
                }
            }
            else{
                for(int i=1; i<=Math.abs(offset); i++){
                    newChar-=1;
                    if(newChar<'A'){
                        newChar='Z';
                    }
                }
            }
            return (char)newChar;
        }
   }

   public static int rollTilDoubles(boolean verboseMode){
        int rollCount=0, dice1=1, dice2=2;
        while(dice1!=dice2){
            rollCount+=1;
            dice1=(int)(Math.random()*6)+1;
            dice2=(int)(Math.random()*6)+1;
            if(verboseMode){
                System.out.print(dice1+"+"+dice2+" ");
            }
        }
        return rollCount;
   }

    
    
    
    

}
