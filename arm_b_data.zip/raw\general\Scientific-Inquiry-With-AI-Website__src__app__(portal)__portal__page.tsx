import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
import { getSidebarLabs } from "@/lib/portal/data";
import { getStudentClassesWithLabs } from "@/lib/portal/classes";

export const dynamic = "force-dynamic";

// /portal redirects to a lab the viewer is actually allowed to open. Non-students
// (admin, faculty, guest) land on the first published lab globally. Students land on the
// first published lab from a class they're enrolled in, and fall back to /portal/classes
// when they have none — so they're never sent to a lab outside their classes.
export default async function PortalHome() {
  const user = await getCurrentUser();

  if (user && user.role !== "student") {
    const sidebarLabs = await getSidebarLabs();
    if (sidebarLabs.length > 0) {
      redirect(`/portal/labs/${sidebarLabs[0].id}`);
    }
  } else if (user) {
    const classes = await getStudentClassesWithLabs(user.id);
    const firstLabId = classes.flatMap((c) => c.labs)[0]?.id;
    if (firstLabId) {
      redirect(`/portal/labs/${firstLabId}`);
    }
    redirect("/portal/classes");
  }

  return (
    <div className="col">
      <div className="screen-head">
        <div className="section-label">Modules</div>
        <h1>No modules yet</h1>
        <p className="lead muted">
          Your instructor hasn&apos;t published any lab modules yet. Check back soon — they&apos;ll
          appear in the sidebar.
        </p>
      </div>
    </div>
  );
}
