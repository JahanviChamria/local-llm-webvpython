import { notFound } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
import { getLabDetail, getLabDocumentDoneIds } from "@/lib/portal/data";
import { LAB_DOC_SECTION_BY_KIND, type LabDocKind } from "@/lib/portal/lab-sections";
import { LabDocumentList } from "@/components/portal/lab-document-list";
import { LabSectionShell } from "@/components/portal/lab-section-shell";

// Generic viewer for any file-based lab section (activity, analysis guide,
// video tutorial, research paper). Mirrors LabPrelabView/LabPostlabView but is
// driven by the section registry so all four new sections share one component.
export async function LabDocumentSectionView({
  labId,
  basePath,
  kind,
}: {
  labId: string;
  basePath: string;
  kind: LabDocKind;
}) {
  const section = LAB_DOC_SECTION_BY_KIND[kind];
  const detail = await getLabDetail(labId);
  if (!detail || !detail.lab[section.hasFlag]) notFound();

  const user = await getCurrentUser();

  // Faculty-only sections (instructor guide, lesson plan, answer key): fail
  // closed for anyone who isn't faculty/admin, so the sub-page can't be reached
  // by guessing the URL. The file download route is gated too, but the page
  // itself must 404 rather than render an empty shell.
  if (section.facultyOnly && user?.role !== "faculty" && user?.role !== "admin") {
    notFound();
  }

  const doneIds = await getLabDocumentDoneIds(user?.id ?? null);
  const signedIn = !!user;

  const items = detail.docsByKind[kind].map((f) => ({
    labFileId: f.labFileId,
    file: f.file,
    done: doneIds.has(f.labFileId),
  }));

  return (
    <LabSectionShell basePath={basePath} lab={detail.lab} sectionTitle={section.title}>
      {section.instructions && (
        <div className="callout" style={{ marginBottom: 12 }}>
          {section.instructions}
        </div>
      )}
      {items.length === 0 ? (
        <p className="muted" style={{ fontSize: 13 }}>
          No {section.title.toLowerCase()} {kind === "video_tutorial" ? "videos" : "documents"}{" "}
          attached yet.
        </p>
      ) : (
        <LabDocumentList
          labId={labId}
          kind={kind}
          items={items}
          signedIn={signedIn}
          downloadOnly={section.downloadOnly ?? false}
        />
      )}
    </LabSectionShell>
  );
}
