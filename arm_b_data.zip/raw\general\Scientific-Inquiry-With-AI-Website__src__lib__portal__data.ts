import { cache } from "react";
import { and, asc, desc, eq, inArray, isNotNull, sql } from "drizzle-orm";
import { db } from "@/lib/db/client";
import {
  files,
  labs,
  labFiles,
  labDocumentCompletions,
  questions,
} from "@/lib/db/schema";
import type { User } from "@/lib/db/schema";
import { findSimulation, type Simulation } from "@/lib/portal/simulations";
import { LAB_DOC_KINDS, type LabDocKind } from "@/lib/portal/lab-sections";

export type PortalFile = {
  id: string;
  title: string;
  description: string | null;
  category: string | null;
  accessLevel: "public" | "faculty";
  filename: string;
  contentType: string;
  sizeBytes: number;
  uploadedAt: Date;
};

/**
 * Ready files the given viewer is allowed to see.
 * - signed out / student / guest → public only
 * - faculty / admin → public + faculty
 */
export async function getPortalFiles(user: User | null): Promise<PortalFile[]> {
  const canSeeFaculty = user?.role === "faculty" || user?.role === "admin";
  const allowed: ("public" | "faculty")[] = canSeeFaculty ? ["public", "faculty"] : ["public"];

  return db
    .select({
      id: files.id,
      title: files.title,
      description: files.description,
      category: files.category,
      accessLevel: files.accessLevel,
      filename: files.filename,
      contentType: files.contentType,
      sizeBytes: files.sizeBytes,
      uploadedAt: files.uploadedAt,
    })
    .from(files)
    .where(and(eq(files.status, "ready"), inArray(files.accessLevel, allowed)))
    .orderBy(desc(files.uploadedAt));
}

export type PortalLab = {
  id: string;
  name: string;
  total: number;
  easy: number;
  medium: number;
  hard: number;
};

/** Labs with their question counts. Excludes labs that have no questions. */
export async function getPortalLabs(): Promise<PortalLab[]> {
  const rows = await db
    .select({
      id: labs.id,
      name: labs.name,
      easy: sql<number>`count(*) filter (where ${questions.difficulty} = 'easy')`,
      medium: sql<number>`count(*) filter (where ${questions.difficulty} = 'medium')`,
      hard: sql<number>`count(*) filter (where ${questions.difficulty} = 'hard')`,
      total: sql<number>`count(*)`,
    })
    .from(labs)
    .innerJoin(questions, eq(questions.labId, labs.id))
    .groupBy(labs.id, labs.name)
    .orderBy(asc(labs.name));

  return rows.map((r) => ({
    id: r.id,
    name: r.name,
    total: Number(r.total),
    easy: Number(r.easy),
    medium: Number(r.medium),
    hard: Number(r.hard),
  }));
}

export type SidebarLab = {
  id: string;
  name: string;
  moduleOrder: number;
};

// Used by both the portal layout (sidebar) and the /portal redirect, so first-lab selection
// can never diverge from sidebar-first-item. Tertiary id ASC tiebreaker because created_at
// can collide at microsecond resolution under concurrent admin inserts.
// Wrapped in `cache()` so layout + child server components share one query per render.
export const getSidebarLabs = cache(async (): Promise<SidebarLab[]> => {
  const rows = await db
    .select({
      id: labs.id,
      name: labs.name,
      moduleOrder: labs.moduleOrder,
    })
    .from(labs)
    .where(isNotNull(labs.moduleOrder))
    .orderBy(asc(labs.moduleOrder), asc(labs.createdAt), asc(labs.id));

  return rows.map((r) => ({ id: r.id, name: r.name, moduleOrder: r.moduleOrder ?? 0 }));
});

export type LabDocumentEntry = {
  labFileId: string;
  file: PortalFile;
};

export type LabPracticeSummary = {
  id: string;
  name: string;
  total: number;
};

export type LabDetail = {
  lab: {
    id: string;
    name: string;
    description: string | null;
    moduleOrder: number;
    hasPrelab: boolean;
    hasPostlab: boolean;
    hasPractice: boolean;
    hasSimulation: boolean;
    hasActivity: boolean;
    hasAnalysisGuide: boolean;
    hasVideoTutorial: boolean;
    hasResearchPaper: boolean;
    hasStudentGuide: boolean;
    hasSelfCheck: boolean;
    hasAiGradingPrompt: boolean;
    hasInstructorGuide: boolean;
    hasLessonPlan: boolean;
    hasSelfCheckAnswerKey: boolean;
  };
  // Attached files bucketed by lab_file_kind. prelabFiles/postlabFiles are kept
  // as convenience aliases for existing callers.
  docsByKind: Record<LabDocKind, LabDocumentEntry[]>;
  prelabFiles: LabDocumentEntry[];
  postlabFiles: LabDocumentEntry[];
  simulation: Simulation | null;
  practiceLab: LabPracticeSummary | null;
};

/**
 * Detail for a single published lab. Returns null if the lab doesn't exist or is unpublished
 * (so the route can call notFound()). Resolves the simulation slug against the static registry
 * and returns null silently if it no longer exists, so the UI surfaces an enabled-empty card
 * instead of crashing.
 */
export async function getLabDetail(labId: string): Promise<LabDetail | null> {
  const [labRow] = await db
    .select({
      id: labs.id,
      name: labs.name,
      description: labs.description,
      moduleOrder: labs.moduleOrder,
      hasPrelab: labs.hasPrelab,
      hasPostlab: labs.hasPostlab,
      hasPractice: labs.hasPractice,
      hasSimulation: labs.hasSimulation,
      hasActivity: labs.hasActivity,
      hasAnalysisGuide: labs.hasAnalysisGuide,
      hasVideoTutorial: labs.hasVideoTutorial,
      hasResearchPaper: labs.hasResearchPaper,
      hasStudentGuide: labs.hasStudentGuide,
      hasSelfCheck: labs.hasSelfCheck,
      hasAiGradingPrompt: labs.hasAiGradingPrompt,
      hasInstructorGuide: labs.hasInstructorGuide,
      hasLessonPlan: labs.hasLessonPlan,
      hasSelfCheckAnswerKey: labs.hasSelfCheckAnswerKey,
      simulationId: labs.simulationId,
      practiceLabId: labs.practiceLabId,
    })
    .from(labs)
    .where(and(eq(labs.id, labId), isNotNull(labs.moduleOrder)))
    .limit(1);

  if (!labRow) return null;

  const docs = await db
    .select({
      labFileId: labFiles.id,
      kind: labFiles.kind,
      position: labFiles.position,
      file: {
        id: files.id,
        title: files.title,
        description: files.description,
        category: files.category,
        accessLevel: files.accessLevel,
        filename: files.filename,
        contentType: files.contentType,
        sizeBytes: files.sizeBytes,
        uploadedAt: files.uploadedAt,
      },
    })
    .from(labFiles)
    .innerJoin(files, eq(files.id, labFiles.fileId))
    .where(eq(labFiles.labId, labId))
    .orderBy(asc(labFiles.position), asc(labFiles.createdAt));

  const docsByKind = Object.fromEntries(
    LAB_DOC_KINDS.map((k) => [k, [] as LabDocumentEntry[]]),
  ) as Record<LabDocKind, LabDocumentEntry[]>;
  for (const d of docs) {
    // d.kind is the lab_file_kind enum; every value is a LabDocKind.
    docsByKind[d.kind as LabDocKind]?.push({ labFileId: d.labFileId, file: d.file });
  }
  const prelabFiles = docsByKind.prelab;
  const postlabFiles = docsByKind.postlab;

  const simulation = labRow.simulationId ? findSimulation(labRow.simulationId) ?? null : null;

  let practiceLab: LabPracticeSummary | null = null;
  if (labRow.practiceLabId) {
    const [pl] = await db
      .select({
        id: labs.id,
        name: labs.name,
        total: sql<number>`count(${questions.id})`,
      })
      .from(labs)
      .leftJoin(questions, eq(questions.labId, labs.id))
      .where(eq(labs.id, labRow.practiceLabId))
      .groupBy(labs.id, labs.name)
      .limit(1);
    if (pl) {
      practiceLab = { id: pl.id, name: pl.name, total: Number(pl.total) };
    }
  }

  return {
    lab: {
      id: labRow.id,
      name: labRow.name,
      description: labRow.description,
      moduleOrder: labRow.moduleOrder ?? 0,
      hasPrelab: labRow.hasPrelab,
      hasPostlab: labRow.hasPostlab,
      hasPractice: labRow.hasPractice,
      hasSimulation: labRow.hasSimulation,
      hasActivity: labRow.hasActivity,
      hasAnalysisGuide: labRow.hasAnalysisGuide,
      hasVideoTutorial: labRow.hasVideoTutorial,
      hasResearchPaper: labRow.hasResearchPaper,
      hasStudentGuide: labRow.hasStudentGuide,
      hasSelfCheck: labRow.hasSelfCheck,
      hasAiGradingPrompt: labRow.hasAiGradingPrompt,
      hasInstructorGuide: labRow.hasInstructorGuide,
      hasLessonPlan: labRow.hasLessonPlan,
      hasSelfCheckAnswerKey: labRow.hasSelfCheckAnswerKey,
    },
    docsByKind,
    prelabFiles,
    postlabFiles,
    simulation,
    practiceLab,
  };
}

/** Set of lab_file_ids the user has marked done. Empty for signed-out users. */
export async function getLabDocumentDoneIds(userId: string | null): Promise<Set<string>> {
  if (!userId) return new Set();
  const rows = await db
    .select({ labFileId: labDocumentCompletions.labFileId })
    .from(labDocumentCompletions)
    .where(eq(labDocumentCompletions.userId, userId));
  return new Set(rows.map((r) => r.labFileId));
}

/** Emoji icon for a file, by content type then category. Matches the design's doc-icon look. */
export function fileIcon(contentType: string, category: string | null): string {
  const ct = contentType.toLowerCase();
  if (ct.startsWith("image/")) return "🖼️";
  if (ct.startsWith("audio/")) return "🎧";
  if (ct.startsWith("video/")) return "🎬";
  if (ct.includes("pdf")) return "📄";
  if (ct.includes("spreadsheet") || ct.includes("excel") || ct.includes("csv")) return "📊";
  if (ct.includes("word") || ct.includes("document")) return "📘";
  const cat = (category ?? "").toLowerCase();
  if (cat.includes("template")) return "📊";
  if (cat.includes("lesson") || cat.includes("tutor")) return "🧮";
  if (cat.includes("image")) return "🖼️";
  if (cat.includes("audio")) return "🎧";
  return "📄";
}

export function formatFileSize(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}
