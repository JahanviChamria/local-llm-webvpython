// sim.js — Block 1: headless direct-mapped cache model + access-pattern harness
// Run: node sim.js
//
// Default config (deliberate): cache 16 sets x 16 B blocks = 256 B,
// array 16x16 x 4-byte ints = 1024 B (4x the cache), so neither loop
// order can just fit the whole array and hide the story. 16 sets (not 8)
// per the 2026-07-07 config decision in the PRD: at 8 sets the shadow
// cache classified every non-cold column-major miss as capacity, so the
// conflict tally was zero on every pattern.

class DirectMappedCache {
  constructor({ numSets = 16, blockSize = 16 } = {}) {
    if ((numSets & (numSets - 1)) || (blockSize & (blockSize - 1))) {
      throw new Error("numSets and blockSize must be powers of two");
    }
    this.numSets = numSets;
    this.blockSize = blockSize;
    this.offsetBits = Math.log2(blockSize);
    this.indexBits = Math.log2(numSets);
    this.reset();
  }

  reset() {
    this.valid = new Array(this.numSets).fill(false);
    this.tags = new Array(this.numSets).fill(0);
    this.stats = { accesses: 0, hits: 0, misses: 0 };
  }

  // Returns a full event record so the renderer (Block 2/3) can replay it.
  access(addr) {
    const block = Math.floor(addr / this.blockSize);
    const set = block & (this.numSets - 1);
    const tag = block >> this.indexBits;

    this.stats.accesses++;
    const hit = this.valid[set] && this.tags[set] === tag;
    const evictedTag = !hit && this.valid[set] ? this.tags[set] : null;

    if (hit) {
      this.stats.hits++;
    } else {
      this.stats.misses++;
      this.valid[set] = true;
      this.tags[set] = tag;
    }
    return { addr, block, set, tag, hit, evictedTag };
  }

  hitRate() {
    return this.stats.accesses ? this.stats.hits / this.stats.accesses : 0;
  }
}

// ---- 3C miss classification (Block 4) ----
// Shadow fully-associative LRU cache of equal capacity (numLines = the real
// cache's set count, same block size) plus a first-touch block set.
// A real-cache miss is:
//   compulsory — first touch of the block
//   conflict   — the shadow cache would have hit
//   capacity   — the shadow cache missed too
class MissClassifier {
  constructor({ numLines = 16 } = {}) {
    this.numLines = numLines;
    this.reset();
  }

  reset() {
    this.seen = new Set();
    this.lru = []; // resident block numbers, least-recently-used first
    this.tally = { compulsory: 0, conflict: 0, capacity: 0 };
  }

  // Call once per access, with the real cache's event record. The shadow
  // cache is updated on every access; only real misses get a label.
  classify(ev) {
    const first = !this.seen.has(ev.block);
    this.seen.add(ev.block);

    const idx = this.lru.indexOf(ev.block);
    const shadowHit = idx !== -1;
    if (shadowHit) this.lru.splice(idx, 1);
    else if (this.lru.length >= this.numLines) this.lru.shift();
    this.lru.push(ev.block);

    if (ev.hit) return null;
    const type = first ? "compulsory" : shadowHit ? "conflict" : "capacity";
    this.tally[type]++;
    return type;
  }
}

// ---- Address generators over an N x N array of 4-byte ints ----
const INT = 4;

function* rowMajor(n) {
  for (let r = 0; r < n; r++)
    for (let c = 0; c < n; c++) yield (r * n + c) * INT;
}

function* colMajor(n) {
  for (let c = 0; c < n; c++)
    for (let r = 0; r < n; r++) yield (r * n + c) * INT;
}

function* strided(n, strideInts) {
  const total = n * n;
  for (let s = 0; s < strideInts; s++)
    for (let i = s; i < total; i += strideInts) yield i * INT;
}

// ---- Harness ----
function run(name, gen, config) {
  const cache = new DirectMappedCache(config);
  const clf = new MissClassifier({ numLines: config.numSets });
  for (const addr of gen) clf.classify(cache.access(addr));
  const { accesses, hits, misses } = cache.stats;
  const t = clf.tally;
  console.log(
    `${name.padEnd(22)} accesses=${String(accesses).padStart(4)}  ` +
    `hits=${String(hits).padStart(4)}  misses=${String(misses).padStart(4)}  ` +
    `hit rate=${(cache.hitRate() * 100).toFixed(1)}%  ` +
    `3C: compulsory=${t.compulsory} conflict=${t.conflict} capacity=${t.capacity}`
  );
  return cache.hitRate();
}

if (typeof require !== "undefined" && require.main === module) {
  const N = 16;
  const config = { numSets: 16, blockSize: 16 };
  console.log(
    `Config: ${config.numSets} sets x ${config.blockSize} B blocks = ` +
    `${config.numSets * config.blockSize} B cache; array ${N}x${N} ints = ${N * N * INT} B\n`
  );

  const rm = run("row-major", rowMajor(N), config);
  const cm = run("column-major", colMajor(N), config);
  run("strided (stride 8)", strided(N, 8), config);

  const ratio = cm === 0 ? Infinity : rm / cm;
  const pass = rm >= 5 * cm && rm > 0;
  console.log(
    `\nEXIT CHECK (Block 1): row-major / column-major = ` +
    `${ratio === Infinity ? "inf" : ratio.toFixed(1)}x  ->  ${pass ? "PASS (>=5x)" : "FAIL"}`
  );
  process.exitCode = pass ? 0 : 1;
}

if (typeof module !== "undefined") {
  module.exports = { DirectMappedCache, MissClassifier, rowMajor, colMajor, strided, INT };
}
