"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

// Human labels for the section keys the import route echoes back in `applied`.
const SECTION_LABELS: Record<string, string> = {
  topicMastery: "Topic mastery",
  mindMap: "Mind map",
  personalization: "Personalization",
  learningStyle: "Learning style",
  struggles: "Struggles",
};

type Status =
  | { kind: "idle" }
  | { kind: "working" }
  | { kind: "ok"; applied: string[]; topicSkipped: number }
  | { kind: "error"; message: string };

// Client-side import for the student's own prelab progress. Reads a JSON file
// from the device, POSTs it to /api/portal/profile/import, and refreshes the
// server-rendered sections below on success. Applies immediately on file pick.
export function ProfileImportButton() {
  const router = useRouter();
  const [status, setStatus] = useState<Status>({ kind: "idle" });

  async function onFile(file: File) {
    setStatus({ kind: "working" });

    let text: string;
    try {
      text = await file.text();
    } catch {
      setStatus({ kind: "error", message: "Could not read that file." });
      return;
    }

    let payload: unknown;
    try {
      payload = JSON.parse(text);
    } catch {
      setStatus({ kind: "error", message: "That file isn't valid JSON." });
      return;
    }

    try {
      const res = await fetch("/api/portal/profile/import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = (await res.json().catch(() => ({}))) as {
        ok?: boolean;
        applied?: string[];
        topicSkipped?: number;
        error?: string;
        detail?: string;
      };
      if (!res.ok || !data.ok) {
        setStatus({
          kind: "error",
          message: data.detail ?? data.error ?? `Import failed (${res.status}).`,
        });
        return;
      }
      setStatus({
        kind: "ok",
        applied: data.applied ?? [],
        topicSkipped: data.topicSkipped ?? 0,
      });
      router.refresh();
    } catch {
      setStatus({ kind: "error", message: "Network error during import." });
    }
  }

  return (
    <div className="col" style={{ gap: 8 }}>
      <div className="row" style={{ gap: 10, alignItems: "center", flexWrap: "wrap" }}>
        <label
          className="btn primary sm"
          style={{ cursor: status.kind === "working" ? "default" : "pointer" }}
        >
          {status.kind === "working" ? "Importing…" : "Import JSON summary"}
          <input
            type="file"
            accept="application/json,.json"
            style={{ display: "none" }}
            disabled={status.kind === "working"}
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) void onFile(f);
              e.currentTarget.value = "";
            }}
          />
        </label>
        <span className="muted" style={{ fontSize: 12.5 }}>
          Upload the JSON your chatbot gave you to update the sections below.
        </span>
      </div>

      <details style={{ fontSize: 12.5 }}>
        <summary className="muted" style={{ cursor: "pointer" }}>
          Accepted format
        </summary>
        <p className="muted" style={{ margin: "6px 0" }}>
          Any of these sections may be present. <code className="mono">mind_map</code> and{" "}
          <code className="mono">learning_style</code> are also accepted. To set a lab&apos;s
          engagement level, include <code className="mono">lab_name</code> (matched to one of
          your published labs) alongside the score.
        </p>
        <pre
          className="mono"
          style={{
            fontSize: 12,
            lineHeight: 1.5,
            overflow: "auto",
            background: "var(--surface)",
            border: "1px solid var(--border)",
            borderRadius: "var(--radius-sm)",
            padding: 12,
            whiteSpace: "pre",
          }}
        >
{`{
  "engagement_scoring": {
    "lab_name": "collisions",
    "total_ai_engagement_score": "2.00 / 5"
  },
  "mind_map": { },
  "personalization": { },
  "learning_style": { },
  "struggles": { }
}`}
        </pre>
      </details>

      {status.kind === "ok" && (
        <div className="callout green">
          <strong>Imported.</strong>{" "}
          {status.applied.length > 0
            ? "Updated " +
              status.applied.map((s) => SECTION_LABELS[s] ?? s).join(", ") +
              "."
            : "No sections changed."}
          {status.topicSkipped > 0 && (
            <>
              {" "}
              {status.topicSkipped} topic-mastery entr
              {status.topicSkipped === 1 ? "y was" : "ies were"} skipped (not among
              your published labs).
            </>
          )}
        </div>
      )}

      {status.kind === "error" && (
        <div className="callout orange">
          <strong>Import failed.</strong> {status.message}
        </div>
      )}
    </div>
  );
}
