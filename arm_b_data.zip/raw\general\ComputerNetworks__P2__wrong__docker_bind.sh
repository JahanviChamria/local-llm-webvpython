#!/bin/sh

if [ $# -ne 1 ]; then
    echo "Usage: ./docker_bind.sh BIND_PORT"
    exit 1
fi

BIND_PORT=$1

docker run --tty --interactive --rm --name=${USER}_bind \
    --publish $BIND_PORT:53/udp  --publish $BIND_PORT:53/tcp \
    --cap-add=NET_RAW --cap-add=NET_ADMIN \
    agemberjacobson/colgate-cosc465-bind:latest
