import { and, desc, eq, gt, inArray, isNull, or, sql } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { classes, classOwnershipTransfers, users } from "@/lib/db/schema";
import { ClassNotFoundError } from "@/lib/admin/classes";

export class TargetOwnerInvalidError extends Error {
  reason: "not_found" | "wrong_role" | "expired";
  constructor(reason: "not_found" | "wrong_role" | "expired") {
    super(`target owner invalid: ${reason}`);
    this.reason = reason;
  }
}

export type AdminClassSummary = {
  id: string;
  name: string;
  ownerId: string;
  ownerUsername: string;
  archivedAt: Date | null;
  createdAt: Date;
  studentCount: number;
  labCount: number;
};

export async function listAllClasses({
  includeArchived = false,
}: { includeArchived?: boolean } = {}): Promise<AdminClassSummary[]> {
  const conditions = includeArchived ? [] : [isNull(classes.archivedAt)];

  const rows = await db
    .select({
      id: classes.id,
      name: classes.name,
      ownerId: classes.ownerId,
      ownerUsername: users.username,
      archivedAt: classes.archivedAt,
      createdAt: classes.createdAt,
      // See listClassesForOwner: ${classes.id} renders unqualified inside a
      // sql`` template and would bind to the inner table's own id column, so
      // correlate explicitly against classes.id via an aliased subquery.
      studentCount: sql<number>`(select count(*) from class_enrollments ce where ce.class_id = classes.id)`,
      labCount: sql<number>`(select count(*) from class_labs cl where cl.class_id = classes.id)`,
    })
    .from(classes)
    .innerJoin(users, eq(users.id, classes.ownerId))
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(classes.createdAt));

  return rows.map((r) => ({
    id: r.id,
    name: r.name,
    ownerId: r.ownerId,
    ownerUsername: r.ownerUsername,
    archivedAt: r.archivedAt,
    createdAt: r.createdAt,
    studentCount: Number(r.studentCount),
    labCount: Number(r.labCount),
  }));
}

export type EligibleOwner = {
  id: string;
  username: string;
  displayName: string | null;
  role: "admin" | "faculty";
};

export async function listEligibleOwners(): Promise<EligibleOwner[]> {
  const now = new Date();
  const rows = await db
    .select({
      id: users.id,
      username: users.username,
      displayName: users.displayName,
      role: users.role,
    })
    .from(users)
    .where(
      and(
        inArray(users.role, ["admin", "faculty"]),
        or(isNull(users.expiresAt), gt(users.expiresAt, now)),
      ),
    )
    .orderBy(users.username);

  return rows.map((r) => ({
    id: r.id,
    username: r.username,
    displayName: r.displayName,
    role: r.role as "admin" | "faculty",
  }));
}

export async function transferOwnership(
  classId: string,
  newOwnerId: string,
  actorUserId: string,
): Promise<void> {
  await db.transaction(async (tx) => {
    const [cls] = await tx
      .select({
        id: classes.id,
        name: classes.name,
        ownerId: classes.ownerId,
      })
      .from(classes)
      .where(eq(classes.id, classId))
      .limit(1);
    if (!cls) throw new ClassNotFoundError();

    const [target] = await tx
      .select({
        id: users.id,
        username: users.username,
        role: users.role,
        expiresAt: users.expiresAt,
      })
      .from(users)
      .where(eq(users.id, newOwnerId))
      .limit(1);
    if (!target) throw new TargetOwnerInvalidError("not_found");
    if (target.role !== "admin" && target.role !== "faculty") {
      throw new TargetOwnerInvalidError("wrong_role");
    }
    if (target.expiresAt && target.expiresAt <= new Date()) {
      throw new TargetOwnerInvalidError("expired");
    }

    const [fromUser] = await tx
      .select({ id: users.id, username: users.username })
      .from(users)
      .where(eq(users.id, cls.ownerId))
      .limit(1);
    const [actor] = await tx
      .select({ id: users.id, username: users.username })
      .from(users)
      .where(eq(users.id, actorUserId))
      .limit(1);

    await tx
      .update(classes)
      .set({ ownerId: newOwnerId, updatedAt: new Date() })
      .where(eq(classes.id, classId));

    await tx.insert(classOwnershipTransfers).values({
      classId,
      className: cls.name,
      fromUserId: fromUser?.id ?? null,
      fromUsername: fromUser?.username ?? "(unknown)",
      toUserId: target.id,
      toUsername: target.username,
      actorUserId: actor?.id ?? null,
      actorUsername: actor?.username ?? "(unknown)",
    });
  });
}
