import { config } from "dotenv";
config({ path: ".env.local" });
config({ path: ".env" });

const endpoint = (process.env.R2_ENDPOINT ?? "").replace(/\/$/, "");
const privateBucket = process.env.R2_BUCKET ?? "";
const publicBucket = process.env.R2_PUBLIC_BUCKET ?? "";
const origins = ["http://localhost:3000", "http://localhost:3001"];

async function preflight(bucket: string, origin: string) {
  const url = `${endpoint}/${bucket}/__cors_probe__`;
  const res = await fetch(url, {
    method: "OPTIONS",
    headers: {
      Origin: origin,
      "Access-Control-Request-Method": "PUT",
      "Access-Control-Request-Headers": "content-type",
    },
  });
  return {
    status: res.status,
    allowOrigin: res.headers.get("access-control-allow-origin"),
    allowMethods: res.headers.get("access-control-allow-methods"),
    allowHeaders: res.headers.get("access-control-allow-headers"),
  };
}

async function main() {
  console.log("endpoint:", endpoint || "MISSING");
  for (const [label, bucket] of [
    ["private", privateBucket],
    ["public", publicBucket],
  ] as const) {
    console.log(`\n=== ${label} bucket: ${bucket || "(unset)"} ===`);
    if (!bucket || !endpoint) {
      console.log("  missing config; skipping");
      continue;
    }
    for (const origin of origins) {
      try {
        const r = await preflight(bucket, origin);
        const ok = r.allowOrigin ? "ALLOWED" : "BLOCKED";
        console.log(
          `  ${origin} -> ${ok}  (status ${r.status}, allow-origin=${r.allowOrigin ?? "none"}, methods=${r.allowMethods ?? "none"})`,
        );
      } catch (err) {
        console.log(`  ${origin} -> request error:`, err instanceof Error ? err.message : String(err));
      }
    }
  }
}

main();
