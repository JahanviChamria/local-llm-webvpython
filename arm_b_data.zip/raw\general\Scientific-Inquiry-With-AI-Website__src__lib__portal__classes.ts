import { cache } from "react";
import { and, asc, eq, inArray, isNotNull, isNull } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { classes, classEnrollments, classLabs, labs } from "@/lib/db/schema";

export type StudentClassNav = {
  id: string;
  name: string;
};

export type StudentClassLab = {
  id: string;
  name: string;
  moduleOrder: number | null;
  isLocked: boolean;
};

export type StudentClassWithLabs = StudentClassNav & {
  labs: StudentClassLab[];
};

export const getStudentClassesWithLabs = cache(
  async (userId: string): Promise<StudentClassWithLabs[]> => {
    const classRows = await db
      .select({ id: classes.id, name: classes.name })
      .from(classes)
      .innerJoin(classEnrollments, eq(classEnrollments.classId, classes.id))
      .where(and(eq(classEnrollments.userId, userId), isNull(classes.archivedAt)))
      .orderBy(asc(classes.name));

    if (classRows.length === 0) return [];

    const classIds = classRows.map((c) => c.id);
    const labRows = await db
      .select({
        classId: classLabs.classId,
        labId: labs.id,
        labName: labs.name,
        moduleOrder: labs.moduleOrder,
        orderIndex: classLabs.orderIndex,
        isLocked: classLabs.isLocked,
      })
      .from(classLabs)
      .innerJoin(labs, eq(labs.id, classLabs.labId))
      // Published-only: students never see unpublished labs even if one was assigned.
      .where(and(inArray(classLabs.classId, classIds), isNotNull(labs.moduleOrder)))
      .orderBy(asc(classLabs.classId), asc(classLabs.orderIndex));

    const byClass = new Map<string, StudentClassLab[]>();
    for (const id of classIds) byClass.set(id, []);
    for (const r of labRows) {
      byClass.get(r.classId)!.push({
        id: r.labId,
        name: r.labName,
        moduleOrder: r.moduleOrder,
        isLocked: r.isLocked,
      });
    }

    return classRows.map((c) => ({
      id: c.id,
      name: c.name,
      labs: byClass.get(c.id) ?? [],
    }));
  },
);

export const getClassForStudent = cache(
  async (
    classId: string,
    userId: string,
  ): Promise<StudentClassWithLabs | null> => {
    const [classRow] = await db
      .select({ id: classes.id, name: classes.name })
      .from(classes)
      .innerJoin(classEnrollments, eq(classEnrollments.classId, classes.id))
      .where(
        and(
          eq(classes.id, classId),
          eq(classEnrollments.userId, userId),
          isNull(classes.archivedAt),
        ),
      )
      .limit(1);

    if (!classRow) return null;

    const labRows = await db
      .select({
        id: labs.id,
        name: labs.name,
        moduleOrder: labs.moduleOrder,
        isLocked: classLabs.isLocked,
      })
      .from(classLabs)
      .innerJoin(labs, eq(labs.id, classLabs.labId))
      // Published-only: students never see unpublished labs even if one was assigned.
      .where(and(eq(classLabs.classId, classId), isNotNull(labs.moduleOrder)))
      .orderBy(asc(classLabs.orderIndex));

    return {
      id: classRow.id,
      name: classRow.name,
      labs: labRows,
    };
  },
);
