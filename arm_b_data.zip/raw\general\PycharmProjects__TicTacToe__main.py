import random

print("TIC TAC TOE")
choice=input("X or O?")
if choice=="X":
    cc="O"
else:
    cc="X"

grid=[]
count=0
n=0
x=0
y=0
while x<3:
    y=0
    while y<3:
        grid.append({"x":x, "y":y, "status":"E"})
        n+=1
        y+=1
    x+=1

def choose():
    boxx = int(input("X coordinate:"))
    boxy = int(input("Y coordinate:"))
    for _ in grid:
        if _["x"] == boxx and _["y"] == boxy:
            if _["status"] == "E":
                global count
                _["status"] = choice
                count+=1
            else:
                print("Occupied! Choose again.")
                choose()

def choosec():
    bx = random.randint(0, 2)
    by = random.randint(0, 2)
    for _ in grid:
        if _["x"] == bx and _["y"] == by:
            if _["status"] == "E":
                global count
                _["status"] = cc
                count+=1
            else:
                choosec()
def gridd():
    for a in range(3):
        for _ in grid:
            if _["status"]=="E":
                print("  |")
            else:
                print(f"{_['status']}|")
        print("\n______________\n")

game=True
while game:
    gridd()
    choose()
    choosec()
    if count>9:
        game=False

