from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By

chromedriver_path="E:\Development\chromedriver.exe"
service=Service(chromedriver_path)
driver=webdriver.Chrome(service=service)

driver.get("https://www.python.org/")

event_times=driver.find_elements(By.CSS_SELECTOR, ".event-widget time")
event_names=driver.find_elements(By.CSS_SELECTOR, ".event-widget li a")
events={}

for n in range(len(event_names)):
    events[n]={
        "time":event_times[n].text,
        "name":event_names[n].text
    }

print(events)