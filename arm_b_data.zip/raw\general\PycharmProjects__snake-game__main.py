from turtle import Screen
import random
from snake import Snake
import time
from food import Food
from score import Scoreboard

screen=Screen()
screen.setup(600, 600)
screen.bgcolor("black")
screen.title("Snake Game")
screen.tracer(0)
screen.listen()

snake=Snake()
food=Food()
scoreboard=Scoreboard()

screen.onkey(snake.up, "Up")
screen.onkey(snake.down, "Down")
screen.onkey(snake.left, "Left")
screen.onkey(snake.right, "Right")

game=True
while game:
    screen.update()
    time.sleep(0.1)
    snake.move()

    if snake.head.distance(food)<15:
        food.refresh()
        scoreboard.add()
        snake.extend()

    if snake.head.xcor() > 280 or snake.head.xcor()<-280 or snake.head.ycor()>280 or snake.head.ycor()<-280:
        scoreboard.reset()
        snake.reset()

    for seg in snake.segments[1:]:
        if snake.head.distance(seg)<10:
            scoreboard.reset()
            snake.reset()










screen.exitonclick()