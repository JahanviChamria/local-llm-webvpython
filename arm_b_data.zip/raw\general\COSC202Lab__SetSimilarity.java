import java.util.*;
public class SetSimilarity
{
    /**
     * Sparse similarity version (when most pairs have zero overlap)
     * Time complexity: O(nk + u*t^2)
     * Space complexity: O(u*t)
     */
    public static <E> Map<Integer, Map<Integer, Double>> similarities(ArrayList<Set<E>> setList) {

    //list of set indices mapping
    Map<E, ArrayList<Integer>> elementToSets = new HashMap<>();

    for (int i = 0; i < setList.size(); i++) {
        Set<E> currentSet = setList.get(i);
        for (E item : currentSet) {
            if (!elementToSets.containsKey(item)) {
                elementToSets.put(item, new ArrayList<Integer>());
            }
            elementToSets.get(item).add(i);
        }
    }

    //count intersections for pairs (i, j) with i < j
    Map<Integer, Map<Integer, Double>> intersections = new HashMap<>();

    for (E item : elementToSets.keySet()) {
        ArrayList<Integer> setsWithItem = elementToSets.get(item);

        for (int a = 0; a < setsWithItem.size(); a++) {
            int i = setsWithItem.get(a);
            for (int b = a + 1; b < setsWithItem.size(); b++) {
                int j = setsWithItem.get(b); // ensure j > i

                if (!intersections.containsKey(i)) {
                    intersections.put(i, new HashMap<Integer, Double>());
                }

                Map<Integer, Double> innerMap = intersections.get(i);

                if (!innerMap.containsKey(j)) {
                    innerMap.put(j, 1.0);
                } else {
                    innerMap.put(j, innerMap.get(j) + 1.0);
                }
            }
        }
    }

    //compute similarity from intersection counts
    for (int i : intersections.keySet()) {
        Map<Integer, Double> innerMap = intersections.get(i);
        for (int j : innerMap.keySet()) {
            double intersectionSize = innerMap.get(j);
            int sizeI = setList.get(i).size();
            int sizeJ = setList.get(j).size();
            double unionSize = sizeI + sizeJ - intersectionSize;
            double similarity = intersectionSize / unionSize;
            innerMap.put(j, similarity);
        }
    }

    return intersections;
    }

    public static void main(String[] args) {
        ArrayList<Set<Integer>> setList = new ArrayList<>();
        setList.add(new HashSet<>(Arrays.asList(1, 2, 4, 8)));
        setList.add(new HashSet<>(Arrays.asList(2, 4, 6, 8, 10)));
        setList.add(new HashSet<>(Arrays.asList(5, 8, 10)));

        System.out.println("\n=== Sparse Case ===");
        System.out.println(similarities(setList));
    }
}
