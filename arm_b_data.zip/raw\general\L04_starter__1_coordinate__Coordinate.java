
//An abstraction of a geometric point in space, consisting of an x and y value
public class Coordinate {
     
     private int x;         // Each Coordinate object has
     private int y;         // int x and y values as its attributes.
      
     
     //Comment the below constructor out for 2.1.2!
     // /*
     public Coordinate(){
         this(0,0);
     }
     // */
     
     

      //*** For 2.1.5 ***
      // Add the appropriate constructor that takes two int values

      public Coordinate(int x, int y){
         this.x=x;
         this.y=y;
      }



     
     public String toString() {
          return "Coordinate at (" + this.x + ", " + this.y + ")";
     }
     
     
     public int getX(){
         return this.x;
     }
     
     public int getY(){
         return this.y;
     }
         
     
      

      
      //*** For 2.1.3 ***
      //Translates (i.e. "moves") the referenced Coordinate object's x and y 
      //values by deltaX and deltaY, respectively.
      public void translate(int deltaX, int deltaY) {
           this.x = this.x + deltaX;
           this.y = this.y + deltaY;
      }
      

     
     

   
      //*** For 2.2.1 ***
      //Implement the getQuadrant() method.
      //Returns which quadrant of the xy-plane this Coordinate object falls in
      public int getQuadrant(){
            if(x==0 || y==0)
                return 0;
            else if(x>0 && y>0)
                return 1;
            else if(x<0 && y>0)
                return 2;
            else if(x<0 && y<0)
                return 3;
            else
                return 4;
      }

     
      
     

      //*** For 2.2.2 ***
      //Implement the generateRotation() method.
      //Creates and returns a new Coordinate with the referenced Coordinate's values, 
      //but rotated 90 degrees counter-clockwise
    
      public Coordinate generateRotation(){
            Coordinate coordrotated=new Coordinate(-this.y, this.x);
            return coordrotated;
      }




      //*** For 2.2.3 ***
      //Implement the areSameQuadrant(...) method.
      //Returns a boolean indicating if the reference and argument Coordinate objects exist
      //in the same quadrant (true) or not (false)
    
      public boolean areSameQuadrant(Coordinate other){
            if(this.getQuadrant()==other.getQuadrant())
                return true;
            else
                return false;
      }
     
     
     
     
     
}
