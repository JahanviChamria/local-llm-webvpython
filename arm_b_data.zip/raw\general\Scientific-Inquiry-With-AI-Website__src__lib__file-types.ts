// Single source of truth for upload allowlist + size cap.
// Server validates by MIME with an extension fallback (see isAllowedUploadType).
// Client picker uses MIME + extensions because OS pickers are inconsistent
// about MIME-only matching for less common types (.m4a / .flac / .md / .csv).

export const ALLOWED_UPLOAD_TYPES = [
  // Documents
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "application/vnd.ms-powerpoint",
  "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  // Text
  "text/plain",
  "text/csv",
  "text/markdown",
  // Images
  "image/png",
  "image/jpeg",
  "image/gif",
  "image/webp",
  // Archives
  "application/zip",
  "application/x-zip-compressed",
  // Audio — canonical types + variants browsers send in the wild
  "audio/mpeg",
  "audio/mp3",
  "audio/wav",
  "audio/x-wav",
  "audio/vnd.wave",
  "audio/mp4",
  "audio/x-m4a",
  "audio/aac",
  "audio/ogg",
  "application/ogg",
  "audio/flac",
  "audio/x-flac",
  "audio/webm",
  // Video — for lab video tutorials
  "video/mp4",
  "video/webm",
  "video/quicktime",
  "video/x-m4v",
] as const;

export const ALLOWED_UPLOAD_TYPES_SET: ReadonlySet<string> = new Set(ALLOWED_UPLOAD_TYPES);

export const ALLOWED_UPLOAD_EXTENSIONS = [
  ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
  ".txt", ".csv", ".md",
  ".png", ".jpg", ".jpeg", ".gif", ".webp",
  ".zip",
  ".mp3", ".wav", ".m4a", ".aac", ".ogg", ".oga", ".flac", ".weba",
  ".mp4", ".webm", ".mov", ".m4v",
] as const;

export function isVideoMime(t: string | null | undefined): boolean {
  return !!t && t.startsWith("video/");
}

export const ACCEPT_ATTRIBUTE = [
  ...ALLOWED_UPLOAD_TYPES,
  ...ALLOWED_UPLOAD_EXTENSIONS,
].join(",");

// 200 MB. Shared so client pre-check, /upload-url, and /complete agree.
export const MAX_UPLOAD_BYTES = 200 * 1024 * 1024;

export function isAudioMime(t: string | null | undefined): boolean {
  return !!t && (t.startsWith("audio/") || t === "application/ogg");
}

// MIME-first, extension fallback. Strictly more permissive than MIME-only —
// a renamed .exe → .mp3 passes the gate. Accepted because uploads are
// admin-only, R2 stores opaque blobs, and the server never executes them.
export function isAllowedUploadType(contentType: string, filename: string): boolean {
  if (ALLOWED_UPLOAD_TYPES_SET.has(contentType)) return true;
  const lower = filename.toLowerCase();
  return ALLOWED_UPLOAD_EXTENSIONS.some((ext) => lower.endsWith(ext));
}

// Bridges the extension-fallback gate to MIME-only downstream consumers
// (isAudioMime, the player, /media-url). When the sent MIME is empty or
// generic but the filename ends in a known audio extension, rewrite to the
// canonical audio/<...> MIME. Idempotent for already-canonical inputs.
const AUDIO_EXT_TO_MIME: ReadonlyArray<readonly [string, string]> = [
  [".mp3", "audio/mpeg"],
  [".wav", "audio/wav"],
  [".m4a", "audio/mp4"],
  [".aac", "audio/aac"],
  [".oga", "audio/ogg"],
  [".ogg", "audio/ogg"],
  [".flac", "audio/flac"],
  [".weba", "audio/webm"],
];

export function canonicalizeContentType(contentType: string, filename: string): string {
  if (contentType && contentType !== "application/octet-stream") return contentType;
  const lower = filename.toLowerCase();
  for (const [ext, mime] of AUDIO_EXT_TO_MIME) {
    if (lower.endsWith(ext)) return mime;
  }
  return contentType;
}
