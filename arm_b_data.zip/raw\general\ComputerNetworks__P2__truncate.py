import pandas as pd

#first 10,000 rows
df = pd.read_csv('C:/Users/jahan/Downloads/tranco_ZWL2G.csv', nrows=10000)

#save to a new file
df.to_csv('C:/Users/jahan/Downloads/tranco_10k.csv', index=False)