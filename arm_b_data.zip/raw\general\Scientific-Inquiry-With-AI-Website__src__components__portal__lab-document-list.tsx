import Link from "next/link";
import { fileIcon, formatFileSize, type PortalFile } from "@/lib/portal/data";
import type { LabDocKind } from "@/lib/portal/lab-sections";
import { Badge } from "@/components/portal/primitives";
import { LabDocumentMarkDone } from "@/components/portal/mark-done";

export type LabDocumentItem = {
  labFileId: string;
  file: PortalFile;
  done: boolean;
};

function timeAgo(d: Date): string {
  const days = Math.floor((Date.now() - new Date(d).getTime()) / 86_400_000);
  if (days <= 0) return "today";
  if (days === 1) return "1 day ago";
  if (days < 30) return `${days} days ago`;
  return new Date(d).toLocaleDateString();
}

function DocRow({
  labId,
  labFileId,
  f,
  signedIn,
  done,
  downloadOnly,
}: {
  labId: string;
  labFileId: string;
  f: PortalFile;
  signedIn: boolean;
  done: boolean;
  downloadOnly: boolean;
}) {
  const ext = (f.contentType.split("/").pop() || "file").toUpperCase().slice(0, 4);
  return (
    <div className="doc-row">
      <div className="doc-icon">{fileIcon(f.contentType, f.category)}</div>
      <div className="doc-info">
        <div className="doc-name">{f.title}</div>
        <div className="doc-meta">
          {timeAgo(f.uploadedAt)} · {ext} · {formatFileSize(f.sizeBytes)}
        </div>
        {f.description && (
          <div className="muted" style={{ fontSize: 12, marginTop: 3 }}>
            {f.description}
          </div>
        )}
      </div>
      <div className="doc-actions">
        {f.accessLevel === "faculty" && <Badge kind="progress">Faculty</Badge>}
        {!downloadOnly && (
          <Link
            className="btn ghost sm"
            href={`/portal/files/${f.id}?from=lab&labId=${labId}`}
          >
            View
          </Link>
        )}
        <a className="btn primary sm" href={`/api/files/${f.id}/download`}>
          ↓ Download
        </a>
        {signedIn && <LabDocumentMarkDone labFileId={labFileId} initialDone={done} />}
      </div>
    </div>
  );
}

export function LabDocumentList({
  labId,
  kind,
  items,
  signedIn,
  downloadOnly = false,
}: {
  labId: string;
  kind: LabDocKind;
  items: LabDocumentItem[];
  signedIn: boolean;
  downloadOnly?: boolean;
}) {
  return (
    <section data-kind={kind} className="col" style={{ gap: 9 }}>
      {items.map((it) => (
        <DocRow
          key={`${kind}-${it.labFileId}`}
          labId={labId}
          labFileId={it.labFileId}
          f={it.file}
          signedIn={signedIn}
          done={it.done}
          downloadOnly={downloadOnly}
        />
      ))}
    </section>
  );
}
