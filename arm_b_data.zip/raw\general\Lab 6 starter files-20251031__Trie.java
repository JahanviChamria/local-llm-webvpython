import java.io.*;
import java.util.*;

public class Trie {

    // node class
    private static class TrieNode {

        boolean isWord;
        HashMap<Character, TrieNode> children = new HashMap<
            Character,
            TrieNode
        >();
    }

    // root node
    private TrieNode root = new TrieNode();

    // implemented method
    public HashMap<String, Integer> suggestions(String target, int dist) {
        HashMap<String, Integer> results = new HashMap<String, Integer>();
        StringBuilder sb = new StringBuilder(); //to reduce the runtime for appends

        //start the recursive search from the root node
        recursiveHelper(root, sb, 0, 0, dist, target, results);

        return results;
    }

    //recursive helper
    private void recursiveHelper(TrieNode node, StringBuilder currentWord, int targetIndex, int currentDist, int maxDist, String target, HashMap<String, Integer> results) {
        //if we are already over the max distance, stop
        if (currentDist > maxDist) {
            return;
        }

        //check for a valid word
        if (node.isWord) {
            //complete word in the trie
            // final distance=current distance+cost of deleting all remaining characters from the target string
            int finalDist = currentDist + (target.length() - targetIndex);

            if (finalDist <= maxDist) {
                String word = currentWord.toString();
                
                //add the word if it is not present or update it if we found a shorter path (a smaller distance)
                if (!results.containsKey(word) || finalDist < results.get(word)) {
                    results.put(word, finalDist);
                }
            }
        }

        //all 3 Levenshtein operations

        //deletion (from trie word) 
        //consume a character from the target but stay at the same trie node
        if (targetIndex < target.length()) {
            recursiveHelper(node, currentWord, targetIndex + 1, currentDist + 1, maxDist, target, results);
        }

        //insertion and substitution/match
        //moving to a child node in the trie
        for (Map.Entry<Character, TrieNode> entry : node.children.entrySet()) {
            char childChar = entry.getKey();
            TrieNode childNode = entry.getValue();

            currentWord.append(childChar); //add char for this path

            //insertion (into trie word)
            //consume a trie char (move to child) but stay at the same target index
            recursiveHelper(childNode, currentWord, targetIndex, currentDist + 1, maxDist, target, results);

            //substitution or match
            //consume a char from both the trie (move to child) and the target
            if (targetIndex < target.length()) {
                int cost = (childChar == target.charAt(targetIndex)) ? 0 : 1;
                recursiveHelper(childNode, currentWord, targetIndex + 1, currentDist + cost,  maxDist, target, results);
            }

            currentWord.deleteCharAt(currentWord.length() - 1); //backtrack
        }
    }

    // method to add a string
    public boolean add(String s) {
        s = s.trim().toLowerCase();

        TrieNode current = root;

        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isLowerCase(c)) {
                TrieNode child = current.children.get(c);
                if (child == null) {
                    child = new TrieNode();
                    current.children.put(c, child);
                }
                current = child;
            }
        }

        if (current.isWord) return false;

        current.isWord = true;
        return true;
    }

    // method to check if a string has been added
    public boolean contains(String s) {
        s = s.trim().toLowerCase();

        TrieNode current = root;

        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isLowerCase(c)) {
                TrieNode child = current.children.get(c);
                if (child == null) {
                    return false;
                }
                current = child;
            }
        }

        return current.isWord;
    }

    // empty constructor
    public Trie() {
        super();
    }

    // constructor to add words from a stream, like standard input
    public Trie(InputStream source) {
        Scanner scan = new Scanner(source);
        addWords(scan);
        scan.close();
    }

    // constructor to add words from a file
    public Trie(String filename) throws FileNotFoundException {
        Scanner scan = new Scanner(new File(filename));
        addWords(scan);
        scan.close();
    }

    // helper function to add words from a scanner
    private void addWords(Scanner scan) {
        while (scan.hasNext()) {
            add(scan.next());
        }
    }

    // main function for testing
    public static void main(String[] args) {
        Trie dictionary;

        // the following section of code is set up
        // to read the filename from a command-line argument
        //
        // if you prefer to hard-code a filename for testing
        // or add words to the Trie manually, comment this section

        if (args.length > 0) {
            try {
                dictionary = new Trie(args[0]);
            } catch (FileNotFoundException e) {
                System.err.printf(
                    "could not open file %s for reading\n",
                    args[0]
                );
                return;
            }
        } else {
            dictionary = new Trie(System.in);
        }

        // here is an example of hard-coding the filename
        // making it easier to use the "Run" button in VS Code

        /*
        dictionary = new Trie("ospd.txt");
        */

        // here is an example of adding words to the Trie manually

        /*
        dictionary = new Trie();

        dictionary.add("cat");
        dictionary.add("car");
        dictionary.add("hat");
        */

        // here is an example of calling functions to test the Trie

        System.out.println(dictionary.contains("cat"));
        System.out.println(dictionary.suggestions("zat", 1));
    }
}
