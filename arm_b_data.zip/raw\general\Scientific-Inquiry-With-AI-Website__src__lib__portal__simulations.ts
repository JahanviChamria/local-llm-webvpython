/**
 * Registry of postlab simulations.
 *
 * Each simulation is a self-contained HTML file (with its own JS/canvas) that
 * lives in `public/simulations/`. The portal embeds it in an <iframe>, so the
 * sim's scripts and styles stay fully isolated from the app.
 *
 * To add a simulation:
 *   1. Drop its HTML file into `public/simulations/` (e.g. bouncing-ball.html).
 *   2. Add an entry below. `file` is the filename inside that folder.
 *
 * `labName` is optional and currently informational — how sims map to DB labs
 * will be finalized once the real files land.
 */
export type Simulation = {
  /** Stable slug — used in the URL query (?sim=) and as the React key. */
  id: string;
  title: string;
  subtitle: string;
  /** Filename inside public/simulations/, e.g. "bouncing-ball.html". */
  file: string;
  /** Optional: which lab this simulation extends. Mapping TBD. */
  labName?: string;
  badge?: "new" | "complete";
};

export const simulations: Simulation[] = [
  {
    id: "bouncing-ball",
    title: "Bouncing Ball — Coefficient of Restitution",
    subtitle: "From your happy / sad ball investigation",
    file: "bouncing-ball.html",
    labName: "Investigation of Inelastic Collisions",
    badge: "new",
  },
];

/** Public URL for a simulation's embedded HTML. */
export function simulationSrc(sim: Simulation): string {
  return `/simulations/${sim.file}`;
}

export function findSimulation(id: string | undefined): Simulation | undefined {
  if (!id) return undefined;
  return simulations.find((s) => s.id === id);
}
