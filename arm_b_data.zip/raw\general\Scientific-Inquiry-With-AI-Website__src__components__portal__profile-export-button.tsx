"use client";

// Client-side download of the student's own prelab progress as a JSON file.
// Emits the same flat five-key shape the import route accepts, so a downloaded
// file re-imports cleanly. The data is already on the page (server-fetched), so
// there's no round-trip — we just serialize it to a Blob and trigger a save.

type ProfileSections = {
  topicMastery: Record<string, unknown>;
  mindMap: Record<string, unknown>;
  personalization: Record<string, unknown>;
  learningStyle: Record<string, unknown>;
  struggles: Record<string, unknown>;
};

export function ProfileExportButton({
  data,
  alias,
}: {
  data: ProfileSections;
  alias: string;
}) {
  function download() {
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const date = new Date().toISOString().slice(0, 10); // YYYY-MM-DD
    const a = document.createElement("a");
    a.href = url;
    a.download = `prelab-progress-${alias}-${date}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="col" style={{ gap: 6 }}>
      <button type="button" className="btn sm" onClick={download}>
        Download my history (JSON)
      </button>
      <span className="muted" style={{ fontSize: 12.5 }}>
        Exports all five sections above. The file can be re-imported here or
        shared with your chatbot.
      </span>
    </div>
  );
}
