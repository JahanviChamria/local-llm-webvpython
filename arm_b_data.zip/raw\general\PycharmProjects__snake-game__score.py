from turtle import Turtle

class Scoreboard(Turtle):

    def __init__(self):
        super().__init__()
        self.penup()
        with open("data.txt", mode="r") as data:
            file=data.read()
            self.hs=int(file)
        self.hideturtle()
        self.color("white")
        self.goto(x=0, y=280)
        self.s = 0
        self.update()
    def update(self):
        self.clear()
        self.write(f"Score: {self.s} High score: {self.hs}", False, align="center", font=('Arial', 10, 'normal'))
    def add(self):
        self.s+=1
        self.update()


    def reset(self):
        if self.s>self.hs:
            self.hs=self.s
            with open("data.txt", mode="w") as data:
                data.write(f"{self.hs}")
        self.s=0
        self.update()
    #
    # def gameover(self):
    #     self.goto(0,0)
    #     self.write("GAME OVER!", False, align="center", font=('Arial', 14, 'normal'))