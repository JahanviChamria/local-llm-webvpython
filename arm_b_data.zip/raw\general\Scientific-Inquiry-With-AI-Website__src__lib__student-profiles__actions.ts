// OAuth-authenticated actions on student_profiles.
//
// Scope today: a single typed write — `setTopicMastery(topic, level)`. Deliberately
// narrow per the writeback foothold plan: the public /students/[alias] page is
// out of scope until D1 (auth-gate decision) lands, so we ship only the path
// that closes the loop INSIDE the authenticated portal first.
//
// Why this shape (vs a generic JSONB patch):
//   - topic is a closed enum, not freeform → no PII into the row.
//   - level is bounded int 0-5 → no payload growth surface.
//   - the SET expression is a single jsonb_set with a parameter-bound path
//     (array[$topic]::text[]) — NEVER string-concatenated into `'{...}'`
//     literal — so a topic with commas / braces cannot become a nested path.
//     (And the Zod enum gate ensures only vocabulary entries reach here.)
//   - one statement, RETURNING the new column value → no read-modify-write,
//     no separate re-read, and concurrent calls with different topics both
//     converge under READ COMMITTED.
//
// Zod schemas live in ./topics so they can be imported in unit tests without
// pulling in the db client.

import { eq, sql } from "drizzle-orm";
import type { AnyPgColumn } from "drizzle-orm/pg-core";
import { db } from "@/lib/db/client";
import { studentProfiles } from "@/lib/db/schema";
import { hasScope, toolError, type McpContext } from "@/lib/mcp/context";
import { isLabAccessible } from "@/lib/portal/accessible-labs";
import { SCOPE_STUDY_READ, SCOPE_STUDY_WRITE } from "@/lib/oauth/scopes";
import {
  setTopicMasteryInput,
  setTopicMasteryOutput,
  mergeProfileColumnInput,
  mergeProfileColumnOutput,
  getStudentProfileOutput,
  TOPIC_VOCABULARY,
  type SetTopicMasteryInput,
  type MergeProfileColumnInput,
  type MergeableColumn,
  type Topic,
} from "./topics";

export async function setTopicMasteryImpl(args: SetTopicMasteryInput, ctx: McpContext) {
  if (!hasScope(ctx, SCOPE_STUDY_WRITE)) return toolError("study:write scope required");
  if (ctx.user.role === "guest") return toolError("verified students only");

  // `args.topic` is a lab id. Only labs currently published to this student
  // (assigned + unlocked in a non-archived class they're enrolled in) are valid
  // mastery targets — mirrors exactly what the topic-mastery UI renders.
  if (!(await isLabAccessible(ctx.user.id, args.topic))) {
    return toolError(
      "topic_not_accessible: pass a lab id from sciai://labs/current; that lab is not published to you.",
    );
  }

  // Single statement: lookup-by-userId AND apply the jsonb_set in one UPDATE
  // with RETURNING. If no row matches, RETURNING is empty and we report
  // profile_not_initialized — same outcome as a separate SELECT-then-UPDATE
  // but without the read-modify-write race.
  //
  // The schema marks topic_mastery NOT NULL DEFAULT '{}' so the coalesce is
  // defense-in-depth, not strictly required.
  const rows = await db
    .update(studentProfiles)
    .set({
      topicMastery: sql`jsonb_set(coalesce(${studentProfiles.topicMastery}, '{}'::jsonb), array[${args.topic}]::text[], to_jsonb(${args.level}::int), true)`,
      updatedAt: new Date(),
    })
    .where(eq(studentProfiles.userId, ctx.user.id))
    .returning({ topicMastery: studentProfiles.topicMastery });

  if (rows.length === 0) {
    return toolError(
      "profile_not_initialized: ask faculty to enable your learning history before updates.",
    );
  }

  const newMastery = rows[0].topicMastery as Record<string, unknown>;

  // Validate the returned shape against the output schema before stringifying
  // so doc/impl drift surfaces at runtime instead of at customer-report time.
  const payload = setTopicMasteryOutput.parse({
    status: "updated",
    topic: args.topic,
    level: args.level,
    topicMastery: newMastery,
  });

  return {
    content: [
      {
        type: "text" as const,
        text: JSON.stringify(payload),
      },
    ],
  };
}

// --- Freeform JSONB column merges (mindMap, personalization, learningStyle,
//     struggles) -----------------------------------------------------------
//
// Single statement: `<column> = <column> || $patch::jsonb`. Top-level shallow
// merge. RETURNING the new value so the GPT can echo without a follow-up read.
// READ COMMITTED + per-row implicit write lock means concurrent merges to
// different top-level keys on the same column both apply (second waiter
// re-evaluates the SET against the freshly committed row); concurrent merges
// to the *same* top-level key are last-writer-wins.
//
// The schema marks every JSONB column NOT NULL DEFAULT '{}', so we can skip
// the coalesce dance the read review flagged for NULL-typed columns.

const COLUMN_FIELD: Record<MergeableColumn, AnyPgColumn> = {
  mindMap: studentProfiles.mindMap,
  personalization: studentProfiles.personalization,
  learningStyle: studentProfiles.learningStyle,
  struggles: studentProfiles.struggles,
};

export async function mergeProfileColumnImpl(
  columnKey: MergeableColumn,
  args: MergeProfileColumnInput,
  ctx: McpContext,
) {
  if (!hasScope(ctx, SCOPE_STUDY_WRITE)) return toolError("study:write scope required");
  if (ctx.user.role === "guest") return toolError("verified students only");

  const column = COLUMN_FIELD[columnKey];
  const patchJson = JSON.stringify(args.patch);

  const rows = await db
    .update(studentProfiles)
    .set({
      [columnKey]: sql`${column} || ${patchJson}::jsonb`,
      updatedAt: new Date(),
    })
    .where(eq(studentProfiles.userId, ctx.user.id))
    .returning({ value: column });

  if (rows.length === 0) {
    return toolError(
      "profile_not_initialized: ask faculty to enable your learning history before updates.",
    );
  }

  const payload = mergeProfileColumnOutput.parse({
    status: "updated",
    column: columnKey,
    value: rows[0].value as Record<string, unknown>,
  });

  return {
    content: [{ type: "text" as const, text: JSON.stringify(payload) }],
  };
}

// Thin wrappers per column — each REST handler imports its own to keep the
// route-file → impl mapping 1:1 and let openapi.json describe each operationId
// independently. The shared mergeProfileColumnImpl is the only piece that
// touches the DB.
export const setMindMapImpl = (args: MergeProfileColumnInput, ctx: McpContext) =>
  mergeProfileColumnImpl("mindMap", args, ctx);
export const setPersonalizationImpl = (args: MergeProfileColumnInput, ctx: McpContext) =>
  mergeProfileColumnImpl("personalization", args, ctx);
export const setLearningStyleImpl = (args: MergeProfileColumnInput, ctx: McpContext) =>
  mergeProfileColumnImpl("learningStyle", args, ctx);
export const setStrugglesImpl = (args: MergeProfileColumnInput, ctx: McpContext) =>
  mergeProfileColumnImpl("struggles", args, ctx);

// --- Read endpoint ----------------------------------------------------------
//
// Returns all five JSONB columns + the public alias + an ISO updatedAt. The
// GPT calls this before a merge that needs to extend a nested array, so it
// has the existing value to combine with. Required-read for the public-page
// writeback contract, but not strictly load-bearing for top-level-key writes
// (those merge non-destructively).

export async function getStudentProfileImpl(_args: unknown, ctx: McpContext) {
  if (!hasScope(ctx, SCOPE_STUDY_READ)) return toolError("study:read scope required");
  if (ctx.user.role === "guest") return toolError("verified students only");

  const [row] = await db
    .select({
      alias: studentProfiles.alias,
      topicMastery: studentProfiles.topicMastery,
      mindMap: studentProfiles.mindMap,
      personalization: studentProfiles.personalization,
      learningStyle: studentProfiles.learningStyle,
      struggles: studentProfiles.struggles,
      updatedAt: studentProfiles.updatedAt,
    })
    .from(studentProfiles)
    .where(eq(studentProfiles.userId, ctx.user.id))
    .limit(1);

  if (!row) {
    return toolError("profile_not_initialized: ask faculty to enable your learning history.");
  }

  const payload = getStudentProfileOutput.parse({
    alias: row.alias,
    topicMastery: row.topicMastery as Record<string, unknown>,
    mindMap: row.mindMap as Record<string, unknown>,
    personalization: row.personalization as Record<string, unknown>,
    learningStyle: row.learningStyle as Record<string, unknown>,
    struggles: row.struggles as Record<string, unknown>,
    updatedAt: row.updatedAt.toISOString(),
  });

  return {
    content: [{ type: "text" as const, text: JSON.stringify(payload) }],
  };
}

// Re-exports so callers can `import { ... } from "@/lib/student-profiles/actions"`
// without reaching into ./topics.
export {
  setTopicMasteryInput,
  setTopicMasteryOutput,
  mergeProfileColumnInput,
  mergeProfileColumnOutput,
  getStudentProfileOutput,
  TOPIC_VOCABULARY,
  type Topic,
  type SetTopicMasteryInput,
  type MergeProfileColumnInput,
  type MergeableColumn,
};
