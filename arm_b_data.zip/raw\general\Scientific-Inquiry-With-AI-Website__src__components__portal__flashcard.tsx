"use client";

import { useState } from "react";

export function Flashcard({ q, a, flippedStart }: { q: string; a: string; flippedStart?: boolean }) {
  const [flipped, setFlipped] = useState(!!flippedStart);
  return (
    <div className={"flashcard" + (flipped ? " flipped" : "")} onClick={() => setFlipped((f) => !f)}>
      <div className="fc-side">{flipped ? "Answer" : "Question"}</div>
      <div className="fc-q">{flipped ? a : q}</div>
      <div className="fc-hint">{flipped ? "Tap to hide" : "Tap to reveal answer"}</div>
    </div>
  );
}
