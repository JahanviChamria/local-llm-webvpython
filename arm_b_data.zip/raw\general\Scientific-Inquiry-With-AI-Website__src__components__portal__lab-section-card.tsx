import Link from "next/link";
import type { ReactNode } from "react";

export type LabSectionCardProps = {
  index: number;
  topTag: string;
  icon: ReactNode;
  title: string;
  href: string;
};

export function LabSectionCard({ index, topTag, icon, title, href }: LabSectionCardProps) {
  const num = String(index).padStart(2, "0");
  return (
    <Link href={href} className="lab-card">
      <div className="lab-card-h">
        <span className="lab-card-num">{num}</span>
        <span className="lab-card-tag">{topTag}</span>
      </div>
      <div className="lab-card-icon">{icon}</div>
      <div className="lab-card-title">{title}</div>
    </Link>
  );
}
