import { redirect } from "next/navigation";
import { isNotNull, sql } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { labs } from "@/lib/db/schema";
import { getCurrentUser } from "@/lib/auth/session";
import { NewClassForm, type LabOption } from "./client";

export const dynamic = "force-dynamic";

export default async function NewClassPage() {
  const me = await getCurrentUser();
  if (!me) redirect("/login?next=/admin/classes/new");
  if (me.role !== "admin" && me.role !== "faculty") {
    return (
      <div className="col">
        <div className="screen-head">
          <div className="section-label">Restricted</div>
          <h1>Not available</h1>
        </div>
      </div>
    );
  }

  // Only published modules (module_order is set) are assignable. Unpublished
  // labs — e.g. question-bank labs auto-created on bank import — have a null
  // module_order and shouldn't appear in the picker.
  const labRows = await db
    .select({ id: labs.id, name: labs.name, moduleOrder: labs.moduleOrder })
    .from(labs)
    .where(isNotNull(labs.moduleOrder))
    .orderBy(sql`${labs.moduleOrder} asc nulls last, ${labs.name} asc`);

  const options: LabOption[] = labRows.map((l) => ({
    id: l.id,
    name: l.name,
    moduleOrder: l.moduleOrder,
  }));

  return (
    <div className="col">
      <div className="screen-head">
        <div className="section-label">Teaching</div>
        <h1>New class</h1>
        <p className="lead muted">
          Name the class and pick which labs it covers. You can edit the lab list later.
        </p>
      </div>
      <NewClassForm options={options} />
    </div>
  );
}
