// Class-wide "common mistakes" compilation for the Prelab progress views.
//
// Two data sources, per the feature decision:
//   1. Retrieval misses — srsReviews rated "again"/"hard", grouped by question
//      and by lab. Structured and countable ("faced by multiple students").
//   2. Struggles — the freeform `struggles` JSONB the AI tutor writes per
//      student. Aggregated by extracting string leaves and counting how many
//      distinct students repeat each phrase.
//
// Scope mirrors the surrounding view (see the Scope answer): admins aggregate
// across every student; faculty aggregate across one class they own. The scope
// resolver re-validates class ownership so it is safe to call from the API route
// on untrusted input, not just from the already-authorized page.

import { and, eq, inArray, isNull, sql } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { isUuid } from "@/lib/ids";
import {
  classEnrollments,
  classes,
  labs,
  questions,
  srsReviews,
  studentProfiles,
  users,
} from "@/lib/db/schema";

// A phrase/question must be shared by at least this many distinct students to
// count as "common" — the whole point of the compilation.
const MIN_STUDENTS = 2;
const MAX_QUESTIONS = 8;
const MAX_LABS = 6;
const MAX_THEMES = 8;
// A lab needs some review volume before a miss rate is meaningful.
const MIN_LAB_REVIEWS = 4;
// String leaves outside this length are dropped as noise (single tokens like
// "low", or giant blobs) when mining the freeform struggles column.
const MIN_STRUGGLE_CHARS = 4;
const MAX_STRUGGLE_CHARS = 160;

export type MistakeScope =
  | { kind: "all" }
  | { kind: "class"; classId: string; ownerId: string };

export type MissedQuestion = {
  questionId: string;
  prompt: string;
  labName: string | null;
  studentsAffected: number;
  totalMisses: number;
};

export type WeakLab = {
  labId: string;
  name: string;
  studentsStruggling: number;
  missRate: number; // 0-100, share of reviews rated again/hard
};

export type StruggleTheme = {
  text: string;
  studentsAffected: number;
};

export type CommonMistakesReport = {
  studentsInScope: number;
  missedQuestions: MissedQuestion[];
  weakLabs: WeakLab[];
  struggleThemes: StruggleTheme[];
};

const EMPTY_REPORT: CommonMistakesReport = {
  studentsInScope: 0,
  missedQuestions: [],
  weakLabs: [],
  struggleThemes: [],
};

// Resolve a scope to the set of in-scope student ids. Returns null when the
// scope is invalid (class missing / not owned / archived, or a malformed id) so
// callers can 404/deny rather than silently aggregate the wrong students.
async function resolveScopeStudentIds(scope: MistakeScope): Promise<string[] | null> {
  if (scope.kind === "all") {
    const rows = await db
      .select({ id: users.id })
      .from(users)
      .where(eq(users.role, "student"));
    return rows.map((r) => r.id);
  }

  // class scope — guard the uuid before drizzle (labs.id is a uuid column) and
  // re-verify ownership + non-archived, mirroring getStudentsForClass.
  if (!isUuid(scope.classId)) return null;
  const [classRow] = await db
    .select({ id: classes.id })
    .from(classes)
    .where(
      and(
        eq(classes.id, scope.classId),
        eq(classes.ownerId, scope.ownerId),
        isNull(classes.archivedAt),
      ),
    )
    .limit(1);
  if (!classRow) return null;

  const rows = await db
    .select({ id: users.id })
    .from(classEnrollments)
    .innerJoin(users, eq(users.id, classEnrollments.userId))
    .where(and(eq(classEnrollments.classId, scope.classId), eq(users.role, "student")));
  return rows.map((r) => r.id);
}

function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

// Collect sentence-like string leaves from one student's freeform struggles
// JSONB. Recurses through nested objects/arrays; ignores keys and short/long
// noise. Values are normalized (whitespace collapsed) so trivially-different
// phrasings still group.
function collectStruggleStrings(value: unknown, out: Set<string>): void {
  if (typeof value === "string") {
    const norm = value.replace(/\s+/g, " ").trim();
    if (norm.length >= MIN_STRUGGLE_CHARS && norm.length <= MAX_STRUGGLE_CHARS) {
      out.add(norm);
    }
    return;
  }
  if (Array.isArray(value)) {
    for (const v of value) collectStruggleStrings(v, out);
    return;
  }
  if (isRecord(value)) {
    for (const v of Object.values(value)) collectStruggleStrings(v, out);
  }
}

export async function getCommonMistakes(
  scope: MistakeScope,
): Promise<CommonMistakesReport | null> {
  const studentIds = await resolveScopeStudentIds(scope);
  if (studentIds === null) return null; // invalid scope → let caller deny
  if (studentIds.length === 0) return EMPTY_REPORT;

  const inScope = inArray(srsReviews.userId, studentIds);
  // "again"/"hard" are the two miss ratings; "good"/"easy" are passes.
  const missFilter = sql`${srsReviews.rating} in ('again', 'hard')`;
  const studentsAffected = sql<number>`count(distinct ${srsReviews.userId}) filter (where ${missFilter})`;
  const totalMisses = sql<number>`count(*) filter (where ${missFilter})`;

  const [questionRows, labRows, struggleRows] = await Promise.all([
    // Per-question miss counts.
    db
      .select({
        questionId: srsReviews.questionId,
        prompt: questions.prompt,
        labName: labs.name,
        studentsAffected,
        totalMisses,
      })
      .from(srsReviews)
      .innerJoin(questions, eq(questions.id, srsReviews.questionId))
      .leftJoin(labs, eq(labs.id, questions.labId))
      .where(inScope)
      .groupBy(srsReviews.questionId, questions.prompt, labs.name),
    // Per-lab miss rate.
    db
      .select({
        labId: labs.id,
        name: labs.name,
        studentsStruggling: studentsAffected,
        misses: totalMisses,
        total: sql<number>`count(*)`,
      })
      .from(srsReviews)
      .innerJoin(questions, eq(questions.id, srsReviews.questionId))
      .innerJoin(labs, eq(labs.id, questions.labId))
      .where(inScope)
      .groupBy(labs.id, labs.name),
    // Freeform struggles columns for the in-scope students.
    db
      .select({ struggles: studentProfiles.struggles })
      .from(studentProfiles)
      .where(inArray(studentProfiles.userId, studentIds)),
  ]);

  const missedQuestions: MissedQuestion[] = questionRows
    .map((r) => ({
      questionId: r.questionId,
      prompt: r.prompt,
      labName: r.labName ?? null,
      studentsAffected: Number(r.studentsAffected),
      totalMisses: Number(r.totalMisses),
    }))
    .filter((q) => q.studentsAffected >= MIN_STUDENTS)
    .sort((a, b) => b.studentsAffected - a.studentsAffected || b.totalMisses - a.totalMisses)
    .slice(0, MAX_QUESTIONS);

  const weakLabs: WeakLab[] = labRows
    .map((r) => {
      const total = Number(r.total);
      const misses = Number(r.misses);
      return {
        labId: r.labId,
        name: r.name,
        studentsStruggling: Number(r.studentsStruggling),
        missRate: total > 0 ? Math.round((misses / total) * 100) : 0,
        total,
      };
    })
    .filter((l) => l.total >= MIN_LAB_REVIEWS && l.studentsStruggling >= MIN_STUDENTS)
    .sort((a, b) => b.missRate - a.missRate || b.studentsStruggling - a.studentsStruggling)
    .slice(0, MAX_LABS)
    .map(({ total: _total, ...rest }) => rest);

  // Count distinct students per normalized struggle phrase. Each student
  // contributes a phrase at most once (Set dedup) so the count is "how many
  // students", not "how many times".
  const themeCounts = new Map<string, { text: string; students: number }>();
  for (const row of struggleRows) {
    const strings = new Set<string>();
    collectStruggleStrings(row.struggles, strings);
    for (const s of strings) {
      const key = s.toLowerCase();
      const existing = themeCounts.get(key);
      if (existing) existing.students += 1;
      else themeCounts.set(key, { text: s, students: 1 });
    }
  }
  const struggleThemes: StruggleTheme[] = [...themeCounts.values()]
    .filter((t) => t.students >= MIN_STUDENTS)
    .sort((a, b) => b.students - a.students)
    .slice(0, MAX_THEMES)
    .map((t) => ({ text: t.text, studentsAffected: t.students }));

  return {
    studentsInScope: studentIds.length,
    missedQuestions,
    weakLabs,
    struggleThemes,
  };
}

// True when there is enough aggregated signal to be worth showing / summarizing.
export function reportHasData(r: CommonMistakesReport): boolean {
  return (
    r.missedQuestions.length > 0 ||
    r.weakLabs.length > 0 ||
    r.struggleThemes.length > 0
  );
}
