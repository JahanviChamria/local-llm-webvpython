// Shared prelab fetch: returns a lab's prelab document text (from the extraction
// pipeline, file_texts), gated to labs published to the student. Used by BOTH
// the sciai://labs/{labId}/prelab resource and the get_prelab tool.
//
// Why both: claude.ai surfaces TOOLS to the model reliably but does not surface
// resource TEMPLATES as readable, so a resource-only prelab is invisible to the
// model there. The tool guarantees the model can always pull the prelab; the
// resource stays for clients that consume templates. One fetch, so they can't
// drift.

import { and, asc, eq } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { files, fileTexts, labs, labFiles } from "@/lib/db/schema";
import { isLabAccessible } from "@/lib/portal/accessible-labs";

// Same UUID form the lab ids in sciai://labs/current carry. Guards a garbage
// {labId} out of the DB.
export const LAB_UUID_RE =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export type PrelabDocument = {
  title: string;
  filename: string;
  // null while extraction is pending or for a non-extractable upload.
  text: string | null;
  extractionPending: boolean;
};

export type PrelabData =
  | { ok: true; labId: string; labName: string | null; documents: PrelabDocument[] }
  | { ok: false; error: "invalid_lab_id" | "lab_not_accessible"; detail: string };

export async function getPrelabData(userId: string, labId: string): Promise<PrelabData> {
  if (!LAB_UUID_RE.test(labId)) {
    return {
      ok: false,
      error: "invalid_lab_id",
      detail: "labId must be a lab UUID from sciai://labs/current.",
    };
  }
  if (!(await isLabAccessible(userId, labId))) {
    return {
      ok: false,
      error: "lab_not_accessible",
      detail: "That lab is not published to you. Use a labId from sciai://labs/current.",
    };
  }

  const rows = await db
    .select({
      labName: labs.name,
      title: files.title,
      filename: files.filename,
      text: fileTexts.extractedText,
    })
    .from(labFiles)
    .innerJoin(labs, eq(labs.id, labFiles.labId))
    .innerJoin(files, eq(files.id, labFiles.fileId))
    .leftJoin(fileTexts, eq(fileTexts.fileId, files.id))
    .where(and(eq(labFiles.labId, labId), eq(labFiles.kind, "prelab")))
    .orderBy(asc(labFiles.position), asc(labFiles.createdAt));

  return {
    ok: true,
    labId,
    labName: rows[0]?.labName ?? null,
    documents: rows.map((r) => ({
      title: r.title,
      filename: r.filename,
      text: r.text,
      extractionPending: r.text === null,
    })),
  };
}
