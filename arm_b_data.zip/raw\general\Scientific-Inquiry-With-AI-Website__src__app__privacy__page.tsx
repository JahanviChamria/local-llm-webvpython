// Privacy policy for Sci-AI. Describes what the system actually stores when an
// external AI host (Claude, ChatGPT, or a Custom GPT) is connected via the
// OAuth/MCP/Actions surfaces, and how users can inspect or delete it.
//
// Source-of-truth for the facts below:
//   - aiChatSummaries / studentProfileSignals schema in src/lib/db/schema.ts
//   - sanitizeStudentText / SUMMARY_MAX_BYTES in src/lib/mcp/redact.ts
//   - sweepOldAiChatSummaries / DEFAULT_RETENTION_DAYS in src/lib/mcp/lifecycle.ts
//   - exportUserData / purgeUserData in the same file
//
// Update both the page text and the source citations together when behavior
// changes — outdated text on this page is a compliance liability.

import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Privacy — Sci-AI",
  description:
    "What Sci-AI stores when an external AI tool (Claude, ChatGPT, or a Custom GPT) writes back to your account, how long it's kept, and how to download or delete it.",
};

const LAST_UPDATED = "June 28, 2026";

export default function PrivacyPage() {
  return (
    <main
      className="portal-root"
      style={{ maxWidth: "780px", margin: "0 auto", padding: "2rem 1.5rem" }}
    >
      <div style={{ marginBottom: "1.5rem" }}>
        <div className="section-label">Sci-AI</div>
        <h1 style={{ margin: "0.25rem 0 0.5rem" }}>Privacy</h1>
        <p className="muted" style={{ margin: 0 }}>
          Last updated {LAST_UPDATED}.
        </p>
      </div>

      <section style={{ marginBottom: "2rem" }}>
        <h2 style={{ fontSize: "1.15rem", marginBottom: "0.5rem" }}>What this page covers</h2>
        <p style={{ margin: 0 }}>
          Sci-AI is UC Merced&apos;s research-practice platform. This page describes the data the
          platform stores about you when you connect an external AI tool — Claude, ChatGPT, or a
          custom OpenAI GPT — to your Sci-AI account. The general site also stores ordinary
          account information (username, email, class enrollments, study progress); this page
          focuses on the AI-integration surface, which is the part most students are likely to
          have specific questions about.
        </p>
      </section>

      <section style={{ marginBottom: "2rem" }}>
        <h2 style={{ fontSize: "1.15rem", marginBottom: "0.5rem" }}>
          What the AI integration writes to our database
        </h2>
        <p>
          When you authorize an external AI tool to connect to Sci-AI, that tool can call a small
          set of write actions on your behalf. Each call creates a row in one of two tables:
        </p>
        <ul style={{ paddingLeft: "1.25rem", lineHeight: 1.6 }}>
          <li>
            <strong>Session summaries</strong> — a 1–3 sentence summary the AI writes at the end
            of an educational conversation, plus the topics you discussed and an optional
            structured note (how long you worked, what you struggled with, what you mastered).
            Also includes which lab and class the session was about, if known.
          </li>
          <li>
            <strong>Concept signals</strong> — short observations the AI flags when it notices
            you&apos;re struggling with a specific topic (e.g. &quot;confusion about the chain
            rule&quot;). Used by your instructor&apos;s dashboard, not for personalization.
          </li>
          <li>
            <strong>Self-assessments</strong> — when you explicitly tell the AI how you feel about
            what you studied (e.g. &quot;I&apos;d rate my understanding 4 out of 5&quot;).
          </li>
        </ul>
        <p>
          Each row is linked to your user account and to the specific AI app (OAuth grant) that
          wrote it, so you can revoke one app without affecting others.
        </p>
      </section>

      <section style={{ marginBottom: "2rem" }}>
        <h2 style={{ fontSize: "1.15rem", marginBottom: "0.5rem" }}>
          Personal information is scrubbed before being stored
        </h2>
        <p>
          Before any AI-written summary is saved, the server runs a redactor that replaces likely
          personal information with placeholder markers. Patterns currently scrubbed:
        </p>
        <ul style={{ paddingLeft: "1.25rem", lineHeight: 1.6 }}>
          <li>Email addresses</li>
          <li>US-shaped phone numbers</li>
          <li>SSN-shaped numbers</li>
          <li>Long contiguous digit runs (likely credit-card numbers or IDs)</li>
          <li>Long random-looking character runs (likely API keys or tokens)</li>
        </ul>
        <p>
          We do not keep a pre-scrub copy. There is also a hard size cap (~4&nbsp;KB) on the
          summary text and (~16&nbsp;KB) on the structured note; anything longer is truncated
          before storage. Note that the redactor is a best-effort defense, not a guarantee — if
          you type sensitive information to an AI tool in an unusual format, it may not be
          recognized. Don&apos;t paste secrets into AI chats.
        </p>
      </section>

      <section style={{ marginBottom: "2rem" }}>
        <h2 style={{ fontSize: "1.15rem", marginBottom: "0.5rem" }}>
          What the AI integration does <em>not</em> store
        </h2>
        <ul style={{ paddingLeft: "1.25rem", lineHeight: 1.6 }}>
          <li>
            <strong>Full conversation transcripts.</strong> Only the summaries the AI explicitly
            writes back are stored. Whatever else you discussed with Claude or ChatGPT stays with
            them, governed by their own privacy policies.
          </li>
          <li>
            <strong>Raw OAuth tokens.</strong> Every access token and refresh token is hashed
            (SHA-256) before storage. We cannot recover the original token, only verify a presented
            one. Client secrets (for Custom GPT integrations) are stored as bcrypt hashes for the
            same reason.
          </li>
          <li>
            <strong>Tracking data outside the AI surface.</strong> The AI integration does not
            inject analytics or third-party tracking pixels.
          </li>
        </ul>
      </section>

      <section style={{ marginBottom: "2rem" }}>
        <h2 style={{ fontSize: "1.15rem", marginBottom: "0.5rem" }}>How long we keep it</h2>
        <ul style={{ paddingLeft: "1.25rem", lineHeight: 1.6 }}>
          <li>
            <strong>Session summaries and concept signals:</strong> retained for one year (365
            days) and then automatically deleted by a scheduled sweep.
          </li>
          <li>
            <strong>OAuth access tokens:</strong> expire on a short timer (about an hour) and are
            swept from the database after expiry. Refresh tokens have a 30-day timer.
          </li>
          <li>
            <strong>Class-scoped summaries:</strong> when you&apos;re removed from a class, any
            session summaries tied to that class are deleted automatically, even before the
            365-day window.
          </li>
        </ul>
      </section>

      <section style={{ marginBottom: "2rem" }}>
        <h2 style={{ fontSize: "1.15rem", marginBottom: "0.5rem" }}>
          Your rights (and how to use them today)
        </h2>
        <p>
          You can exercise all of the following at any time — email the Sci-AI
          maintainers (see Contact below) and we&apos;ll action it:
        </p>
        <ul style={{ paddingLeft: "1.25rem", lineHeight: 1.6 }}>
          <li>
            <strong>See which AI apps are connected.</strong> Each connection shows its name, when
            you authorized it, when it last used the connection, and exactly which permissions you
            granted.
          </li>
          <li>
            <strong>Revoke a connection.</strong> We cut off that app&apos;s access. The
            very next call it tries to make returns 401 and it must re-authorize from scratch.
            Existing summaries that app already wrote are kept (under your control) — revocation
            stops future writes, it doesn&apos;t delete past ones.
          </li>
          <li>
            <strong>Download everything.</strong> A JSON file with every session summary and
            concept signal across every AI app you&apos;ve ever connected. This is the FERPA
            &quot;right to inspect&quot; for the AI-integration data.
          </li>
          <li>
            <strong>Delete everything.</strong> Hard-deletes every summary and signal you own.
            OAuth grants are kept separately so you can revoke them in the same place; deleting
            data doesn&apos;t accidentally lock connected apps in a half-authorized state.
          </li>
        </ul>
      </section>

      <section style={{ marginBottom: "2rem" }}>
        <h2 style={{ fontSize: "1.15rem", marginBottom: "0.5rem" }}>Who can see this data</h2>
        <ul style={{ paddingLeft: "1.25rem", lineHeight: 1.6 }}>
          <li>
            <strong>You.</strong> Via the download link above; also displayed in your own portal
            views.
          </li>
          <li>
            <strong>Your instructor.</strong> Concept signals and session summaries for classes
            you are enrolled in feed instructor dashboards intended to surface where students are
            struggling. Instructors see aggregate and per-student views for their own classes only.
          </li>
          <li>
            <strong>Sci-AI maintainers.</strong> For debugging and incident response. Access is
            limited to the small number of people responsible for keeping the platform running.
          </li>
        </ul>
        <p>
          We do not sell this data, share it with advertisers, or pass it to any third party for
          marketing purposes.
        </p>
      </section>

      <section style={{ marginBottom: "2rem" }}>
        <h2 style={{ fontSize: "1.15rem", marginBottom: "0.5rem" }}>
          What the external AI service stores
        </h2>
        <p>
          When you use Claude, ChatGPT, or a Custom GPT, that service has its own data-handling
          policies separate from Sci-AI. The Sci-AI integration only governs what is written back
          to Sci-AI&apos;s database. For what the AI service itself stores about your chat
          history, see Anthropic&apos;s or OpenAI&apos;s respective privacy policies.
        </p>
      </section>

      <section style={{ marginBottom: "2rem" }}>
        <h2 style={{ fontSize: "1.15rem", marginBottom: "0.5rem" }}>FERPA</h2>
        <p>
          Information written to Sci-AI by AI tools you authorize is part of your educational
          record under FERPA. On request to the Sci-AI maintainers (see Contact below), the
          download and delete of your AI-integration data are intended to satisfy the FERPA
          inspection and amendment rights without requiring a formal request.
        </p>
      </section>

      <section style={{ marginBottom: "2rem" }}>
        <h2 style={{ fontSize: "1.15rem", marginBottom: "0.5rem" }}>Contact</h2>
        <p>
          Questions, concerns, or requests about your data: email{" "}
          <a href="mailto:tle271@ucmerced.edu" style={{ textDecoration: "underline" }}>
            tle271@ucmerced.edu
          </a>
          .
        </p>
      </section>

      <div style={{ marginTop: "2rem" }}>
        <Link href="/" style={{ textDecoration: "underline" }}>
          ← Back to home
        </Link>
      </div>
    </main>
  );
}
