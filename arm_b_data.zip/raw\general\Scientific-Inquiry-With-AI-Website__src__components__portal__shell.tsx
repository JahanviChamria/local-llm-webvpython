"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react";
import { Av, NavIco, type NavIcoName } from "./primitives";
import { BrandLogo } from "@/components/brand-logo";

type PortalCrumbContextValue = {
  override: string[] | null;
  setOverride: (c: string[] | null) => void;
};

const PortalCrumbContext = createContext<PortalCrumbContextValue>({
  override: null,
  setOverride: () => {},
});

// Lets a server-rendered page push a custom breadcrumb into the topbar.
// Renders nothing; the effect syncs into the shell's state on mount and clears
// on unmount so navigation away cleanly restores the default resolver.
export function SetPortalCrumb({ crumb }: { crumb: string[] }) {
  const { setOverride } = useContext(PortalCrumbContext);
  const key = crumb.join("");
  useEffect(() => {
    setOverride(crumb);
    return () => setOverride(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, setOverride]);
  return null;
}

export type PortalRole = "admin" | "faculty" | "student" | "guest";

export type ModuleNavItem = {
  id: string;
  label: string;
  href: string;
  num?: string;
  // Set on class-scoped lab links when the teacher has paused the lab.
  // The link stays clickable; the page-level guard renders the locked view.
  locked?: boolean;
};

export type ClassNavItem = {
  id: string;
  name: string;
  labs: ModuleNavItem[];
};

type NavItem = { id: string; label: string; href: string; ico: NavIcoName; num?: string; external?: boolean };
type NavGroup = { group: string; items: NavItem[] };

// Personal student self-views. Staff don't get these — their class-facing
// equivalents (instructor "Retrieval progress" and "Prelab progress" student
// histories) live under the Teaching group instead.
const YOU_PROGRESS_ITEMS: NavItem[] = [
  { id: "progress", label: "Retrieval progress", href: "/portal/progress", ico: "progress" },
  { id: "profile", label: "Prelab progress", href: "/portal/profile", ico: "profile" },
];
const RETRIEVAL_TOOL_ITEM: NavItem = {
  id: "schedule",
  label: "Retrieval Tool",
  href: "/portal/retrievaltool",
  ico: "brain",
};

// Role-aware static groups. The Modules group is dynamic and rendered separately.
function staticGroupsFor(role: PortalRole): NavGroup[] {
  const isStaff = role === "admin" || role === "faculty";
  const isAdmin = role === "admin";

  const you: NavGroup = {
    group: "You",
    items: isStaff
      ? [RETRIEVAL_TOOL_ITEM]
      : [...YOU_PROGRESS_ITEMS, RETRIEVAL_TOOL_ITEM],
  };
  const groups: NavGroup[] = [you];

  if (isStaff) {
    groups.push({
      group: "Teaching",
      items: [
        { id: "instructor", label: "Retrieval progress", href: "/portal/instructor", ico: "dashboard" },
        { id: "classes-admin", label: "Classes", href: "/admin/classes", ico: "monitor" },
        { id: "files", label: "Files", href: "/admin/files", ico: "folder" },
        { id: "questions", label: "Retrieval Tool Questions", href: "/admin/questions", ico: "question" },
        { id: "history", label: "Prelab progress", href: "/portal/history", ico: "clockHistory" },
      ],
    });
  }
  if (isAdmin) {
    groups.push({
      group: "Admin",
      items: [
        { id: "labs", label: "Labs", href: "/admin/labs", ico: "flask" },
        { id: "all-classes", label: "All classes", href: "/admin/all-classes", ico: "layers" },
        { id: "users", label: "Users", href: "/admin/users", ico: "users" },
      ],
    });
  }
  return groups;
}

const STATIC_CRUMB: Record<string, string[]> = {
  "/portal": ["Home"],
  "/portal/classes": ["Classes"],
  "/portal/practice/session": ["Retrieval practice", "Session"],
  "/portal/progress": ["You", "Retrieval progress"],
  "/portal/profile": ["You", "Prelab progress"],
  "/portal/history": ["Teaching", "Prelab progress"],
  "/portal/retrievaltool": ["You", "Retrieval Tool"],
  "/portal/instructor": ["Teaching", "Retrieval progress"],
  "/admin": ["Course tools"],
  "/admin/classes": ["Teaching", "Classes"],
  "/admin/classes/new": ["Teaching", "Classes", "New"],
  "/admin/classes/archived": ["Teaching", "Classes", "Archived"],
  "/admin/all-classes": ["Admin", "All classes"],
  "/admin/files": ["Teaching", "Files & materials"],
  "/admin/labs": ["Admin", "Labs"],
  "/admin/questions": ["Teaching", "Retrieval Tool Questions"],
  "/admin/users": ["Admin", "Users"],
};

const CLASS_PATH_RE = /^\/portal\/classes\/([^/]+)/;

function classScopeFromPath(path: string): string | null {
  const m = CLASS_PATH_RE.exec(path);
  return m ? m[1] : null;
}

function resolveCrumb(
  path: string,
  modules: ModuleNavItem[],
  enrolledClasses: ClassNavItem[],
): string[] {
  if (STATIC_CRUMB[path]) return STATIC_CRUMB[path];

  const classScopeId = classScopeFromPath(path);
  if (classScopeId) {
    const cls = enrolledClasses.find((c) => c.id === classScopeId);
    const className = cls?.name ?? "Class";
    // Inside-class lab page
    const labMatch = /^\/portal\/classes\/[^/]+\/labs\/([^/]+)/.exec(path);
    if (labMatch) {
      const labId = labMatch[1];
      const lab = cls?.labs.find((l) => l.id === labId);
      return lab ? ["Classes", className, lab.label] : ["Classes", className];
    }
    return ["Classes", className];
  }

  const labMatch = /^\/portal\/labs\/([^/]+)/.exec(path);
  if (labMatch) {
    const id = labMatch[1];
    const found = modules.find((m) => m.id === id);
    return found ? ["Labs", found.label] : ["Labs"];
  }
  return ["Home"];
}

function staticActiveIdForPath(path: string): string | null {
  if (path === "/portal") return "home";
  if (path.startsWith("/portal/progress")) return "progress";
  if (path.startsWith("/portal/profile")) return "profile";
  if (path.startsWith("/portal/history")) return "history";
  if (path.startsWith("/portal/retrievaltool")) return "schedule";
  if (path.startsWith("/portal/instructor")) return "instructor";
  if (path.startsWith("/admin/classes")) return "classes-admin";
  if (path.startsWith("/admin/all-classes")) return "all-classes";
  if (path.startsWith("/admin/files")) return "files";
  if (path.startsWith("/admin/labs")) return "labs";
  if (path.startsWith("/admin/questions")) return "questions";
  if (path.startsWith("/admin/users")) return "users";
  return null;
}

// Strict segment match — `path === ".../id" || path.startsWith(".../id/")` — so id
// "1" doesn't get highlighted when the path is ".../10".
function isActiveSegment(path: string, base: string): boolean {
  return path === base || path.startsWith(`${base}/`);
}

export function PortalShell({
  children,
  user,
  role = "student",
  signedIn = true,
  streak = 0,
  modules,
  enrolledClasses = [],
}: {
  children: ReactNode;
  user: { name: string; initials: string };
  role?: PortalRole;
  signedIn?: boolean;
  streak?: number;
  modules: ModuleNavItem[];
  enrolledClasses?: ClassNavItem[];
}) {
  const pathname = usePathname() || "/portal";
  const staticActiveId = staticActiveIdForPath(pathname);

  // Class scope: if the pathname is inside an enrolled class, swap the Modules list
  // to that class's assigned labs. Soft navigation re-runs this on every click via
  // usePathname() — no fetch, no flash, no stale list.
  const classScopeId = classScopeFromPath(pathname);
  const activeClass = classScopeId
    ? enrolledClasses.find((c) => c.id === classScopeId) ?? null
    : null;
  const renderedModules = activeClass ? activeClass.labs : modules;

  const [crumbOverride, setCrumbOverride] = useState<string[] | null>(null);
  const resolvedCrumb = resolveCrumb(pathname, modules, enrolledClasses);
  const crumb = crumbOverride ?? resolvedCrumb;
  const navGroups = staticGroupsFor(role);
  const roleLabel = role.charAt(0).toUpperCase() + role.slice(1);
  const [loggingOut, setLoggingOut] = useState(false);

  // Mobile nav drawer. Hidden by default; the topbar hamburger opens it and it
  // slides over the content (see the ≤640px rules in portal.css). Auto-close on
  // route change so tapping a nav link navigates and dismisses the drawer.
  const [navOpen, setNavOpen] = useState(false);
  useEffect(() => {
    setNavOpen(false);
  }, [pathname]);

  async function logout() {
    setLoggingOut(true);
    try {
      const res = await fetch("/api/auth/logout", { method: "POST" });
      if (res.ok) {
        window.location.replace("/portal");
        return;
      }
    } catch {
      // fall through to re-enable the button
    }
    setLoggingOut(false);
  }

  return (
    <PortalCrumbContext.Provider value={{ override: crumbOverride, setOverride: setCrumbOverride }}>
      <div className="app">
      {navOpen && (
        <div
          className="nav-scrim"
          aria-hidden="true"
          onClick={() => setNavOpen(false)}
        />
      )}
      <aside className={"sidebar" + (navOpen ? " open" : "")}>
        <div className="brand">
          <BrandLogo />
          <div className="ver">PHYS 021 · UC Merced</div>
        </div>

        {(role === "student" || enrolledClasses.length > 0) && (
          <div style={{ display: "contents" }}>
            <div className="nav-group">Classes</div>
            {enrolledClasses.length === 0 ? (
              <div className="nav-item muted" style={{ fontStyle: "italic", fontSize: 12 }}>
                Enrolled in no classes
              </div>
            ) : (
              enrolledClasses.map((c) => (
                <Link
                  key={c.id}
                  href={`/portal/classes/${c.id}`}
                  className={
                    "nav-item" +
                    (isActiveSegment(pathname, `/portal/classes/${c.id}`) ? " active" : "")
                  }
                >
                  <NavIco name="instructor" />
                  <span className="grow">{c.name}</span>
                </Link>
              ))
            )}
          </div>
        )}

        <div style={{ display: "contents" }}>
          <div className="nav-group">
            Labs
            {activeClass && (
              <span
                className="label"
                style={{ marginLeft: 6, fontSize: 11, opacity: 0.7 }}
              >
                from {activeClass.name}
              </span>
            )}
          </div>
          {renderedModules.length === 0 ? (
            <div className="nav-item muted" style={{ fontStyle: "italic", fontSize: 12 }}>
              {activeClass ? "No labs assigned yet" : "No labs available yet"}
            </div>
          ) : (
            renderedModules.map((m) => {
              // For class-scoped lab links the base is /portal/classes/[id]/labs/[labId];
              // for global it's /portal/labs/[id]. Use the href as the base.
              const isActive = isActiveSegment(pathname, m.href);
              const showLock = m.locked && role === "student";
              return (
                <Link
                  key={m.id}
                  href={m.href}
                  className={"nav-item" + (isActive ? " active" : "")}
                  title={showLock ? "Locked by your instructor" : undefined}
                >
                  <NavIco name="doc" />
                  <span className="grow">{m.label}</span>
                  {showLock ? (
                    <span
                      className="nav-num"
                      aria-label="locked"
                      style={{ opacity: 0.8 }}
                    >
                      🔒
                    </span>
                  ) : (
                    m.num && <span className="nav-num">{m.num}</span>
                  )}
                </Link>
              );
            })
          )}
        </div>

        {navGroups.map(({ group, items }) => (
          <div key={group} style={{ display: "contents" }}>
            <div className="nav-group">{group}</div>
            {items.map((item) => (
              <Link
                key={item.id}
                href={item.href}
                className={"nav-item" + (staticActiveId === item.id ? " active" : "")}
              >
                <NavIco name={item.ico} />
                <span className="grow">{item.label}</span>
                {item.num && <span className="nav-num">{item.num}</span>}
                {item.external && <span className="nav-num">↗</span>}
              </Link>
            ))}
          </div>
        ))}

        <div className="nav-spacer" />

        <div className="streak-pill">
          <span className="fire">🔥</span>
          <div>
            <b>{streak}</b> <span className="label" style={{ marginLeft: 2 }}>day streak</span>
          </div>
        </div>
        {signedIn ? (
          <>
            <div className="side-user">
              <Av initials={user.initials} sm />
              <div>
                <div style={{ fontSize: 13, fontWeight: 500 }}>{user.name}</div>
                <div className="label">{roleLabel}</div>
              </div>
            </div>
            <button
              type="button"
              onClick={logout}
              disabled={loggingOut}
              className="btn ghost sm"
              style={{ justifyContent: "center", marginTop: 8 }}
            >
              {loggingOut ? "Signing out…" : "Sign out"}
            </button>
          </>
        ) : (
          <Link href="/login?next=/portal" className="btn primary" style={{ justifyContent: "center" }}>
            Sign in
          </Link>
        )}
      </aside>

      <main className="main">
        <div className="topbar">
          <button
            type="button"
            className="nav-toggle"
            aria-label="Open menu"
            aria-expanded={navOpen}
            onClick={() => setNavOpen(true)}
          >
            <span />
            <span />
            <span />
          </button>
          <span className="crumb">
            {crumb.map((c, i) => (
              <span key={i}>
                {i > 0 && " / "}
                {i === crumb.length - 1 ? <b>{c}</b> : c}
              </span>
            ))}
          </span>
          <span className="grow" />
          {signedIn ? (
            <div className="avatar">{user.initials}</div>
          ) : (
            <Link href="/login?next=/portal" className="btn primary sm">
              Sign in
            </Link>
          )}
        </div>
        <div className="screen">{children}</div>
      </main>
      </div>
    </PortalCrumbContext.Provider>
  );
}
