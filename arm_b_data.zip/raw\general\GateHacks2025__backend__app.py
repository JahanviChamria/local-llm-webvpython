
from flask import Flask, request, jsonify
from flask_cors import CORS
import json

app = Flask(__name__)
CORS(app)

with open('moviedb.json', 'r') as f:
    movies_db = json.load(f)
    print(movies_db)

keyword_to_movie = {}
for idx, movie in enumerate(movies_db):
    cast_tags = movie.get('cast', [])
    genre_tags = movie.get('genres', [])
    keyword_tags = movie.get('keywords', [])

    tags = cast_tags + genre_tags + keyword_tags

    for tag in tags:
        tag_lower = tag.lower()
        if tag_lower not in keyword_to_movie:
            keyword_to_movie[tag_lower] = set()
        keyword_to_movie[tag_lower].add(idx)
    print (keyword_to_movie)


def recommend_movies(user_inputs, top_n=5):
    num_movies = len(movies_db)
    literal_scores = [0] * num_movies
    vibe_scores = [0] * num_movies

    # LITERAL MATCHES
    for user_input in user_inputs:
        words = user_input
        print (words)
        matched_movies_for_this_user = set()

        for word in words:
            if word in keyword_to_movie:
                matched_movies_for_this_user.update(keyword_to_movie[word])

        for movie_index in matched_movies_for_this_user:
            literal_scores[movie_index] += 1

    # normalize
    literal_scores = [min(score / len(user_inputs), 1) for score in literal_scores]

    # VIBE MATCHES
    for movie_index, movie in enumerate(movies_db):
        movie_vibe_tags = [tag.lower() for tag in movie.get('vibe_tags', [])]
        total_overlap = 0

        for user_input in user_inputs:
            words = user_input.lower().split()
            total_overlap += len(set(words) & set(movie_vibe_tags))

        vibe_scores[movie_index] = total_overlap / len(user_inputs)

    # COMBINE
    final_scores = [
        0.6 * literal_scores[i] + 0.4 * vibe_scores[i]
        for i in range(num_movies)
    ]

    print(final_scores)

    # SORT
    top_indices = sorted(
        range(num_movies),
        key=lambda i: final_scores[i],
        reverse=True
    )[:top_n]

    movies_return = [movies_db[i] for i in top_indices]
    print(movies_return)
    return movies_return


@app.route('/')
def home():
    return "Flask backend running!"

@app.route('/recommend', methods=['POST'])
def recommend():
    '''
    data = request.json
    print("Received:", data)  # DEBUG
    user_inputs = data.get("inputs", [])
    '''
    
    data = request.json

    # Expect a list directly
    if not isinstance(data, list):
        return {"error": "Expected a list of user preference objects."}, 400

    user_inputs = data

    print(user_inputs)
    recommendations = recommend_movies(user_inputs)
    return jsonify({"results": recommendations})


if __name__ == "__main__":
    app.run(debug=True)
'''

from flask import Flask, request, jsonify
from flask_cors import CORS
import json

app = Flask(__name__)
CORS(app)

# --------------------------------------------------------
# Load movie database
# --------------------------------------------------------
with open("moviedb.json", "r", encoding="utf-8") as f:
    MOVIES = json.load(f)


# --------------------------------------------------------
# Scoring functions
# --------------------------------------------------------

def score_runtime(movie_runtime, preferred_runtime):
    diff = abs(movie_runtime - preferred_runtime)
    if diff <= 15:
        return 8
    elif diff <= 30:
        return 4
    return 0


def score_year(movie_year, preferred_year):
    diff = abs(movie_year - preferred_year)
    if diff <= 5:
        return 6
    elif diff <= 10:
        return 3
    return 0


def score_rating(movie_rating, allowed_ratings):
    if movie_rating in allowed_ratings:
        return 5
    return -5


def score_single_user(movie, prefs):
    score = 0

    # Genres
    if "genres" in prefs:
        user_genres = [g.lower() for g in prefs["genres"]]
        for genre in movie["genres"]:
            if genre.lower() in user_genres:
                score += 6

    # Runtime
    if prefs.get("runtime_min"):
        score += score_runtime(movie["runtime_min"], prefs["runtime_min"])

    # Year
    if prefs.get("year"):
        score += score_year(movie["year"], prefs["year"])

    # Rating
    if prefs.get("ratings"):
        score += score_rating(movie["rating"], prefs["ratings"])

    # Keywords
    if "keywords" in prefs:
        user_keywords = [k.lower() for k in prefs["keywords"]]
        for kw in movie["keywords"]:
            if kw.lower() in user_keywords:
                score += 3

    # Director
    if prefs.get("director"):
        if movie["director"].lower() == prefs["director"].lower():
            score += 10

    # Cast
    if "cast" in prefs:
        user_cast = [c.lower() for c in prefs["cast"]]
        for actor in movie["cast"]:
            if actor.lower() in user_cast:
                score += 4

    return score


# --------------------------------------------------------
# /recommend endpoint for GROUP input
# --------------------------------------------------------

@app.route("/recommend", methods=["POST"])
def recommend():

    """
    Expected POST body:

    [
        {
            "genres": ["Action", "Sci-Fi"],
            "runtime_min": 150,
            "year": 2010,
            "ratings": ["PG-13"],
            "keywords": ["thrilling"],
            "director": "Christopher Nolan",
            "cast": ["Leonardo DiCaprio"]
        },
        {
            "genres": ["Drama"],
            "runtime_min": 160,
            "year": 2012,
            "ratings": ["PG-13", "R"],
            "keywords": ["emotional", "space"],
            "director": "",
            "cast": []
        }
    ]

    Multiple users → score movie for each → sum total score.
    """

    group_prefs = request.get_json()

    results = []

    for movie in MOVIES:
        total_score = 0

        # Score this movie for each user, add it up
        for prefs in group_prefs:
            total_score += score_single_user(movie, prefs)

        results.append({"movie": movie["title"], "score": total_score, "data": movie})

    # Sort descending by total group score
    results.sort(key=lambda x: x["score"], reverse=True)

    # Return the top 5 movies by group match
    return jsonify(results[:5])


# --------------------------------------------------------
# Run server
# --------------------------------------------------------

if __name__ == "__main__":
    app.run(debug=True)
'''
