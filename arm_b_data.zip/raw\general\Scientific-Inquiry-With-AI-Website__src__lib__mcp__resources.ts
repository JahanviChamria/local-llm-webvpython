// MCP resource registrations. Resources are read-only — they advertise
// `readOnlyHint: true` so ChatGPT won't show a confirmation modal for reads
// the model uses to ground its responses.
//
// All resources close over the authenticated user. URIs don't carry user IDs;
// "the current user" is always implicit.

import { and, desc, eq, gte, sql } from "drizzle-orm";
import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { ResourceTemplate } from "@modelcontextprotocol/sdk/server/mcp.js";

import { db } from "@/lib/db/client";
import {
  classEnrollments,
  classes,
  classLabs,
  labs,
  srsReviews,
  srsSessions,
  studentProfiles,
} from "@/lib/db/schema";

import { SCOPE_PROFILE_READ, SCOPE_STUDY_READ } from "@/lib/oauth/scopes";
import { getPrelabData } from "./prelab-data";
import { type McpContext, hasScope } from "./context";

// JSON resource result shape per MCP spec — single content entry.
function jsonResource(uri: string, data: unknown) {
  return {
    contents: [
      {
        uri,
        mimeType: "application/json",
        text: JSON.stringify(data, null, 2),
      },
    ],
  };
}

// Error resource result — returned when scope is missing. The MCP spec doesn't
// have a "scope insufficient" code at the resource layer; we return an
// explanatory JSON body instead of failing the JSON-RPC call.
function scopeMissingResource(uri: string, requiredScope: string) {
  return {
    contents: [
      {
        uri,
        mimeType: "application/json",
        text: JSON.stringify({
          error: "insufficient_scope",
          requiredScope,
        }),
      },
    ],
  };
}

const PROFILE_URI = "sciai://user/profile";
const PROGRESS_URI = "sciai://user/recent-progress";
const LABS_URI = "sciai://labs/current";
const PRELAB_URI_TEMPLATE = "sciai://labs/{labId}/prelab";

export async function readProfileResource(ctx: McpContext) {
  if (!hasScope(ctx, SCOPE_PROFILE_READ)) {
    return scopeMissingResource(PROFILE_URI, SCOPE_PROFILE_READ);
  }

  const profileRows = await db
    .select({ alias: studentProfiles.alias })
    .from(studentProfiles)
    .where(eq(studentProfiles.userId, ctx.user.id))
    .limit(1);

  const enrollment = await db
    .select({ id: classes.id, name: classes.name })
    .from(classEnrollments)
    .innerJoin(classes, eq(classEnrollments.classId, classes.id))
    .where(eq(classEnrollments.userId, ctx.user.id))
    .orderBy(desc(classEnrollments.enrolledAt))
    .limit(1);

  return jsonResource(PROFILE_URI, {
    username: ctx.user.username,
    displayName: ctx.user.displayName,
    role: ctx.user.role,
    alias: profileRows[0]?.alias ?? null,
    currentClass: enrollment[0]
      ? { id: enrollment[0].id, name: enrollment[0].name }
      : null,
  });
}

export async function readRecentProgressResource(ctx: McpContext) {
  if (!hasScope(ctx, SCOPE_STUDY_READ)) {
    return scopeMissingResource(PROGRESS_URI, SCOPE_STUDY_READ);
  }

  const since = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

  // Roll-up of last 7d of srsReviews: counts by rating.
  const ratingCounts = await db
    .select({
      rating: srsReviews.rating,
      count: sql<number>`count(*)::int`,
    })
    .from(srsReviews)
    .where(and(eq(srsReviews.userId, ctx.user.id), gte(srsReviews.reviewedAt, since)))
    .groupBy(srsReviews.rating);

  // Session count over the same window.
  const sessionRows = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(srsSessions)
    .where(and(eq(srsSessions.userId, ctx.user.id), gte(srsSessions.startedAt, since)));

  // Most recent session for "last activity".
  const lastSession = await db
    .select({ startedAt: srsSessions.startedAt, finishedAt: srsSessions.finishedAt })
    .from(srsSessions)
    .where(eq(srsSessions.userId, ctx.user.id))
    .orderBy(desc(srsSessions.startedAt))
    .limit(1);

  const ratings: Record<string, number> = {};
  for (const row of ratingCounts) ratings[row.rating] = row.count;

  return jsonResource(PROGRESS_URI, {
    windowDays: 7,
    sessions: sessionRows[0]?.count ?? 0,
    reviewsByRating: ratings,
    totalReviews: Object.values(ratings).reduce((a, b) => a + b, 0),
    lastSessionStartedAt: lastSession[0]?.startedAt ?? null,
    lastSessionFinishedAt: lastSession[0]?.finishedAt ?? null,
  });
}

export async function readCurrentLabsResource(ctx: McpContext) {
  if (!hasScope(ctx, SCOPE_STUDY_READ)) {
    return scopeMissingResource(LABS_URI, SCOPE_STUDY_READ);
  }

  // Active class = most recent enrollment.
  const enrollment = await db
    .select({ classId: classEnrollments.classId })
    .from(classEnrollments)
    .where(eq(classEnrollments.userId, ctx.user.id))
    .orderBy(desc(classEnrollments.enrolledAt))
    .limit(1);

  const classId = enrollment[0]?.classId;
  if (!classId) {
    return jsonResource(LABS_URI, { class: null, labs: [] });
  }

  const labRows = await db
    .select({
      id: labs.id,
      name: labs.name,
      description: labs.description,
      orderIndex: classLabs.orderIndex,
      isLocked: classLabs.isLocked,
      hasPractice: labs.hasPractice,
      hasPrelab: labs.hasPrelab,
      hasPostlab: labs.hasPostlab,
      hasSimulation: labs.hasSimulation,
    })
    .from(classLabs)
    .innerJoin(labs, eq(classLabs.labId, labs.id))
    .where(eq(classLabs.classId, classId))
    .orderBy(classLabs.orderIndex);

  return jsonResource(LABS_URI, {
    classId,
    labs: labRows,
  });
}

// Serve a lab's prelab document text so the student can work through the prelab
// in chat. Gated to labs currently published to the student (same predicate as
// the topic-mastery write-gate), so it can never leak an unpublished lab's
// prelab. Text comes from the extraction pipeline (file_texts); it's null while
// extraction is pending or for a non-extractable upload.
export async function readPrelabResource(
  ctx: McpContext,
  labId: string,
  uri: string = `sciai://labs/${labId}/prelab`,
) {
  if (!hasScope(ctx, SCOPE_STUDY_READ)) {
    return scopeMissingResource(uri, SCOPE_STUDY_READ);
  }
  const data = await getPrelabData(ctx.user.id, labId);
  if (!data.ok) {
    return jsonResource(uri, { error: data.error, detail: data.detail });
  }
  return jsonResource(uri, {
    labId: data.labId,
    labName: data.labName,
    hasPrelab: data.documents.length > 0,
    documents: data.documents,
  });
}

export function registerResources(server: McpServer, ctx: McpContext): void {
  server.registerResource(
    "user_profile",
    PROFILE_URI,
    {
      title: "Your Sci-AI profile",
      description: "Alias, role, and current class enrollment for the signed-in student.",
      mimeType: "application/json",
      // Resources are inherently read-only in MCP — no readOnlyHint annotation
      // needed; ChatGPT does NOT show a confirmation modal for resource reads.
    },
    () => readProfileResource(ctx),
  );

  server.registerResource(
    "user_recent_progress",
    PROGRESS_URI,
    {
      title: "Recent study progress",
      description:
        "Last 7 days of the student's SRS review activity: session count, reviews by rating, last session time.",
      mimeType: "application/json",
      // Resources are inherently read-only in MCP — no readOnlyHint annotation
      // needed; ChatGPT does NOT show a confirmation modal for resource reads.
    },
    () => readRecentProgressResource(ctx),
  );

  server.registerResource(
    "labs_current",
    LABS_URI,
    {
      title: "Current class labs",
      description:
        "Ordered list of labs in the student's active class, including which have practice/prelab/postlab/simulation modules and which are locked.",
      mimeType: "application/json",
      // Resources are inherently read-only in MCP — no readOnlyHint annotation
      // needed; ChatGPT does NOT show a confirmation modal for resource reads.
    },
    () => readCurrentLabsResource(ctx),
  );

  server.registerResource(
    "lab_prelab",
    new ResourceTemplate(PRELAB_URI_TEMPLATE, { list: undefined }),
    {
      title: "Lab prelab content",
      description:
        "Extracted text of a lab's prelab document(s) so the student can work through the prelab in chat. Substitute {labId} with a lab id from sciai://labs/current.",
      mimeType: "application/json",
    },
    (uri, variables) => {
      const raw = variables.labId;
      const labId = Array.isArray(raw) ? raw[0] : raw;
      return readPrelabResource(ctx, String(labId ?? ""), uri.toString());
    },
  );
}
