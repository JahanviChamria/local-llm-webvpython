import { NextResponse } from "next/server";
import { z } from "zod";
import { revalidatePath } from "next/cache";
import { and, eq, inArray, isNotNull, sql } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { questions, questionFamilies, files } from "@/lib/db/schema";
import { requireAdmin, checkOrigin } from "@/lib/auth/guards";
import {
  findOrCreateLabByName,
  InvalidLabNameError,
} from "@/lib/labs/find-or-create";
import {
  bankSchema,
  collectFigureRefs,
  normalizeFormat,
  parseMcOptions,
  type Bank,
  type BankFamily,
  type BankVariant,
} from "@/lib/questions/bank-schema";
import {
  sampleDraw,
  computeAnswers,
  renderTemplate,
  hasUnresolvedTokens,
  type Parameterization,
} from "@/lib/questions/parameterize";
import { bestEffortDelete, bucketFor } from "@/lib/r2";

export const runtime = "nodejs";

const bodySchema = z.object({
  labName: z.string().trim().min(1).max(100),
  bankId: z.string().trim().min(1).max(80),
  bank: bankSchema,
  figureFileIds: z.record(z.string().uuid()).default({}),
});

const FUZZ_SEEDS = 1000;

type CleanupCandidate = { fileId: string; r2Key: string };

export async function POST(req: Request) {
  const csrf = checkOrigin(req);
  if (csrf) return csrf;
  const g = await requireAdmin();
  if (g instanceof NextResponse) return g;

  // Cleanup candidates: every file_id supplied in figureFileIds. On any non-2xx
  // exit we filter to those NOT referenced by any question and delete from both
  // R2 and the files table. Built up incrementally as we validate.
  let cleanupCandidateIds: string[] = [];
  let response: NextResponse | null = null;

  try {
    let body: z.infer<typeof bodySchema>;
    try {
      body = bodySchema.parse(await req.json());
    } catch (err) {
      return (response = json(
        { error: "invalid body", detail: String(err) },
        400,
      ));
    }

    cleanupCandidateIds = Object.values(body.figureFileIds);

    // ------ figure validation ------
    const requiredFigureFiles = collectFigureRefs(body.bank);
    const missing = requiredFigureFiles.filter(
      (f) => !body.figureFileIds[f],
    );
    if (missing.length > 0) {
      return (response = json(
        {
          error: "missing_figure_files",
          missing,
          detail:
            "Each figure referenced by a variant must have a corresponding file_id in figureFileIds.",
        },
        400,
      ));
    }

    if (cleanupCandidateIds.length > 0) {
      const figureRows = await db
        .select({
          id: files.id,
          r2Key: files.r2Key,
          status: files.status,
          accessLevel: files.accessLevel,
          contentType: files.contentType,
        })
        .from(files)
        .where(inArray(files.id, cleanupCandidateIds));

      const byId = new Map(figureRows.map((r) => [r.id, r]));
      const badFigures: Array<{ ref: string; reason: string }> = [];
      for (const [ref, fileId] of Object.entries(body.figureFileIds)) {
        const f = byId.get(fileId);
        if (!f) {
          badFigures.push({ ref, reason: "file row not found" });
          continue;
        }
        if (f.status !== "ready") {
          badFigures.push({ ref, reason: `file status is ${f.status}, need ready` });
        }
        if (f.accessLevel !== "public") {
          badFigures.push({
            ref,
            reason: `file accessLevel is ${f.accessLevel}, need public`,
          });
        }
        if (!f.contentType.startsWith("image/")) {
          badFigures.push({
            ref,
            reason: `contentType ${f.contentType} is not an image/*`,
          });
        }
      }
      if (badFigures.length > 0) {
        return (response = json({ error: "invalid_figure_files", badFigures }, 400));
      }
    }

    // ------ fuzz-validate parameterizers ------
    const fuzzFailures: Array<{
      familyId: string;
      seed: number;
      error: string;
    }> = [];
    // Prompts/answers whose {tokens} aren't all covered by the draw — e.g. a
    // prompt referencing {duration_s} the parameterization never defines. These
    // otherwise render literally ("{duration_s}") to students, so reject at
    // import instead of shipping a broken question.
    const unresolvedFailures: Array<{
      familyId: string;
      variantId: string;
      example: string;
    }> = [];
    for (const family of body.bank.families) {
      if (!family.parameterization) continue;
      const spec = family.parameterization as Parameterization;
      for (let s = 1; s <= FUZZ_SEEDS; s++) {
        try {
          const draw = sampleDraw(spec, s);
          const answers = computeAnswers(spec, draw);
          // Mirror serveCard's scope, then confirm every templated field fully
          // resolves. One good seed is enough; the token set is seed-invariant.
          if (s === 1) {
            const scope = { ...draw, ...answers };
            for (const variant of family.variants) {
              const fields = [variant.prompt, variant.variant_answer_notes ?? ""];
              for (const field of fields) {
                const rendered = renderTemplate(field, scope);
                if (hasUnresolvedTokens(rendered)) {
                  unresolvedFailures.push({
                    familyId: family.id,
                    variantId: variant.id,
                    example: rendered,
                  });
                  break;
                }
              }
            }
          }
        } catch (err) {
          fuzzFailures.push({
            familyId: family.id,
            seed: s,
            error: (err as Error).message,
          });
          break; // one example per family is enough
        }
      }
    }
    if (fuzzFailures.length > 0) {
      return (response = json(
        {
          error: "parameterization_fuzz_failed",
          failures: fuzzFailures,
          detail:
            "Family formulas threw on some seeds in the parameter ranges. Tighten the range or fix the formula.",
        },
        400,
      ));
    }
    if (unresolvedFailures.length > 0) {
      return (response = json(
        {
          error: "unresolved_prompt_tokens",
          failures: unresolvedFailures,
          detail:
            "Some prompts/answers reference {tokens} the parameterization never defines, so they'd render literally to students. Add the missing parameter (or fix the token name).",
        },
        400,
      ));
    }

    // ------ lab create/find (autocommit, race-safe) ------
    let lab: { id: string; name: string };
    try {
      lab = await findOrCreateLabByName(body.labName);
    } catch (err) {
      if (err instanceof InvalidLabNameError) {
        return (response = json(
          { error: "invalid_lab_name", detail: err.message },
          400,
        ));
      }
      throw err;
    }

    // ------ transaction: upsert families + variants ------
    let insertedCount = 0;
    let updatedCount = 0;
    let removedVariants: string[] = [];

    const newVariantKeys = new Set<string>();
    for (const family of body.bank.families) {
      for (const variant of family.variants) {
        newVariantKeys.add(`${body.bankId}:${variant.id}`);
      }
    }

    await db.transaction(async (tx) => {
      // Existing variants for this lab — used to compute removedVariants below.
      const existingForLab = await tx
        .select({ id: questions.id, variantKey: questions.variantKey })
        .from(questions)
        .where(and(eq(questions.labId, lab.id), isNotNull(questions.variantKey)));

      for (const family of body.bank.families) {
        const bankKey = `${body.bankId}:${family.id}`;
        const failureModes = family.failure_modes ?? [];
        const graderTemplate =
          body.bank.grading_protocol?.grader_prompt_template ?? null;

        // Upsert family by bankKey.
        const [familyRow] = await tx
          .insert(questionFamilies)
          .values({
            labId: lab.id,
            bankKey,
            concept: family.concept,
            category: family.category,
            answerCore: family.answer_core,
            failureModes: failureModes as unknown as object,
            graderPromptTemplate: graderTemplate,
            parameterization: (family.parameterization ?? null) as unknown as object | null,
            updatedAt: new Date(),
          })
          .onConflictDoUpdate({
            target: questionFamilies.bankKey,
            set: {
              concept: family.concept,
              category: family.category,
              answerCore: family.answer_core,
              failureModes: failureModes as unknown as object,
              graderPromptTemplate: graderTemplate,
              parameterization: (family.parameterization ?? null) as unknown as object | null,
              updatedAt: new Date(),
            },
          })
          .returning({ id: questionFamilies.id });

        for (const variant of family.variants) {
          const variantKey = `${body.bankId}:${variant.id}`;
          const result = await upsertVariant(tx, {
            labId: lab.id,
            familyId: familyRow.id,
            createdBy: g.id,
            variantKey,
            variant,
            family,
            figureFileIds: body.figureFileIds,
          });
          if (result === "inserted") insertedCount++;
          else if (result === "updated") updatedCount++;
        }
      }

      // Removed: variants previously in this lab whose variantKey is not in the
      // new bank. We leave them in place (SRS cards stay attached) but report so
      // the admin can hand-delete after reviewing.
      removedVariants = existingForLab
        .filter((q) => q.variantKey && !newVariantKeys.has(q.variantKey))
        .map((q) => q.variantKey!) as string[];
    });

    revalidatePath("/admin/questions");
    revalidatePath("/admin/labs");

    return (response = json(
      {
        labId: lab.id,
        labName: lab.name,
        familyCount: body.bank.families.length,
        variantCount: insertedCount + updatedCount,
        insertedCount,
        updatedCount,
        removedVariants,
      },
      200,
    ));
  } catch (err) {
    console.error("[bank-import] unexpected error", err);
    return (response = json(
      { error: "internal_error", detail: String(err) },
      500,
    ));
  } finally {
    if (response && response.status >= 300 && cleanupCandidateIds.length > 0) {
      await cleanupOrphanedFigures(cleanupCandidateIds);
    }
  }
}

async function upsertVariant(
  tx: Parameters<Parameters<typeof db.transaction>[0]>[0],
  args: {
    labId: string;
    familyId: string;
    createdBy: string;
    variantKey: string;
    variant: BankVariant;
    family: BankFamily;
    figureFileIds: Record<string, string>;
  },
): Promise<"inserted" | "updated"> {
  const { variant, family, figureFileIds } = args;
  const format = normalizeFormat(variant.format);
  const isParameterized = !!family.parameterization;
  const promptText = variant.prompt;
  const expectedAnswer = variant.variant_answer_notes ?? null;
  const options = variant.options ? parseMcOptions(variant.options) : null;
  const correctOption = variant.correct ?? null;
  const figureFileId = variant.figure?.file
    ? figureFileIds[variant.figure.file]
    : null;

  // Look up existing row by variant_key for UPDATE (NEVER delete+recreate; that
  // would break srs_cards.questionId FKs).
  const existing = (
    await tx
      .select({ id: questions.id })
      .from(questions)
      .where(eq(questions.variantKey, args.variantKey))
      .limit(1)
  )[0];

  const values = {
    labId: args.labId,
    familyId: args.familyId,
    variantKey: args.variantKey,
    difficulty: variant.difficulty,
    prompt: promptText,
    expectedAnswer,
    format,
    role: variant.role,
    promptIsTemplate: isParameterized,
    options: options as unknown as object | null,
    correctOption,
    variantAnswerNotes: variant.variant_answer_notes ?? null,
    figureFileId,
    updatedAt: new Date(),
  };

  if (existing) {
    await tx.update(questions).set(values).where(eq(questions.id, existing.id));
    return "updated";
  } else {
    await tx.insert(questions).values({ ...values, createdBy: args.createdBy });
    return "inserted";
  }
}

async function cleanupOrphanedFigures(candidateIds: string[]) {
  try {
    // Only delete file rows that aren't referenced by ANY question.figure_file_id.
    // Guards against the request supplying an already-attached file id that then
    // failed validation — that figure must NOT be deleted from a prior import.
    const referenced = await db
      .select({ id: questions.figureFileId })
      .from(questions)
      .where(inArray(questions.figureFileId, candidateIds));
    const referencedIds = new Set(referenced.map((r) => r.id).filter(Boolean));
    const orphanIds = candidateIds.filter((id) => !referencedIds.has(id));
    if (orphanIds.length === 0) return;

    const rows = await db
      .select({ id: files.id, r2Key: files.r2Key, accessLevel: files.accessLevel })
      .from(files)
      .where(inArray(files.id, orphanIds));

    // R2 delete first (best-effort), then DB row delete. If R2 fails we still
    // drop the DB row so the orphan-sweep job can clean up the R2 side later.
    for (const f of rows) {
      await bestEffortDelete(bucketFor(f.accessLevel), f.r2Key);
    }
    await db.delete(files).where(inArray(files.id, orphanIds));
  } catch (err) {
    console.error("[bank-import] cleanup failed", err);
  }
}

function json(body: unknown, status: number): NextResponse {
  return NextResponse.json(body, { status });
}
