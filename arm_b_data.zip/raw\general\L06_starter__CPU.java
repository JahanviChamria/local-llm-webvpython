import java.awt.Color;

//A CPU controlled JavaPong paddle
public abstract class CPU extends Paddle{
   
   
   
   //****************   CONSTRUCTORS  *************
   public CPU(double length, double speed, Color color){ 
      super(length, speed, color);
   }  
   
   
   
   //determines if the Paddle should move up, down, or stay in its current position
   //Returns one of three int values, telling the game that, per the key being 
   //pressed, if the Paddle should move up, down, or not move at all (neutral) 
   //
   //arguments include (in order):
   //bX, bY: the ball's current x and y coordinates
   //bXVel, bYVel: the ball's current x and y velocities
   public int decideMove(double bX, double bY, double bXVel, double bYVel){
      if (bXVel > 0)
         return decideMoveBallGoingRight(bX, bY, bXVel, bYVel);
      else if (bXVel < 0)
         return decideMoveBallGoingLeft(bX, bY, bXVel, bYVel);
      //if the ball is not moving (ie hasn't launched), the CPU paddle doesn't start moving yet
      return MOVE_NEUTRAL;
   }
   
   


   
   //****************   ABSTRACT METHODS  *************
   
   //helpers used by decideMove(...) to determine the Paddle's move when ball is travelling left/right
   //like decideMove(...), returns one of three int values to dictate move up, down, nor eutral
   protected abstract int decideMoveBallGoingLeft(double bX, double bY, double bXVel, double bYVel);
   protected abstract int decideMoveBallGoingRight(double bX, double bY, double bXVel, double bYVel);  
   
   
   //Called automatically whenver the ball collides with this paddle
   public abstract void reactToVolley();
   
   
   //Called automatically whenever EITHER paddle (Human or CPU) scores a point.
   //argument indicates if it was the CPU who scored (true) or the human (false).
   public abstract void reactToScore(boolean didCPUScore);
   
}