import type { ReactNode } from "react";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
import { getLabDetail, getLabDocumentDoneIds } from "@/lib/portal/data";
import { LabDocumentList } from "@/components/portal/lab-document-list";
import { LabSectionShell } from "@/components/portal/lab-section-shell";
import { PrelabConnectHelp } from "@/components/portal/prelab-connect-help";

// Public custom-GPT URL for this course. This is the only spot that needs to
// change if the link is ever updated.
const CUSTOM_GPT_URL =
  "https://chatgpt.com/g/g-6a41f8e43b808191823a43a662ee8475-knowledge-with-ai";

// The student-facing "Prelab progress" page (manual JSON upload lives here).
const PRELAB_PROGRESS_PATH = "/portal/profile";

export async function LabPrelabView({ labId, basePath }: { labId: string; basePath: string }) {
  const detail = await getLabDetail(labId);
  if (!detail || !detail.lab.hasPrelab) notFound();

  const user = await getCurrentUser();
  const doneIds = await getLabDocumentDoneIds(user?.id ?? null);
  const signedIn = !!user;

  const items = detail.prelabFiles.map((f) => ({
    labFileId: f.labFileId,
    file: f.file,
    done: doneIds.has(f.labFileId),
  }));

  return (
    <LabSectionShell basePath={basePath} lab={detail.lab} sectionTitle="Prelab">
      {/* How-to-sync: informational only. No upload/endpoint wiring here — this
          section just explains, per chatbot, how prelab work gets back onto the
          site. Rendered above the document list so students see it first. */}
      <section className="col" style={{ gap: 12 }}>
        <div>
          <div className="section-label">Sync your prelab</div>
          <p className="muted" style={{ fontSize: 13, margin: "4px 0 0", maxWidth: 640 }}>
            Pick your chatbot below — each one gets your prelab work back onto the
            site a little differently.
          </p>
        </div>

        <div className="grid g3">
          <SyncBox
            borderColor="var(--green)"
            textColor="var(--green-mid)"
            typeLabel="Auto-sync"
            heading="ChatGPT"
            action={
              <a
                className="btn sm"
                href={CUSTOM_GPT_URL}
                target="_blank"
                rel="noopener noreferrer"
                style={{ borderColor: "var(--green)", color: "var(--green-mid)" }}
              >
                Open the custom GPT
              </a>
            }
            note="Log into ChatGPT first, then click the button — the link won't open the custom GPT if you're signed out. You can also download a JSON summary from the chat and upload it manually on your Prelab progress page if you prefer."
          >
            There&apos;s a custom GPT for this course. Open it, do your prelab, and
            it updates your prelab progress automatically — nothing to upload.
          </SyncBox>

          <SyncBox
            borderColor="var(--blue)"
            textColor="var(--blue)"
            typeLabel="Manual upload"
            heading="Gemini"
            action={
              <Link
                className="btn sm"
                href={PRELAB_PROGRESS_PATH}
                style={{ borderColor: "var(--blue)", color: "var(--blue)" }}
              >
                Go to Prelab progress
              </Link>
            }
          >
            Gemini can&apos;t write back automatically. After your prelab, download
            the JSON file the chatbot gives you, then upload it on your Prelab
            progress page.
          </SyncBox>

          <SyncBox
            borderColor="var(--orange)"
            textColor="var(--orange-mid)"
            typeLabel="Connector · auto-sync"
            heading="Claude"
            action={<PrelabConnectHelp labName={detail.lab.name} />}
            note="You can also download a JSON summary and upload it manually on your Prelab progress page."
          >
            Claude connects through the course MCP connector, so it updates your
            prelab progress automatically once connected. Add the course MCP
            connector inside Claude to link it.
          </SyncBox>
        </div>
      </section>

      {items.length === 0 ? (
        <p className="muted" style={{ fontSize: 13 }}>
          No prelab documents attached yet.
        </p>
      ) : (
        <LabDocumentList labId={labId} kind="prelab" items={items} signedIn={signedIn} />
      )}
    </LabSectionShell>
  );
}

// One chatbot's "how to sync" card. Presentational only.
function SyncBox({
  borderColor,
  textColor,
  typeLabel,
  heading,
  action,
  note,
  children,
}: {
  borderColor: string;
  textColor: string;
  typeLabel: string;
  heading: string;
  action?: ReactNode;
  note?: string;
  children: ReactNode;
}) {
  return (
    <div
      className="card"
      style={{
        borderTop: `3px solid ${borderColor}`,
        display: "flex",
        flexDirection: "column",
        gap: 10,
      }}
    >
      <div>
        <div className="section-label" style={{ color: textColor }}>
          {typeLabel}
        </div>
        <h3 style={{ color: textColor, margin: "2px 0 0" }}>{heading}</h3>
      </div>
      <p className="muted" style={{ fontSize: 13, lineHeight: 1.55, margin: 0, flexGrow: 1 }}>
        {children}
      </p>
      {action ? <div>{action}</div> : null}
      {note ? (
        <p className="muted" style={{ fontSize: 12, lineHeight: 1.5, margin: 0 }}>
          {note}
        </p>
      ) : null}
    </div>
  );
}
