import { NextResponse } from "next/server";
import { and, eq, isNotNull } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth/session";
import { checkOrigin } from "@/lib/auth/guards";
import { db } from "@/lib/db/client";
import { labs, simulationCompletions } from "@/lib/db/schema";
import { findSimulation } from "@/lib/portal/simulations";

// Verifies the lab is currently published AND actually has this simulation attached.
// Returns the row's id (truthy) when the (lab, sim) pair is a valid completion target.
async function validateLabSim(labId: string, simId: string): Promise<boolean> {
  const [row] = await db
    .select({ id: labs.id })
    .from(labs)
    .where(
      and(
        eq(labs.id, labId),
        eq(labs.simulationId, simId),
        eq(labs.hasSimulation, true),
        isNotNull(labs.moduleOrder),
      ),
    )
    .limit(1);
  return !!row;
}

// GET ?sim=<id>&lab=<id> → whether the signed-in student has completed it on this lab.
export async function GET(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ done: false });

  const params = new URL(req.url).searchParams;
  const simId = params.get("sim") ?? undefined;
  const labId = params.get("lab") ?? undefined;
  if (!simId || !labId) {
    return NextResponse.json({ error: "sim and lab required" }, { status: 400 });
  }

  const [row] = await db
    .select({ id: simulationCompletions.id })
    .from(simulationCompletions)
    .where(
      and(
        eq(simulationCompletions.userId, user.id),
        eq(simulationCompletions.labId, labId),
        eq(simulationCompletions.simId, simId),
      ),
    )
    .limit(1);

  return NextResponse.json({ done: !!row });
}

// Toggle self-reported simulation completion for the signed-in student.
export async function POST(req: Request) {
  const origin = checkOrigin(req);
  if (origin) return origin;

  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "unauthenticated" }, { status: 401 });

  const body = (await req.json().catch(() => null)) as
    | { simId?: string; labId?: string; done?: boolean }
    | null;
  const simId = body?.simId;
  const labId = body?.labId;
  const done = body?.done ?? true;
  if (!simId || !findSimulation(simId)) {
    return NextResponse.json({ error: "unknown_simulation" }, { status: 400 });
  }
  if (!labId) {
    return NextResponse.json({ error: "labId required" }, { status: 400 });
  }

  // Publish-gate explicitly — not just FK existence. A future schema change that
  // retains rows post-unpublish should not quietly re-open the write path.
  if (!(await validateLabSim(labId, simId))) {
    return NextResponse.json({ error: "lab_sim_mismatch_or_unpublished" }, { status: 404 });
  }

  if (done) {
    await db
      .insert(simulationCompletions)
      .values({ userId: user.id, labId, simId })
      .onConflictDoNothing({
        target: [simulationCompletions.userId, simulationCompletions.labId, simulationCompletions.simId],
      });
  } else {
    await db
      .delete(simulationCompletions)
      .where(
        and(
          eq(simulationCompletions.userId, user.id),
          eq(simulationCompletions.labId, labId),
          eq(simulationCompletions.simId, simId),
        ),
      );
  }

  return NextResponse.json({ ok: true, done });
}
