import { notFound, redirect } from "next/navigation";
import { isNotNull, sql } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { labs } from "@/lib/db/schema";
import { ClassNotFoundError, getClassForOwner } from "@/lib/admin/classes";
import { getCurrentUser } from "@/lib/auth/session";
import { ManageClassClient, type AssignedLab, type LabOption } from "./client";

export const dynamic = "force-dynamic";

export default async function ManageClassPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const me = await getCurrentUser();
  if (!me) redirect(`/login?next=/admin/classes/${id}`);
  if (me.role !== "admin" && me.role !== "faculty") {
    return (
      <div className="col">
        <div className="screen-head">
          <div className="section-label">Restricted</div>
          <h1>Not available</h1>
        </div>
      </div>
    );
  }

  let detail;
  try {
    detail = await getClassForOwner(id, me.id);
  } catch (err) {
    if (err instanceof ClassNotFoundError) notFound();
    throw err;
  }

  // Only published modules (module_order is set) are assignable to a class.
  // Unpublished labs — e.g. question-bank labs auto-created on bank import — have
  // a null module_order and would otherwise leak into the "Add labs" picker.
  const labRows = await db
    .select({ id: labs.id, name: labs.name, moduleOrder: labs.moduleOrder })
    .from(labs)
    .where(isNotNull(labs.moduleOrder))
    .orderBy(sql`${labs.moduleOrder} asc nulls last, ${labs.name} asc`);

  const allLabs: LabOption[] = labRows.map((l) => ({
    id: l.id,
    name: l.name,
    moduleOrder: l.moduleOrder,
  }));

  // Already ordered by orderIndex in getClassForOwner.
  const assignedLabs: AssignedLab[] = detail.labs.map((l) => ({
    id: l.labId,
    name: l.name,
    orderIndex: l.orderIndex,
    isLocked: l.isLocked,
  }));

  return (
    <div className="col">
      <div className="screen-head">
        <div className="section-label">Teaching · Classes</div>
        <h1>{detail.name}</h1>
        <p className="lead muted">
          Manage roster, assigned labs, and lifecycle. Roster changes don&apos;t touch student
          history; the danger zone below covers global resets.
        </p>
      </div>
      <ManageClassClient
        classId={detail.id}
        initialName={detail.name}
        archivedAt={detail.archivedAt ? detail.archivedAt.toISOString() : null}
        students={detail.students.map((s) => ({
          userId: s.userId,
          username: s.username,
          displayName: s.displayName,
          email: s.email,
          enrolledAt: s.enrolledAt.toISOString(),
        }))}
        assignedLabs={assignedLabs}
        allLabs={allLabs}
      />
    </div>
  );
}
