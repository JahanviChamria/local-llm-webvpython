Web VPython 3.2
sun=sphere(pos=vector(0,0,0), color=color.orange, radius=0.75)
planet1=sphere(pos=vector(0,0,0), radius=0.25, make_trail=True, trail_type="points",   interval=1)
xaxis=cylinder(pos=vector(10,0,0), axis=vector(-20,0,0), radius=0.05)
yaxis=cylinder(pos=vector(0,10,0), axis=vector(0,-20,0), radius=0.05)
scene.userspin = False
scene.fov = 0.01
scene.background=color.white
theta=0
x=1.5
t=0
y=0
r=5
while theta<pi*2:
    rate(50)
    x=r*cos(theta)
    y=r*sin(theta)
    planet1.pos=vector(x,y,0)
    theta+=0.1
    t+=0.01