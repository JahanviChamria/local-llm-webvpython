JavaScript 3.2

scene.title = "A ball bounces in a box"
let s = 'To rotate "camera", drag with right button or Ctrl-drag.\n'
s += "To zoom, drag with middle button or Alt/Option depressed, or use scroll wheel.\n"
s += "  On a two-button mouse, middle is left + right.\n"
s += "To pan left/right and up/down, Shift-drag.\n"
s += "Touch screen: pinch/extend to zoom, swipe or two-finger rotate.\n"
scene.caption = s

let side = 4.0
let thk = 0.3
let s2 = 2*side - thk
let s3 = 2*side + thk
let wallR = box ( {pos:vec( side, 0, 0), size:vec(thk,s2,s3),  color : color.red} )
let wallL = box ( {pos:vec(-side, 0, 0), size:vec(thk,s2,s3),  color : color.red} )
let wallB = box ( {pos:vec(0, -side, 0), size:vec(s3,thk,s3),  color : color.blue} )
let wallT = box ( {pos:vec(0,  side, 0), size:vec(s3,thk,s3),  color : color.blue} )
let wallBK = box( {pos:vec(0, 0, -side), size:vec(s2,s2,thk), color : color.gray(0.7)} )

let ball = sphere ( {color : color.green, size : 0.8*vec(1,1,1)} )
ball.mass = 1.0
ball.p = vec (-0.15, -0.23, +0.27)
attach_trail(ball, {pps:200, retain:100, color:ball.color})

side = side - thk*0.5 - ball.size.x/2
let dt = 0.3

while ( true) { 
  // The rate statement tells VPython to execute the while statements
  // about 200 times per second. The "wait" keyword is necessary to permit
  // periodic updates to the window.
  await rate(200)
  ball.pos = ball.pos + (ball.p/ball.mass)*dt
  if (! (-side < ball.pos.x && ball.pos.x < side)) { 
    ball.p.x = -ball.p.x
  }
  if (! (-side < ball.pos.y && ball.pos.y < side)) { 
    ball.p.y = -ball.p.y
  }
  if (! (-side < ball.pos.z && ball.pos.z < side)) { 
    ball.p.z = -ball.p.z
  }
}
