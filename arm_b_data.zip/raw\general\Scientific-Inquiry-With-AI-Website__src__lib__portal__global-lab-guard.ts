import { notFound, redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
import { getStudentClassesWithLabs } from "@/lib/portal/classes";
import { getSidebarLabs } from "@/lib/portal/data";

// Guard for the global /portal/labs/[id] routes (landing + sub-pages).
//
// - admin / faculty: full access — manage and preview any lab.
// - student: only a published lab assigned to a class they're enrolled in, else 404,
//   so they can't reach labs outside their classes (or unpublished labs) via the
//   global path. getStudentClassesWithLabs already returns published-only labs.
// - guest: a read-only browse of *published* labs only — unpublished labs 404.
//
// Listing surfaces (sidebar, /portal redirect) already filter to published via
// getSidebarLabs; scoping guests here means a module page fails closed at the
// guard rather than relying on each view's getLabDetail call. The class-scoped
// routes have their own guard (loadStudentClassLab).
export async function guardStudentGlobalLab(labId: string): Promise<void> {
  const user = await getCurrentUser();
  if (!user) redirect(`/login?next=/portal/labs/${labId}`);
  if (user.role === "admin" || user.role === "faculty") return;

  if (user.role === "student") {
    const classes = await getStudentClassesWithLabs(user.id);
    const allowed = classes.some((c) => c.labs.some((l) => l.id === labId));
    if (!allowed) notFound();
    return;
  }

  // Guests (and any other non-staff role): published labs only. getSidebarLabs is
  // cache()'d and already loaded by the portal layout, so this reuses that query.
  const published = await getSidebarLabs();
  if (!published.some((l) => l.id === labId)) notFound();
}
