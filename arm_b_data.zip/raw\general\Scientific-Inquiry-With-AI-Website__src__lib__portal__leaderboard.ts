import { and, eq, gte, inArray, isNotNull, sql } from "drizzle-orm";
import { db } from "@/lib/db/client";
import type { User } from "@/lib/db/schema";
import {
  classEnrollments,
  classLabs,
  questions,
  srsReviews,
  srsSessions,
  users,
} from "@/lib/db/schema";
import { computeStreak, dayKey } from "@/lib/portal/progress";
import { listClassesForOwner } from "@/lib/admin/classes";
import { listAllClasses } from "@/lib/admin/all-classes";

// Flat bonus points added per day of the student's running practice streak.
// Tunable; if it ever dominates practice points, cap the streak used here.
export const STREAK_BONUS_PER_DAY = 3;

export type LeaderboardEntry = {
  userId: string;
  name: string;
  practicePoints: number;
  answers: number;
  streak: number;
  streakBonus: number;
  score: number;
  rank: number;
};

export type ClassLeaderboard = {
  classId: string;
  className: string;
  entries: LeaderboardEntry[];
};

export type LeaderboardPeriod = { start: Date; endsAt: Date; label: string };

/**
 * The current weekly leaderboard window: Monday 00:00 UTC through next Monday.
 * Weekly + global, so there's no per-class setting and the board resets on its
 * own. Switch the anchor to a course timezone here if local-midnight resets are
 * preferred.
 */
export function getCurrentWeek(now: Date = new Date()): LeaderboardPeriod {
  const start = new Date(
    Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()),
  );
  const dow = start.getUTCDay(); // 0 Sun .. 6 Sat
  const sinceMonday = dow === 0 ? 6 : dow - 1;
  start.setUTCDate(start.getUTCDate() - sinceMonday);
  const endsAt = new Date(start);
  endsAt.setUTCDate(endsAt.getUTCDate() + 7);
  return { start, endsAt, label: "This week" };
}

// Aggregates use raw, table-qualified column names: inside a sql`` template
// Drizzle renders ${table.column} unqualified, and `id` exists in several of
// the joined tables — `srs_reviews.id` keeps it unambiguous.
const practicePointsSql = sql<number>`coalesce(sum(case srs_reviews.rating
  when 'easy' then 3 when 'good' then 2 when 'hard' then 1 else 0 end), 0)`;
const answersSql = sql<number>`count(srs_reviews.id)`;

/**
 * Ranked leaderboard for one class for the current week. Practice points are
 * scoped to the class's assigned-lab questions; the streak bonus uses each
 * student's global running day-streak. Enrolled students with no activity
 * appear at 0.
 */
export async function getClassLeaderboard(
  classId: string,
): Promise<LeaderboardEntry[]> {
  const week = getCurrentWeek();

  // Questions belonging to this class's assigned labs (scopes the points).
  const qRows = await db
    .select({ id: questions.id })
    .from(questions)
    .innerJoin(classLabs, eq(classLabs.labId, questions.labId))
    .where(eq(classLabs.classId, classId));
  const questionIds = qRows.map((r) => r.id);

  // Join conditions live in the ON clause so 0-point students still appear.
  // Lab scope only: external standalone practice never scores class points.
  const reviewConds = [
    eq(srsReviews.userId, classEnrollments.userId),
    eq(srsReviews.scope, "lab"),
    gte(srsReviews.reviewedAt, week.start),
    questionIds.length
      ? inArray(srsReviews.questionId, questionIds)
      : sql`false`, // class has no questions → nobody scores points
  ];

  const pointRows = await db
    .select({
      userId: users.id,
      displayName: users.displayName,
      username: users.username,
      practicePoints: practicePointsSql,
      answers: answersSql,
    })
    .from(classEnrollments)
    .innerJoin(users, eq(users.id, classEnrollments.userId))
    .leftJoin(srsReviews, and(...reviewConds))
    .where(eq(classEnrollments.classId, classId))
    .groupBy(users.id, users.displayName, users.username);

  if (pointRows.length === 0) return [];

  // Running day-streaks for the same students — finished-session days run
  // through computeStreak. Lab-scope only, so this can trail the Progress-page
  // streak (which counts external practice too) — intentional: only class-linked
  // practice earns ranked bonus points.
  const userIds = pointRows.map((r) => r.userId);
  const sessionRows = await db
    .select({ userId: srsSessions.userId, finishedAt: srsSessions.finishedAt })
    .from(srsSessions)
    .where(
      and(
        inArray(srsSessions.userId, userIds),
        eq(srsSessions.scope, "lab"),
        isNotNull(srsSessions.finishedAt),
      ),
    );

  const daysByUser = new Map<string, Set<string>>();
  for (const r of sessionRows) {
    if (!r.finishedAt) continue;
    let set = daysByUser.get(r.userId);
    if (!set) {
      set = new Set();
      daysByUser.set(r.userId, set);
    }
    set.add(dayKey(r.finishedAt));
  }

  const entries: LeaderboardEntry[] = pointRows.map((r) => {
    const practicePoints = Number(r.practicePoints);
    const answers = Number(r.answers);
    const streak = computeStreak(daysByUser.get(r.userId) ?? new Set());
    const streakBonus = streak * STREAK_BONUS_PER_DAY;
    return {
      userId: r.userId,
      name: r.displayName?.trim() || r.username,
      practicePoints,
      answers,
      streak,
      streakBonus,
      score: practicePoints + streakBonus,
      rank: 0,
    };
  });

  // Total score, then practice points, then name. Dense rank (ties share).
  entries.sort(
    (a, b) =>
      b.score - a.score ||
      b.practicePoints - a.practicePoints ||
      a.name.localeCompare(b.name),
  );
  let rank = 0;
  let prevScore = Number.NaN;
  entries.forEach((e, i) => {
    if (e.score !== prevScore) {
      rank = i + 1;
      prevScore = e.score;
    }
    e.rank = rank;
  });

  return entries;
}

/**
 * Leaderboards for every class an instructor can see: their owned classes
 * (faculty) or all active classes (admin).
 */
export async function getInstructorLeaderboards(
  user: User,
): Promise<ClassLeaderboard[]> {
  const classRows =
    user.role === "admin"
      ? await listAllClasses({ includeArchived: false })
      : await listClassesForOwner(user.id, { includeArchived: false });

  return Promise.all(
    classRows.map(async (c) => ({
      classId: c.id,
      className: c.name,
      entries: await getClassLeaderboard(c.id),
    })),
  );
}
