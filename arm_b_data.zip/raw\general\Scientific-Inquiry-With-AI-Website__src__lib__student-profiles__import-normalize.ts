// Pure (no-DB) normalization + validation for a student's prelab-progress import.
//
// Split out from the import route so BOTH transports share one source of truth:
//   - POST /api/portal/profile/import  (manual JSON upload — Gemini/ChatGPT file)
//   - the sync_prelab_progress MCP tool (Claude, end-of-prelab tool call)
//
// Kept free of any db-client import so it can be unit-tested without a database
// (see scripts/test-prelab-sync.ts), exactly like ./topics for the topic-mastery
// schema. The db-touching gate + merge lives in ./import.

import { z } from "zod";
import { jsonbPatchSchema, MAX_FIELD_BYTES } from "@/lib/student-profiles/codes";

// Keep the schema permissive (string→number); the accessible-lab + 0..5 gate is
// enforced after parse so out-of-range entries are skipped, not rejected. Still
// byte-capped like the freeform columns.
export const topicMasterySchema = z
  .record(z.string(), z.number())
  .refine((v) => Buffer.byteLength(JSON.stringify(v), "utf8") <= MAX_FIELD_BYTES, {
    message: `topicMastery exceeds ${MAX_FIELD_BYTES} bytes`,
  });

// No "at least one section" refine here: an engagement_scoring-only paste is
// valid but carries none of these keys (it's resolved separately). The final
// applied.length check returns nothing_applicable when truly nothing landed.
export const bodySchema = z.object({
  topicMastery: topicMasterySchema.optional(),
  mindMap: jsonbPatchSchema.optional(),
  personalization: jsonbPatchSchema.optional(),
  learningStyle: jsonbPatchSchema.optional(),
  struggles: jsonbPatchSchema.optional(),
});

export type ImportBody = z.infer<typeof bodySchema>;

// Pull a leading number out of a value that may be a number or a string like
// "2.00" or "2.00 / 5". Returns null when there's no parseable number.
export function coerceScore(v: unknown): number | null {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string") {
    const m = v.match(/-?\d+(?:\.\d+)?/);
    if (m) return Number(m[0]);
  }
  return null;
}

export function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

// Fold the chatbot's raw output into the canonical import shape for the freeform
// columns + any canonical (id-keyed) topicMastery map. Accepts snake_case
// aliases; unrecognized keys are ignored here and dropped by bodySchema. The
// engagement_scoring block is handled separately (see extractEngagement) because
// resolving a lab_name to an id needs the student's published-lab list.
export function normalizeImport(raw: unknown): Record<string, unknown> {
  if (!isRecord(raw)) return {};
  const out: Record<string, unknown> = {};

  const mindMap = raw.mindMap ?? raw.mind_map;
  if (mindMap !== undefined) out.mindMap = mindMap;
  if (raw.personalization !== undefined) out.personalization = raw.personalization;
  const learningStyle = raw.learningStyle ?? raw.learning_style;
  if (learningStyle !== undefined) out.learningStyle = learningStyle;
  if (raw.struggles !== undefined) out.struggles = raw.struggles;

  if (isRecord(raw.topicMastery)) {
    const topic: Record<string, number> = {};
    for (const [labId, level] of Object.entries(raw.topicMastery)) {
      const n = coerceScore(level);
      if (n !== null) topic[labId] = Math.round(n);
    }
    if (Object.keys(topic).length > 0) out.topicMastery = topic;
  }

  return out;
}

// Pull a lab name out of a value that's either a plain string ("collisions") or
// an object with a name field ({ "name": "collisions" }) — chatbots emit both.
function asName(v: unknown): string | undefined {
  if (typeof v === "string") return v;
  if (isRecord(v) && typeof v.name === "string") return v.name;
  return undefined;
}

// First defined value among the given keys on a record.
function firstOf(rec: Record<string, unknown>, keys: string[]): unknown {
  for (const k of keys) if (rec[k] !== undefined) return rec[k];
  return undefined;
}

// A parsed engagement_scoring block, before the lab is resolved to an id. Either
// labName or labId may be set; level is the rounded 0..5-ish score (range gated
// downstream). Returns null when there's no usable score.
export type Engagement = { labId?: string; labName?: string; level: number };

// The tutor doc is internally inconsistent about the engagement scale: the
// student-facing chat feedback is out of 100, while the JSON schema is out of 5.
// The model sometimes carries the /100 figure into the JSON. Any value above 5
// can only be a percentage, so rescale it into the 0-5 mastery band rather than
// dropping it as out-of-range.
function toMasteryLevel(score: number): number {
  const scaled = score > 5 ? score / 20 : score;
  return Math.round(scaled);
}

export function extractEngagement(raw: unknown): Engagement | null {
  if (!isRecord(raw)) return null;
  const eng = raw.engagement_scoring ?? raw.engagementScoring;
  if (!isRecord(eng)) return null;

  const score = coerceScore(eng.total_ai_engagement_score ?? eng.totalAiEngagementScore);
  if (score === null) return null;

  // Look for the lab in the engagement block first, then at the top level, under
  // any common spelling. Name may be a string or a { name } object.
  const idKeys = ["lab_id", "labId"];
  const nameKeys = ["lab_name", "labName", "Lab_name", "lab"];
  const labId = firstOf(eng, idKeys) ?? firstOf(raw, idKeys);
  const labName = asName(firstOf(eng, nameKeys)) ?? asName(firstOf(raw, nameKeys));
  return {
    labId: typeof labId === "string" ? labId : undefined,
    labName,
    level: toMasteryLevel(score),
  };
}
