import Link from "next/link";
import { SessionRunner } from "@/components/practice/session-runner";

export const dynamic = "force-dynamic";

export default async function SessionPage({
  searchParams,
}: {
  searchParams: Promise<{ lab?: string }>;
}) {
  const { lab } = await searchParams;

  if (!lab) {
    return (
      <div className="col" style={{ alignItems: "center", gap: 14 }}>
        <div className="callout orange" style={{ maxWidth: 520 }}>
          <strong>No lab selected.</strong> Open a lab module from the sidebar and start the session from its retrieval-practice card.
        </div>
        <Link className="btn primary" href="/portal">
          ← Back to modules
        </Link>
      </div>
    );
  }

  return <SessionRunner labId={lab} />;
}
