import java.util.*;

public class Consistency {
    public static Set<IntervalInfo> checkStatements(Collection<Statement> statements) {
        //graph: key is a node ("As" or "Ae"), value is a list of nodes it points to
        Map<String, List<String>> graph = new HashMap<>();
        //keep track of all interval identifiers
        Set<Integer> intervals = new HashSet<>();

        //build graph nodes and edges
        for (Statement s : statements) {
            int X = s.firstInterval();
            int Y = s.secondInterval();
            intervals.add(X);
            intervals.add(Y);

            String Xs = X + "s";
            String Xe = X + "e";
            String Ys = Y + "s";
            String Ye = Y + "e";

            //ensure all nodes exist in graph
            graph.putIfAbsent(Xs, new ArrayList<>());
            graph.putIfAbsent(Xe, new ArrayList<>());
            graph.putIfAbsent(Ys, new ArrayList<>());
            graph.putIfAbsent(Ye, new ArrayList<>());

            //every interval is start -> end
            graph.get(Xs).add(Xe);
            graph.get(Ys).add(Ye);

            if (s.isOverlap()) {
                //overlap so Ys -> Xe, Xs -> Ye
                graph.get(Ys).add(Xe);
                graph.get(Xs).add(Ye);
            } else {
                //X ends before Y starts so Xe -> Ys
                graph.get(Xe).add(Ys);
            }
        }

        //topological sort
        List<String> topoOrder = topologicalSort(graph);
        if (topoOrder == null) {
            //cycle detected so inconsistent
            return null;
        }

        //assign times based on topological order
        Map<String, Integer> timeMap = new HashMap<>();
        int time = 1;
        for (String node : topoOrder) {
            timeMap.put(node, time++);
        }

        //create IntervalInfo objects
        Set<IntervalInfo> result = new HashSet<>();
        for (int id : intervals) {
            IntervalInfo info = new IntervalInfo(id);
            info.setStart(timeMap.get(id + "s"));
            info.setEnd(timeMap.get(id + "e"));
            result.add(info);
        }

        return result;
    }

    //topological sort using DFS
    private static List<String> topologicalSort(Map<String, List<String>> graph) {
        Set<String> visited = new HashSet<>();
        Set<String> visiting = new HashSet<>();
        List<String> order = new ArrayList<>();

        for (String node : graph.keySet()) {
            if (!visited.contains(node)) {
                if (!dfs(node, graph, visited, visiting, order)) {
                    return null; // cycle detected
                }
            }
        }

        Collections.reverse(order);
        return order;
    }

    private static boolean dfs(String node, Map<String, List<String>> graph, Set<String> visited, Set<String> visiting, List<String> order) {
        visiting.add(node);
        for (String neighbor : graph.get(node)) {
            if (visited.contains(neighbor)) 
                continue;
            if (visiting.contains(neighbor)) 
                return false; // cycle
            if (!dfs(neighbor, graph, visited, visiting, order)) 
                return false;
        }

        visiting.remove(node);
        visited.add(node);
        order.add(node);
        return true;
    }

    public static void main(String[] args) {
        //consistent statements
        List<Statement> statements1 = new ArrayList<>();
        statements1.add(new Statement(true, 1, 2));    // 1 overlaps 2
        statements1.add(new Statement(true, 2, 3));    // 2 overlaps 3
        statements1.add(new Statement(false, 1, 3));   // 1 ends before 3 starts
        statements1.add(new Statement(false, 3, 4));   // 3 ends before 4 starts
        statements1.add(new Statement(true, 4, 5));    // 4 overlaps 5
        statements1.add(new Statement(false, 5, 6));   // 5 ends before 6 starts

        testConsistency(statements1);

        //example 2: Inconsistent statements
        List<Statement> statements2 = new ArrayList<>();
        statements2.add(new Statement(true, 1, 2));    // 1 overlaps 2
        statements2.add(new Statement(false, 2, 3));   // 2 ends before 3 starts
        statements2.add(new Statement(true, 3, 4));    // 3 overlaps 4
        statements2.add(new Statement(false, 4, 1));   // 4 ends before 1 starts

        testConsistency(statements2);
    }

    private static void testConsistency(Collection<Statement> statements) {
        Set<IntervalInfo> result = checkStatements(statements);
        if (result == null) {
            System.out.println("Statements are inconsistent.");
        } 
        else {
            System.out.println("Statements are consistent. Interval assignments:");
            for (IntervalInfo info : result) {
                System.out.println("Interval " + info.getIdentifier() +": start=" + info.getStart() +", end=" + info.getEnd());
            }
        }
    }

}