Web VPython 3.2
tablex = 2.5
tabley = -2
tablez = -1
tableLength=4
tableWidth=5
tableHeight=1
legRadius=tableWidth/10
tableColor=color.black
scene.background=color.white
scene.range=5
table=box(pos=vector(tablex, tabley, tablez), color=tableColor, length=tableLength, width=tableWidth, height=tableHeight)
cylinder(color=table.color, radius=legRadius, axis=vector(0, -tableHeight*4, 0), pos=table.pos)