import { LabSimulationView } from "@/components/portal/lab-simulation-view";
import { guardStudentGlobalLab } from "@/lib/portal/global-lab-guard";

export const dynamic = "force-dynamic";

export default async function LabSimulationPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  await guardStudentGlobalLab(id);
  return <LabSimulationView labId={id} basePath={`/portal/labs/${id}`} />;
}
