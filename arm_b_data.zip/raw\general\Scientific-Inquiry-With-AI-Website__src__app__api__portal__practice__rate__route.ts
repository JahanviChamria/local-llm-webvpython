import { NextResponse } from "next/server";
import { and, eq, isNull, sql } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth/session";
import { checkOrigin } from "@/lib/auth/guards";
import { db } from "@/lib/db/client";
import { questions, srsAttempts, srsCards, srsReviews, srsSessions } from "@/lib/db/schema";
import { schedule, type SrsRating } from "@/lib/srs/scheduler";
import {
  computeTimeFactor,
  deriveAutoRating,
  effectiveBaseline,
  estimateReadMs,
  nextBaseline,
  thinkingMs,
} from "@/lib/srs/timing";

const RATINGS: SrsRating[] = ["again", "hard", "good", "easy"];

export async function POST(req: Request) {
  const origin = checkOrigin(req);
  if (origin) return origin;

  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "unauthenticated" }, { status: 401 });

  const body = (await req.json().catch(() => null)) as
    | {
        attemptId?: string;
        sessionId?: string;
        rating?: string;
        answerText?: string;
        selectedOption?: string;
      }
    | null;
  const { attemptId, sessionId } = body ?? {};
  const rating = body?.rating as SrsRating | undefined;
  if (!attemptId || !rating || !RATINGS.includes(rating)) {
    return NextResponse.json(
      { error: "attemptId and valid rating required" },
      { status: 400 },
    );
  }

  const [attempt] = await db
    .select()
    .from(srsAttempts)
    .where(and(eq(srsAttempts.id, attemptId), eq(srsAttempts.userId, user.id)))
    .limit(1);
  if (!attempt) {
    return NextResponse.json({ error: "attempt not found" }, { status: 404 });
  }

  // Idempotent re-rate: a network retry on a rate that already landed should
  // succeed silently rather than surface a 4xx that the student sees as
  // "something broke." Since reveal now auto-rates every format, this is also
  // the normal path for stale clients that still call rate afterwards.
  if (attempt.ratedAt) {
    const [card] = await db
      .select({ intervalDays: srsCards.intervalDays, due: srsCards.due })
      .from(srsCards)
      .where(eq(srsCards.id, attempt.cardId))
      .limit(1);
    return NextResponse.json({
      ok: true,
      alreadyRated: true,
      intervalAfter: card?.intervalDays ?? 0,
      due: card?.due ?? null,
    });
  }

  const [card] = await db
    .select()
    .from(srsCards)
    .where(eq(srsCards.id, attempt.cardId))
    .limit(1);
  if (!card) {
    return NextResponse.json({ error: "card not found" }, { status: 404 });
  }

  const [question] = await db
    .select({
      format: questions.format,
      baselineAnswerMs: questions.baselineAnswerMs,
      baselineSampleCount: questions.baselineSampleCount,
    })
    .from(questions)
    .where(eq(questions.id, attempt.questionId))
    .limit(1);

  const now = new Date();

  // Body fields override what reveal stored on the attempt. This keeps rate
  // honest when a student rates without clicking reveal (allowed) — otherwise
  // the audit log would record null and lose the answer entirely.
  const finalAnswer =
    body?.selectedOption ?? body?.answerText ?? attempt.answerText ?? null;

  const baseline = question
    ? effectiveBaseline(
        question.baselineAnswerMs,
        question.baselineSampleCount,
        question.format,
        attempt.promptSnapshot.length,
      )
    : null;
  // Reading-adjusted times: strip estimated reading from both the measured time
  // and the baseline so the speed signal reflects recall, not prompt length.
  const readMs =
    baseline != null ? estimateReadMs(attempt.promptSnapshot.length, baseline) : 0;
  const tThink = attempt.answerMs != null ? thinkingMs(attempt.answerMs, readMs) : null;
  const baselineThink = baseline != null ? thinkingMs(baseline, readMs) : null;
  const tf = baselineThink != null ? computeTimeFactor(tThink, baselineThink) : 1;

  // Choice formats are auto-graded: the server derives the rating from the
  // answer vs. the snapshot, ignoring the client-sent rating. A client that
  // skips reveal can't self-rate a wrong MC/TF answer up.
  const isChoice = attempt.correctOptionSnapshot != null;
  const wasCorrect = isChoice ? finalAnswer === attempt.correctOptionSnapshot : null;
  const effectiveRating: SrsRating =
    isChoice && baselineThink != null
      ? deriveAutoRating(wasCorrect === true, tThink, baselineThink)
      : rating;

  const next = schedule(
    {
      state: card.state,
      reps: card.reps,
      lapses: card.lapses,
      ease: card.ease,
      intervalDays: card.intervalDays,
    },
    effectiveRating,
    now,
    { timeFactor: tf },
  );

  // Claim the attempt atomically before writing anything else. The ratedAt read
  // above is a fast pre-check, not a guard: two concurrent rates (or a rate
  // racing a reveal) can both pass it. The conditional update on ratedAt is the
  // real lock — mirrors reveal's finalizeRating — so a lost race inserts no
  // duplicate review and doesn't re-advance the schedule.
  const claimed = await db.transaction(async (tx) => {
    const claim = await tx
      .update(srsAttempts)
      .set({ ratedAt: now, answerText: finalAnswer, wasCorrect })
      .where(and(eq(srsAttempts.id, attempt.id), isNull(srsAttempts.ratedAt)))
      .returning({ id: srsAttempts.id });
    if (claim.length === 0) return false;

    await tx
      .update(srsCards)
      .set({
        state: next.state,
        reps: next.reps,
        lapses: next.lapses,
        ease: next.ease,
        intervalDays: next.intervalDays,
        due: next.due,
        lastReviewedAt: now,
      })
      .where(eq(srsCards.id, attempt.cardId));

    await tx.insert(srsReviews).values({
      userId: user.id,
      cardId: attempt.cardId,
      questionId: attempt.questionId,
      attemptId: attempt.id,
      rating: effectiveRating,
      ratingSource: isChoice ? "auto" : "self",
      answerMs: attempt.answerMs,
      timeFactor: tf,
      scope: card.scope,
      answerText: finalAnswer,
      parameterDraw: attempt.draw,
      intervalBefore: card.intervalDays,
      intervalAfter: next.intervalDays,
    });

    // Baseline learns from confident recalls only: correct choice answers are
    // handled at reveal; here, self-rated good/easy with a measured time.
    if (
      !isChoice &&
      attempt.answerMs != null &&
      question &&
      (effectiveRating === "good" || effectiveRating === "easy")
    ) {
      const nb = nextBaseline(
        question.baselineAnswerMs,
        question.baselineSampleCount,
        attempt.answerMs,
      );
      await tx
        .update(questions)
        .set({ baselineAnswerMs: nb.baseline, baselineSampleCount: nb.count })
        .where(eq(questions.id, attempt.questionId));
    }
    return true;
  });

  // Lost the claim: another rate/reveal already finalized this attempt. Return the
  // same idempotent success as the ratedAt pre-check, without double-counting the
  // session or the review log.
  if (!claimed) {
    return NextResponse.json({
      ok: true,
      alreadyRated: true,
      intervalAfter: next.intervalDays,
      due: next.due,
    });
  }

  if (sessionId) {
    await db
      .update(srsSessions)
      .set({ reviewedCount: sql`${srsSessions.reviewedCount} + 1` })
      .where(and(eq(srsSessions.id, sessionId), eq(srsSessions.userId, user.id)));
  }

  return NextResponse.json({
    ok: true,
    alreadyRated: false,
    intervalAfter: next.intervalDays,
    due: next.due,
  });
}
