import java.awt.Color;

//A Smart CPU Paddle
//Logic is as follows:
// -if the ball is moving towards the Human player, execute CPUStandard Paddle's
//  logic for if the ball is moving RIGHT
// -if the ball is moving towards the CPU player:
//      =if the ball will NOT bounce before reaching CPU, move to the ball's projected location 
//      =if ball WILL bounce before reaching cpu:
//         *if ball is in lefmost 1/3rd of window, move to center of game window
//         *if ball is in rightmost 2/3rds of window, move to match ball's y coord,
//          but cannot move above/below middle 50% of the window vertically
public class CPUSmart extends CPUStandard{
   
   
   //CPU Smart Paddle attributes 
   public static final double CPU_SMART_PADDLE_LENGTH = 60.0;   
   public static final double CPU_SMART_PADDLE_SPEED = 3.0;   
   public static final Color CPU_SMART_PADDLE_COLOR = Color.orange;    

   
               
   //****************   CONSTRUCTORS  *************   
   public CPUSmart(){
      this(CPU_SMART_PADDLE_LENGTH);
   }
   
   public CPUSmart(double length){
      this(length, CPU_SMART_PADDLE_SPEED);
   }

   public CPUSmart(double length, double speed){
      this(length, speed, CPU_SMART_PADDLE_COLOR);
   } 

   public CPUSmart(double length, double speed, Color color){ 
      super(length, speed, color);
   }  
   
   
   
   
   //******************************************************************************
   //Determine how the paddle should move when the ball is moving left or right with 
   //the argument coordinates/velocities.
   //Returns -1, 0, or 1 if paddle should move up, neutral, or down, respectively.
   //
   //arguments include (in order):
   //bX, bY: the ball's current x and y coordinates
   //bXVel, bYVel: the ball's current x and y velocities    
   protected int decideMoveBallGoingLeft(double bX, double bY, double bXVel, double bYVel){ 
      return super.decideMoveBallGoingRight(bX,bY,bXVel,bYVel);
   }
      


   protected int decideMoveBallGoingRight(double bX, double bY, double bXVel, double bYVel){
      
      double windowHeight=this.getWindowHeight();
      double windowWidth=this.getWindowWidth();
      double projectedY=this.getProjectedY(bX,bY,bXVel,bYVel);
      double paddleY = this.getY();
      double paddleTopY = this.getTopY();
      double paddleBottomY = this.getBottomY();
      if(projectedY<0 || projectedY>windowHeight){ //ball will bounce
         if(bX<=(windowWidth/3.0)){  //ball currently in leftmost third of the window
            return super.decideMoveBallGoingLeft(bX,bY,bXVel,bYVel);
         }
         else{ //ball currently in rightmost 2/3rds of the window
            if(paddleTopY>(windowHeight/4.0) && paddleBottomY<((windowHeight*3)/4.0)){  //paddle in middle 50%
               return super.decideMoveBallGoingRight(bX,bY,bXVel,bYVel);
            }
         }
      }
      else{ //ball will not bounce
         if(Math.abs(projectedY-paddleY)<MOVE_THRESHOLD)
            return MOVE_NEUTRAL;
         else if(paddleY<bY)
            return MOVE_DOWN;
         return MOVE_UP;
      }
      return MOVE_NEUTRAL;
   }
   //******************************************************************************   
   
   
   
}
