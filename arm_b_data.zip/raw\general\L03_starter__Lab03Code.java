public class Lab03Code{
    



     //***COMPLETE 2.1 BEFORE YOU START WRITING ANY CODE! ***
  

    //Jahanvi Chamria, Lola Garrigue


     
    //Start writing your code for 2.2 here!

    public static int longestStreak(int[] nums, boolean checkEvens){
        int streak=0, streakMax=0;
        if(checkEvens){
            for(int i=0;i<nums.length;i++){
                if(nums[i]%2==0 && nums[i]!=0){
                    streak+=1;
                }
                else{
                    if(streak>=streakMax){
                        streakMax=streak;
                        streak=0;
                    }
                }
            }
        }
        else{
            for(int i=0;i<nums.length;i++){
                if(nums[i]%2!=0 && nums[i]!=0){
                    streak+=1;
                }
                else{
                    if(streak>=streakMax){
                        streakMax=streak;
                        streak=0;
                    }
                }
            }
        }
        return streakMax;
    }

    public static String[] getUniqueSuffixes(String[] str, int suffLen){
        String[] uSuffixes = new String[str.length];
        int k = 0;
        if(suffLen<=0){
            String[] empty = new String[0];
            return empty;
        }
        else{
            for(int i = 0; i<str.length; i++){
                if(str[i].length()>=suffLen){
                    String suf = str[i].substring(str[i].length()-suffLen);
                    if(uniqueString(uSuffixes, suf, k)){
                        uSuffixes[k++] = suf;
                    }
                }
            }
            String[] toReturn = new String[k];
            int l = 0;
            for(int j = 0; j<uSuffixes.length; j++){
                if(uSuffixes[j]!=null && uSuffixes[j].length()>0){
                    toReturn[l++] = uSuffixes[j];
                }
            }
        return toReturn;
        }
    }

    public static boolean uniqueString(String[] uSuf, String wordSuffix, int k){
        boolean flag = true;
        if(uSuf[0]==null){
            return flag;
        }
        for(int i = 0; i<k; i++){
            if(uSuf[i].equals(wordSuffix))
                flag = false;
        }
        return flag;
    }
}
