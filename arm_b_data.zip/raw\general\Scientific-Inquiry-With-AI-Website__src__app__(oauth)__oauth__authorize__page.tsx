// OAuth 2.1 consent page.
//
// Validates the /authorize query parameters, resolves the requesting client
// (CIMD or static), checks redirect_uri exact-match, and renders the consent
// UI. The form POSTs to /api/oauth/authorize which mints the auth code and
// redirects to the client's redirect_uri with code + state + iss.
//
// Two-bucket error handling:
//
//   - **Untrusted bucket** (bad client_id or unregistered redirect_uri):
//     render an error page on this AS. NEVER redirect to the supplied
//     redirect_uri — it could be attacker-controlled. The user sees an
//     in-app error, not a redirect to evil.example.com.
//
//   - **Trusted bucket** (client + redirect_uri verified, other params bad):
//     still render an error page here. We could redirect with error=...
//     per RFC 6749 §4.1.2.1, but for the consent surface a human-readable
//     screen is friendlier; the POST handler handles the redirect-style
//     error responses for downstream OAuth machinery.
//
// PKCE S256 is mandatory — reject anything else at this stage.

import { redirect } from "next/navigation";
import { AuthShell } from "@/components/auth/auth-shell";
import { getCurrentUser } from "@/lib/auth/session";
import { resolveClient, redirectUriMatches } from "@/lib/oauth/client-lookup";
import {
  canonicalizeResource,
  getCanonicalMcpResource,
  getCanonicalActionsResource,
  InvalidResourceError,
} from "@/lib/oauth/canonical-resource";
import {
  parseScopeString,
  filterToKnownScopes,
  SCOPE_LABELS,
  ALL_SCOPES,
} from "@/lib/oauth/scopes";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type SearchParams = Record<string, string | string[] | undefined>;

function pickOne(v: string | string[] | undefined): string | null {
  if (typeof v === "string" && v.length > 0) return v;
  return null;
}

function buildAuthorizeUrl(params: SearchParams): string {
  const sp = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (typeof v === "string") sp.set(k, v);
  }
  return `/oauth/authorize?${sp.toString()}`;
}

function ErrorScreen({ title, message }: { title: string; message: string }) {
  return (
    <AuthShell
      eyebrow="Authorize a connection"
      title={title}
      subtitle={message}
      backHref="/"
      backLabel="Back to home"
    >
      <div className="col" style={{ gap: "0.75rem" }}>
        <p className="muted" style={{ margin: 0 }}>
          If you reached this page from Claude or ChatGPT, return there and try connecting again.
          If the problem persists, the connector configuration may be out of date.
        </p>
      </div>
    </AuthShell>
  );
}

export default async function AuthorizePage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>;
}) {
  const params = await searchParams;

  // 1. Sign-in gate. Redirect to /login with the full /authorize URL as next.
  const user = await getCurrentUser();
  if (!user) {
    const back = buildAuthorizeUrl(params);
    redirect(`/login?next=${encodeURIComponent(back)}`);
  }

  // 2. Pull and validate required params.
  const clientId = pickOne(params.client_id);
  const redirectUri = pickOne(params.redirect_uri);
  const responseType = pickOne(params.response_type);
  const codeChallenge = pickOne(params.code_challenge);
  const codeChallengeMethod = pickOne(params.code_challenge_method);
  const resourceParam = pickOne(params.resource);
  const scope = pickOne(params.scope) ?? "";
  const state = pickOne(params.state) ?? "";

  if (!clientId) {
    return <ErrorScreen title="Missing client" message="No client_id was provided." />;
  }

  // 3. Resolve the client. Untrusted bucket — if this fails we don't redirect.
  const clientResult = await resolveClient(clientId);
  if (!clientResult.ok) {
    return (
      <ErrorScreen
        title="Unknown application"
        message="The application asking to connect couldn't be verified."
      />
    );
  }
  const client = clientResult.client;

  // 4. redirect_uri exact-match. Also untrusted until we confirm it.
  if (!redirectUri || !redirectUriMatches(client, redirectUri)) {
    return (
      <ErrorScreen
        title="Invalid redirect URL"
        message="The redirect URL doesn't match what this application registered."
      />
    );
  }

  // 5. From here on, params errors COULD be reported via redirect-with-error,
  //    but consent-surface UX is better with an in-app error screen. The POST
  //    handler does redirect-style errors for invalid Allow submissions.
  if (responseType !== "code") {
    return (
      <ErrorScreen
        title="Unsupported response type"
        message={`Only response_type=code is supported (got "${responseType ?? "missing"}").`}
      />
    );
  }

  // 5a. PKCE rules differ by client type. Confidential clients (GPT Builder
  //     Actions) authenticate via client_secret at the token endpoint, not PKCE.
  //     Public clients (CIMD) still require PKCE S256.
  if (client.isPublic) {
    if (!codeChallenge) {
      return (
        <ErrorScreen
          title="Missing PKCE challenge"
          message="A code_challenge is required for OAuth 2.1 / PKCE."
        />
      );
    }
    if (codeChallengeMethod !== "S256") {
      return (
        <ErrorScreen
          title="Unsupported PKCE method"
          message={`Only code_challenge_method=S256 is supported (got "${codeChallengeMethod ?? "missing"}").`}
        />
      );
    }
  } else {
    // Confidential: any PKCE inputs are ignored. Don't even let the form carry
    // them — invariant E: code_challenge_method="none" must be a confidential-
    // only signal, so we render the form without those hidden inputs at all.
  }

  // 6. Resource binding. Confidential clients default to the Actions resource
  //    when missing; public clients still require the MCP resource explicitly.
  //    Cross-pair invariants enforced below: public clients can't request the
  //    Actions resource, and confidential clients can't request the MCP resource.
  const expectedResource = client.isPublic
    ? getCanonicalMcpResource()
    : getCanonicalActionsResource();

  let resourceCanonical: string;
  if (!resourceParam) {
    if (client.isPublic) {
      return (
        <ErrorScreen
          title="Missing resource"
          message="The resource parameter is required so the token can be bound to this server."
        />
      );
    }
    resourceCanonical = expectedResource;
  } else {
    try {
      resourceCanonical = canonicalizeResource(resourceParam);
    } catch (err) {
      const reason = err instanceof InvalidResourceError ? err.message : "malformed URL";
      return (
        <ErrorScreen
          title="Invalid resource"
          message={`The resource parameter could not be parsed: ${reason}.`}
        />
      );
    }
  }
  if (resourceCanonical !== expectedResource) {
    return (
      <ErrorScreen
        title="Wrong resource"
        message={
          client.isPublic
            ? "The resource parameter doesn't match this server's MCP endpoint."
            : "This client must request the Actions resource, not MCP."
        }
      />
    );
  }

  // 7. Compute the scopes we'll actually grant. Filter to known scopes; if
  //    the client requested unknown ones, silently drop them (per OAuth 2.1
  //    advice — never error on unknown scopes, just don't grant them).
  const requestedScopes = parseScopeString(scope);
  const grantableScopes = filterToKnownScopes(requestedScopes);
  // Default at consent time: if client didn't request any specific scopes,
  // offer the full study + profile read/write set. Always honor offline_access
  // request explicitly (it controls whether a refresh token is issued).
  const scopesToShow =
    grantableScopes.length > 0 ? grantableScopes : ALL_SCOPES.filter((s) => s !== "offline_access");

  return (
    <AuthShell
      eyebrow="Authorize a connection"
      title={`Allow ${client.clientName} to access Sci-AI?`}
      subtitle={`Signed in as ${user.displayName ?? user.username}. The app will only see what you allow below.`}
      backHref="/"
      backLabel="Cancel and go home"
    >
      <form method="POST" action="/api/oauth/authorize" className="col" style={{ gap: "1rem" }}>
        {/* Pass every validated param through. The POST handler re-validates
            everything from scratch — these inputs are convenience, not trust.
            PKCE fields are omitted for confidential clients so the POST handler
            sees their absence as the "no PKCE for this auth code" signal. */}
        <input type="hidden" name="client_id" value={clientId} />
        <input type="hidden" name="redirect_uri" value={redirectUri} />
        <input type="hidden" name="response_type" value="code" />
        {client.isPublic && codeChallenge && (
          <>
            <input type="hidden" name="code_challenge" value={codeChallenge} />
            <input type="hidden" name="code_challenge_method" value="S256" />
          </>
        )}
        <input type="hidden" name="resource" value={resourceCanonical} />
        <input type="hidden" name="scope" value={scopesToShow.join(" ")} />
        <input type="hidden" name="state" value={state} />

        <div className="col" style={{ gap: "0.5rem" }}>
          <div className="section-label">What this app will be able to do</div>
          <ul style={{ margin: 0, paddingLeft: "1.25rem", lineHeight: 1.6 }}>
            {scopesToShow.map((s) => (
              <li key={s}>{SCOPE_LABELS[s] ?? s}</li>
            ))}
          </ul>
        </div>

        <div className="col" style={{ gap: "0.25rem" }}>
          <span className="muted" style={{ fontSize: "0.875rem" }}>
            You can revoke this connection at any time by contacting the Sci-AI maintainers.
          </span>
          <span className="muted" style={{ fontSize: "0.875rem" }}>
            Anything you log via this connector is governed by Sci-AI&apos;s data retention policy.
          </span>
        </div>

        <div className="row" style={{ gap: "0.75rem", justifyContent: "flex-end" }}>
          <button type="submit" name="decision" value="deny" className="btn btn-secondary">
            Deny
          </button>
          <button type="submit" name="decision" value="allow" className="btn btn-primary">
            Allow
          </button>
        </div>
      </form>
    </AuthShell>
  );
}
