"use client";

import { useState } from "react";

type FieldKey = "topicMastery" | "mindMap" | "personalization" | "learningStyle" | "struggles";

const FIELDS: { key: FieldKey; label: string; hint: string }[] = [
  {
    key: "topicMastery",
    label: "Topic mastery",
    hint: 'JSON object, e.g. { "algebra": 0.7, "biology": 0.4 }',
  },
  {
    key: "mindMap",
    label: "Mind map",
    hint: 'JSON object describing nodes/edges, e.g. { "nodes": [], "edges": [] }',
  },
  {
    key: "personalization",
    label: "Personalization",
    hint: 'JSON object, e.g. { "preferred_examples": "real-world" }',
  },
  {
    key: "learningStyle",
    label: "Learning style",
    hint: 'JSON object, e.g. { "visual": 0.8, "auditory": 0.3 }',
  },
  {
    key: "struggles",
    label: "Struggles",
    hint: 'JSON object, e.g. { "algebra": ["quadratics"] }',
  },
];

export default function UpdatePage() {
  const [username, setUsername] = useState("");
  const [code, setCode] = useState("");
  const [values, setValues] = useState<Record<FieldKey, string>>({
    topicMastery: "",
    mindMap: "",
    personalization: "",
    learningStyle: "",
    struggles: "",
  });
  const [status, setStatus] = useState<
    | { kind: "idle" }
    | { kind: "submitting" }
    | { kind: "ok"; alias: string }
    | { kind: "error"; message: string }
  >({ kind: "idle" });

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStatus({ kind: "submitting" });

    const updates: Record<string, unknown> = {};
    for (const { key, label } of FIELDS) {
      const raw = values[key].trim();
      if (!raw) continue;
      try {
        const parsed = JSON.parse(raw);
        if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) {
          setStatus({ kind: "error", message: `${label} must be a JSON object (use { ... })` });
          return;
        }
        updates[key] = parsed;
      } catch {
        setStatus({ kind: "error", message: `${label} is not valid JSON` });
        return;
      }
    }

    if (Object.keys(updates).length === 0) {
      setStatus({ kind: "error", message: "Fill in at least one field." });
      return;
    }

    const res = await fetch("/api/students/update", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, code, updates }),
    });

    if (res.ok) {
      const data = (await res.json()) as { alias: string };
      setStatus({ kind: "ok", alias: data.alias });
      return;
    }

    if (res.status === 429) {
      setStatus({ kind: "error", message: "Too many attempts. Wait a few minutes." });
      return;
    }
    if (res.status === 413) {
      setStatus({ kind: "error", message: "Payload too large. Try shorter JSON." });
      return;
    }
    setStatus({ kind: "error", message: "Invalid username or code." });
  }

  return (
    <div className="col" style={{ maxWidth: 720 }}>
      <div className="screen-head">
        <div className="section-label">Learning history</div>
        <h1>Update your learning history</h1>
        <p className="lead">
          Enter your account username and the secret code your teacher gave you. The code is{" "}
          <strong>not</strong> your account password. Existing values are <em>shallow-merged</em>:
          to update a specific key, send the full object you want to persist for that field.
        </p>
      </div>

      <form onSubmit={onSubmit} className="col">
        <label className="field-label">
          <span>Username</span>
          <input
            id="username"
            type="text"
            autoComplete="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
            className="field"
          />
        </label>

        <label className="field-label">
          <span>Secret code</span>
          <input
            id="code"
            type="password"
            autoComplete="off"
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            required
            placeholder="12 characters from 23456789ABCDEFGHJKLMNPQRSTUVWXYZ"
            className="field mono"
          />
        </label>

        {FIELDS.map(({ key, label, hint }) => (
          <label key={key} className="field-label">
            <span>{label}</span>
            <p className="label" style={{ margin: "0 0 6px", textTransform: "none", letterSpacing: 0, fontSize: 11.5 }}>
              {hint}
            </p>
            <textarea
              id={key}
              rows={4}
              value={values[key]}
              onChange={(e) => setValues((v) => ({ ...v, [key]: e.target.value }))}
              className="field mono"
              style={{ fontSize: 12.5 }}
            />
          </label>
        ))}

        <div>
          <button
            type="submit"
            disabled={status.kind === "submitting"}
            className="btn primary"
            style={status.kind === "submitting" ? { opacity: 0.5 } : undefined}
          >
            {status.kind === "submitting" ? "Submitting…" : "Submit update"}
          </button>
        </div>

        {status.kind === "error" && (
          <div className="callout orange">{status.message}</div>
        )}
        {status.kind === "ok" && (
          <div className="callout green">
            Updated. View your profile at{" "}
            <a href={`/students/${status.alias}`} style={{ textDecoration: "underline" }}>
              /students/{status.alias}
            </a>
            .
          </div>
        )}
      </form>
    </div>
  );
}
