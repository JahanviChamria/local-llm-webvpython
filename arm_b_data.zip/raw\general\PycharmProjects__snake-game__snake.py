from turtle import Turtle, Screen
pos = [(0, 0), (-20, 0), (-40, 0)]
dist=20
u=90
d=270
l=180
r=0
class Snake:

    def __init__(self):
        self.segments=[]
        self.createsnake()
        self.head=self.segments[0]

    def createsnake(self):
        for position in pos:
            self.addsegment(position)


    def move(self):
        for segnum in range(len(self.segments)-1, 0, -1):
            newx=self.segments[segnum-1].xcor()
            newy = self.segments[segnum - 1].ycor()
            self.segments[segnum].goto(newx, newy)
        self.head.forward(dist)

    def up(self):
        if self.head.heading()!=d:
            self.head.setheading(u)

    def left(self):
        if self.head.heading() != r:
            self.head.setheading(l)

    def down(self):
        if self.head.heading() != u:
            self.head.setheading(d)

    def right(self):
        if self.head.heading() != l:
            self.head.setheading(r)

    def addsegment(self, position):
        a = Turtle()
        a.shape("square")
        a.color("white")
        a.penup()
        a.goto(position)
        self.segments.append(a)

    def extend(self):
        self.addsegment(self.segments[-1].position())

    def reset(self):
        for seg in self.segments:
            seg.goto(1000,1000)
        self.segments.clear()
        self.createsnake()
        self.head=self.segments[0]