import turtle

screen = turtle.Screen()
screen.bgcolor("white")

t = turtle.Turtle()
t.speed("fast")

def draw_spiral(n):
    a=0
    b=1
    for x in range(n):
        for y in range(4):
            t.forward(b)
            t.left(90)
        a=b
        b=a+b

t.penup()
t.goto(-50, -50)
t.pendown()
t.setheading(0)

n = 100
draw_spiral(n)

screen.exitonclick()
