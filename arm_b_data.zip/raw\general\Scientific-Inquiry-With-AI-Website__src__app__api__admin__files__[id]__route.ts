import { NextResponse } from "next/server";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { eq, isNotNull } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { files, fileTexts, extractionJobs, labFiles, labs, type FileRow } from "@/lib/db/schema";
import { requireAdmin, checkOrigin } from "@/lib/auth/guards";
import {
  bestEffortDelete,
  bucketFor,
  copyObject,
  deleteObject,
  headObject,
  publicUrlFor,
  R2_PUBLIC_HOST,
} from "@/lib/r2";
import { purgeUrls } from "@/lib/cloudflare-cache";
import { getBaseUrl } from "@/lib/site-url";

export const runtime = "nodejs";

const patchSchema = z.object({
  title: z.string().min(1).max(200).optional(),
  description: z.string().max(2000).nullable().optional(),
  category: z.string().max(80).nullable().optional(),
  access_level: z.enum(["public", "faculty"]).optional(),
});

// Published lab ids that have this file attached. Used to block access-level
// downgrades and deletes that would otherwise resurface a faculty-classified
// file on a public lab page. The join + isNotNull filter scopes to currently
// published labs — soft-unpublished labs don't keep the file invariant alive.
async function publishedAttachmentLabs(fileId: string): Promise<string[]> {
  const rows = await db
    .select({ labId: labs.id })
    .from(labFiles)
    .innerJoin(labs, eq(labs.id, labFiles.labId))
    .where(eq(labFiles.fileId, fileId));
  if (rows.length === 0) return [];
  const published = await db
    .select({ id: labs.id })
    .from(labs)
    .where(isNotNull(labs.moduleOrder));
  const publishedSet = new Set(published.map((r) => r.id));
  return rows.map((r) => r.labId).filter((id) => publishedSet.has(id));
}

function urlsToPurge(row: Pick<FileRow, "id" | "r2Key">): string[] {
  // Caller is responsible for only invoking this on objects that were public.
  // We purge BOTH the direct CDN URL and the Vercel /api/files/.../download redirect.
  return [publicUrlFor(row.r2Key), `${getBaseUrl()}/api/files/${row.id}/download`];
}

// Demote public → faculty: copy public→private, delete from public, purge cache,
// drop file_texts. Cache purge is load-bearing — without it the public-bucket
// edge cache keeps serving the now-private bytes until TTL.
async function demoteToFaculty(row: FileRow): Promise<void> {
  if (!R2_PUBLIC_HOST) throw new Error("public bucket not configured");

  await copyObject({
    srcBucket: bucketFor("public"),
    dstBucket: bucketFor("faculty"),
    key: row.r2Key,
    contentType: row.contentType,
  });
  // Confirm the copy landed before we delete the original or touch the cache.
  const head = await headObject(bucketFor("faculty"), row.r2Key);
  if (head.contentLength !== row.sizeBytes) {
    throw new Error(
      `private-bucket copy size mismatch: expected ${row.sizeBytes}, got ${head.contentLength}`,
    );
  }

  // Fatal (not best-effort): if this delete fails, the object stays in
  // sciai-public and the CDN keeps serving a now-faculty-classified file.
  // Throwing aborts the flip before the DB is updated, so the row stays
  // public and the bytes stay where the classification says.
  await deleteObject(bucketFor("public"), row.r2Key);

  // Mandatory: purge Cloudflare edge cache for both the public R2 URL and the
  // Vercel /api/files/.../download redirect. If purge fails we abort and the
  // caller surfaces the error — leaving a still-cached public object behind is
  // the worst outcome of a flip.
  await purgeUrls(urlsToPurge(row));

  await db.transaction(async (tx) => {
    await tx.delete(fileTexts).where(eq(fileTexts.fileId, row.id));
    await tx.delete(extractionJobs).where(eq(extractionJobs.fileId, row.id));
    await tx.update(files).set({ accessLevel: "faculty" }).where(eq(files.id, row.id));
  });

  revalidatePath(`/files/${row.id}`);
}

// Promote faculty → public: copy private→public, delete from private,
// enqueue extraction. No cache purge needed — the public URL didn't exist yet.
async function promoteToPublic(row: FileRow): Promise<void> {
  if (!R2_PUBLIC_HOST) throw new Error("public bucket not configured");

  await copyObject({
    srcBucket: bucketFor("faculty"),
    dstBucket: bucketFor("public"),
    key: row.r2Key,
    contentType: row.contentType,
  });
  const head = await headObject(bucketFor("public"), row.r2Key);
  if (head.contentLength !== row.sizeBytes) {
    throw new Error(
      `public-bucket copy size mismatch: expected ${row.sizeBytes}, got ${head.contentLength}`,
    );
  }

  await bestEffortDelete(bucketFor("faculty"), row.r2Key);

  await db.transaction(async (tx) => {
    await tx.update(files).set({ accessLevel: "public" }).where(eq(files.id, row.id));
    await tx
      .insert(extractionJobs)
      .values({ fileId: row.id, status: "pending" })
      .onConflictDoUpdate({
        target: extractionJobs.fileId,
        set: { status: "pending", enqueuedAt: new Date(), finishedAt: null, error: null },
      });
  });

  revalidatePath(`/files/${row.id}`);
}

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const csrf = checkOrigin(req);
  if (csrf) return csrf;
  const g = await requireAdmin();
  if (g instanceof NextResponse) return g;

  const { id } = await ctx.params;
  let body: z.infer<typeof patchSchema>;
  try {
    body = patchSchema.parse(await req.json());
  } catch (err) {
    return NextResponse.json({ error: "invalid body", detail: String(err) }, { status: 400 });
  }

  const existing = (await db.select().from(files).where(eq(files.id, id)).limit(1))[0];
  if (!existing) return NextResponse.json({ error: "not found" }, { status: 404 });

  // Handle access_level flip first — it touches buckets, cache, and other tables.
  // Only attempt for ready files; pending files haven't been uploaded yet.
  if (body.access_level !== undefined && body.access_level !== existing.accessLevel) {
    if (existing.status !== "ready") {
      return NextResponse.json(
        { error: "cannot flip access_level on a pending upload" },
        { status: 409 },
      );
    }
    // Downgrade guard: a file attached to any published lab cannot be flipped
    // to faculty-only — that would either 403 student downloads or, depending
    // on the download path, leak a faculty document. Promotion (faculty → public)
    // is always allowed.
    if (body.access_level === "faculty") {
      const attachedLabIds = await publishedAttachmentLabs(id);
      if (attachedLabIds.length > 0) {
        return NextResponse.json(
          {
            error: "file_attached_to_published_labs",
            detail:
              "Detach this file from the listed labs (or unpublish them) before downgrading to faculty.",
            labIds: attachedLabIds,
          },
          { status: 409 },
        );
      }
    }
    try {
      if (body.access_level === "faculty") {
        await demoteToFaculty(existing);
      } else {
        await promoteToPublic(existing);
      }
    } catch (err) {
      return NextResponse.json(
        {
          error: "access_level flip failed; row left unchanged",
          detail: err instanceof Error ? err.message : String(err),
        },
        { status: 500 },
      );
    }
  }

  // Apply other field updates (title/description/category) after the flip.
  const updates: Partial<typeof files.$inferInsert> = {};
  if (body.title !== undefined) updates.title = body.title;
  if (body.description !== undefined) updates.description = body.description ?? null;
  if (body.category !== undefined) updates.category = body.category ?? null;

  if (Object.keys(updates).length > 0) {
    await db.update(files).set(updates).where(eq(files.id, id));
    revalidatePath(`/files/${id}`);
  }

  const updated = (await db.select().from(files).where(eq(files.id, id)).limit(1))[0];
  return NextResponse.json({ file: updated });
}

export async function DELETE(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const csrf = checkOrigin(req);
  if (csrf) return csrf;
  const g = await requireAdmin();
  if (g instanceof NextResponse) return g;

  const { id } = await ctx.params;

  // Delete guard: refuse to delete a file that is attached to any published lab.
  // A hard delete would cascade through lab_files, leaving the lab module with
  // a missing PDF. The admin must detach (or unpublish the lab) first.
  const attachedLabIds = await publishedAttachmentLabs(id);
  if (attachedLabIds.length > 0) {
    return NextResponse.json(
      {
        error: "file_attached_to_published_labs",
        detail:
          "Detach this file from the listed labs (or unpublish them) before deleting it.",
        labIds: attachedLabIds,
      },
      { status: 409 },
    );
  }

  // DB first — establish "file is gone" before touching R2 so even if R2/cache
  // ops fail the UI is consistent. ON DELETE CASCADE cleans up file_texts +
  // extraction_jobs automatically.
  const deleted = await db
    .delete(files)
    .where(eq(files.id, id))
    .returning({ r2Key: files.r2Key, accessLevel: files.accessLevel });
  if (deleted.length === 0) return NextResponse.json({ error: "not found" }, { status: 404 });

  const row = deleted[0];
  await bestEffortDelete(bucketFor(row.accessLevel), row.r2Key);

  // If it was public, the bytes might be sitting in Cloudflare's cache —
  // purge before declaring the delete done.
  if (row.accessLevel === "public" && R2_PUBLIC_HOST) {
    try {
      await purgeUrls([
        publicUrlFor(row.r2Key),
        `${getBaseUrl()}/api/files/${id}/download`,
      ]);
    } catch (err) {
      console.error("[delete] cache purge failed; object deleted but cache may be stale", {
        id,
        err: err instanceof Error ? err.message : String(err),
      });
      return NextResponse.json(
        {
          ok: true,
          warning: "cache_purge_failed",
          detail: err instanceof Error ? err.message : String(err),
        },
        { status: 200 },
      );
    }
  }

  revalidatePath(`/files/${id}`);
  return NextResponse.json({ ok: true });
}
