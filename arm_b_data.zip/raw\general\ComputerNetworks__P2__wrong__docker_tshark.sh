#!/bin/bash

docker exec --tty --interactive ${USER}_bind \
    tshark -Odns udp and port 53
