import Link from "next/link";
import { getCurrentUser } from "@/lib/auth/session";
import { LogoutButton } from "@/components/logout-button";
import { Av } from "@/components/portal/primitives";
import { BrandLogo } from "@/components/brand-logo";

export default async function PracticeLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser();
  const initials = user
    ? (user.displayName ?? user.username).slice(0, 2).toUpperCase()
    : "";
  const roleLabel = user ? user.role.charAt(0).toUpperCase() + user.role.slice(1) : "";

  return (
    <div className="portal-root">
      <div className="app">
        <aside className="sidebar">
          <div className="brand">
            <BrandLogo href="/" />
            <div className="ver">PHYS 021 · UC Merced</div>
          </div>

          <div style={{ display: "contents" }}>
            <div className="nav-group">Retrieval</div>
            <Link href="/students/practice" className="nav-item">
              <span className="grow">All labs</span>
            </Link>
          </div>

          <div style={{ display: "contents" }}>
            <div className="nav-group">You</div>
            <Link href="/portal" className="nav-item">
              <span className="grow">Portal</span>
            </Link>
          </div>

          <div className="nav-spacer" />

          {user ? (
            <>
              <div className="side-user">
                <Av initials={initials} sm />
                <div>
                  <div style={{ fontSize: 13, fontWeight: 500 }}>
                    {user.displayName ?? user.username}
                  </div>
                  <div className="label">{roleLabel}</div>
                </div>
              </div>
              <div style={{ padding: "0 10px" }}>
                <LogoutButton />
              </div>
            </>
          ) : (
            <Link
              href="/login"
              className="btn primary"
              style={{ justifyContent: "center", margin: "0 10px" }}
            >
              Sign in
            </Link>
          )}
        </aside>

        <main className="main">
          <div className="screen">{children}</div>
        </main>
      </div>
    </div>
  );
}
