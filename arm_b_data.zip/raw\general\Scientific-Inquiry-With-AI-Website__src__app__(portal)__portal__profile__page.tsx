import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
import { getStudentProfile } from "@/lib/portal/profile";
import { getAccessibleLabs } from "@/lib/portal/accessible-labs";
import { ProfileSection } from "@/components/portal/profile-section";
import { ProfileImportButton } from "@/components/portal/profile-import-button";
import { ProfileExportButton } from "@/components/portal/profile-export-button";

export const dynamic = "force-dynamic";

export default async function ProfileScreen() {
  // The (portal) layout already redirects anonymous → /login, so user is never
  // null here. The cast is for the type system, not runtime safety.
  const user = (await getCurrentUser())!;
  // Prelab progress is a student self-view; staff view their students' via the
  // Prelab progress student-histories page instead.
  if (user.role === "admin" || user.role === "faculty") {
    redirect("/portal/history");
  }
  const [profile, labs] = await Promise.all([
    getStudentProfile(user.id),
    getAccessibleLabs(user.id),
  ]);

  return (
    <div className="col" style={{ maxWidth: 820 }}>
      <div className="screen-head">
        <div className="section-label">You</div>
        <h1>Prelab progress</h1>
        <p className="lead muted">
          What the AI tutor knows about how you study. Private — only you see this
          page. The same data also renders at{" "}
          <code className="mono">/students/{profile?.alias ?? "p_…"}</code> if you
          choose to share that link.
        </p>
      </div>

      <ProfileImportButton />

      <ProfileSection
        profile={profile}
        labs={labs}
        emptyMessage={
          <>
            <strong>Profile not initialized.</strong> Ask faculty to enable your
            learning history. Once it&apos;s enabled, writes from the AI tutor
            will start landing here.
          </>
        }
      />

      {profile && (
        <ProfileExportButton
          alias={profile.alias}
          data={{
            topicMastery: profile.topicMastery,
            mindMap: profile.mindMap,
            personalization: profile.personalization,
            learningStyle: profile.learningStyle,
            struggles: profile.struggles,
          }}
        />
      )}
    </div>
  );
}
