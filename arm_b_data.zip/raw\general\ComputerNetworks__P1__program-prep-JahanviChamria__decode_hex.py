#!/usr/bin/python3

import sys

def main():
    for line in sys.stdin:
        raw_hex = line.strip()
        raw_ascii = bytearray.fromhex(raw_hex).decode()
        pretty_ascii = repr(raw_ascii)
        print(pretty_ascii)

if __name__ == '__main__':
    main()
