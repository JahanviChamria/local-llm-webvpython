import logging
from apscheduler.schedulers.blocking import BlockingScheduler
from apscheduler.triggers.cron import CronTrigger
import pytz

import config
from scraper import load_watchlist
from watchlist_updater import update_watchlist
from spread_math import run_all_spreads
from database import save_scan_results
from alerts import send_alert

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")

DEFAULT_FILTERS = {
    "min_otm_pct": 0.0,
    "max_dte": 30,
    "min_net_credit": 0.10,
    "min_return_on_margin": 0.1,
    "max_short_delta": -0.05,
}
EXCLUDE_EARNINGS = True

SCAN_TIMES = [
    ("10", "00"),
    ("12", "00"),
    ("15", "15"),
]


def run_scan():
    logger.info("=== Scheduled scan starting ===")
    logger.info("Refreshing watchlist with top 50 by volume")
    update_watchlist(50)
    tickers = load_watchlist()
    if not tickers:
        logger.warning("Watchlist is empty, skipping scan")
        return

    logger.info(f"Scraping {len(tickers)} tickers")
    from scraper import scrape_ticker
    chain_data = {}
    for ticker in tickers:
        try:
            df = scrape_ticker(ticker, DEFAULT_FILTERS["max_dte"])
            if df is not None:
                chain_data[ticker] = df
        except Exception as e:
            logger.error(f"{ticker}: {e}")

    results = run_all_spreads(chain_data, **DEFAULT_FILTERS)

    if EXCLUDE_EARNINGS and not results.empty and "earnings_risk" in results.columns:
        results = results[~results["earnings_risk"]].reset_index(drop=True)

    if not results.empty:
        save_scan_results(results)
        logger.info(f"Scan complete: {len(results)} opportunities found")
        send_alert(results, config.ALERT_EMAIL)
    else:
        logger.info("Scan complete: no opportunities found")


def start():
    et = pytz.timezone("America/New_York")
    scheduler = BlockingScheduler(timezone=et)

    for hour, minute in SCAN_TIMES:
        scheduler.add_job(
            run_scan,
            CronTrigger(day_of_week="mon-fri", hour=int(hour), minute=int(minute), timezone=et),
        )
        logger.info(f"Scheduled scan at {hour}:{minute} ET (weekdays)")

    logger.info("Scheduler running — waiting for next scan")
    scheduler.start()


if __name__ == "__main__":
    start()
