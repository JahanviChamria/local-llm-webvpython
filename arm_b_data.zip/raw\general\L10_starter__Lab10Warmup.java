


public class Lab10Warmup {
 
     //Reverses the bottommost count elements on the argument Stack
     //If an invalid count is provided, this function does nothing
     //Ex: if myStack contains (bottom to top):  {7, 8, 1, 3, 19, 4, 12}
     //    after calling reverseTopElements(myStack, 4),
     //    myStack now contains (bottom to top): {3, 1, 8, 7, 19, 4, 12}
     //
     //***FOR THIS FUNCTION, YOU MAY NOT CREATE ANY NON-PRIMITIVE VARIABLES
     //   BESIDES LabStack and LabQueue OBJECTS (NO ARRAYLISTS, ARRAYS, ETC)***
     public static void reverseBottomElements(LabStack<Integer> stack, int count){
          if(!stack.isEmpty()){
               if(count<0||count>stack.size()){
                    return;
               }
               LabStack<Integer> stackRev=new LabStack<>();
               int len=stack.size();
               for(int i=0;i<len-count;i++){    //elements to be left unmodified
                    stackRev.push(stack.pop());
               }
               LabStack<Integer> stackRevCount=new LabStack<>();
               for(int i=0;i<count;i++){        //bottommost count elements
                    stackRevCount.push(stack.pop());
               }
               LabStack<Integer> stackRevCountTemp=new LabStack<>();
               for(int i=0;i<count;i++){        //reversing order again
                    stackRevCountTemp.push(stackRevCount.pop());
               }
               for(int i=0;i<count;i++){        //pushing bottom count elements in the reversed order
                    stack.push(stackRevCountTemp.pop());
               }
               for(int i=0;i<len-count;i++){    //pushing the unmodified elements back
                    stack.push(stackRev.pop());
               }
          }
     }
     

     //Inserts all of Q2s elements into Q1 at index idx.
     //Q2 must be in its original state after the function is ran.
     //If idx is invalid, this function does nothing. 
     //Ex: if q1 = {a -> b -> c -> d -> e} and q2 = {x -> y -> z}
     //    after calling insertAllAtIndex(q1, q2, 3)
     //    q1 = {a -> b -> c -> x -> y -> z -> d -> e} and q2 = {x -> y -> z}
     //    
     //***FOR THIS FUNCTION, YOU MAY NOT CREATE ANY NON-PRIMITIVE VARIABLES
     //   BESIDES invidual Strings (NO String arrays, Stacks, Queues, ETC )***
     public static void insertAllAtIndex(LabQueue<String> q1, LabQueue<String> q2, int idx){
          if(!(idx<0||idx>q1.size())){
               int q1Size=q1.size();
               int q2Size=q2.size();
               String temp="";
               for (int i=0;i<idx;i++){
                    q1.enqueue(q1.dequeue());
               }
               for (int i=0;i<q2Size;i++){
                    temp=q2.dequeue();
                    q1.enqueue(temp);
                    q2.enqueue(temp);        //ensure q2 remains unchanged
               }
               for (int i=idx;i<q1Size;i++) {
                    q1.enqueue(q1.dequeue());
               }
          }
     }
     
     
     
}

