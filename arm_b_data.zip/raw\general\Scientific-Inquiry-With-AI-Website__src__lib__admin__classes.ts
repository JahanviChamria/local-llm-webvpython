import { and, asc, desc, eq, inArray, isNull, sql } from "drizzle-orm";
import { db } from "@/lib/db/client";
import {
  classes,
  classEnrollments,
  classLabs,
  labs,
  users,
} from "@/lib/db/schema";
import { cascadeDeenrollment } from "@/lib/mcp/lifecycle";

export class ClassNotFoundError extends Error {
  constructor() {
    super("class not found");
  }
}

export class StudentNotFoundError extends Error {
  constructor() {
    super("student not found");
  }
}

export class StudentAmbiguousError extends Error {
  candidates: { id: string; username: string }[];
  constructor(candidates: { id: string; username: string }[]) {
    super("identifier matches multiple students");
    this.candidates = candidates;
  }
}

export class AlreadyEnrolledError extends Error {
  constructor() {
    super("student already enrolled in this class");
  }
}

export class ClassNotArchivedError extends Error {
  constructor() {
    super("class must be archived before hard delete");
  }
}

export type ClassSummary = {
  id: string;
  name: string;
  archivedAt: Date | null;
  studentCount: number;
  labCount: number;
  createdAt: Date;
};

export async function listClassesForOwner(
  ownerId: string,
  { includeArchived = false }: { includeArchived?: boolean } = {},
): Promise<ClassSummary[]> {
  const conditions = [eq(classes.ownerId, ownerId)];
  if (!includeArchived) conditions.push(isNull(classes.archivedAt));

  const rows = await db
    .select({
      id: classes.id,
      name: classes.name,
      archivedAt: classes.archivedAt,
      createdAt: classes.createdAt,
      // NB: alias the inner table and reference classes.id explicitly. Drizzle
      // renders ${classes.id} inside a sql`` template as an unqualified "id",
      // which then binds to class_enrollments.id (this table has its own id
      // column) instead of the outer classes.id — making the count always 0.
      studentCount: sql<number>`(select count(*) from class_enrollments ce where ce.class_id = classes.id)`,
      labCount: sql<number>`(select count(*) from class_labs cl where cl.class_id = classes.id)`,
    })
    .from(classes)
    .where(and(...conditions))
    .orderBy(desc(classes.createdAt));

  return rows.map((r) => ({
    id: r.id,
    name: r.name,
    archivedAt: r.archivedAt,
    createdAt: r.createdAt,
    studentCount: Number(r.studentCount),
    labCount: Number(r.labCount),
  }));
}

export type ClassDetail = {
  id: string;
  name: string;
  archivedAt: Date | null;
  createdAt: Date;
  ownerId: string;
  students: {
    userId: string;
    username: string;
    displayName: string | null;
    email: string | null;
    enrolledAt: Date;
  }[];
  labs: {
    labId: string;
    name: string;
    moduleOrder: number | null;
    orderIndex: number;
    isLocked: boolean;
  }[];
};

export async function getClassForOwner(
  classId: string,
  ownerId: string,
): Promise<ClassDetail> {
  const [classRow] = await db
    .select()
    .from(classes)
    .where(and(eq(classes.id, classId), eq(classes.ownerId, ownerId)))
    .limit(1);
  if (!classRow) throw new ClassNotFoundError();

  const students = await db
    .select({
      userId: users.id,
      username: users.username,
      displayName: users.displayName,
      email: users.email,
      enrolledAt: classEnrollments.enrolledAt,
    })
    .from(classEnrollments)
    .innerJoin(users, eq(users.id, classEnrollments.userId))
    .where(eq(classEnrollments.classId, classId))
    .orderBy(asc(users.username));

  const labRows = await db
    .select({
      labId: labs.id,
      name: labs.name,
      moduleOrder: labs.moduleOrder,
      orderIndex: classLabs.orderIndex,
      isLocked: classLabs.isLocked,
    })
    .from(classLabs)
    .innerJoin(labs, eq(labs.id, classLabs.labId))
    .where(eq(classLabs.classId, classId))
    .orderBy(asc(classLabs.orderIndex));

  return {
    id: classRow.id,
    name: classRow.name,
    archivedAt: classRow.archivedAt,
    createdAt: classRow.createdAt,
    ownerId: classRow.ownerId,
    students,
    labs: labRows,
  };
}

export async function createClass(
  ownerId: string,
  { name, labIds }: { name: string; labIds: string[] },
): Promise<{ id: string }> {
  return db.transaction(async (tx) => {
    const [row] = await tx
      .insert(classes)
      .values({ name, ownerId })
      .returning({ id: classes.id });

    const uniqueLabIds = Array.from(new Set(labIds));
    if (uniqueLabIds.length > 0) {
      // Validate the referenced labs exist
      const found = await tx
        .select({ id: labs.id })
        .from(labs)
        .where(inArray(labs.id, uniqueLabIds));
      if (found.length !== uniqueLabIds.length) {
        throw new Error("one or more lab ids are invalid");
      }
      await tx
        .insert(classLabs)
        .values(
          uniqueLabIds.map((labId, i) => ({
            classId: row.id,
            labId,
            orderIndex: i + 1,
          })),
        );
    }
    return { id: row.id };
  });
}

export async function updateClassName(
  classId: string,
  ownerId: string,
  name: string,
): Promise<void> {
  const result = await db
    .update(classes)
    .set({ name, updatedAt: new Date() })
    .where(and(eq(classes.id, classId), eq(classes.ownerId, ownerId)))
    .returning({ id: classes.id });
  if (result.length === 0) throw new ClassNotFoundError();
}

export async function setClassLabs(
  classId: string,
  ownerId: string,
  labIds: string[],
): Promise<void> {
  await db.transaction(async (tx) => {
    // FOR UPDATE on the parent class row serialises with reorderClassLabs and other
    // setClassLabs calls touching the same class — the validating read and the writes
    // below all happen under one lock, eliminating the TOCTOU window on the
    // (class_id, order_index) set.
    const [classRow] = await tx
      .select({ id: classes.id })
      .from(classes)
      .where(and(eq(classes.id, classId), eq(classes.ownerId, ownerId)))
      .for("update")
      .limit(1);
    if (!classRow) throw new ClassNotFoundError();

    const desired = Array.from(new Set(labIds));
    if (desired.length > 0) {
      const found = await tx
        .select({ id: labs.id })
        .from(labs)
        .where(inArray(labs.id, desired));
      if (found.length !== desired.length) {
        throw new Error("one or more lab ids are invalid");
      }
    }

    const existing = await tx
      .select({ labId: classLabs.labId, orderIndex: classLabs.orderIndex })
      .from(classLabs)
      .where(eq(classLabs.classId, classId));
    const existingSet = new Set(existing.map((r) => r.labId));
    const desiredSet = new Set(desired);

    const toAdd = desired.filter((id) => !existingSet.has(id));
    const toRemove = [...existingSet].filter((id) => !desiredSet.has(id));

    if (toRemove.length > 0) {
      await tx
        .delete(classLabs)
        .where(
          and(eq(classLabs.classId, classId), inArray(classLabs.labId, toRemove)),
        );
    }
    if (toAdd.length > 0) {
      // Append new assignments after the current max. Compute once, then assign
      // max+1, max+2, ... so a single PATCH adding multiple labs at once doesn't
      // hand them all the same index.
      const currentMax = existing.reduce(
        (m, r) => (r.orderIndex > m ? r.orderIndex : m),
        0,
      );
      await tx.insert(classLabs).values(
        toAdd.map((labId, i) => ({
          classId,
          labId,
          orderIndex: currentMax + i + 1,
        })),
      );
    }

    // Renormalise to 1..N when removals leave gaps. The deferred unique constraint
    // absorbs the transient overlap between the existing values and the new ones.
    if (toRemove.length > 0) {
      await tx.execute(sql`
        WITH ranked AS (
          SELECT id, row_number() OVER (ORDER BY order_index) AS rn
          FROM class_labs WHERE class_id = ${classId}
        )
        UPDATE class_labs cl
        SET order_index = ranked.rn
        FROM ranked
        WHERE cl.id = ranked.id
      `);
    }

    await tx
      .update(classes)
      .set({ updatedAt: new Date() })
      .where(eq(classes.id, classId));
  });
}

// Rewrites the per-class lab order to exactly the supplied permutation. Strict:
// the input must be a permutation of currently-assigned lab ids (no adds, no
// removals, no duplicates). Use setClassLabs for add/remove.
export async function reorderClassLabs(
  classId: string,
  ownerId: string,
  orderedLabIds: string[],
): Promise<void> {
  if (new Set(orderedLabIds).size !== orderedLabIds.length) {
    throw new Error("orderedLabIds contains duplicates");
  }
  await db.transaction(async (tx) => {
    const [classRow] = await tx
      .select({ id: classes.id })
      .from(classes)
      .where(and(eq(classes.id, classId), eq(classes.ownerId, ownerId)))
      .for("update")
      .limit(1);
    if (!classRow) throw new ClassNotFoundError();

    // Read after lock — no other writer can mutate this set until COMMIT.
    const existing = await tx
      .select({ labId: classLabs.labId })
      .from(classLabs)
      .where(eq(classLabs.classId, classId));
    const existingSet = new Set(existing.map((r) => r.labId));

    if (orderedLabIds.length !== existingSet.size) {
      throw new Error("orderedLabIds must include every assigned lab exactly once");
    }
    for (const id of orderedLabIds) {
      if (!existingSet.has(id)) {
        throw new Error(`${id} is not assigned to this class`);
      }
    }

    // Multi-row UPDATEs would briefly violate the unique constraint, but the
    // constraint is DEFERRABLE INITIALLY DEFERRED — Postgres only checks at COMMIT.
    for (let i = 0; i < orderedLabIds.length; i++) {
      await tx
        .update(classLabs)
        .set({ orderIndex: i + 1 })
        .where(
          and(eq(classLabs.classId, classId), eq(classLabs.labId, orderedLabIds[i])),
        );
    }

    await tx
      .update(classes)
      .set({ updatedAt: new Date() })
      .where(eq(classes.id, classId));
  });
}

export async function setClassLabLocked(
  classId: string,
  ownerId: string,
  labId: string,
  locked: boolean,
): Promise<void> {
  // Single-row UPDATE joined to the ownership check. No need for the parent lock —
  // is_locked is independent of order_index. Zero affected rows means either the
  // class isn't owned by this user or the lab isn't assigned; surface the same
  // ClassNotFoundError so callers don't need to distinguish.
  const result = await db
    .update(classLabs)
    .set({ isLocked: locked })
    .where(
      and(
        eq(classLabs.labId, labId),
        eq(
          classLabs.classId,
          sql`(SELECT id FROM ${classes} WHERE id = ${classId} AND owner_id = ${ownerId})`,
        ),
      ),
    )
    .returning({ id: classLabs.id });
  if (result.length === 0) throw new ClassNotFoundError();
}

// Looks up a student by exact username OR email. Two separate queries so we can detect
// the rare case where username-match and email-match resolve to different student users
// and surface that as ambiguous instead of silently picking one.
export async function addStudentToClass(
  classId: string,
  ownerId: string,
  usernameOrEmail: string,
): Promise<{
  userId: string;
  username: string;
  displayName: string | null;
  email: string | null;
  enrolledAt: Date;
}> {
  const identifier = usernameOrEmail.trim();
  if (identifier.length === 0) throw new StudentNotFoundError();

  const [classRow] = await db
    .select({ id: classes.id })
    .from(classes)
    .where(and(eq(classes.id, classId), eq(classes.ownerId, ownerId)))
    .limit(1);
  if (!classRow) throw new ClassNotFoundError();

  // Select the same fields the roster renders so the caller can append an
  // accurate row optimistically, not just the username.
  const cols = {
    id: users.id,
    username: users.username,
    displayName: users.displayName,
    email: users.email,
  };
  const byUsername = await db
    .select(cols)
    .from(users)
    .where(and(eq(users.username, identifier), eq(users.role, "student")))
    .limit(1);
  const byEmail = await db
    .select(cols)
    .from(users)
    .where(and(eq(users.email, identifier), eq(users.role, "student")))
    .limit(1);

  const candidates: {
    id: string;
    username: string;
    displayName: string | null;
    email: string | null;
  }[] = [];
  if (byUsername[0]) candidates.push(byUsername[0]);
  if (byEmail[0] && byEmail[0].id !== byUsername[0]?.id) candidates.push(byEmail[0]);

  if (candidates.length === 0) throw new StudentNotFoundError();
  if (candidates.length > 1) {
    throw new StudentAmbiguousError(
      candidates.map((c) => ({ id: c.id, username: c.username })),
    );
  }

  const target = candidates[0];
  let enrolledAt: Date;
  try {
    const [row] = await db
      .insert(classEnrollments)
      .values({ classId, userId: target.id })
      .returning({ enrolledAt: classEnrollments.enrolledAt });
    enrolledAt = row.enrolledAt;
  } catch (err) {
    const e = err as { code?: string };
    if (e?.code === "23505") throw new AlreadyEnrolledError();
    throw err;
  }
  return {
    userId: target.id,
    username: target.username,
    displayName: target.displayName,
    email: target.email,
    enrolledAt,
  };
}

export async function removeStudentFromClass(
  classId: string,
  ownerId: string,
  userId: string,
): Promise<void> {
  // Owner check first so we don't leak existence of enrollments across classes
  const [classRow] = await db
    .select({ id: classes.id })
    .from(classes)
    .where(and(eq(classes.id, classId), eq(classes.ownerId, ownerId)))
    .limit(1);
  if (!classRow) throw new ClassNotFoundError();

  await db
    .delete(classEnrollments)
    .where(
      and(eq(classEnrollments.classId, classId), eq(classEnrollments.userId, userId)),
    );

  // FERPA: the educational relationship for THIS student in THIS class just
  // ended. Drop the AI-derived study content scoped to that pair. SRS rows
  // are not touched (those are first-party platform data the student created
  // directly, not AI-host content).
  await cascadeDeenrollment(userId, classId).catch((err) => {
    console.error(
      `[admin/removeStudentFromClass] cascadeDeenrollment failed for user=${userId} class=${classId}:`,
      err,
    );
  });
}

export async function archiveClass(classId: string, ownerId: string): Promise<void> {
  const result = await db
    .update(classes)
    .set({ archivedAt: new Date(), updatedAt: new Date() })
    .where(
      and(
        eq(classes.id, classId),
        eq(classes.ownerId, ownerId),
        isNull(classes.archivedAt),
      ),
    )
    .returning({ id: classes.id });
  if (result.length === 0) throw new ClassNotFoundError();
}

export async function unarchiveClass(classId: string, ownerId: string): Promise<void> {
  const result = await db
    .update(classes)
    .set({ archivedAt: null, updatedAt: new Date() })
    .where(and(eq(classes.id, classId), eq(classes.ownerId, ownerId)))
    .returning({ id: classes.id });
  if (result.length === 0) throw new ClassNotFoundError();
}

export async function hardDeleteClass(
  classId: string,
  ownerId: string,
): Promise<void> {
  const [classRow] = await db
    .select({ id: classes.id, archivedAt: classes.archivedAt })
    .from(classes)
    .where(and(eq(classes.id, classId), eq(classes.ownerId, ownerId)))
    .limit(1);
  if (!classRow) throw new ClassNotFoundError();
  if (classRow.archivedAt === null) throw new ClassNotArchivedError();

  // FERPA: every enrolled student's AI-derived content for this class needs
  // to go too. classEnrollments cascades on the class delete (FK), so collect
  // the userIds BEFORE the delete then drop their summaries scoped to this
  // class. Done before the class delete so the join still works.
  const enrolled = await getEnrolledUserIds(classId);
  for (const userId of enrolled) {
    await cascadeDeenrollment(userId, classId).catch((err) => {
      console.error(
        `[admin/hardDeleteClass] cascadeDeenrollment failed for user=${userId} class=${classId}:`,
        err,
      );
    });
  }

  // Cascade removes class_enrollments and class_labs. SRS history not touched.
  await db.delete(classes).where(eq(classes.id, classId));
}

export async function countClassesOwnedBy(userId: string): Promise<{
  classIds: string[];
}> {
  const rows = await db
    .select({ id: classes.id })
    .from(classes)
    .where(eq(classes.ownerId, userId));
  return { classIds: rows.map((r) => r.id) };
}

// Internal helper used by lib/admin/history.ts to load the enrolled user ids for a
// class the caller already owns. Owner check is performed before calling this.
export async function getEnrolledUserIds(classId: string): Promise<string[]> {
  const rows = await db
    .select({ userId: classEnrollments.userId })
    .from(classEnrollments)
    .where(eq(classEnrollments.classId, classId));
  return rows.map((r) => r.userId);
}

export async function getClassNameById(classId: string): Promise<string | null> {
  const [row] = await db
    .select({ name: classes.name })
    .from(classes)
    .where(eq(classes.id, classId))
    .limit(1);
  return row?.name ?? null;
}

