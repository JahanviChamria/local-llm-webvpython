import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";

export const dynamic = "force-dynamic";

type Tool = { href: string; title: string; desc: string; adminOnly?: boolean };

const TOOLS: Tool[] = [
  { href: "/admin/classes", title: "Classes", desc: "Group your students into classes and assign them labs. Each class shows only its assigned labs in the student sidebar." },
  { href: "/admin/files", title: "Files & materials", desc: "Upload, set access, and delete prelab documents and resources." },
  { href: "/admin/labs", title: "Labs", desc: "Build the lab modules students see in the sidebar: prelab + postlab docs, practice, simulation.", adminOnly: true },
  { href: "/admin/questions", title: "Retrieval Tool Questions", desc: "Author the retrieval-practice questions that seed student queues." },
  { href: "/admin/labs/import", title: "Import question bank", desc: "Drop a JSON bank file + figures to bulk-create families, variants, and figures." },
  { href: "/portal/history", title: "Prelab progress", desc: "Browse any student's prelab progress — the AI profile (topic mastery, mind map, personalization, learning style, struggles)." },
  { href: "/admin/all-classes", title: "All classes (admin)", desc: "Every class across all faculty. Use this view to transfer class ownership when a faculty member leaves.", adminOnly: true },
  { href: "/admin/users", title: "Users", desc: "Create admin/faculty accounts, change roles, reset passwords.", adminOnly: true },
];

export default async function AdminHomePage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/admin");
  if (user.role !== "admin" && user.role !== "faculty") {
    return (
      <div className="col">
        <div className="screen-head">
          <div className="section-label">Restricted</div>
          <h1>Not available</h1>
        </div>
        <div className="callout orange">
          <strong>Faculty and admins only.</strong> Your account doesn&apos;t have access to course tools.
        </div>
      </div>
    );
  }

  const tools = TOOLS.filter((t) => !t.adminOnly || user.role === "admin");

  return (
    <div className="col">
      <div className="screen-head">
        <div className="section-label">{user.role === "admin" ? "Admin" : "Teaching"}</div>
        <h1>Course tools</h1>
        <p className="lead muted">Publish materials and questions, and manage students from one place.</p>
      </div>

      <div className="grid g2">
        {tools.map((t) => (
          <Link key={t.href} href={t.href} className="info-card" style={{ textDecoration: "none" }}>
            <div className="ic-top" style={{ background: "var(--green)" }} />
            <div className="ic-title">{t.title} ↗</div>
            <div className="ic-body">{t.desc}</div>
          </Link>
        ))}
      </div>
    </div>
  );
}
