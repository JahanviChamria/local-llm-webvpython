// Shared write-side helpers for the file-based lab sections, used by both the
// create (POST /api/admin/labs) and update (PATCH /api/admin/labs/[id]) routes.

import { NextResponse } from "next/server";
import { inArray } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { files } from "@/lib/db/schema";
import { LAB_DOC_SECTIONS, type LabDocKind, type LabUploadKind } from "@/lib/portal/lab-sections";
import { isVideoMime } from "@/lib/file-types";

export function uploadTypeOk(contentType: string, upload: LabUploadKind): boolean {
  if (upload === "video") return isVideoMime(contentType);
  if (upload === "markdown") {
    return contentType === "text/markdown" || contentType === "text/plain";
  }
  return contentType === "application/pdf";
}

function uploadTypeError(upload: LabUploadKind, facultyOnly: boolean): string {
  const access = facultyOnly ? "private (faculty)" : "public";
  if (upload === "video") {
    return `Only ready ${access} video files can be attached to the video tutorial.`;
  }
  if (upload === "markdown") {
    return `Only ready ${access} Markdown/text files (.md/.txt) can be attached to this section.`;
  }
  return `Only ready ${access} PDFs can be attached to this section.`;
}

// Validates every file about to be attached: ready, content type matching the
// section's upload family (PDF, or video for the tutorial), and the right access
// level — faculty-only sections (instructor guide, lesson plan, answer key)
// require a private file; every other section requires a public one. Batch-loads
// once to keep round-trips flat.
export async function validateLabFileEligibility(
  entries: { id: string; upload: LabUploadKind; facultyOnly: boolean }[],
): Promise<NextResponse | null> {
  if (entries.length === 0) return null;
  const ids = entries.map((e) => e.id);
  const rows = await db
    .select({
      id: files.id,
      status: files.status,
      accessLevel: files.accessLevel,
      contentType: files.contentType,
    })
    .from(files)
    .where(inArray(files.id, ids));
  const found = new Map(rows.map((r) => [r.id, r]));
  for (const { id, upload, facultyOnly } of entries) {
    const f = found.get(id);
    if (!f) {
      return NextResponse.json(
        { error: "invalid_file", detail: `file ${id} not found` },
        { status: 400 },
      );
    }
    const requiredAccess = facultyOnly ? "faculty" : "public";
    if (
      f.status !== "ready" ||
      f.accessLevel !== requiredAccess ||
      !uploadTypeOk(f.contentType, upload)
    ) {
      return NextResponse.json(
        {
          error: "ineligible_file",
          detail: uploadTypeError(upload, facultyOnly),
          fileId: id,
        },
        { status: 400 },
      );
    }
  }
  return null;
}

// A file may only belong to one kind per lab (unique lab_id, file_id). Returns
// the offending id, or null if there are no cross-kind duplicates.
export function findCrossKindDuplicate(kindIds: Record<LabDocKind, string[]>): string | null {
  const seen = new Set<string>();
  for (const s of LAB_DOC_SECTIONS) {
    for (const id of kindIds[s.kind]) {
      if (seen.has(id)) return id;
      seen.add(id);
    }
  }
  return null;
}
