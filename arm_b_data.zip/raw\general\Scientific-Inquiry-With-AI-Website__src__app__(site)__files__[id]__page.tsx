import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { files, fileTexts } from "@/lib/db/schema";
import { getBaseUrl } from "@/lib/site-url";
import { Card } from "@/components/portal/primitives";

export const revalidate = 3600;

type Params = { id: string };

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

async function loadPublicFile(id: string) {
  if (!UUID_RE.test(id)) return null;
  const row = (
    await db
      .select({
        id: files.id,
        title: files.title,
        description: files.description,
        category: files.category,
        filename: files.filename,
        sizeBytes: files.sizeBytes,
        contentType: files.contentType,
        uploadedAt: files.uploadedAt,
        extractedText: fileTexts.extractedText,
      })
      .from(files)
      .leftJoin(fileTexts, eq(fileTexts.fileId, files.id))
      .where(
        and(
          eq(files.id, id),
          eq(files.status, "ready"),
          eq(files.accessLevel, "public"),
        ),
      )
      .limit(1)
  )[0];
  return row ?? null;
}

function formatSize(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

export async function generateMetadata({
  params,
}: {
  params: Promise<Params>;
}): Promise<Metadata> {
  const { id } = await params;
  const row = await loadPublicFile(id);
  if (!row) return { title: "File not found" };

  const description = row.description ?? `Course material: ${row.title}.`;
  const url = `${getBaseUrl()}/files/${row.id}`;

  return {
    title: row.title,
    description,
    alternates: { canonical: url },
    openGraph: {
      type: "article",
      url,
      title: row.title,
      description,
    },
    twitter: {
      card: "summary",
      title: row.title,
      description,
    },
  };
}

export default async function FilePage({
  params,
}: {
  params: Promise<Params>;
}) {
  const { id } = await params;
  const row = await loadPublicFile(id);
  if (!row) notFound();

  const base = getBaseUrl();
  const downloadUrl = `${base}/api/files/${row.id}/download`;
  const uploadedAtIso =
    typeof row.uploadedAt === "string"
      ? row.uploadedAt
      : row.uploadedAt.toISOString();

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": ["LearningResource", "DigitalDocument"],
    name: row.title,
    description: row.description ?? undefined,
    encodingFormat: row.contentType,
    contentUrl: downloadUrl,
    datePublished: uploadedAtIso,
    learningResourceType: row.category ?? undefined,
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <div
        className="col"
        style={{ maxWidth: 760, margin: "0 auto" }}
      >
        <div className="screen-head">
          <div className="section-label">{row.category ?? "Course material"}</div>
          <h1>{row.title}</h1>
          {row.description && <p className="lead muted">{row.description}</p>}
        </div>

        <Card title="Details">
          <div className="grid g2">
            <div className="col" style={{ gap: 4 }}>
              <div className="label">Filename</div>
              <div className="mono" style={{ fontSize: 13 }}>{row.filename}</div>
            </div>
            <div className="col" style={{ gap: 4 }}>
              <div className="label">Size</div>
              <div style={{ fontSize: 13 }}>{formatSize(row.sizeBytes)}</div>
            </div>
            <div className="col" style={{ gap: 4 }}>
              <div className="label">Type</div>
              <div className="mono" style={{ fontSize: 13 }}>{row.contentType}</div>
            </div>
            <div className="col" style={{ gap: 4 }}>
              <div className="label">Published</div>
              <div style={{ fontSize: 13 }}>
                <time dateTime={uploadedAtIso}>
                  {new Date(uploadedAtIso).toLocaleDateString()}
                </time>
              </div>
            </div>
          </div>
        </Card>

        <div>
          <a className="btn primary" href={downloadUrl}>
            ↓ Download
          </a>
        </div>

        {row.extractedText && (
          <Card title="Extracted text">
            <pre
              className="mono"
              style={{
                fontSize: 12.5,
                lineHeight: 1.55,
                maxHeight: "60vh",
                overflow: "auto",
                whiteSpace: "pre-wrap",
                wordBreak: "break-word",
                background: "var(--surface)",
                border: "1px solid var(--border)",
                borderRadius: "var(--radius-sm)",
                padding: 14,
                color: "var(--ink)",
              }}
            >
              {row.extractedText}
            </pre>
          </Card>
        )}
      </div>
    </>
  );
}
