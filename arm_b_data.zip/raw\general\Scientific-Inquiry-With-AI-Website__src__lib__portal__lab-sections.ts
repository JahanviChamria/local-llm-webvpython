// Single source of truth for the file-based lab sections (the "has a …?"
// toggles on a lab). Each is backed by a boolean column on `labs`, a value in
// the lab_file_kind enum, and one or more attached files. Adding a new section
// = one entry here plus the matching schema column + enum value.
//
// prelab/postlab predate this registry but are included so the data layer,
// admin form, and create/update routes can iterate over every kind uniformly.

import type { NavIcoName } from "@/components/portal/primitives";

export const LAB_DOC_KINDS = [
  "prelab",
  "postlab",
  "activity",
  "analysis_guide",
  "video_tutorial",
  "research_paper",
  "student_guide",
  "self_check",
  "ai_grading_prompt",
  "instructor_guide",
  "lesson_plan",
  "self_check_answer_key",
] as const;

export type LabDocKind = (typeof LAB_DOC_KINDS)[number];

export type LabHasFlag =
  | "hasPrelab"
  | "hasPostlab"
  | "hasActivity"
  | "hasAnalysisGuide"
  | "hasVideoTutorial"
  | "hasResearchPaper"
  | "hasStudentGuide"
  | "hasSelfCheck"
  | "hasAiGradingPrompt"
  | "hasInstructorGuide"
  | "hasLessonPlan"
  | "hasSelfCheckAnswerKey";

// Which upload MIME family a section accepts. "pdf" mirrors the original
// prelab/postlab rule; "video" is for the video tutorial; "markdown" is for the
// AI grading prompt (.md/.txt).
export type LabUploadKind = "pdf" | "video" | "markdown";

export type LabDocSectionMeta = {
  kind: LabDocKind;
  hasFlag: LabHasFlag;
  // Key used in both the admin FormState and the create/update API bodies.
  bodyKey:
    | "prelabFileIds"
    | "postlabFileIds"
    | "activityFileIds"
    | "analysisGuideFileIds"
    | "videoTutorialFileIds"
    | "researchPaperFileIds"
    | "studentGuideFileIds"
    | "selfCheckFileIds"
    | "aiGradingPromptFileIds"
    | "instructorGuideFileIds"
    | "lessonPlanFileIds"
    | "selfCheckAnswerKeyFileIds";
  // Key used in the admin GET response + client LabRow (attached file objects).
  filesKey:
    | "prelabFiles"
    | "postlabFiles"
    | "activityFiles"
    | "analysisGuideFiles"
    | "videoTutorialFiles"
    | "researchPaperFiles"
    | "studentGuideFiles"
    | "selfCheckFiles"
    | "aiGradingPromptFiles"
    | "instructorGuideFiles"
    | "lessonPlanFiles"
    | "selfCheckAnswerKeyFiles";
  title: string; // "Analysis guide"
  formLabel: string; // "This lab has an analysis guide"
  routeSegment: string; // url segment under a lab, e.g. "analysis-guide"
  topTag: string; // landing card corner tag
  icon: NavIcoName;
  upload: LabUploadKind;
  // When true, the student sub-page offers Download only (no in-browser View),
  // and `instructions` (if set) renders as a callout above the file list. Used
  // by the AI grading prompt, which students feed to their chatbot rather than
  // read on screen.
  downloadOnly?: boolean;
  instructions?: string;
  // Instructor-only material (instructor guide, lesson plan, self-check answer
  // key). When true: the landing card and sub-page render only for faculty/admin
  // (never students or guests), and attached files must be private (faculty
  // access level) rather than public. Students never see the card, and the
  // download route already 401s non-faculty on the file itself.
  facultyOnly?: boolean;
};

export const LAB_DOC_SECTIONS: readonly LabDocSectionMeta[] = [
  {
    kind: "prelab",
    hasFlag: "hasPrelab",
    bodyKey: "prelabFileIds",
    filesKey: "prelabFiles",
    title: "Prelab",
    formLabel: "This lab has a prelab",
    routeSegment: "prelab",
    topTag: "READ FIRST",
    icon: "doc",
    upload: "pdf",
  },
  {
    kind: "postlab",
    hasFlag: "hasPostlab",
    bodyKey: "postlabFileIds",
    filesKey: "postlabFiles",
    title: "Postlab",
    formLabel: "This lab has a postlab",
    routeSegment: "postlab",
    topTag: "SELF-CHECK",
    icon: "progress",
    upload: "pdf",
  },
  {
    kind: "activity",
    hasFlag: "hasActivity",
    bodyKey: "activityFileIds",
    filesKey: "activityFiles",
    title: "Activity",
    formLabel: "This lab has an activity",
    routeSegment: "activity",
    topTag: "HANDS-ON",
    icon: "flask",
    upload: "pdf",
  },
  {
    kind: "analysis_guide",
    hasFlag: "hasAnalysisGuide",
    bodyKey: "analysisGuideFileIds",
    filesKey: "analysisGuideFiles",
    title: "Analysis guide",
    formLabel: "This lab has an analysis guide",
    routeSegment: "analysis-guide",
    topTag: "ANALYSIS",
    icon: "layers",
    upload: "pdf",
  },
  {
    kind: "video_tutorial",
    hasFlag: "hasVideoTutorial",
    bodyKey: "videoTutorialFileIds",
    filesKey: "videoTutorialFiles",
    title: "Video tutorial",
    formLabel: "This lab has a video tutorial",
    routeSegment: "video-tutorial",
    topTag: "WATCH",
    icon: "monitor",
    upload: "video",
  },
  {
    kind: "research_paper",
    hasFlag: "hasResearchPaper",
    bodyKey: "researchPaperFileIds",
    filesKey: "researchPaperFiles",
    title: "Research paper",
    formLabel: "This lab has a research paper",
    routeSegment: "research-paper",
    topTag: "READING",
    icon: "folder",
    upload: "pdf",
  },
  {
    kind: "student_guide",
    hasFlag: "hasStudentGuide",
    bodyKey: "studentGuideFileIds",
    filesKey: "studentGuideFiles",
    title: "Student guide",
    formLabel: "This lab has a student guide",
    routeSegment: "student-guide",
    topTag: "GUIDE",
    icon: "profile",
    upload: "pdf",
  },
  {
    kind: "self_check",
    hasFlag: "hasSelfCheck",
    bodyKey: "selfCheckFileIds",
    filesKey: "selfCheckFiles",
    title: "Self check",
    formLabel: "This lab has a self check",
    routeSegment: "self-check",
    topTag: "CHECK",
    icon: "question",
    upload: "pdf",
  },
  {
    kind: "ai_grading_prompt",
    hasFlag: "hasAiGradingPrompt",
    bodyKey: "aiGradingPromptFileIds",
    filesKey: "aiGradingPromptFiles",
    title: "AI grading prompt",
    formLabel: "This lab has an AI grading prompt",
    routeSegment: "ai-grading-prompt",
    topTag: "SELF-GRADE",
    icon: "brain",
    upload: "markdown",
    downloadOnly: true,
    instructions:
      "Download this grading prompt, then upload it to your AI chatbot together " +
      "with your completed self-check analysis document and ask it to grade your work.",
  },
  {
    kind: "instructor_guide",
    hasFlag: "hasInstructorGuide",
    bodyKey: "instructorGuideFileIds",
    filesKey: "instructorGuideFiles",
    title: "Instructor guide",
    formLabel: "This lab has an instructor guide",
    routeSegment: "instructor-guide",
    topTag: "INSTRUCTOR",
    icon: "instructor",
    upload: "pdf",
    facultyOnly: true,
  },
  {
    kind: "lesson_plan",
    hasFlag: "hasLessonPlan",
    bodyKey: "lessonPlanFileIds",
    filesKey: "lessonPlanFiles",
    title: "Lesson plan",
    formLabel: "This lab has a lesson plan",
    routeSegment: "lesson-plan",
    topTag: "LESSON PLAN",
    icon: "schedule",
    upload: "pdf",
    facultyOnly: true,
  },
  {
    kind: "self_check_answer_key",
    hasFlag: "hasSelfCheckAnswerKey",
    bodyKey: "selfCheckAnswerKeyFileIds",
    filesKey: "selfCheckAnswerKeyFiles",
    title: "Self check answer key",
    formLabel: "This lab has a self-check answer key",
    routeSegment: "self-check-answer-key",
    topTag: "ANSWER KEY",
    icon: "dashboard",
    upload: "pdf",
    facultyOnly: true,
  },
] as const;

export const LAB_DOC_SECTION_BY_KIND: Record<LabDocKind, LabDocSectionMeta> =
  Object.fromEntries(LAB_DOC_SECTIONS.map((s) => [s.kind, s])) as Record<
    LabDocKind,
    LabDocSectionMeta
  >;

// The newer sections — used where prelab/postlab already have bespoke wiring and
// only the new ones need generic handling (routes, landing cards).
export const NEW_LAB_DOC_SECTIONS = LAB_DOC_SECTIONS.filter(
  (s) => s.kind !== "prelab" && s.kind !== "postlab",
);

// Instructor-only sections: their cards/pages are faculty/admin-gated and their
// files must be private. `self_check_answer_key` was previously a file-only
// category; it's now a full faculty section with its own card and sub-page.
export const FACULTY_ONLY_KINDS: ReadonlySet<LabDocKind> = new Set(
  LAB_DOC_SECTIONS.filter((s) => s.facultyOnly).map((s) => s.kind),
);

// Extra file-upload categories that are NOT lab sections: teacher/grading
// materials that populate the admin file-category dropdown but have no student
// landing card, sub-page, or schema column. Titles are the stored category
// string. Combined with LAB_DOC_SECTIONS titles to build the dropdown.
export const FILE_ONLY_CATEGORIES = [] as const;

// Every selectable file-upload category, in dropdown order: the lab-section
// titles followed by the file-only categories.
export const FILE_CATEGORY_OPTIONS: readonly string[] = [
  ...LAB_DOC_SECTIONS.map((s) => s.title),
  ...FILE_ONLY_CATEGORIES,
];
