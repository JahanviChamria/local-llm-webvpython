"use client";

import { useEffect, useState } from "react";

/** Self-reported lab-document completion toggle ("Mark done"). Keyed on lab_file_id so
 * the same PDF attached to two labs tracks completion independently per placement. */
export function LabDocumentMarkDone({
  labFileId,
  initialDone,
}: {
  labFileId: string;
  initialDone: boolean;
}) {
  const [done, setDone] = useState(initialDone);
  const [busy, setBusy] = useState(false);

  async function toggle() {
    const next = !done;
    setBusy(true);
    try {
      const res = await fetch("/api/portal/lab-document/complete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ labFileId, done: next }),
      });
      if (res.ok) setDone(next);
    } finally {
      setBusy(false);
    }
  }

  return (
    <button
      type="button"
      className={"btn sm " + (done ? "complete" : "ghost")}
      onClick={toggle}
      disabled={busy}
      aria-pressed={done}
    >
      {done ? "✓ Done" : "Mark done"}
    </button>
  );
}

/** Self-reported simulation completion toggle. Scoped per (student, lab, sim) so a sim
 * attached to two labs tracks completion independently. Loads current state on mount. */
export function SimComplete({ simId, labId }: { simId: string; labId: string }) {
  const [done, setDone] = useState<boolean | null>(null);
  const [busy, setBusy] = useState(false);
  const [needAuth, setNeedAuth] = useState(false);

  useEffect(() => {
    let active = true;
    const qs = new URLSearchParams({ sim: simId, lab: labId }).toString();
    fetch(`/api/portal/simulation/complete?${qs}`)
      .then((r) => r.json())
      .then((d) => active && setDone(!!d.done))
      .catch(() => active && setDone(false));
    return () => {
      active = false;
    };
  }, [simId, labId]);

  async function toggle() {
    if (done === null) return;
    const next = !done;
    setBusy(true);
    try {
      const res = await fetch("/api/portal/simulation/complete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ simId, labId, done: next }),
      });
      if (res.status === 401) {
        setNeedAuth(true);
        return;
      }
      if (res.ok) setDone(next);
    } finally {
      setBusy(false);
    }
  }

  if (needAuth) {
    return <span className="light" style={{ fontSize: 11.5 }}>Sign in to track completion.</span>;
  }

  return (
    <button
      type="button"
      className={"btn sm " + (done ? "complete" : "primary")}
      onClick={toggle}
      disabled={busy || done === null}
      aria-pressed={!!done}
      // Sized to content instead of stretching the full width of the .col container.
      style={{ alignSelf: "flex-start" }}
    >
      {done ? "✓ Completed" : "Mark as complete"}
    </button>
  );
}
