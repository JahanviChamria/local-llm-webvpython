import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Scanner;

//************************************************************************************
//*                                                                                  *
//*                    YOU ARE NOT ALLOWED TO MODIFY THIS CLASS                      *
//*                                                                                  *
//************************************************************************************

public class SpeedReadingTrainer extends JComponent implements ActionListener, KeyListener {      
     
     //Dimension of SRT window
     private static final int FRAME_WIDTH = 800;
     private static final int FRAME_HEIGHT = 200;
     //Minmum words-per-minute
     private static final int MIN_WPM = 60;
     //Size t display words in the widnow
     private static final int FONT_SIZE = 52;
          
     //Seconds and ms per Minute
     //Used in timing calculations for WPM
     private static final int SEC_PER_MIN = 60; 
     private static final int MS_PER_MIN = SEC_PER_MIN * 1000;

     //string length thresholds for how the focus index is determined 
     private static final int[] FOCUS_INDEX_THRESHOLDS = {1, 5, 9, 13};     
     
     //Current word being displayed
     private String currentWord;
     //Tracks if "autorun" mode is currently enabled (true) or not (false)
     private boolean autorun = false;  
     //Font to display words (must be monospaced)   
     private Font font;  
     
     //Iterator which cycles through the provided file's words
     private WordBank words;
     //Graphical window
     private JFrame window;
     //Current WPM
     private int wpm;
     


     public SpeedReadingTrainer(String fname, int wpm) {
          words = new WordBank(readFile(fname));
          currentWord = words.nextWord();
          this.wpm = Math.max(wpm, MIN_WPM);
          // Needs to be a Monospace font
          font = new Font("Courier", Font.BOLD, FONT_SIZE); //What is this hard-coded 42?  Check the API
     }
     


     private void initWindow(){
          window = new JFrame("Speed Reading Trainer");
          window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);          
          window.setSize(FRAME_WIDTH, FRAME_HEIGHT);
          window.add(this);
          wpm = Math.max(wpm, MIN_WPM);

          //Fix Windows listener bug(?)
          this.setFocusable(true);
          //window.requestFocus();
          this.requestFocusInWindow();
          
          this.setOpaque(true);
          window.setVisible(true);
          window.setResizable(false);            
     }


     private void initListenersAndTimers(){          
          int inBwWordDelay = delay(wpm); 
          //Instantiation of our timer
          //http://docs.oracle.com/javase/7/docs/api/javax/swing/Timer.html
          //'this' tells the timer to use the actionPerformed declared in SpeedReadingTrainer
          Timer timer = new Timer(0, this);      
          timer.setDelay(inBwWordDelay);
          timer.start();

          addKeyListener(this);
     }     


     //returns the millisecond value corresponding to words/minute
     public static int delay(int wpm) {
          return MS_PER_MIN / wpm; 
     }
     

     //Reacts to keys on the keyboard being pressed
     public void keyPressed(KeyEvent ae) {   
          //Quit the SpeedReadingTrainer
          if (ae.getKeyCode()==KeyEvent.VK_ESCAPE) 
               System.exit(0);
          else if (ae.getKeyCode()==KeyEvent.VK_SPACE)
               autorun = !autorun; //toggle autorun mode     
          else if (ae.getKeyCode()==KeyEvent.VK_R){
               words.reset();//reset back to the start of the file
               currentWord = words.nextWord();               
          }
          //Manually advancing through words only works when autorun is disabled
          else if (!autorun){
               if (ae.getKeyCode()==KeyEvent.VK_RIGHT) { 
                    String next = words.nextWord();
                    if (next != null) //ensure there's a next word to retrieve
                         currentWord = next;
               }
               else if (ae.getKeyCode()==KeyEvent.VK_LEFT) { //... or space
                    String prev = words.prevWord();
                    if (prev != null)
                         currentWord = prev;
               }  
          }
          repaint();
     }

     
     /**
      * Paints the elements on our window
      */
     @Override
     protected void paintComponent(Graphics g) {
          super.paintComponent(g);

          //if file hasn't been parsed yet, don't try to paint a word.
          if (currentWord == null)
               return;
          Graphics2D g2d = (Graphics2D)g;
          g2d.setFont(font);          
          
          //repaint background to clear the window each time
          g2d.setColor(Color.YELLOW);    
          g2d.fillRect(0, 0, getWidth(), getHeight()); 

          
          //First, draw the centered, "focus" charactger
          g2d.setColor(Color.RED);      
          int focusIdx = getFocusIndex(currentWord);
          String focusChar = currentWord.substring(focusIdx, focusIdx + 1);
          
          //The class FontMetrics and the methods used below are useful for your positioning
          //http://docs.oracle.com/javase/7/docs/api/java/awt/FontMetrics.html
          FontMetrics metrics = g2d.getFontMetrics();
          int focusWidth = metrics.stringWidth(focusChar);
          g2d.drawString(focusChar, (getWidth() / 2) - (focusWidth / 2), getHeight() / 2 );
          

          //...then, draw the left and righ t"black" halves of the String
          g2d.setColor(Color.BLACK);
          String left = currentWord.substring(0, focusIdx);
          int leftWidth = metrics.stringWidth(left);
          g2d.drawString(left, (getWidth() / 2) - (focusWidth / 2) - leftWidth, getHeight() / 2 );
          g2d.drawString(currentWord.substring(focusIdx + 1), (getWidth() / 2) + (focusWidth / 2), getHeight() / 2 );
          
          g2d.dispose();
     }
     
     
     /**
      * Handles Timer events 
      * this method gets called automatically every time the timer "ticks"
      * See the instantiation of the timer / Java API to see the frequency at which
      * the timer "ticks"
      */
     public void actionPerformed(ActionEvent ae) {
          if (autorun){ 
               String next = words.nextWord();
               if (next != null){
                    currentWord = next;
                    repaint();
               }
          }
     }
     
     
     //Reads the file with the argument name; returns a Queue of the words
     //out of the file in order.  If file can't be opened, kills the program.
     private LabQueue<String> readFile(String fname){
          LabQueue<String> toReturn = new LabQueue<String>();
          try{
               Scanner scan = new Scanner(new File(fname));
               
               while (scan.hasNext())
                    toReturn.enqueue(scan.next());   
               
               scan.close();            
          }
          catch (FileNotFoundException fnfe){
               System.err.println("Error!  Could not open file: " + fname + "... exiting Speed Reading Trainer!");
               System.exit(1);
          }
          return toReturn;
     }
     

     //Determine the "focus index" (ie the centered, red character) for the 
     //argument String (determined per the String's length)
     private static int getFocusIndex(String word){
          int i;
          for (i = 0; i < FOCUS_INDEX_THRESHOLDS.length; i++){
               if (word.length() <= FOCUS_INDEX_THRESHOLDS[i])
                    return i;                              
          }
          return i;                                 
     }        

     public void launchTrainer(){
          initWindow();
          initListenersAndTimers();
          repaint();
     }



     public void keyReleased(KeyEvent e) {}    

     public void keyTyped(KeyEvent e) {}    
     
}

