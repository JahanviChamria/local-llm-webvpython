import { Card } from "@/components/portal/primitives";
import { CommonMistakesSummaryButton } from "@/components/portal/common-mistakes-summary-button";
import type { CommonMistakesReport } from "@/lib/portal/common-mistakes";

// Server-rendered compilation of class-wide common mistakes, with the AI-summary
// button embedded at the bottom. `classId` is passed through to the button so
// faculty summaries stay scoped to the class being viewed (admins omit it).
export function CommonMistakesSection({
  report,
  classId,
}: {
  report: CommonMistakesReport;
  classId?: string;
}) {
  const hasData =
    report.missedQuestions.length > 0 ||
    report.weakLabs.length > 0 ||
    report.struggleThemes.length > 0;

  return (
    <Card
      title="Common mistakes"
      label={`${report.studentsInScope} student${report.studentsInScope === 1 ? "" : "s"} · shared by ≥2`}
    >
      {!hasData ? (
        <p className="muted" style={{ fontSize: 13, margin: 0 }}>
          No shared mistakes yet. Once several students practice retrieval or the AI
          tutor records struggles, patterns faced by multiple students appear here.
        </p>
      ) : (
        <div className="col" style={{ gap: 18 }}>
          {report.missedQuestions.length > 0 && (
            <div>
              <div className="label" style={{ marginBottom: 8 }}>
                Most-missed questions
              </div>
              <div className="col" style={{ gap: 10 }}>
                {report.missedQuestions.map((q) => (
                  <div key={q.questionId}>
                    <div style={{ fontSize: 13.5, lineHeight: 1.5 }}>{q.prompt}</div>
                    <div className="muted" style={{ fontSize: 12, marginTop: 2 }}>
                      {q.studentsAffected} student{q.studentsAffected === 1 ? "" : "s"}
                      {" · "}
                      {q.totalMisses} miss{q.totalMisses === 1 ? "" : "es"}
                      {q.labName ? ` · ${q.labName}` : ""}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {report.weakLabs.length > 0 && (
            <div>
              <div className="label" style={{ marginBottom: 8 }}>
                Labs with the highest miss rates
              </div>
              <div className="col" style={{ gap: 6 }}>
                {report.weakLabs.map((l) => (
                  <div
                    key={l.labId}
                    className="row"
                    style={{ gap: 10, alignItems: "baseline", fontSize: 13.5 }}
                  >
                    <span style={{ flex: "1 1 auto" }}>{l.name}</span>
                    <span style={{ color: "var(--orange)", fontWeight: 600 }}>
                      {l.missRate}% missed
                    </span>
                    <span className="muted" style={{ fontSize: 12 }}>
                      {l.studentsStruggling} struggling
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {report.struggleThemes.length > 0 && (
            <div>
              <div className="label" style={{ marginBottom: 8 }}>
                Recurring struggle notes
              </div>
              <ul style={{ margin: 0, paddingLeft: 18, fontSize: 13, lineHeight: 1.5 }}>
                {report.struggleThemes.map((t, i) => (
                  <li key={i}>
                    {t.text}{" "}
                    <span className="muted" style={{ fontSize: 12 }}>
                      · {t.studentsAffected} students
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      <div style={{ marginTop: 18, borderTop: "1px solid var(--border)", paddingTop: 16 }}>
        <div className="label" style={{ marginBottom: 8 }}>
          AI summary
        </div>
        {hasData ? (
          <CommonMistakesSummaryButton classId={classId} />
        ) : (
          <p className="muted" style={{ fontSize: 12.5, margin: 0 }}>
            Available once there is shared data to summarize.
          </p>
        )}
      </div>
    </Card>
  );
}
