from dotenv import load_dotenv
import os

load_dotenv()

def _secret(key: str, default: str = "") -> str:
    try:
        import streamlit as st
        return st.secrets.get(key, os.getenv(key, default))
    except Exception:
        return os.getenv(key, default)

RESEND_API_KEY = _secret("RESEND_API_KEY")
ALERT_EMAIL = _secret("ALERT_EMAIL")
SCHEDULER_TIME = os.getenv("SCHEDULER_TIME", "08:30")
