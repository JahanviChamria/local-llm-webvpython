/* Non-interactive portal widgets ported from the design handoff. */

/**
 * Activity heatmap. Pass `data` (one count per day, oldest → newest, length
 * weeks*7) to render real activity; intensity is normalized to the busiest day.
 * Without `data` it falls back to a decorative pattern.
 */
export function ActivityHeat({ weeks = 5, data }: { weeks?: number; data?: number[] }) {
  const max = data && data.length ? Math.max(1, ...data) : 1;
  return (
    <div className="col" style={{ gap: 4 }}>
      {Array.from({ length: weeks }).map((_, r) => (
        <div className="row" style={{ gap: 4 }} key={r}>
          {Array.from({ length: 7 }).map((_, c) => {
            const seed = r * 7 + c;
            let lvl: number;
            if (data) {
              const v = data[seed] ?? 0;
              lvl = v === 0 ? 0 : 0.25 + 0.75 * (v / max);
            } else {
              lvl = seed % 5 === 0 ? 0 : seed % 3 === 0 ? 0.25 : seed % 2 === 0 ? 0.55 : 0.9;
            }
            return (
              <div
                key={c}
                style={{
                  flex: 1,
                  aspectRatio: "1",
                  borderRadius: 4,
                  border: "1px solid var(--border)",
                  background: lvl ? `color-mix(in srgb, var(--green) ${lvl * 100}%, var(--canvas))` : "var(--canvas)",
                }}
              />
            );
          })}
        </div>
      ))}
    </div>
  );
}

export function BounceSVG() {
  return (
    <svg width="440" height="210" viewBox="0 0 440 210" style={{ maxWidth: "100%" }}>
      {/* floor */}
      <line x1="20" y1="178" x2="420" y2="178" stroke="#d8d5cd" strokeWidth="1.5" />
      {/* decaying bounce trajectory */}
      <path
        d="M40,24 Q70,110 100,178 Q140,46 196,178 Q232,96 282,178 Q308,128 346,178 Q364,152 392,178"
        fill="none"
        stroke="#a0a09a"
        strokeWidth="1.5"
        strokeDasharray="4 3"
      />
      {/* peak markers */}
      <circle cx="148" cy="74" r="2.5" fill="#a0a09a" />
      <circle cx="257" cy="120" r="2.5" fill="#a0a09a" />
      {/* ball at first rebound apex */}
      <circle cx="148" cy="74" r="9" fill="#1a8a5a" />
      {/* velocity arrow */}
      <line x1="148" y1="74" x2="170" y2="58" stroke="#0F6E56" strokeWidth="1.5" strokeDasharray="3 2" />
      <polygon points="170,58 162,59 166,65" fill="#0F6E56" />
      {/* labels */}
      <text x="58" y="20" fontSize="11" fill="#6b6b65" fontFamily="DM Sans, sans-serif">
        drop 1.00 m
      </text>
      <text x="118" y="92" fontSize="11" fill="#0F6E56" fontFamily="DM Sans, sans-serif">
        0.56 m
      </text>
      <text x="232" y="138" fontSize="11" fill="#a0a09a" fontFamily="DM Sans, sans-serif">
        0.31 m
      </text>
      <text x="300" y="200" fontSize="10" fill="#a0a09a" fontFamily="Courier New, monospace">
        e = 0.75 · happy ball
      </text>
    </svg>
  );
}
