import streamlit as st
import pandas as pd
import json
import subprocess
from pathlib import Path

from scraper import load_watchlist
from spread_math import run_all_spreads
from database import save_scan_results, load_scan_history
from alerts import send_alert
from watchlist_updater import update_watchlist
import watchlists as wl
import config

WATCHLIST_PATH = Path("watchlist.txt")
CONFIG_PATH = Path("scan_config.json")


def load_scan_config() -> dict:
    if CONFIG_PATH.exists():
        return json.loads(CONFIG_PATH.read_text())
    return {
        "min_otm_pct": 0.0,
        "max_dte": 30,
        "min_net_credit": 0.10,
        "min_return_on_margin": 0.1,
        "max_short_delta": -0.05,
        "exclude_earnings": True,
    }


def _git_persist(paths: list[str], message: str):
    """Commit + push the given paths so changes survive Streamlit Cloud reboots."""
    try:
        subprocess.run(["git", "add", *paths], check=True, capture_output=True)
        subprocess.run(["git", "commit", "-m", message], check=True, capture_output=True)
        subprocess.run(["git", "push"], check=True, capture_output=True)
    except Exception:
        pass  # local saves still work even if git push fails


def save_scan_config(cfg: dict):
    CONFIG_PATH.write_text(json.dumps(cfg, indent=2))
    # Push to GitHub so Actions picks up the new settings
    _git_persist(["scan_config.json"], "Update scan settings from dashboard")


cfg = load_scan_config()

st.set_page_config(page_title="Bull Put Scanner", layout="wide", initial_sidebar_state="expanded")
st.title("Bull Put Spread Scanner")

# ── Sidebar ──────────────────────────────────────────────────────────────────
with st.sidebar:
    st.header("Watchlist")
    if st.button("Auto-fill Top 50 by Volume"):
        with st.spinner("Fetching top 50 tickers…"):
            tickers = update_watchlist(50)
        if tickers:
            st.success(f"Watchlist updated: {len(tickers)} tickers")
            st.rerun()
        else:
            st.error("Failed to fetch tickers")
    raw_watchlist = WATCHLIST_PATH.read_text() if WATCHLIST_PATH.exists() else ""
    edited = st.text_area("One ticker per line", value=raw_watchlist, height=150)
    if st.button("Save Watchlist"):
        WATCHLIST_PATH.write_text(edited)
        st.success("Saved")

    st.subheader("Saved Lists")
    list_name = st.text_input("Name this list", key="wl_name", placeholder="e.g. Top 100, Next 100")
    if st.button("Save as named list"):
        saved = wl.save(list_name, edited)
        if saved:
            _git_persist([f"watchlists/{saved}.txt"], f"Save watchlist '{saved}'")
            st.success(f"Saved list '{list_name}' (persisted)")
            st.rerun()
        else:
            st.warning("Enter a valid name first")

    saved_lists = wl.list_saved()
    if saved_lists:
        chosen_list = st.selectbox("Load a saved list", options=["—"] + saved_lists, key="wl_load")
        c1, c2 = st.columns(2)
        if c1.button("Load") and chosen_list != "—":
            WATCHLIST_PATH.write_text(wl.load(chosen_list))
            st.success(f"Loaded '{chosen_list}'")
            st.rerun()
        if c2.button("Delete") and chosen_list != "—":
            wl.delete(chosen_list)
            _git_persist(["watchlists"], f"Delete watchlist '{chosen_list}'")
            st.rerun()

    st.header("Filters")
    st.caption("Changes here also update the scheduled email scans.")
    min_otm_pct = st.slider("Min % OTM", 0, 60, int(cfg["min_otm_pct"]))
    max_dte = st.slider("Max DTE", 1, 30, int(cfg["max_dte"]))
    min_net_credit = st.number_input("Min Net Credit ($)", min_value=0.0, max_value=2.00, value=float(cfg["min_net_credit"]), step=0.01)
    min_rom = st.number_input("Min Return on Margin (%)", min_value=0.0, value=float(cfg["min_return_on_margin"]), step=0.1)
    max_short_delta = st.number_input(
        "Max Short-Put Delta",
        min_value=-1.000, max_value=0.000,
        value=float(cfg.get("max_short_delta", -0.05)),
        step=0.001, format="%.3f",
        help="Put deltas are negative; closer to 0 = safer. -0.05 keeps trades with ≥95% chance of expiring OTM.",
    )
    exclude_earnings = st.toggle(
        "Hide trades with earnings before expiration",
        value=bool(cfg.get("exclude_earnings", True)),
        help="A trade is flagged when its expiration is on/after the next earnings date.",
    )

    if st.button("Save Filters (also updates scheduled scans)"):
        cfg.update({
            "min_otm_pct": min_otm_pct,
            "max_dte": max_dte,
            "min_net_credit": min_net_credit,
            "min_return_on_margin": min_rom,
            "max_short_delta": max_short_delta,
            "exclude_earnings": exclude_earnings,
        })
        save_scan_config(cfg)
        st.success("Saved — next scheduled scan will use these filters")

    st.header("Actions")
    run_scan = st.button("Run Scan", type="primary")


# ── Session state ─────────────────────────────────────────────────────────────
if "results" not in st.session_state:
    st.session_state.results = pd.DataFrame()
if "chain_data" not in st.session_state:
    st.session_state.chain_data = {}

# ── Run scan ──────────────────────────────────────────────────────────────────
if run_scan:
    tickers = load_watchlist()
    if not tickers:
        st.sidebar.error("Watchlist is empty.")
    else:
        progress = st.progress(0, text="Starting scan…")
        chain_data = {}
        from scraper import scrape_ticker
        for i, ticker in enumerate(tickers):
            progress.progress(i / len(tickers), text=f"Scraping {ticker} ({i+1}/{len(tickers)})…")
            try:
                df = scrape_ticker(ticker, max_dte)
                if df is not None:
                    chain_data[ticker] = df
            except Exception:
                pass
        progress.progress(1.0, text="Running spread math…")
        st.session_state.chain_data = chain_data

        results = run_all_spreads(
            chain_data,
            min_otm_pct=min_otm_pct,
            max_dte=max_dte,
            min_net_credit=min_net_credit,
            min_return_on_margin=min_rom,
            max_short_delta=max_short_delta,
        )
        st.session_state.results = results
        progress.empty()

        if not results.empty:
            save_scan_results(results)

# ── Tabs ──────────────────────────────────────────────────────────────────────
tab1, tab2, tab3, tab4 = st.tabs(["Live Results", "Full Chains", "Scan History", "Settings"])

# ── Tab 1: Live Results ───────────────────────────────────────────────────────
with tab1:
    results = st.session_state.results

    if results.empty:
        st.info("No results yet — press Run Scan in the sidebar.")
    else:
        # Earnings is a view filter — toggling it does not require a rescan.
        if exclude_earnings and "earnings_risk" in results.columns:
            hidden = int(results["earnings_risk"].sum())
            results = results[~results["earnings_risk"]].reset_index(drop=True)
            if hidden:
                st.caption(f"Hiding {hidden} trade(s) that expire on/after earnings.")

        st.write(f"**{len(results)} opportunities found**")

        if config.ALERT_EMAIL:
            if st.button("Email me these results"):
                send_alert(results, config.ALERT_EMAIL)
                st.success("Alert sent to the configured address.")

        def row_color(row):
            if row["return_pct"] > 5:
                return ["background-color: #d4edda"] * len(row)
            elif row["return_pct"] >= 2:
                return ["background-color: #fff3cd"] * len(row)
            return [""] * len(row)

        styled = results.style.apply(row_color, axis=1).format({
            "short_strike": "{:.2f}",
            "long_strike": "{:.2f}",
            "net_credit": "${:.2f}",
            "margin": "${:.0f}",
            "return_pct": "{:.2f}%",
            "otm_pct": "{:.2f}%",
            "short_delta": "{:.3f}",
        }, na_rep="—")
        st.dataframe(styled, use_container_width=True)

        st.subheader("Expand ticker chain")
        ticker_sel = st.selectbox("Select ticker", options=results["ticker"].unique(), key="expand_ticker")
        if ticker_sel and ticker_sel in st.session_state.chain_data:
            st.dataframe(st.session_state.chain_data[ticker_sel], use_container_width=True)

# ── Tab 2: Full Chains ────────────────────────────────────────────────────────
with tab2:
    chain_data = st.session_state.chain_data
    if not chain_data:
        st.info("Run a scan first to populate chain data.")
    else:
        chosen = st.selectbox("Select ticker", options=list(chain_data.keys()), key="chain_ticker")
        if chosen:
            df_chain = chain_data[chosen].copy()
            results = st.session_state.results
            best_short = None
            if not results.empty:
                ticker_results = results[results["ticker"] == chosen]
                if not ticker_results.empty:
                    best_short = ticker_results.iloc[0]["short_strike"]

            def highlight_best(row):
                if best_short and row.get("strike") == best_short:
                    return ["background-color: #cce5ff"] * len(row)
                return [""] * len(row)

            st.dataframe(df_chain.style.apply(highlight_best, axis=1), use_container_width=True)

# ── Tab 3: Scan History ───────────────────────────────────────────────────────
with tab3:
    history = load_scan_history()
    if history.empty:
        st.info("No scan history yet.")
    else:
        st.dataframe(history, use_container_width=True)

# ── Tab 4: Settings ───────────────────────────────────────────────────────────
with tab4:
    st.subheader("API Configuration")
    st.info(
        "API keys are managed via Streamlit Cloud secrets (or a local `.env` file). "
        "Do not enter keys here."
    )
    st.write("**Resend API key:**", "✅ configured" if config.RESEND_API_KEY else "❌ not set")
    st.write("**Alert email:**", "✅ configured" if config.ALERT_EMAIL else "❌ not set (using scan_config.json)")

