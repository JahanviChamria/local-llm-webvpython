// Per-request McpServer factory. Builds a fresh server with the authenticated
// user closure-captured into every tool and resource. Stateless by design —
// no per-instance session state survives between requests, which fits
// Vercel's invocation model.

import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { type McpContext, clientToSource } from "./context";
import { registerTools } from "./tools";
import { registerResources } from "./resources";

// Cross-tool guidance lives here. ChatGPT honors the server `instructions`
// field as its cross-tool steering lever — this is more reliable than the
// MCP `prompts` primitive for that purpose. Different copy per host because
// ChatGPT shows a write-confirmation modal on every write tool call and a
// frequent-call cadence would train students to dismiss it reflexively.
function serverInstructions(ctx: McpContext): string {
  const source = clientToSource(ctx.client);
  const base = [
    "You are connected to Sci-AI, the UC Merced research practice platform for the signed-in student.",
    "Use the sciai://user/profile, sciai://user/recent-progress, and sciai://labs/current resources to ground your responses in what the student is actually studying.",
    "Never make up details about their progress — read the resources first.",
    "To run a prelab: find the lab in sciai://labs/current (note its id), call the get_prelab tool with that lab_id to fetch the prelab document, and work the student through it exactly as that document directs.",
    "When the prelab is done, call sync_prelab_progress once. Put the prelab's entire final JSON output into the prelab_json argument, exactly as the document produced it, as one object — do not split it into separate fields or rename its keys. Also pass lab_id (that same lab id) to route the engagement score. Only score work the student actually did.",
  ];

  // ChatGPT custom MCP apps / connectors inherit the same write-confirmation
  // modal as first-party ChatGPT, so they share this conservative cadence.
  // Don't split them out without confirming the modal behavior changed.
  if (source === "chatgpt") {
    base.push(
      "Call log_study_session ONLY at clear end-of-conversation moments (the student says goodbye, switches topics decisively, or wraps up). Do NOT call it mid-conversation — each write triggers a confirmation modal and frequent prompts will train the student to dismiss them.",
    );
  } else {
    base.push(
      "Call log_study_session at the end of any educational conversation AND every ~15 messages of substantive discussion. Mid-conversation calls are cheap on this host.",
    );
  }

  base.push(
    "If the student asks you to 'save' or 'log' the session, call save_current_session_summary.",
    "Do NOT include personally identifying information (emails, phone numbers, ID numbers) in summaries — the server scrubs these but you should not write them in the first place.",
  );

  return base.join(" ");
}

export function buildMcpServer(ctx: McpContext): McpServer {
  const server = new McpServer(
    {
      name: "sciai-mcp",
      version: "0.1.0",
    },
    {
      instructions: serverInstructions(ctx),
    },
  );

  registerTools(server, ctx);
  registerResources(server, ctx);

  return server;
}
