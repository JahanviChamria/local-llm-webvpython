import Link from "next/link";
import { redirect } from "next/navigation";
import { asc, eq, sql } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { labs, questions } from "@/lib/db/schema";
import { getCurrentUser } from "@/lib/auth/session";
import { getUnlockedLabs } from "@/lib/portal/accessible-labs";

export const dynamic = "force-dynamic";

export default async function PracticeLabsPage() {
  const me = await getCurrentUser();
  if (!me) redirect("/login?next=/students/practice");

  const isStaff = me.role === "admin" || me.role === "faculty";

  // innerJoin excludes labs with no questions.
  const allRows = await db
    .select({
      id: labs.id,
      name: labs.name,
      easy: sql<number>`count(*) filter (where ${questions.difficulty} = 'easy')`,
      medium: sql<number>`count(*) filter (where ${questions.difficulty} = 'medium')`,
      hard: sql<number>`count(*) filter (where ${questions.difficulty} = 'hard')`,
      total: sql<number>`count(*)`,
    })
    .from(labs)
    .innerJoin(questions, eq(questions.labId, labs.id))
    .groupBy(labs.id, labs.name)
    .orderBy(asc(labs.name));

  // Students only see unlocked labs (no enrollment needed here); staff preview all.
  const rows = isStaff
    ? allRows
    : await (async () => {
        const unlocked = new Set((await getUnlockedLabs()).map((l) => l.id));
        return allRows.filter((r) => unlocked.has(r.id));
      })();

  return (
    <div className="col">
      <div className="screen-head">
        <div className="section-label">Retrieval practice</div>
        <h1>Pick a lab</h1>
        <p className="lead">
          Short spaced-repetition sessions — answer, reveal, then rate how well you knew it. Cards
          you find hard come back sooner.
        </p>
      </div>

      {rows.length === 0 ? (
        <p className="muted" style={{ fontSize: 13 }}>
          No practice questions are available yet.
        </p>
      ) : (
        <div className="grid g2">
          {rows.map((lab) => {
            const total = Number(lab.total);
            const easy = Number(lab.easy);
            const medium = Number(lab.medium);
            const hard = Number(lab.hard);
            return (
              <Link
                key={lab.id}
                href={`/students/practice/${lab.id}`}
                className="doc-row"
                style={{ alignItems: "flex-start" }}
              >
                <div className="doc-icon">✎</div>
                <div className="doc-info">
                  <div className="doc-name">{lab.name}</div>
                  <div className="doc-meta">
                    {total} question{total === 1 ? "" : "s"}
                  </div>
                  <div className="row wrap" style={{ gap: 5, marginTop: 8 }}>
                    {easy > 0 && <span className="badge complete">{easy} easy</span>}
                    {medium > 0 && <span className="badge progress">{medium} medium</span>}
                    {hard > 0 && (
                      <span
                        className="badge"
                        style={{ background: "var(--orange-bg)", color: "var(--orange-mid)" }}
                      >
                        {hard} hard
                      </span>
                    )}
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
