// Tests for the SRS response-time signal + scheduler timeFactor + queue
// priority — pure-function checks only.
//
// Run: npx tsx --test scripts/test-srs-timing.ts

import { test, describe } from "node:test";
import assert from "node:assert/strict";

import {
  clampElapsedMs,
  baselinePrior,
  effectiveBaseline,
  nextBaseline,
  deriveAutoRating,
  computeTimeFactor,
  estimateReadMs,
  thinkingMs,
  MIN_ANSWER_MS,
  MAX_ANSWER_MS,
  BASELINE_WARMUP,
  TIME_FACTOR_MIN,
  TIME_FACTOR_MAX,
  READ_BASE_MS,
  READ_MS_PER_CHAR,
  READ_BASELINE_CAP,
  THINK_FLOOR_MS,
} from "@/lib/srs/timing";
import { schedule, NEW_CARD, type CardSchedule } from "@/lib/srs/scheduler";
import { priorityScore, selectWithNewSlots, NEW_CARD_SLOTS } from "@/lib/srs/priority";

const NOW = new Date("2026-07-05T12:00:00Z");

describe("clampElapsedMs", () => {
  const startedAt = new Date(NOW.getTime() - 600_000); // served 10 min ago

  test("passes through a sane value", () => {
    assert.equal(clampElapsedMs(20_000, startedAt, NOW), 20_000);
  });
  test("floors at 1s", () => {
    assert.equal(clampElapsedMs(5, startedAt, NOW), MIN_ANSWER_MS);
  });
  test("caps at 4min", () => {
    assert.equal(clampElapsedMs(500_000, startedAt, NOW), MAX_ANSWER_MS);
  });
  test("bounded by server-observable wall clock", () => {
    const justServed = new Date(NOW.getTime() - 3_000);
    assert.equal(clampElapsedMs(100_000, justServed, NOW), 3_000);
  });
  test("garbage → null", () => {
    for (const bad of [null, undefined, "12", NaN, Infinity, -5, 0]) {
      assert.equal(clampElapsedMs(bad, startedAt, NOW), null, String(bad));
    }
  });
});

describe("baselinePrior / effectiveBaseline", () => {
  test("prior respects format floors and caps", () => {
    assert.equal(baselinePrior("true_false", 0), 8_000);
    assert.equal(baselinePrior("true_false", 10_000), 45_000);
    assert.equal(baselinePrior("multiple_choice", 0), 12_000);
    assert.equal(baselinePrior("multiple_choice", 10_000), 60_000);
    assert.equal(baselinePrior("short_answer", 500), 45_000);
    assert.equal(baselinePrior("calculation", 500), 90_000);
  });
  test("no samples → pure prior", () => {
    assert.equal(effectiveBaseline(null, 0, "short_answer", 100), 45_000);
    assert.equal(effectiveBaseline(30_000, 0, "short_answer", 100), 45_000);
  });
  test("warm question → pure stored baseline", () => {
    assert.equal(effectiveBaseline(30_000, BASELINE_WARMUP, "short_answer", 100), 30_000);
    assert.equal(effectiveBaseline(30_000, 50, "short_answer", 100), 30_000);
  });
  test("mid-warmup blends linearly", () => {
    // n=4 of 8: halfway between prior (45k) and stored (25k) = 35k
    assert.equal(effectiveBaseline(25_000, 4, "short_answer", 100), 35_000);
  });
});

describe("nextBaseline", () => {
  test("first sample seeds the baseline", () => {
    assert.deepEqual(nextBaseline(null, 0, 12_345), { baseline: 12_345, count: 1 });
  });
  test("moves at most 15% per sample (up)", () => {
    const { baseline } = nextBaseline(10_000, 5, 1_000_000);
    assert.equal(baseline, 11_500);
  });
  test("moves at most 15% per sample (down)", () => {
    const { baseline } = nextBaseline(10_000, 5, 1);
    assert.equal(baseline, 8_500);
  });
  test("small deltas apply exactly", () => {
    const { baseline, count } = nextBaseline(10_000, 5, 10_500);
    assert.equal(baseline, 10_500);
    assert.equal(count, 6);
  });
});

describe("deriveAutoRating", () => {
  const B = 10_000;
  test("wrong → again regardless of speed", () => {
    assert.equal(deriveAutoRating(false, 100, B), "again");
    assert.equal(deriveAutoRating(false, null, B), "again");
  });
  test("correct with no timer → good", () => {
    assert.equal(deriveAutoRating(true, null, B), "good");
  });
  test("fast correct → easy (strict < 0.6×)", () => {
    assert.equal(deriveAutoRating(true, 5_999, B), "easy");
    assert.equal(deriveAutoRating(true, 6_000, B), "good"); // boundary: not strict-less
  });
  test("normal correct → good (≤ 1.5×)", () => {
    assert.equal(deriveAutoRating(true, 15_000, B), "good"); // boundary inclusive
  });
  test("slow correct → hard (> 1.5×)", () => {
    assert.equal(deriveAutoRating(true, 15_001, B), "hard");
  });
});

describe("computeTimeFactor", () => {
  const B = 10_000;
  test("null / degenerate → neutral 1", () => {
    assert.equal(computeTimeFactor(null, B), 1);
    assert.equal(computeTimeFactor(10_000, 0), 1);
  });
  test("bounded to [0.8, 1.2]", () => {
    assert.equal(computeTimeFactor(100, B), TIME_FACTOR_MAX);
    assert.equal(computeTimeFactor(1_000_000, B), TIME_FACTOR_MIN);
  });
  test("baseline-speed answer → 1", () => {
    assert.equal(computeTimeFactor(10_000, B), 1);
  });
});

describe("estimateReadMs / thinkingMs", () => {
  test("scales with prompt length when the baseline is generous", () => {
    assert.equal(estimateReadMs(0, 60_000), READ_BASE_MS);
    assert.equal(estimateReadMs(100, 60_000), READ_BASE_MS + READ_MS_PER_CHAR * 100);
  });
  test("reading can't claim more than READ_BASELINE_CAP of the baseline", () => {
    // A very long prompt against a small baseline is capped.
    assert.equal(estimateReadMs(100_000, 20_000), Math.round(READ_BASELINE_CAP * 20_000));
  });
  test("thinkingMs subtracts reading and floors positive", () => {
    assert.equal(thinkingMs(10_000, 3_000), 7_000);
    assert.equal(thinkingMs(2_000, 5_000), THINK_FLOOR_MS);
  });
  test("removing reading time flips a fast recall on a long prompt to easy", () => {
    // Long TF question: learned baseline 40s, ~300-char prompt, answered in 27s.
    const B = 40_000;
    const chars = 300;
    const t = 27_000;
    const readMs = estimateReadMs(chars, B); // 800 + 50*300 = 15_800 (< 0.7*B)
    // Raw ratio 27k/40k = 0.675 → "good": fast recall masked by reading time.
    assert.equal(deriveAutoRating(true, t, B), "good");
    // Net of reading: 11.2k / 24.2k = 0.46 < 0.6 → correctly "easy".
    assert.equal(
      deriveAutoRating(true, thinkingMs(t, readMs), thinkingMs(B, readMs)),
      "easy",
    );
  });
});

describe("schedule with timeFactor", () => {
  const reviewCard: CardSchedule = {
    state: "review",
    reps: 3,
    lapses: 1,
    ease: 2.5,
    intervalDays: 10,
  };

  test("tf=1 (and omitted) reproduces legacy outputs exactly", () => {
    for (const rating of ["again", "hard", "good", "easy"] as const) {
      const legacy = schedule(reviewCard, rating, NOW);
      const withTf = schedule(reviewCard, rating, NOW, { timeFactor: 1 });
      assert.deepEqual(withTf, legacy, rating);
    }
    // Known legacy values.
    assert.equal(schedule(reviewCard, "good", NOW).intervalDays, 25); // 10 * 2.5
    assert.equal(schedule(reviewCard, "hard", NOW).intervalDays, 12); // 10 * 1.2
    const easy = schedule(reviewCard, "easy", NOW);
    assert.equal(easy.ease, 2.65);
    assert.ok(Math.abs(easy.intervalDays - 10 * 2.65 * 1.3) < 1e-9);
  });

  test("tf shapes good/easy review intervals within ±20%", () => {
    const fast = schedule(reviewCard, "good", NOW, { timeFactor: 1.2 });
    const slow = schedule(reviewCard, "good", NOW, { timeFactor: 0.8 });
    const base = schedule(reviewCard, "good", NOW).intervalDays;
    assert.ok(fast.intervalDays > base && fast.intervalDays <= base * 1.2 * 1.01);
    assert.ok(slow.intervalDays < base && slow.intervalDays >= base * 0.8 * 0.98);
  });

  test("tf nudges ease on good by at most ±0.01", () => {
    const fast = schedule(reviewCard, "good", NOW, { timeFactor: 1.2 });
    const slow = schedule(reviewCard, "good", NOW, { timeFactor: 0.8 });
    assert.ok(Math.abs(fast.ease - 2.51) < 1e-9);
    assert.ok(Math.abs(slow.ease - 2.49) < 1e-9);
  });

  test("tf does not touch hard/again", () => {
    for (const rating of ["hard", "again"] as const) {
      assert.deepEqual(
        schedule(reviewCard, rating, NOW, { timeFactor: 1.2 }),
        schedule(reviewCard, rating, NOW),
      );
    }
  });

  test("learning/new states ignore tf", () => {
    for (const rating of ["hard", "good", "easy"] as const) {
      assert.deepEqual(
        schedule(NEW_CARD, rating, NOW, { timeFactor: 1.2 }),
        schedule(NEW_CARD, rating, NOW),
      );
    }
  });

  test("ease never drops below 1.3", () => {
    let card: CardSchedule = { ...reviewCard, ease: 1.35 };
    for (let i = 0; i < 5; i++) {
      const next = schedule(card, "again", NOW, { timeFactor: 0.8 });
      assert.ok(next.ease >= 1.3);
      card = next;
    }
  });
});

describe("priorityScore", () => {
  const base = { intervalDays: 5, lapses: 0, ease: 2.5, lastRating: null, now: NOW };

  test("overdue dominates", () => {
    const fresh = priorityScore({ ...base, due: NOW });
    const overdue = priorityScore({ ...base, due: new Date(NOW.getTime() - 5 * 86_400_000) });
    assert.ok(overdue > fresh + 1.9);
  });
  test("overdue term saturates at 3×interval", () => {
    const a = priorityScore({ ...base, due: new Date(NOW.getTime() - 15 * 86_400_000) });
    const b = priorityScore({ ...base, due: new Date(NOW.getTime() - 150 * 86_400_000) });
    assert.equal(a, b);
  });
  test("lapses, low ease, and a rough last answer all raise priority", () => {
    const plain = priorityScore({ ...base, due: NOW });
    assert.ok(priorityScore({ ...base, due: NOW, lapses: 3 }) > plain);
    assert.ok(priorityScore({ ...base, due: NOW, ease: 1.3 }) > plain);
    assert.ok(priorityScore({ ...base, due: NOW, lastRating: "again" }) > plain);
    assert.ok(priorityScore({ ...base, due: NOW, lastRating: "hard" }) > plain);
    assert.equal(priorityScore({ ...base, due: NOW, lastRating: "good" }), plain);
  });
});

describe("selectWithNewSlots", () => {
  test("reserves slots for new cards when due cards would fill the session", () => {
    const due = ["d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9"];
    const fresh = ["n1", "n2", "n3"];
    const picked = selectWithNewSlots(due, fresh, 8);
    assert.equal(picked.length, 8);
    assert.deepEqual(picked.slice(6), ["n1", "n2"]);
    assert.equal(NEW_CARD_SLOTS, 2);
  });
  test("backfills with new cards when few due", () => {
    const picked = selectWithNewSlots(["d1"], ["n1", "n2", "n3", "n4"], 8);
    assert.deepEqual(picked, ["d1", "n1", "n2", "n3", "n4"]);
  });
  test("backfills with due cards when few new", () => {
    const due = ["d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9"];
    const picked = selectWithNewSlots(due, ["n1"], 8);
    assert.equal(picked.length, 8);
    assert.ok(picked.includes("n1"));
    assert.deepEqual(picked, ["d1", "d2", "d3", "d4", "d5", "d6", "d7", "n1"]);
  });
  test("no candidates → empty", () => {
    assert.deepEqual(selectWithNewSlots([], [], 8), []);
  });
});
