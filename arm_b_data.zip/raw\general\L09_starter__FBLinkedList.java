public class FBLinkedList<E> {

    private int size;
    private Node<E> front, back;

    
    
    //Returns the number of items in the list
    public int size(){
        return size;
    }


    public E get(int idx){
        if (idx >= size || idx < 0)
            throw new IndexOutOfBoundsException("Index out of range! Requested idx: " + idx + ", size = " + size);
        return getNode(idx).data;
    }

    //only intended to be called from inside the FBLinkedList class
    private Node<E> getNode(int idx){
        Node<E> current = front;
        for (int i = 0; i < idx; i++)
            current = current.next;
        return current;
    }


    public String toString(){
        StringBuilder sb = new StringBuilder("[");
        if (size == 0)
            return "[]";
        Node<E> current = front;
        for (int i = 0; i < size - 1; i++){
            sb.append(current.data + " ==> ");
            current = current.next;
        }
        sb.append(current.data + "]");
        return sb.toString();
    }


    
    
    private static class Node<E>{
       
       private E data;                 /** The data value. */
       private Node<E> next = null;    /** The link to the next Node in the list*/
       
       //Our Nodes are SINGLY-LINKED, meaning they maintain only a next 
       //reference, NOT a previous.  You MAY NOT add a previous reference.
       
       public Node(E data, Node<E> next) {
          this.data = data;
          this.next = next;
       }
       
       public Node(E data) {
          this(data, null);
       }               
    }    

    
    
            
    
    
   
    //***************************************************************
    //**                                                           **
    //**     YOU DON"T NEED TO MODIFY ANYTHING ABOVE THIS LINE     **
    //**                     YOUR TASKS ARE BELOW                  **
    //**                                                           **
    //***************************************************************

    
            
    
    
    
    //Appends argument element to the end of the list
    public void add(E toAdd){
       add(this.size, toAdd);
    }    
    
    

    //Inserts the argument element at the specified index 
    //can also be used to append to the end of the list
    //If an invalid index is provided, throws an IndexOutOfBoundsException
    public void add(int index, E toAdd){
        if(this.size==0){
            this.front=new Node<E>(toAdd);
            this.back=this.front;
        }
        else if(index==0){
            this.front=new Node<E>(toAdd,this.front);
        }
        else if(index==this.size){
            this.back.next=new Node<E>(toAdd);
            this.back=this.back.next;
        }
        else if(index<0 || index>this.size){
            throw new IllegalArgumentException("Invalid index provided!");
        }
        else{
            Node<E> temp=this.getNode(index-1);
            temp.next=new Node<E>(toAdd,temp.next);
       }
       this.size++;
    }

    
    
    
    
    

    //Removes all elements from the reference list that appear AFTER
    //the first occurrence of target:
    //list1 = "cat" -> "bat" -> "dog" -> "bird" -> "dog" -> "frog"
    //after list1.retainUpTo("dog");
    //list1 = "cat" -> "bat" -> "dog"
    public void retainUpTo(E target){
        //Implement me for 2.6!!
        if(this.front==null)
            return;
        if(target.equals(this.front.data)){
            this.back=this.front;
            this.front.next=null;
            size=1;
        }
        else{
            Node<E> temp=this.front;
            int count=1;
            while(temp.next!=null){
                if(temp.data.equals(target)){
                    temp.next=null;
                    this.size=count;
                    return;
                }
                temp=temp.next;
                count++;
            }
        }
    }



    //ignore these methoods... used for testing-------------------------
    public E getBackElement(){
        if (back == null)
           return null;
        return back.data;
     }
 
     public boolean getBackNext(){
         return back == null || back.next == null;
     }
     //-------------------------------------------------------------------     

    

}

