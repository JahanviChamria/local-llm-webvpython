"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { Fragment, useMemo, useState, useTransition } from "react";
import { Badge, Card } from "@/components/portal/primitives";
import { FigureField } from "@/components/portal/figure-field";

type Difficulty = "easy" | "medium" | "hard";
type Format = "true_false" | "multiple_choice" | "short_answer" | "calculation";
type Role = "canonical" | "isomorph" | "transfer" | "scaffold" | "extension";

type QuestionRow = {
  id: string;
  labId: string;
  labName: string;
  difficulty: Difficulty;
  prompt: string;
  expectedAnswer: string | null;
  createdAt: Date | string;
  updatedAt: Date | string;
  format: Format;
  role: Role;
  variantKey: string | null;
  familyBankKey: string | null;
};

type LabOption = { id: string; name: string };
type Tab = "new" | "existing";

const DIFFICULTY_KIND: Record<Difficulty, "complete" | "progress" | "alert"> = {
  easy: "complete",
  medium: "progress",
  hard: "alert",
};

const FORMAT_LABEL: Record<Format, string> = {
  short_answer: "Short answer",
  multiple_choice: "Multiple choice",
  true_false: "True / False",
  calculation: "Calculation",
};

const ROLES: Role[] = ["canonical", "isomorph", "transfer", "scaffold", "extension"];

const DIFFICULTY_RANK: Record<Difficulty, number> = { easy: 0, medium: 1, hard: 2 };

type SortMode = "recent" | "diff-asc" | "diff-desc";

function optionLetter(i: number): string {
  return String.fromCharCode(65 + i); // A, B, C, ...
}

export function AdminQuestionsClient({
  questions,
  labs,
  isAdmin,
}: {
  questions: QuestionRow[];
  labs: LabOption[];
  isAdmin: boolean;
}) {
  const router = useRouter();
  const [tab, setTab] = useState<Tab>("new");

  // Faculty get a read-only view: no "New Question" tab and no row actions.
  if (!isAdmin) {
    return (
      <div className="col" style={{ gap: 18 }}>
        <ExistingQuestions questions={questions} isAdmin={false} />
      </div>
    );
  }

  return (
    <div className="col" style={{ gap: 18 }}>
      <div className="files-tabs" role="tablist">
        <button
          type="button"
          role="tab"
          aria-selected={tab === "new"}
          className={tab === "new" ? "on" : ""}
          onClick={() => setTab("new")}
        >
          <span>New Question</span>
        </button>
        <button
          type="button"
          role="tab"
          aria-selected={tab === "existing"}
          className={tab === "existing" ? "on" : ""}
          onClick={() => setTab("existing")}
        >
          <span>Existing Questions</span>
        </button>
      </div>

      {tab === "new" ? (
        <CreateQuestionForm
          labs={labs}
          onCreated={() => {
            setTab("existing");
            router.refresh();
          }}
        />
      ) : (
        <ExistingQuestions questions={questions} isAdmin />
      )}
    </div>
  );
}

function preview(s: string, max: number): string {
  if (s.length <= max) return s;
  return s.slice(0, max).trimEnd() + "…";
}

function ExistingQuestions({ questions, isAdmin }: { questions: QuestionRow[]; isAdmin: boolean }) {
  const router = useRouter();
  const [pending, start] = useTransition();
  // Collapsed set holds lab names that are closed; default (empty) = all expanded.
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());
  // View-only ordering within each lab group; never persisted.
  const [sort, setSort] = useState<SortMode>("recent");

  async function del(q: QuestionRow) {
    if (!confirm(`Delete this ${q.difficulty} question from "${q.labName}"?`)) return;
    start(async () => {
      const res = await fetch(`/api/admin/questions/${q.id}`, { method: "DELETE" });
      if (!res.ok) {
        alert("Delete failed.");
        return;
      }
      router.refresh();
    });
  }

  // Group by lab, preserving first-seen order (rows arrive ordered by updated_at desc).
  const groups = useMemo(() => {
    const order: string[] = [];
    const byLab = new Map<string, QuestionRow[]>();
    for (const q of questions) {
      if (!byLab.has(q.labName)) {
        byLab.set(q.labName, []);
        order.push(q.labName);
      }
      byLab.get(q.labName)!.push(q);
    }
    return order.map((lab) => ({ lab, items: byLab.get(lab)! }));
  }, [questions]);

  function toggle(lab: string) {
    setCollapsed((prev) => {
      const next = new Set(prev);
      if (next.has(lab)) next.delete(lab);
      else next.add(lab);
      return next;
    });
  }

  // Stable sort within a group. "recent" keeps the incoming updated_at desc order.
  function sortItems(items: QuestionRow[]): QuestionRow[] {
    if (sort === "recent") return items;
    const dir = sort === "diff-asc" ? 1 : -1;
    return [...items].sort(
      (a, b) => (DIFFICULTY_RANK[a.difficulty] - DIFFICULTY_RANK[b.difficulty]) * dir,
    );
  }

  return (
    <Card title="Existing questions" label={`${questions.length} total`}>
      {questions.length === 0 ? (
        <p className="muted" style={{ fontSize: 13 }}>
          No questions yet.
        </p>
      ) : (
        <>
        <div className="row center" style={{ gap: 8, marginBottom: 12, justifyContent: "flex-end" }}>
          <span className="label" style={{ marginBottom: 0 }}>Sort within lab</span>
          <select
            className="field sm"
            value={sort}
            onChange={(e) => setSort(e.target.value as SortMode)}
            style={{ width: "auto" }}
          >
            <option value="recent">Recently updated</option>
            <option value="diff-asc">Difficulty: easy → hard</option>
            <option value="diff-desc">Difficulty: hard → easy</option>
          </select>
        </div>
        <div className="table-wrap">
          <table className="p-table">
            <thead>
              <tr>
                <th>Family</th>
                <th>Difficulty</th>
                <th>Format / Role</th>
                <th>Prompt</th>
                {isAdmin && <th style={{ textAlign: "right" }}>Actions</th>}
              </tr>
            </thead>
            <tbody>
              {groups.map((g) => {
                const open = !collapsed.has(g.lab);
                return (
                  <Fragment key={g.lab}>
                    <tr>
                      <td
                        colSpan={isAdmin ? 5 : 4}
                        onClick={() => toggle(g.lab)}
                        style={{
                          cursor: "pointer",
                          userSelect: "none",
                          background: "var(--surface2)",
                          fontWeight: 600,
                        }}
                      >
                        <span className="row center" style={{ gap: 10 }}>
                          <span
                            aria-hidden
                            style={{
                              display: "inline-block",
                              fontSize: 11,
                              color: "var(--muted)",
                              transition: "transform .15s",
                              transform: open ? "rotate(90deg)" : "none",
                            }}
                          >
                            ▶
                          </span>
                          <span>{g.lab}</span>
                          <span className="grow" />
                          <Badge>
                            {g.items.length} {g.items.length === 1 ? "question" : "questions"}
                          </Badge>
                        </span>
                      </td>
                    </tr>
                    {open &&
                      sortItems(g.items).map((q) => (
                        <tr key={q.id}>
                          <td style={{ paddingLeft: 30 }}>
                            {q.familyBankKey ? (
                              <div className="muted" style={{ fontSize: 11.5 }}>
                                {q.familyBankKey}
                                {q.variantKey && (
                                  <>
                                    {" · "}
                                    <code>{q.variantKey.split(":").pop()}</code>
                                  </>
                                )}
                              </div>
                            ) : (
                              <span className="muted" style={{ fontSize: 12 }}>
                                —
                              </span>
                            )}
                          </td>
                          <td>
                            <Badge kind={DIFFICULTY_KIND[q.difficulty]}>{q.difficulty}</Badge>
                          </td>
                          <td style={{ fontSize: 12 }}>
                            <div className="muted">{FORMAT_LABEL[q.format]}</div>
                            <div style={{ fontStyle: "italic" }}>{q.role}</div>
                          </td>
                          <td className="muted">{preview(q.prompt, 120)}</td>
                          {isAdmin && (
                            <td style={{ textAlign: "right", whiteSpace: "nowrap" }}>
                              <Link href={`/admin/questions/${q.id}`} className="btn ghost sm">
                                Edit
                              </Link>{" "}
                              <button
                                type="button"
                                onClick={() => del(q)}
                                disabled={pending}
                                className="btn danger sm"
                              >
                                Delete
                              </button>
                            </td>
                          )}
                        </tr>
                      ))}
                  </Fragment>
                );
              })}
            </tbody>
          </table>
        </div>
        </>
      )}
    </Card>
  );
}

function CreateQuestionForm({
  labs,
  onCreated,
}: {
  labs: LabOption[];
  onCreated: () => void;
}) {
  const [labName, setLabName] = useState("");
  const [difficulty, setDifficulty] = useState<Difficulty>("medium");
  const [format, setFormat] = useState<Format>("short_answer");
  const [role, setRole] = useState<Role>("canonical");
  const [prompt, setPrompt] = useState("");
  const [expectedAnswer, setExpectedAnswer] = useState("");
  const [options, setOptions] = useState<string[]>(["", ""]);
  const [correctIndex, setCorrectIndex] = useState(0);
  const [tfCorrect, setTfCorrect] = useState<"True" | "False">("True");
  const [figureFileId, setFigureFileId] = useState<string | null>(null);
  const [figureBusy, setFigureBusy] = useState(false);
  // Bumped on reset to remount FigureField, clearing its internal preview.
  const [figureKey, setFigureKey] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  const isMC = format === "multiple_choice";
  const isTF = format === "true_false";

  function addOption() {
    setOptions((o) => (o.length >= 12 ? o : [...o, ""]));
  }
  function removeOption(i: number) {
    setOptions((o) => (o.length <= 2 ? o : o.filter((_, idx) => idx !== i)));
    setCorrectIndex((ci) => (ci === i ? 0 : ci > i ? ci - 1 : ci));
  }
  function setOptionText(i: number, v: string) {
    setOptions((o) => o.map((t, idx) => (idx === i ? v : t)));
  }

  function resetForm() {
    setLabName("");
    setDifficulty("medium");
    setFormat("short_answer");
    setRole("canonical");
    setPrompt("");
    setExpectedAnswer("");
    setOptions(["", ""]);
    setCorrectIndex(0);
    setTfCorrect("True");
    setFigureFileId(null);
    setFigureKey((k) => k + 1);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    const payload: Record<string, unknown> = {
      labName,
      difficulty,
      format,
      role,
      prompt,
      expectedAnswer: expectedAnswer.length > 0 ? expectedAnswer : null,
      figureFileId,
    };

    if (isMC) {
      const texts = options.map((t) => t.trim());
      if (texts.length < 2 || texts.some((t) => t.length === 0)) {
        setError("Multiple choice needs at least 2 options, each non-empty.");
        return;
      }
      payload.options = texts.map((text, i) => ({ id: optionLetter(i), text }));
      payload.correctOption = optionLetter(correctIndex);
    } else if (isTF) {
      payload.correctOption = tfCorrect;
    }

    start(async () => {
      const res = await fetch("/api/admin/questions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const j = (await res.json().catch(() => ({}))) as { error?: string };
        setError(j.error ?? `Request failed (${res.status})`);
        return;
      }
      resetForm();
      onCreated();
    });
  }

  return (
    <form onSubmit={submit}>
      <Card title="New question" label="seeds the spaced-repetition queue">
        <label className="field-label">
          <span>Lab name</span>
          <input
            className="field"
            type="text"
            value={labName}
            onChange={(e) => setLabName(e.target.value)}
            list="labs-list"
            required
            maxLength={100}
            placeholder="e.g. Lab 1"
          />
          <datalist id="labs-list">
            {labs.map((l) => (
              <option key={l.id} value={l.name} />
            ))}
          </datalist>
          <span className="light" style={{ fontSize: 11.5, marginTop: 5, display: "block" }}>
            Type a new name to create a lab, or pick an existing one from the list.
          </span>
        </label>

        <label className="field-label" style={{ marginTop: 14 }}>
          <span>Difficulty</span>
          <select
            className="field"
            value={difficulty}
            onChange={(e) => setDifficulty(e.target.value as Difficulty)}
          >
            <option value="easy">Easy</option>
            <option value="medium">Medium</option>
            <option value="hard">Hard</option>
          </select>
        </label>

        <label className="field-label" style={{ marginTop: 14 }}>
          <span>Format</span>
          <select
            className="field"
            value={format}
            onChange={(e) => setFormat(e.target.value as Format)}
          >
            <option value="short_answer">Short answer</option>
            <option value="multiple_choice">Multiple choice</option>
            <option value="true_false">True / False</option>
            <option value="calculation">Calculation</option>
          </select>
        </label>

        <label className="field-label" style={{ marginTop: 14 }}>
          <span>Role</span>
          <select
            className="field"
            value={role}
            onChange={(e) => setRole(e.target.value as Role)}
          >
            {ROLES.map((r) => (
              <option key={r} value={r}>
                {r}
              </option>
            ))}
          </select>
        </label>

        <label className="field-label" style={{ marginTop: 14 }}>
          <span>Question prompt</span>
          <textarea
            className="field"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            required
            rows={4}
            maxLength={10_000}
          />
        </label>

        <FigureField
          key={figureKey}
          onChange={setFigureFileId}
          onBusyChange={setFigureBusy}
        />

        {isMC && (
          <div className="field-label" style={{ marginTop: 14 }}>
            <span>
              Options{" "}
              <span className="light" style={{ fontWeight: 400 }}>
                · select the correct one
              </span>
            </span>
            <div className="col" style={{ gap: 7, marginTop: 6 }}>
              {options.map((text, i) => (
                <div key={i} className="row center" style={{ gap: 9 }}>
                  <input
                    type="radio"
                    name="mc-correct"
                    checked={correctIndex === i}
                    onChange={() => setCorrectIndex(i)}
                    title="Mark as correct"
                  />
                  <span className="mono" style={{ width: 16, color: "var(--muted)", fontSize: 13 }}>
                    {optionLetter(i)}
                  </span>
                  <input
                    className="field grow"
                    type="text"
                    value={text}
                    onChange={(e) => setOptionText(i, e.target.value)}
                    placeholder={`Option ${optionLetter(i)}`}
                    maxLength={2000}
                  />
                  <button
                    type="button"
                    className="btn ghost sm"
                    onClick={() => removeOption(i)}
                    disabled={options.length <= 2}
                    title="Remove option"
                  >
                    ✕
                  </button>
                </div>
              ))}
              <div>
                <button
                  type="button"
                  className="btn ghost sm"
                  onClick={addOption}
                  disabled={options.length >= 12}
                >
                  + Add option
                </button>
              </div>
            </div>
          </div>
        )}

        {isTF && (
          <div className="field-label" style={{ marginTop: 14 }}>
            <span>Correct answer</span>
            <div className="row" style={{ gap: 7, marginTop: 6 }}>
              {(["True", "False"] as const).map((v) => (
                <button
                  key={v}
                  type="button"
                  className={"btn sm" + (tfCorrect === v ? " primary" : "")}
                  onClick={() => setTfCorrect(v)}
                >
                  {v}
                </button>
              ))}
            </div>
          </div>
        )}

        <label className="field-label" style={{ marginTop: 14 }}>
          <span>{isMC || isTF ? "Answer explanation (optional)" : "Expected answer (optional)"}</span>
          <textarea
            className="field"
            value={expectedAnswer}
            onChange={(e) => setExpectedAnswer(e.target.value)}
            rows={3}
            maxLength={50_000}
          />
        </label>

        {error && <p style={{ color: "var(--orange)", fontSize: 13, marginTop: 10 }}>{error}</p>}

        <div style={{ marginTop: 16 }}>
          <button type="submit" className="btn primary" disabled={pending || figureBusy}>
            {pending ? "Creating…" : "Create question"}
          </button>
        </div>
      </Card>
    </form>
  );
}
