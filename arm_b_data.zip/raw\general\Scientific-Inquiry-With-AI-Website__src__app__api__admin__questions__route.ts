import { NextResponse } from "next/server";
import { z } from "zod";
import { eq } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { questions, files } from "@/lib/db/schema";
import { requireAdmin, checkOrigin } from "@/lib/auth/guards";
import {
  createSchema,
  type CreateInput,
  resolveChoiceFields,
  ChoiceValidationError,
} from "@/lib/questions/schemas";
import {
  findOrCreateLabByName,
  InvalidLabNameError,
} from "@/lib/labs/find-or-create";

export const runtime = "nodejs";

export async function POST(req: Request) {
  const csrf = checkOrigin(req);
  if (csrf) return csrf;
  const g = await requireAdmin();
  if (g instanceof NextResponse) return g;

  let body: CreateInput;
  try {
    body = createSchema.parse(await req.json());
  } catch (err) {
    return NextResponse.json(
      { error: "invalid body", detail: String(err) },
      { status: 400 },
    );
  }

  let lab: { id: string; name: string };
  try {
    lab = await findOrCreateLabByName(body.labName);
  } catch (err) {
    if (err instanceof InvalidLabNameError) {
      return NextResponse.json(
        { error: "invalid lab name", detail: err.message },
        { status: 400 },
      );
    }
    throw err;
  }

  // Resolve + validate the choice-specific columns (shared with the update route).
  let options: { id: string; text: string }[] | null = null;
  let correctOption: string | null = null;
  try {
    ({ options, correctOption } = resolveChoiceFields(body.format, body.options, body.correctOption));
  } catch (err) {
    if (err instanceof ChoiceValidationError) {
      return NextResponse.json({ error: err.message }, { status: 400 });
    }
    throw err;
  }

  // Optional figure: must be a ready, public image/* file (same gate the bank
  // importer and the update route apply).
  const figureFileId = body.figureFileId ?? null;
  if (figureFileId) {
    const [f] = await db
      .select({
        status: files.status,
        accessLevel: files.accessLevel,
        contentType: files.contentType,
      })
      .from(files)
      .where(eq(files.id, figureFileId))
      .limit(1);
    if (
      !f ||
      f.status !== "ready" ||
      f.accessLevel !== "public" ||
      !f.contentType.startsWith("image/")
    ) {
      return NextResponse.json(
        { error: "invalid_figure", detail: "Figure must be a ready, public image file." },
        { status: 400 },
      );
    }
  }

  const [row] = await db
    .insert(questions)
    .values({
      labId: lab.id,
      difficulty: body.difficulty,
      format: body.format,
      role: body.role,
      prompt: body.prompt,
      expectedAnswer: body.expectedAnswer ?? null,
      options,
      correctOption,
      figureFileId,
      createdBy: g.id,
    })
    .returning({
      id: questions.id,
      labId: questions.labId,
      difficulty: questions.difficulty,
      format: questions.format,
      role: questions.role,
      prompt: questions.prompt,
      expectedAnswer: questions.expectedAnswer,
      createdAt: questions.createdAt,
      updatedAt: questions.updatedAt,
    });

  return NextResponse.json({ question: { ...row, labName: lab.name } });
}
