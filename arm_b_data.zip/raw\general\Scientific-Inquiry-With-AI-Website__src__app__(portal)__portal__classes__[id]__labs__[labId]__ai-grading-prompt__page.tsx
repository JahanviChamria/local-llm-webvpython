import { loadStudentClassLab } from "@/lib/portal/class-lab-guard";
import { LabDocumentSectionView } from "@/components/portal/lab-document-section-view";
import { LockedLabView } from "@/components/portal/locked-lab-view";

export const dynamic = "force-dynamic";

export default async function ClassLabAiGradingPromptPage({
  params,
}: {
  params: Promise<{ id: string; labId: string }>;
}) {
  const { id, labId } = await params;
  const { user, cls, entry } = await loadStudentClassLab(id, labId);

  if (entry.isLocked && user.role === "student") {
    return <LockedLabView className={cls.name} labName={entry.name} />;
  }

  return (
    <LabDocumentSectionView
      labId={labId}
      basePath={`/portal/classes/${id}/labs/${labId}`}
      kind="ai_grading_prompt"
    />
  );
}
