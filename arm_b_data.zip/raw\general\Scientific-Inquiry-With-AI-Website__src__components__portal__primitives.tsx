/* Shared UI primitives — Design Guide system (Syne/DM Sans, ink/green/orange).
   Ported from the design handoff components.jsx into typed React. */

import type { CSSProperties, ReactNode } from "react";

type BtnVariant = "primary" | "green" | "ghost" | "";

export function Btn({
  children,
  variant,
  sm,
  lg,
  onClick,
  style,
  type = "button",
}: {
  children: ReactNode;
  variant?: BtnVariant;
  sm?: boolean;
  lg?: boolean;
  onClick?: () => void;
  style?: CSSProperties;
  type?: "button" | "submit";
}) {
  return (
    <button
      type={type}
      className={"btn" + (variant ? " " + variant : "") + (sm ? " sm" : "") + (lg ? " lg" : "")}
      onClick={onClick}
      style={style}
    >
      {children}
    </button>
  );
}

type BadgeKind = "complete" | "progress" | "alert" | "new" | "streak" | "default";

export function Badge({ children, kind }: { children: ReactNode; kind?: BadgeKind }) {
  return <span className={"badge" + (kind && kind !== "default" ? " " + kind : "")}>{children}</span>;
}

export function Card({
  children,
  title,
  label,
  action,
  className = "",
  style,
}: {
  children: ReactNode;
  title?: ReactNode;
  label?: ReactNode;
  action?: ReactNode;
  className?: string;
  style?: CSSProperties;
}) {
  return (
    <div className={"card " + className} style={style}>
      {(title || label || action) && (
        <div className="card-h">
          <div className="row center" style={{ gap: 9 }}>
            {title && <h3>{title}</h3>}
            {label && <span className="label">{label}</span>}
          </div>
          {action}
        </div>
      )}
      {children}
    </div>
  );
}

// nav glyph — small geometric line icons (no emoji in chrome)
export type NavIcoName =
  | "home"
  | "doc"
  | "recall"
  | "sim"
  | "progress"
  | "schedule"
  | "instructor"
  | "profile"
  | "brain"
  | "dashboard"
  | "monitor"
  | "folder"
  | "question"
  | "clockHistory"
  | "flask"
  | "layers"
  | "users";

export function NavIco({ name }: { name: NavIcoName }) {
  const paths: Record<NavIcoName, ReactNode> = {
    home: (
      <>
        <path d="M2 7l6-5 6 5" />
        <path d="M3.5 6.5V13h9V6.5" />
      </>
    ),
    doc: (
      <>
        <rect x="3.5" y="2" width="9" height="12" rx="1" />
        <path d="M5.5 5.5h5M5.5 8h5M5.5 10.5h3" />
      </>
    ),
    recall: (
      <>
        <circle cx="8" cy="8" r="5.5" />
        <path d="M8 5v3l2 1.5" />
      </>
    ),
    sim: (
      <>
        <circle cx="8" cy="8" r="2" />
        <path d="M8 1.5v2M8 12.5v2M1.5 8h2M12.5 8h2M3.4 3.4l1.4 1.4M11.2 11.2l1.4 1.4M12.6 3.4l-1.4 1.4M4.8 11.2l-1.4 1.4" />
      </>
    ),
    progress: (
      <>
        <path d="M2.5 13.5V2.5" />
        <path d="M2.5 13.5h11" />
        <path d="M5 11l2.5-3 2 2 3-4" />
      </>
    ),
    schedule: (
      <>
        <rect x="2.5" y="3" width="11" height="10.5" rx="1" />
        <path d="M2.5 6h11M6 1.5v2M10 1.5v2" />
      </>
    ),
    instructor: (
      <>
        <circle cx="8" cy="5" r="2.4" />
        <path d="M3 13c0-2.5 2.2-4 5-4s5 1.5 5 4" />
      </>
    ),
    profile: (
      <>
        <circle cx="8" cy="6" r="2.6" />
        <path d="M3.5 13.5c0-2.4 2-3.8 4.5-3.8s4.5 1.4 4.5 3.8" />
        <circle cx="8" cy="8" r="6.2" />
      </>
    ),
    brain: (
      <>
        <path d="M8 2.5C6.5 1.8 4.5 2.5 4 3.5 3 4 1.8 5 2 6.5 1.5 7.5 1.5 9 2 9.5 1.8 10.5 2.5 12 3.5 12.5 4.5 13.5 6.5 14 8 13.5" />
        <path d="M8 2.5C9.5 1.8 11.5 2.5 12 3.5 13 4 14.2 5 14 6.5 14.5 7.5 14.5 9 14 9.5 14.2 10.5 13.5 12 12.5 12.5 11.5 13.5 9.5 14 8 13.5" />
        <path d="M8 2.5v11" />
        <path d="M4 6.2c1 .5 1 1.5 0 2" />
        <path d="M12 6.2c-1 .5-1 1.5 0 2" />
      </>
    ),
    dashboard: (
      <>
        <rect x="2.5" y="2.5" width="4.5" height="4.5" rx="0.5" />
        <rect x="9" y="2.5" width="4.5" height="4.5" rx="0.5" />
        <rect x="2.5" y="9" width="4.5" height="4.5" rx="0.5" />
        <rect x="9" y="9" width="4.5" height="4.5" rx="0.5" />
      </>
    ),
    monitor: (
      <>
        <rect x="2" y="2.5" width="12" height="8.5" rx="1" />
        <path d="M6 14h4M8 11v3" />
      </>
    ),
    folder: (
      <>
        <path d="M2 4.5c0-.6.4-1 1-1h3l1.2 1.2H13c.6 0 1 .4 1 1V12c0 .6-.4 1-1 1H3c-.6 0-1-.4-1-1V4.5z" />
      </>
    ),
    question: (
      <>
        <circle cx="8" cy="8" r="5.5" />
        <path d="M6.5 6.3c0-1 .8-1.6 1.6-1.6.9 0 1.6.6 1.6 1.5 0 .9-.7 1.2-1.2 1.6-.3.2-.5.5-.5 1" />
        <circle cx="8" cy="11" r="0.5" fill="currentColor" />
      </>
    ),
    clockHistory: (
      <>
        <path d="M3 4v2.5h2.5" />
        <path d="M3 6.5A5.5 5.5 0 1 1 3.5 11" />
        <path d="M8 5.5V8l1.8 1.5" />
      </>
    ),
    flask: (
      <>
        <path d="M6 2h4" />
        <path d="M6.5 2v3.6L3 12.2c-.3.6.1 1.3.9 1.3h8.2c.8 0 1.2-.7.9-1.3L9.5 5.6V2" />
        <path d="M4.5 9.5h7" />
      </>
    ),
    layers: (
      <>
        <path d="M8 2.2 2.2 5 8 7.8 13.8 5z" />
        <path d="M2.2 8 8 10.8 13.8 8" />
        <path d="M2.2 11 8 13.8 13.8 11" />
      </>
    ),
    users: (
      <>
        <circle cx="6" cy="5.5" r="2" />
        <path d="M2.5 13c0-2 1.5-3.2 3.5-3.2s3.5 1.2 3.5 3.2" />
        <circle cx="11" cy="5.5" r="1.7" />
        <path d="M9.5 9.8c2 0 4 1.2 4 3.2" />
      </>
    ),
  };
  return (
    <svg
      width={16}
      height={16}
      viewBox="0 0 16 16"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.6}
      strokeLinecap="round"
      strokeLinejoin="round"
      className="nav-ico"
    >
      {paths[name]}
    </svg>
  );
}

// streak ring — conic, flat
export function Ring({
  value = 70,
  size = 78,
  label,
  sub,
  color = "var(--ink)",
}: {
  value?: number;
  size?: number;
  label: ReactNode;
  sub?: string;
  color?: string;
}) {
  return (
    <div
      className="ring"
      style={{ width: size, height: size, background: `conic-gradient(${color} ${value * 3.6}deg, var(--surface2) 0deg)` }}
    >
      <div className="ring-inner" style={{ width: size - 16, height: size - 16, border: "1px solid var(--border)" }}>
        <b style={{ fontSize: size > 70 ? 22 : 17, color }}>{label}</b>
        {sub && <span className="label" style={{ fontSize: 8, marginTop: 2 }}>{sub}</span>}
      </div>
    </div>
  );
}

export function Track({ pct, color = "var(--ink)", tall }: { pct: number; color?: string; tall?: boolean }) {
  return (
    <div className={"track" + (tall ? " tall" : "")}>
      <span style={{ width: pct + "%", background: color }} />
    </div>
  );
}

type MasteryState = "mastered" | "review" | "strong";

export function MasteryItem({
  label,
  level,
  pct,
  state,
}: {
  label: string;
  level: string;
  pct: number;
  state?: MasteryState;
}) {
  const color = state === "mastered" ? "var(--green)" : state === "review" ? "var(--orange)" : "var(--ink)";
  return (
    <div className="mastery-item">
      <div className="mastery-header">
        <span className="mastery-label">{label}</span>
        <span className="mastery-level">{level}</span>
      </div>
      <Track pct={pct} color={color} />
    </div>
  );
}

export function Ph({ label, h = 120, style }: { label: ReactNode; h?: number; style?: CSSProperties }) {
  return (
    <div className="ph" style={{ minHeight: h, ...style }}>
      {label}
    </div>
  );
}

export function Av({ initials, sm }: { initials: string; sm?: boolean }) {
  return <div className={"avatar" + (sm ? " sm" : "")}>{initials}</div>;
}

// weekly goal day dots
export function WeekDots({ done = 4 }: { done?: number }) {
  return (
    <div className="row" style={{ gap: 5 }}>
      {["M", "T", "W", "T", "F", "S", "S"].map((d, i) => (
        <div key={i} className={"day-dot " + (i < done ? "on" : "off")}>
          {d}
        </div>
      ))}
    </div>
  );
}
