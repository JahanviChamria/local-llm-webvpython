import { LabPrelabView } from "@/components/portal/lab-prelab-view";
import { guardStudentGlobalLab } from "@/lib/portal/global-lab-guard";

export const dynamic = "force-dynamic";

export default async function LabPrelabPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  await guardStudentGlobalLab(id);
  return <LabPrelabView labId={id} basePath={`/portal/labs/${id}`} />;
}
