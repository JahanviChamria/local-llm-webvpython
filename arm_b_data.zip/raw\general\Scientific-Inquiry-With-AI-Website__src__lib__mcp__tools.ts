// MCP tool registrations. Every tool:
//
//   - Closes over the authenticated user — `userId` and `source` are NEVER
//     in any input schema. Tampered tool input cannot misattribute writes.
//   - Checks the scope it requires against grant.scopes server-side. The
//     `securitySchemes` annotation is for client/model discovery; the
//     server-side check is the authoritative one.
//   - Rejects role === "guest" — only verified students write back.
//   - Caps + scrubs free-text input (per data-minimization plan).
//
// Tool callbacks are exported individually so the test suite can call them
// directly without rebuilding the full MCP server.

import { and, eq, gte, sql } from "drizzle-orm";
import { z } from "zod";
import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";

import { db } from "@/lib/db/client";
import {
  aiChatSummaries,
  classEnrollments,
  studentProfileSignals,
  srsSessions,
} from "@/lib/db/schema";

import {
  SCOPE_STUDY_READ,
  SCOPE_STUDY_WRITE,
} from "@/lib/oauth/scopes";

import { sanitizeStudentText, SUMMARY_MAX_BYTES, RAW_MAX_BYTES } from "./redact";
import { applyProfileImport } from "@/lib/student-profiles/import";
import { getAccessibleLabs } from "@/lib/portal/accessible-labs";
import { getPrelabData } from "./prelab-data";
import { type McpContext, hasScope, toolError, clientToSource } from "./context";

// ---------- Input schemas (Zod) ------------------------------------------

// Note: deliberately no userId / source / grantId / classId fields. Identity
// is server-derived. labId is optional and validated; if absent or ambiguous,
// the row is stored with labId=null (bias toward null per the plan).
const logStudySessionSchema = {
  labId: z
    .string()
    .uuid()
    .optional()
    .describe(
      "Optional Sci-AI lab UUID this session is about. If unsure, omit — the server will infer from recent activity when unambiguous, and otherwise store null.",
    ),
  topics: z
    .array(z.string().min(1).max(200))
    .min(1)
    .max(20)
    .describe("Short topic labels covered in this conversation (e.g., 'photosynthesis', 'momentum conservation')."),
  summary: z
    .string()
    .min(1)
    .describe(
      "A 1-3 sentence summary of what the student worked on, what they understood, and what tripped them up. Plain text, no transcript.",
    ),
  durationMinutes: z
    .number()
    .int()
    .positive()
    .max(24 * 60)
    .optional()
    .describe("How long the student worked, in minutes."),
  strugglesObserved: z
    .array(z.string().min(1).max(200))
    .max(10)
    .optional()
    .describe("Specific things the student found difficult."),
  conceptsMastered: z
    .array(z.string().min(1).max(200))
    .max(10)
    .optional()
    .describe("Specific things the student demonstrated they understand."),
};

const recordConceptStruggleSchema = {
  topic: z.string().min(1).max(200).describe("Topic the student is struggling with."),
  signal: z
    .enum(["confusion", "misconception", "missing-prereq", "computational-error", "other"])
    .describe("Kind of struggle observed."),
  detail: z
    .string()
    .min(1)
    .max(500)
    .optional()
    .describe("Short detail about what's not clicking. One sentence."),
};

const submitSelfAssessmentSchema = {
  summary: z
    .string()
    .min(1)
    .describe("Student's own description of how they feel about what they just studied."),
  confidence: z
    .number()
    .int()
    .min(1)
    .max(5)
    .describe("Self-rated confidence 1-5 (1 = lost, 5 = could teach it)."),
  topicsCovered: z
    .array(z.string().min(1).max(200))
    .min(1)
    .max(20)
    .describe("Topics the assessment covers."),
};

// sync_prelab_progress accepts the same tolerant contract as the manual-upload
// route (POST /api/portal/profile/import). Fields stay permissive here; the
// real gate (published-lab resolution, 0..5 clamp, byte caps) lives in
// applyProfileImport, shared verbatim with that route. MCP-only: there is no
// REST/OpenAPI mirror, so no ZodObject export below.
// The prelab produces ONE JSON object (the doc's Section 8 output). Take it as
// ONE open object, not a fan-out of named fields. prelab_json is a free-form
// object (additionalProperties allowed), so every inner block the tutor emits —
// mind_map, personalization, learning_style, struggles, engagement_scoring,
// Lab_name — survives intact, whatever the exact keys. This removes the whole
// class of "the strict schema stripped a key the model sent" failures, and
// means the model passes the doc's output in one piece instead of destructuring
// it into seven arguments (which is where blocks were getting lost).
const syncPrelabProgressSchema = {
  lab_id: z
    .string()
    .uuid()
    .optional()
    .describe(
      "The lab id of the prelab the student just completed, from sciai://labs/current. Routes the engagement score to the right lab, regardless of the JSON's Lab_name.",
    ),
  prelab_json: z
    .record(z.unknown())
    .describe(
      "The COMPLETE JSON object the prelab produced at the end of the session, passed exactly as-is with its original keys (Lab_name, mind_map, personalization, learning_style, struggles, engagement_scoring). Do not rename, restructure, split, or omit anything — pass the whole object in one piece.",
    ),
};

// ---------- Input schemas as ZodObjects ---------------------------------
//
// The field-map shape above is what MCP's registerTool() consumes for its
// inputSchema annotation. For the REST/OpenAPI surface (Actions), we need
// the same shapes as full ZodObjects so route handlers can `.parse()` them
// and zod-to-json-schema can emit OpenAPI schemas. One source of truth.

export const logStudySessionInput = z.object(logStudySessionSchema);
export const recordConceptStruggleInput = z.object(recordConceptStruggleSchema);
export const submitSelfAssessmentInput = z.object(submitSelfAssessmentSchema);

// ---------- Output schemas (Zod) ----------------------------------------
//
// One source of truth for the OpenAPI spec (generated by zod-to-json-schema)
// AND for the dev-time response-shape validation done in the Actions REST
// handler. Each `deduplicated?: true` field is set by the natural-idempotency
// window — see acquireGrantLockAndCheck() below.

export const logStudySessionOutput = z.object({
  status: z.literal("logged"),
  summaryId: z.string().uuid(),
  labIdInferred: z.boolean().optional(),
  truncated: z.boolean().optional(),
  deduplicated: z.literal(true).optional(),
});

export const recordConceptStruggleOutput = z.object({
  status: z.literal("recorded"),
  note: z.string(),
  deduplicated: z.literal(true).optional(),
});

export const submitSelfAssessmentOutput = z.object({
  status: z.literal("submitted"),
  summaryId: z.string().uuid(),
  deduplicated: z.literal(true).optional(),
});

// ---------- Idempotency window ------------------------------------------
//
// Constraint D: GPT Builder Actions (and any HTTP client) may retry a write on
// 5xx/timeout, producing duplicate rows that corrupt SM-2 signal. A naive
// SELECT-then-INSERT has a TOCTOU race when concurrent retries fire.
//
// pg_advisory_xact_lock keyed on hashtext(grantId || '|' || naturalKey)
// serializes concurrent retries for the same (grant, key); the lock releases
// at COMMIT. Combined with a 15s recency window (transport-retry timeframe),
// this absorbs the typical retry-storm pattern.
//
// NOT full idempotency — a clientRequestId unique-index column is the proper
// fix and is tracked as a follow-up. Two genuinely distinct user actions with
// a colliding natural key inside the window would still drop the second; the
// window is kept short so the false-drop surface is tiny.

const DEDUP_WINDOW_MS = 15_000;

async function acquireGrantLock(tx: Parameters<Parameters<typeof db.transaction>[0]>[0], lockKey: string): Promise<void> {
  // hashtext returns int4; pg_advisory_xact_lock(int4) takes one 32-bit key.
  // Spurious collisions (different grants/keys hashing to the same int4) just
  // serialize unrelated work — harmless under expected load.
  await tx.execute(sql`SELECT pg_advisory_xact_lock(hashtext(${lockKey}))`);
}

// ---------- Tool implementations ---------------------------------------

type LogStudySessionInput = {
  labId?: string;
  topics: string[];
  summary: string;
  durationMinutes?: number;
  strugglesObserved?: string[];
  conceptsMastered?: string[];
};

export async function logStudySessionImpl(args: LogStudySessionInput, ctx: McpContext) {
  if (!hasScope(ctx, SCOPE_STUDY_WRITE)) return toolError("study:write scope required");
  if (ctx.user.role === "guest") return toolError("verified students only");

  // Size cap + PII scrub on the free-text summary.
  const sanitized = sanitizeStudentText(args.summary, SUMMARY_MAX_BYTES);
  if (sanitized.truncated) {
    console.warn(
      `[mcp/log_study_session] summary truncated for user=${ctx.user.id.slice(0, 8)}…`,
    );
  }

  // raw stores the structured tool input minus the summary (which lives in
  // its own column). Capped separately. Strugges/concepts/topics may also
  // contain PII so scrub them via a JSON-stringify round-trip.
  const rawObj = {
    durationMinutes: args.durationMinutes,
    strugglesObserved: args.strugglesObserved,
    conceptsMastered: args.conceptsMastered,
  };
  const rawSanitized = sanitizeStudentText(JSON.stringify(rawObj), RAW_MAX_BYTES);
  let rawForDb: unknown = null;
  try {
    rawForDb = JSON.parse(rawSanitized.value);
  } catch {
    // Truncation broke JSON — fall back to a stringified note rather than
    // losing the field entirely.
    rawForDb = { note: "raw truncated during sanitization" };
  }

  // labId inference: if not provided, look for unambiguous recent activity.
  let labId: string | null = args.labId ?? null;
  if (!labId) {
    const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
    const recent = await db
      .select({ labId: srsSessions.labId })
      .from(srsSessions)
      .where(
        and(
          eq(srsSessions.userId, ctx.user.id),
          eq(srsSessions.scope, "lab"),
          gte(srsSessions.startedAt, oneHourAgo),
        ),
      );
    const distinctLabs = new Set(recent.map((r) => r.labId).filter((id): id is string => id !== null));
    if (distinctLabs.size === 1) {
      labId = [...distinctLabs][0];
    }
    // size 0 or 2+ → keep null (don't guess)
  }

  // Look up current class for the user (most recent enrollment).
  const classRows = await db
    .select({ classId: classEnrollments.classId })
    .from(classEnrollments)
    .where(eq(classEnrollments.userId, ctx.user.id))
    .orderBy(classEnrollments.enrolledAt)
    .limit(1);
  const classId = classRows[0]?.classId ?? null;

  // Sanitize topics (each entry) — PII could appear here too.
  const topicsScrubbed = args.topics.map(
    (t) => sanitizeStudentText(t, 200).value,
  );

  const source = clientToSource(ctx.client);

  // Lock-protected dedup window. See acquireGrantLock() above.
  const lockKey = `${ctx.grant.id}|log_session|${sanitized.value}`;
  const cutoff = new Date(Date.now() - DEDUP_WINDOW_MS);

  const result = await db.transaction(async (tx) => {
    await acquireGrantLock(tx, lockKey);

    const existing = await tx
      .select({ id: aiChatSummaries.id })
      .from(aiChatSummaries)
      .where(
        and(
          eq(aiChatSummaries.grantId, ctx.grant.id),
          eq(aiChatSummaries.summary, sanitized.value),
          gte(aiChatSummaries.createdAt, cutoff),
        ),
      )
      .orderBy(sql`${aiChatSummaries.createdAt} desc`)
      .limit(1);
    if (existing[0]) {
      return { id: existing[0].id, deduplicated: true as const };
    }

    const [inserted] = await tx
      .insert(aiChatSummaries)
      .values({
        userId: ctx.user.id,
        source,
        labId,
        classId,
        summary: sanitized.value,
        topics: topicsScrubbed,
        raw: rawForDb,
        grantId: ctx.grant.id,
      })
      .returning({ id: aiChatSummaries.id });
    return { id: inserted.id, deduplicated: false as const };
  });

  return {
    content: [
      {
        type: "text" as const,
        text: JSON.stringify(
          result.deduplicated
            ? { status: "logged", summaryId: result.id, deduplicated: true }
            : {
                status: "logged",
                summaryId: result.id,
                labIdInferred: !args.labId && labId !== null,
                truncated: sanitized.truncated || rawSanitized.truncated,
              },
        ),
      },
    ],
  };
}

type RecordConceptStruggleInput = {
  topic: string;
  signal: "confusion" | "misconception" | "missing-prereq" | "computational-error" | "other";
  detail?: string;
};

export async function recordConceptStruggleImpl(
  args: RecordConceptStruggleInput,
  ctx: McpContext,
) {
  if (!hasScope(ctx, SCOPE_STUDY_WRITE)) return toolError("study:write scope required");
  if (ctx.user.role === "guest") return toolError("verified students only");

  const topic = sanitizeStudentText(args.topic, 200).value;
  const detail = args.detail ? sanitizeStudentText(args.detail, 500).value : null;
  const source = clientToSource(ctx.client);

  const lockKey = `${ctx.grant.id}|struggle|${topic}|${args.signal}`;
  const cutoff = new Date(Date.now() - DEDUP_WINDOW_MS);

  const deduplicated = await db.transaction(async (tx) => {
    await acquireGrantLock(tx, lockKey);

    const existing = await tx
      .select({ id: studentProfileSignals.id })
      .from(studentProfileSignals)
      .where(
        and(
          eq(studentProfileSignals.grantId, ctx.grant.id),
          eq(studentProfileSignals.topic, topic),
          eq(studentProfileSignals.signal, args.signal),
          gte(studentProfileSignals.recordedAt, cutoff),
        ),
      )
      .limit(1);
    if (existing[0]) return true;

    await tx.insert(studentProfileSignals).values({
      userId: ctx.user.id,
      topic,
      signal: args.signal,
      detail,
      source,
      grantId: ctx.grant.id,
    });
    return false;
  });

  return {
    content: [
      {
        type: "text" as const,
        text: JSON.stringify({
          status: "recorded",
          note: "Stored as an observational signal. Used for instructor dashboards only — not for personalization.",
          ...(deduplicated ? { deduplicated: true } : {}),
        }),
      },
    ],
  };
}

type SubmitSelfAssessmentInput = {
  summary: string;
  confidence: number;
  topicsCovered: string[];
};

export async function submitSelfAssessmentImpl(
  args: SubmitSelfAssessmentInput,
  ctx: McpContext,
) {
  if (!hasScope(ctx, SCOPE_STUDY_WRITE)) return toolError("study:write scope required");
  if (ctx.user.role === "guest") return toolError("verified students only");

  const sanitized = sanitizeStudentText(args.summary, SUMMARY_MAX_BYTES);
  const topicsScrubbed = args.topicsCovered.map((t) => sanitizeStudentText(t, 200).value);
  const source = clientToSource(ctx.client);

  const classRows = await db
    .select({ classId: classEnrollments.classId })
    .from(classEnrollments)
    .where(eq(classEnrollments.userId, ctx.user.id))
    .orderBy(classEnrollments.enrolledAt)
    .limit(1);
  const classId = classRows[0]?.classId ?? null;

  const lockKey = `${ctx.grant.id}|self_assessment|${sanitized.value}`;
  const cutoff = new Date(Date.now() - DEDUP_WINDOW_MS);

  const result = await db.transaction(async (tx) => {
    await acquireGrantLock(tx, lockKey);

    const existing = await tx
      .select({ id: aiChatSummaries.id })
      .from(aiChatSummaries)
      .where(
        and(
          eq(aiChatSummaries.grantId, ctx.grant.id),
          eq(aiChatSummaries.summary, sanitized.value),
          gte(aiChatSummaries.createdAt, cutoff),
        ),
      )
      .orderBy(sql`${aiChatSummaries.createdAt} desc`)
      .limit(1);
    if (existing[0]) {
      return { id: existing[0].id, deduplicated: true as const };
    }

    const [inserted] = await tx
      .insert(aiChatSummaries)
      .values({
        userId: ctx.user.id,
        source,
        classId,
        summary: sanitized.value,
        // Topics convention: prepend "self-assessment" so instructor dashboards
        // can split self-reports from model-generated session summaries.
        topics: ["self-assessment", ...topicsScrubbed],
        raw: { kind: "self_assessment", confidence: args.confidence },
        grantId: ctx.grant.id,
      })
      .returning({ id: aiChatSummaries.id });
    return { id: inserted.id, deduplicated: false as const };
  });

  return {
    content: [
      {
        type: "text" as const,
        text: JSON.stringify({
          status: "submitted",
          summaryId: result.id,
          ...(result.deduplicated ? { deduplicated: true } : {}),
        }),
      },
    ],
  };
}

type SyncPrelabProgressInput = {
  lab_id?: string;
  prelab_json?: Record<string, unknown>;
};

export async function syncPrelabProgressImpl(args: SyncPrelabProgressInput, ctx: McpContext) {
  if (!hasScope(ctx, SCOPE_STUDY_WRITE)) return toolError("study:write scope required");
  if (ctx.user.role === "guest") return toolError("verified students only");

  // The doc's whole JSON arrives as one object. applyProfileImport normalizes it
  // (mind_map -> mindMap, learning_style -> learningStyle, etc.), clamps the
  // engagement score to 0..5, and shallow-merges each block into
  // student_profiles. routeLabId (the lab from labs/current) routes the score;
  // the sole-lab fallback covers the common case where the model passed no id
  // because the doc's JSON never carries one.
  const payload =
    args.prelab_json && typeof args.prelab_json === "object" ? args.prelab_json : {};
  const outcome = await applyProfileImport(ctx.user.id, payload, {
    routeLabId: args.lab_id,
    fallbackToSoleAccessibleLab: true,
  });

  if (!outcome.ok) {
    if (outcome.code === "profile_not_initialized") {
      return toolError(
        "profile_not_initialized: ask faculty to enable your learning history before syncing.",
      );
    }
    if (outcome.code === "nothing_applicable") {
      return toolError(
        `nothing_applicable: an engagement score needs a lab_name matching one of your published labs and a level 0-5 (topicSkipped=${outcome.topicSkipped}).`,
      );
    }
    return toolError(`invalid_body: ${outcome.detail}`);
  }

  return {
    content: [
      {
        type: "text" as const,
        text: JSON.stringify({
          status: "synced",
          applied: outcome.applied,
          topicSkipped: outcome.topicSkipped,
        }),
      },
    ],
  };
}

// get_prelab is the READ half exposed as a tool, not only a resource, because
// claude.ai surfaces tools to the model but not resource templates — so a
// resource-only prelab is invisible there. Same fetch as the
// sciai://labs/{labId}/prelab resource (getPrelabData). Read-only.
const getPrelabSchema = {
  lab_id: z
    .string()
    .uuid()
    .optional()
    .describe(
      "The lab whose prelab to fetch, from sciai://labs/current. Omit only if the student has exactly one published lab, in which case that one is used.",
    ),
};

type GetPrelabInput = { lab_id?: string };

export async function getPrelabImpl(args: GetPrelabInput, ctx: McpContext) {
  if (!hasScope(ctx, SCOPE_STUDY_READ)) return toolError("study:read scope required");
  if (ctx.user.role === "guest") return toolError("verified students only");

  let labId = args.lab_id;
  if (!labId) {
    // No id given — fall back to the sole published lab, else ask for one.
    const labs = await getAccessibleLabs(ctx.user.id);
    if (labs.length === 1) labId = labs[0].id;
    else {
      return toolError(
        "pass lab_id: read sciai://labs/current and use the id of the lab you want (you have none or more than one published lab).",
      );
    }
  }

  const data = await getPrelabData(ctx.user.id, labId);
  if (!data.ok) return toolError(`${data.error}: ${data.detail}`);

  return {
    content: [
      {
        type: "text" as const,
        text: JSON.stringify({
          labId: data.labId,
          labName: data.labName,
          hasPrelab: data.documents.length > 0,
          documents: data.documents,
        }),
      },
    ],
  };
}

// ---------- Registration ------------------------------------------------

// Logging-cadence guidance differs per AI host because ChatGPT pops a
// confirmation modal on every write tool call; a 15-message cadence would
// train users to dismiss it reflexively. Claude has no modal — frequent calls
// are cheap there.
function logCadenceGuidance(client: McpContext["client"]): string {
  const source = clientToSource(client);
  if (source === "chatgpt") {
    return (
      "Call log_study_session ONLY when the conversation clearly concludes (the student says " +
      "goodbye, leaves the topic, or you reach a natural stopping point). Do not call it mid-conversation."
    );
  }
  return (
    "Call log_study_session at the end of any educational conversation AND every ~15 messages " +
    "of substantive discussion. Mid-session calls are fine."
  );
}

export function registerTools(server: McpServer, ctx: McpContext): void {
  server.registerTool(
    "log_study_session",
    {
      title: "Log study session",
      description: [
        `Record what the student worked on in Sci-AI. ${logCadenceGuidance(ctx.client)}`,
        "Include topics covered, a short summary, and what (if anything) tripped them up.",
        "Never put a full chat transcript here — a paraphrased summary only.",
      ].join(" "),
      inputSchema: logStudySessionSchema,
      annotations: {
        readOnlyHint: false,
        destructiveHint: false,
        idempotentHint: false,
        openWorldHint: false,
      },
    },
    (args) => logStudySessionImpl(args, ctx),
  );

  server.registerTool(
    "save_current_session_summary",
    {
      title: "Save current session summary",
      description:
        "Same as log_study_session, exposed so the student can ASK you to save a summary verbally " +
        "(e.g., 'save this study session'). Use this when the student explicitly requests logging.",
      inputSchema: logStudySessionSchema,
      annotations: {
        readOnlyHint: false,
        destructiveHint: false,
        idempotentHint: false,
        openWorldHint: false,
      },
    },
    (args) => logStudySessionImpl(args, ctx),
  );

  server.registerTool(
    "get_prelab",
    {
      title: "Get prelab content",
      description: [
        "Fetch the extracted text of a lab's prelab document so you can run the prelab with the student in this chat.",
        "Pass lab_id from sciai://labs/current. Read this first, then follow the document's own instructions to run the session.",
      ].join(" "),
      inputSchema: getPrelabSchema,
      annotations: {
        readOnlyHint: true,
        destructiveHint: false,
        idempotentHint: true,
        openWorldHint: false,
      },
    },
    (args) => getPrelabImpl(args, ctx),
  );

  server.registerTool(
    "sync_prelab_progress",
    {
      title: "Sync prelab progress",
      description: [
        "Write the student's completed prelab result back to their Prelab progress page on Sci-AI.",
        "Call this once, at the end of the prelab, after the student has actually worked through it.",
        "Put the prelab's entire final JSON output into prelab_json, exactly as the document produced it,",
        "as one object — do not split it into separate arguments. Also pass lab_id (the id of the lab from",
        "sciai://labs/current) to route the engagement score. Only labs published to the student are accepted.",
      ].join(" "),
      inputSchema: syncPrelabProgressSchema,
      annotations: {
        readOnlyHint: false,
        destructiveHint: false,
        idempotentHint: true,
        openWorldHint: false,
      },
    },
    (args) => syncPrelabProgressImpl(args, ctx),
  );

  server.registerTool(
    "record_concept_struggle",
    {
      title: "Record concept struggle",
      description:
        "Append an observational signal that the student is struggling with a specific topic. " +
        "Use sparingly — once per distinct struggle per conversation. " +
        "Goes into an instructor-facing signal log, not into personalization.",
      inputSchema: recordConceptStruggleSchema,
      annotations: {
        readOnlyHint: false,
        destructiveHint: false,
        idempotentHint: false,
        openWorldHint: false,
      },
    },
    (args) => recordConceptStruggleImpl(args, ctx),
  );

  server.registerTool(
    "submit_self_assessment",
    {
      title: "Submit self-assessment",
      description:
        "Record the student's own self-report on how confident they feel after studying. " +
        "Use only when the student explicitly provides a self-assessment (confidence 1-5).",
      inputSchema: submitSelfAssessmentSchema,
      annotations: {
        readOnlyHint: false,
        destructiveHint: false,
        idempotentHint: false,
        openWorldHint: false,
      },
    },
    (args) => submitSelfAssessmentImpl(args, ctx),
  );
}
