import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth/session";
import { checkOrigin } from "@/lib/auth/guards";
import { db } from "@/lib/db/client";
import { srsSessions } from "@/lib/db/schema";
import { isLabAccessible, isLabUnlocked } from "@/lib/portal/accessible-labs";
import { buildQueue, serveCard, type PracticeScope } from "@/lib/srs/queue";

const SCOPES: PracticeScope[] = ["lab", "external"];

export async function POST(req: Request) {
  const origin = checkOrigin(req);
  if (origin) return origin;

  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "unauthenticated" }, { status: 401 });

  const body = (await req.json().catch(() => null)) as
    | { labId?: string; scope?: string }
    | null;
  const labId = body?.labId;
  if (!labId) return NextResponse.json({ error: "labId required" }, { status: 400 });

  const scope = (body?.scope ?? "lab") as PracticeScope;
  if (!SCOPES.includes(scope)) {
    return NextResponse.json({ error: "invalid scope" }, { status: 400 });
  }

  // Lock gate. Staff preview any lab. For students, "playable" depends on where
  // the session was launched: the portal (scope "lab") requires the lab to be
  // both unlocked AND assigned to a class they're enrolled in; the standalone
  // practice hub (scope "external") only requires the lab to be unlocked
  // somewhere. Either way, a locked lab is never playable.
  const isStaff = user.role === "admin" || user.role === "faculty";
  if (!isStaff) {
    const allowed =
      scope === "lab"
        ? await isLabAccessible(user.id, labId)
        : await isLabUnlocked(labId);
    if (!allowed) {
      return NextResponse.json({ error: "lab not available" }, { status: 403 });
    }
  }

  const queue = await buildQueue(user.id, labId, 8, scope);
  if (queue.length === 0) {
    return NextResponse.json({ error: "nothing due", cards: [], sessionId: null }, { status: 200 });
  }

  const [session] = await db
    .insert(srsSessions)
    .values({ userId: user.id, labId, scope })
    .returning({ id: srsSessions.id });

  // Mint one srs_attempts row per card delivered to the client. Each carries
  // the rendered prompt, expected answer, options, and correct option as a
  // snapshot — reveal and rate look up the snapshot by attemptId instead of
  // re-reading the current question row (which may be edited or re-imported
  // mid-attempt).
  const served = await Promise.all(
    queue.map((q) => serveCard(user.id, q.cardId, session.id)),
  );
  const cards = served.filter((s): s is NonNullable<typeof s> => s !== null);

  return NextResponse.json({
    sessionId: session.id,
    cards,
  });
}
