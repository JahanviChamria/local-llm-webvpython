import numpy as np
import matplotlib.pyplot as plt

# num_steps = 10000  # Number of steps in the random walk
# step_size = 1     # Size of each step
#
# x = np.zeros(num_steps)
# y = np.zeros(num_steps)
#
# for i in range(1, num_steps):
#     # Generate a random direction (0: up, 1: down, 2: left, 3: right)
#     direction = np.random.randint(4)
#
#     # Update the position based on the chosen direction
#     if direction == 0:
#         y[i] = y[i - 1] + step_size
#     elif direction == 1:
#         y[i] = y[i - 1] - step_size
#     elif direction == 2:
#         x[i] = x[i - 1] - step_size
#     else:
#         x[i] = x[i - 1] + step_size
#
# plt.figure(figsize=(8, 6))
# plt.plot(x, y, marker='o', markersize=2)
# plt.title('2D Random Walk Simulation')
# plt.xlabel('X Position')
# plt.ylabel('Y Position')
# plt.grid(True)
# plt.show()

v0 = float(input("Enter initial velocity (m/s): "))
angle = float(input("Enter launch angle (degrees): "))
g = 9.81  # Acceleration due to gravity (m/s²)
angle_rad = np.radians(angle)
t_flight = (2 * v0 * np.sin(angle_rad)) / g
range_x = (v0 ** 2 * np.sin(2 * angle_rad)) / g
t = np.linspace(0, t_flight, num=100)  # Time values
x = v0 * np.cos(angle_rad) * t  # Horizontal position
y = v0 * np.sin(angle_rad) * t - (0.5 * g * t**2)  # Vertical position
plt.figure(figsize=(8, 6))
plt.plot(x, y)
plt.title("Projectile Motion")
plt.xlabel("Horizontal Distance (m)")
plt.ylabel("Vertical Distance (m)")
plt.grid(True)
plt.show()
print(f"Time of Flight: {t_flight:.2f} seconds")
print(f"Horizontal Range: {range_x:.2f} meters")


