"use client";

import { useEffect, useState } from "react";

// The course MCP endpoint students paste into Claude's custom-connector dialog.
// Same origin as the site; only this constant changes if the route ever moves.
const MCP_URL = "https://knowledgewithai.com/api/mcp";

// "How to connect Claude" button + popup for a single lab's prelab page. Shows
// the one-time connector setup and a ready-to-paste opening prompt scoped to
// THIS lab (so the model calls get_prelab for the right lab). Client-only: the
// lab name is passed down from the server component.
export function PrelabConnectHelp({ labName }: { labName: string }) {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  const prompt = `Hi, can we do the ${labName} Prelab from Knowledge With AI please?`;

  // Close on Escape while open, and lock body scroll behind the overlay.
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("keydown", onKey);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prevOverflow;
    };
  }, [open]);

  async function copyPrompt() {
    try {
      await navigator.clipboard.writeText(prompt);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Clipboard blocked (e.g. insecure context) — the prompt is on screen to
      // copy by hand, so just leave the button label unchanged.
    }
  }

  return (
    <>
      <button
        type="button"
        className="btn sm"
        onClick={() => setOpen(true)}
        style={{ borderColor: "var(--orange)", color: "var(--orange-mid)" }}
      >
        How to connect Claude
      </button>

      {open && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="How to connect Claude"
          onClick={() => setOpen(false)}
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 100,
            background: "rgba(20, 18, 15, 0.45)",
            display: "grid",
            placeItems: "center",
            padding: 16,
          }}
        >
          <div
            className="card"
            onClick={(e) => e.stopPropagation()}
            style={{
              maxWidth: 520,
              width: "100%",
              maxHeight: "85vh",
              overflowY: "auto",
              borderTop: "3px solid var(--orange)",
              display: "flex",
              flexDirection: "column",
              gap: 14,
            }}
          >
            <div className="row" style={{ justifyContent: "space-between", alignItems: "flex-start", gap: 12 }}>
              <div>
                <div className="section-label" style={{ color: "var(--orange-mid)" }}>
                  Connector · auto-sync
                </div>
                <h3 style={{ color: "var(--orange-mid)", margin: "2px 0 0" }}>
                  Do this prelab in Claude
                </h3>
              </div>
              <button
                type="button"
                className="btn sm"
                onClick={() => setOpen(false)}
                aria-label="Close"
              >
                Close
              </button>
            </div>

            <div className="col" style={{ gap: 6 }}>
              <div className="section-label">One-time setup</div>
              <p className="muted" style={{ fontSize: 13, lineHeight: 1.55, margin: 0 }}>
                Connect the course MCP once and every prelab flows straight back
                onto your progress page.
              </p>
              <ol
                className="muted"
                style={{ fontSize: 13, lineHeight: 1.6, margin: "2px 0 0", paddingLeft: 18 }}
              >
                <li>In Claude, open <strong>Settings → Connectors</strong>.</li>
                <li>Click <strong>Add custom connector</strong>.</li>
                <li>
                  Name it <strong>Knowledge With AI</strong> and paste this URL:
                  <code
                    className="mono"
                    style={{
                      display: "block",
                      marginTop: 6,
                      padding: "8px 10px",
                      background: "var(--surface)",
                      border: "1px solid var(--border)",
                      borderRadius: "var(--radius-sm)",
                      fontSize: 12,
                      wordBreak: "break-all",
                    }}
                  >
                    {MCP_URL}
                  </code>
                </li>
                <li>Click <strong>Add</strong>, then <strong>Connect</strong> and sign in with your student login.</li>
              </ol>
            </div>

            <div className="col" style={{ gap: 6 }}>
              <div className="section-label">Then just ask</div>
              <p className="muted" style={{ fontSize: 13, lineHeight: 1.55, margin: 0 }}>
                Start a new Claude chat and type this prompt:
              </p>
              <div
                style={{
                  display: "flex",
                  gap: 10,
                  alignItems: "center",
                  background: "var(--surface)",
                  border: "1px solid var(--border)",
                  borderRadius: "var(--radius-sm)",
                  padding: "10px 12px",
                }}
              >
                <span style={{ flexGrow: 1, fontSize: 13.5, lineHeight: 1.5 }}>
                  &ldquo;{prompt}&rdquo;
                </span>
                <button
                  type="button"
                  className="btn sm"
                  onClick={() => void copyPrompt()}
                  style={{ flex: "0 0 auto" }}
                >
                  {copied ? "Copied" : "Copy"}
                </button>
              </div>
              <p className="muted" style={{ fontSize: 12, lineHeight: 1.5, margin: 0 }}>
                Claude pulls up this prelab, walks you through it, and updates your
                Prelab progress page when you finish. You can also download a JSON
                summary and upload it manually if you prefer.
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
