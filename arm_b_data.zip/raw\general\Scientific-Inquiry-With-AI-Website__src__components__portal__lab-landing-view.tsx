import { notFound } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
import { getLabDetail } from "@/lib/portal/data";
import { NEW_LAB_DOC_SECTIONS, FACULTY_ONLY_KINDS } from "@/lib/portal/lab-sections";
import { NavIco } from "@/components/portal/primitives";
import { LabSectionCard } from "@/components/portal/lab-section-card";

export async function LabLandingView({ labId, basePath }: { labId: string; basePath: string }) {
  const detail = await getLabDetail(labId);
  if (!detail) notFound();

  const user = await getCurrentUser();
  const canSeeFaculty = user?.role === "faculty" || user?.role === "admin";

  const moduleNumber = String(detail.lab.moduleOrder).padStart(2, "0");

  // Faculty-only docs (instructor guide, lesson plan, answer key) don't count
  // toward the student-visible document tally — students never see those cards.
  const documentCount = Object.entries(detail.docsByKind).reduce(
    (n, [kind, files]) =>
      !canSeeFaculty && FACULTY_ONLY_KINDS.has(kind as (typeof NEW_LAB_DOC_SECTIONS)[number]["kind"])
        ? n
        : n + files.length,
    0,
  );
  const questionCount = detail.practiceLab?.total ?? 0;
  const simulationCount = detail.lab.hasSimulation && detail.simulation ? 1 : 0;

  type CardDef = {
    topTag: string;
    icon: React.ReactNode;
    title: string;
    href: string;
  };

  const cards: CardDef[] = [];

  if (detail.lab.hasPrelab) {
    cards.push({
      topTag: "READ FIRST",
      icon: <NavIco name="doc" />,
      title: "Prelab",
      href: `${basePath}/prelab`,
    });
  }

  if (detail.lab.hasPostlab) {
    cards.push({
      topTag: "SELF-CHECK",
      icon: <NavIco name="progress" />,
      title: "Postlab",
      href: `${basePath}/postlab`,
    });
  }

  if (detail.lab.hasPractice) {
    cards.push({
      topTag: questionCount > 0 ? `${questionCount} QUESTIONS` : "PRACTICE",
      icon: <NavIco name="recall" />,
      title: "Retrieval",
      href: `${basePath}/retrieval`,
    });
  }

  if (detail.lab.hasSimulation) {
    cards.push({
      topTag: "INTERACTIVE",
      icon: <NavIco name="sim" />,
      title: "Simulation",
      href: `${basePath}/simulation`,
    });
  }

  // The newer file-based sections, driven by the section registry. Faculty-only
  // sections (instructor guide, lesson plan, answer key) render their card only
  // for faculty/admin — students and guests never see them.
  for (const section of NEW_LAB_DOC_SECTIONS) {
    if (!detail.lab[section.hasFlag]) continue;
    if (section.facultyOnly && !canSeeFaculty) continue;
    cards.push({
      topTag: section.topTag,
      icon: <NavIco name={section.icon} />,
      title: section.title,
      href: `${basePath}/${section.routeSegment}`,
    });
  }

  return (
    <div className="col">
      <div className="screen-head">
        <div className="section-label">Lab {moduleNumber}</div>
        <h1>{detail.lab.name}</h1>
        {detail.lab.description && (
          <p className="lab-landing-desc">{detail.lab.description}</p>
        )}
        {(documentCount > 0 || questionCount > 0 || simulationCount > 0) && (
          <div className="lab-stat-row">
            {documentCount > 0 && (
              <span className="lab-stat-pill">
                <NavIco name="doc" />
                {documentCount} {documentCount === 1 ? "document" : "documents"}
              </span>
            )}
            {questionCount > 0 && (
              <span className="lab-stat-pill">
                <NavIco name="recall" />
                {questionCount} practice {questionCount === 1 ? "question" : "questions"}
              </span>
            )}
            {simulationCount > 0 && (
              <span className="lab-stat-pill">
                <NavIco name="sim" />
                {simulationCount} simulation
              </span>
            )}
          </div>
        )}
      </div>

      {cards.length === 0 ? (
        <p className="muted" style={{ fontSize: 14 }}>
          Nothing is published for this lab yet. Check back soon.
        </p>
      ) : (
        <div className="lab-grid">
          {cards.map((c, i) => (
            <LabSectionCard
              key={c.title}
              index={i + 1}
              topTag={c.topTag}
              icon={c.icon}
              title={c.title}
              href={c.href}
            />
          ))}
        </div>
      )}
    </div>
  );
}
