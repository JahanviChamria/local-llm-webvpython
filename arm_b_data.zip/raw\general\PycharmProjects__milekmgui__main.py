from tkinter import *

window=Tk()
window.title("Mile to Km Converter")
window.minsize(100,100)
window.config(padx=20, pady=20)


def action():
    newl=round(int(mile.get())*1.609, 2)
    ans.config(text=f"{newl}")


space=Label(text="  ")
space.grid(column=0, row=0)

mile=Entry(width=7)
mile.grid(column=1, row=0)

mlabel=Label(text="miles")
mlabel.grid(column=2, row=0)

iseqto=Label(text="is equal to")
iseqto.grid(row=1, column=0)

ans=Label(text=" ")
ans.grid(row=1, column=1)

klabel=Label(text="km")
klabel.grid(row=1, column=2)

button=Button(text="Calculate", command=action)
button.grid(row=2, column=1)
















window.mainloop()