import java.util.Arrays;


public class Lab03Client{
  
  
  public static void main(String[] args){
    
    
    //Below are the test cases provided to you in the lab writeup.
    //They are NOT SUFFICIENT!  You must add tests of your own
    //This will make up part of your lab grade!
    
    
    
    //****  2.1  ****
    
    //Before tackling the coding problems, complete the memory diagram exercise
    //in Lab03MemTrace.java per the instructions in the lab writeup!
    
    
    
    
    //*****  2.2 Tests  *****
    
    
     System.out.println("\n*** Test Longest Streak ***");


     int[] nums1 = {7, 2, 8, 4, 9, 10, 12};  
     boolean isEven1 = true;   
     int streak1 = Lab03Code.longestStreak(nums1, isEven1);
     System.out.println("longestStreak(" + Arrays.toString(nums1) + ", " + isEven1 + ") -> " + streak1);
    

     int[] nums2 = {2, 10, 14, 3, 7, 0, 1, 6};  
     boolean isEven2 = false;   
     int streak2 = Lab03Code.longestStreak(nums2, isEven2);
     System.out.println("longestStreak(" + Arrays.toString(nums2) + ", " + isEven2 + ") -> " + streak2);    
    
    
    //Add tests of your own!

     int[] nums3 = {3, 7, 0, 4, 8, 20, 6, 76, 0};
     boolean isEven3 = true;
     int streak3 = Lab03Code.longestStreak(nums3, isEven3);
     System.out.println("longestStreak(" + Arrays.toString(nums3) + ", " + isEven3 + ") -> " + streak3);

     int[] nums4 = {0, 0, 0};
     boolean isEven4 = false;
     int streak4 = Lab03Code.longestStreak(nums4, isEven4);
     System.out.println("longestStreak(" + Arrays.toString(nums4) + ", " + isEven4 + ") -> " + streak4);

     int[] nums5 = {2, 4, 10, 12};
     boolean isEven5 = false;
     int streak5 = Lab03Code.longestStreak(nums5, isEven5);
     System.out.println("longestStreak(" + Arrays.toString(nums5) + ", " + isEven5 + ") -> " + streak5);

     int[] nums6 = {10, 12, 18, 0, 2, 6, 10};
     boolean isEven6 = true;
     int streak6 = Lab03Code.longestStreak(nums6, isEven6);
     System.out.println("longestStreak(" + Arrays.toString(nums6) + ", " + isEven6 + ") -> " + streak6);






    
    //*****  2.3 Tests  *****
    
        
    System.out.println("\n\n*** Test Get Unique Suffixes ***");    
 



    String[] str1 = {"cat", "bat", "dog", "hog", "elk", "log"};
    int suff1 = 2;
    String[] uniques1 = Lab03Code.getUniqueSuffixes(str1, suff1);
    System.out.print("getUniqueSuffixes(" + Arrays.toString(str1));  
    System.out.println(", " + suff1  + ") -> " + Arrays.toString(uniques1));

    String[] str2 = {"deer", "cat", "bob cat", "steer", "REINDEER"};
    int suff2 = 3;
    String[] uniques2 = Lab03Code.getUniqueSuffixes(str2, suff2);
    System.out.print("getUniqueSuffixes(" + Arrays.toString(str2));  
    System.out.println(", " + suff2  + ") -> " + Arrays.toString(uniques2));    

    String[] str3 = {"catfish", "dogfish", "cat bird"};
    int suff3 = 0;
    String[] uniques3 = Lab03Code.getUniqueSuffixes(str3, suff3);
    System.out.print("getUniqueSuffixes(" + Arrays.toString(str3));
    System.out.println(", " + suff3  + ") -> " + Arrays.toString(uniques3));

    String[] str4 = {"catfish", "dogFISH", "frog", "deer", "reinDEER", "catbird"};
    int suff4 = 4;
    String[] uniques4 = Lab03Code.getUniqueSuffixes(str4, suff4);
    System.out.print("getUniqueSuffixes(" + Arrays.toString(str4));
    System.out.println(", " + suff4  + ") -> " + Arrays.toString(uniques4));

    String[] str5 = {"cat", "dog", "catbird", "parrot"};
    int suff5 = 4;
    String[] uniques5 = Lab03Code.getUniqueSuffixes(str5, suff5);
    System.out.print("getUniqueSuffixes(" + Arrays.toString(str5));
    System.out.println(", " + suff5  + ") -> " + Arrays.toString(uniques5));

    String[] str6 = {"dogfish", "dogfish", "bird", "frog", "lion"};
    int suff6 = 4;
    String[] uniques6 = Lab03Code.getUniqueSuffixes(str6, suff6);
    System.out.print("getUniqueSuffixes(" + Arrays.toString(str6));
    System.out.println(", " + suff6  + ") -> " + Arrays.toString(uniques6));

    String[] str7 = {"cat", "dog", "fish", "frog"};
    int suff7 = 5;
    String[] uniques7 = Lab03Code.getUniqueSuffixes(str7, suff7);
    System.out.print("getUniqueSuffixes(" + Arrays.toString(str7));
    System.out.println(", " + suff7  + ") -> " + Arrays.toString(uniques7));

    String[] str8 = {"helloWorld", "sourceCode", "openSource"};
    int suff8 = 5;
    String[] uniques8 = Lab03Code.getUniqueSuffixes(str8, suff8);
    System.out.print("getUniqueSuffixes(" + Arrays.toString(str8));
    System.out.println(", " + suff8  + ") -> " + Arrays.toString(uniques8));
    

    
    


    
    
  }
  
  
}
