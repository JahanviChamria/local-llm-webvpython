Web VPython 3.2
graph(width=400, height=250, background=color.white,  xtitle='<i>x</i>', ytitle='<i>y</i>')
xDots = gdots(color=color.green)
yDots = gdots(color=color.magenta)

movingSphere=sphere(pos=vector(0,0,0), make_trail=True, trail_type="points",   interval=1)
theta=0
x=0
t=0
y=0
r=5
while theta<pi*2:
    rate(50)
    x=r*cos(theta)
    y=r*sin(theta)
    movingSphere.pos=vector(x,y,0)
    xDots.plot(t,x)
    yDots.plot(t,y) 
    theta+=0.1
    t+=1
print("Animation over!")

