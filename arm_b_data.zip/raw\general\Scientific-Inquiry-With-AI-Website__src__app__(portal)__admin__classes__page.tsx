import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
import { listClassesForOwner } from "@/lib/admin/classes";
import { listAllClasses } from "@/lib/admin/all-classes";
import { Badge, Card } from "@/components/portal/primitives";

export const dynamic = "force-dynamic";

// Normalized row for rendering. `manageable` gates the Manage link: faculty own
// every row they see; admins see every class but can only manage their own.
type ClassRow = {
  id: string;
  name: string;
  studentCount: number;
  labCount: number;
  manageable: boolean;
  ownerUsername: string | null; // shown only for classes the viewer can't manage
};

export default async function AdminClassesPage() {
  const me = await getCurrentUser();
  if (!me) redirect("/login?next=/admin/classes");
  if (me.role !== "admin" && me.role !== "faculty") {
    return (
      <div className="col">
        <div className="screen-head">
          <div className="section-label">Restricted</div>
          <h1>Not available</h1>
        </div>
        <div className="callout orange">
          <strong>Faculty and admins only.</strong> Your account doesn&apos;t have access to classes.
        </div>
      </div>
    );
  }

  const isAdmin = me.role === "admin";

  // Admins get a read view of every class (management stays owner-scoped);
  // faculty get only the classes they own.
  const rows: ClassRow[] = isAdmin
    ? (await listAllClasses({ includeArchived: false })).map((c) => ({
        id: c.id,
        name: c.name,
        studentCount: c.studentCount,
        labCount: c.labCount,
        manageable: c.ownerId === me.id,
        ownerUsername: c.ownerId === me.id ? null : c.ownerUsername,
      }))
    : (await listClassesForOwner(me.id, { includeArchived: false })).map((c) => ({
        id: c.id,
        name: c.name,
        studentCount: c.studentCount,
        labCount: c.labCount,
        manageable: true,
        ownerUsername: null,
      }));

  return (
    <div className="col">
      <div className="screen-head">
        <div className="section-label">Teaching</div>
        <h1>Classes</h1>
        <p className="lead muted">
          {isAdmin ? (
            <>
              Every class across all faculty. You can manage the classes you own; the rest are
              read-only. To reassign a class, use <Link href="/admin/all-classes">All classes</Link>.
            </>
          ) : (
            <>
              Group students you teach into classes and assign them specific labs. Students see only
              their enrolled classes&apos; labs in the sidebar.
            </>
          )}
        </p>
        <div className="row" style={{ gap: 9, marginTop: 9 }}>
          <Link className="btn primary sm" href="/admin/classes/new">
            New class
          </Link>
          <Link className="btn ghost sm" href="/admin/classes/archived">
            Archived
          </Link>
        </div>
      </div>

      {rows.length === 0 ? (
        <Card>
          <p className="muted" style={{ fontSize: 13 }}>
            {isAdmin ? (
              <>No classes exist yet. Click <b>New class</b> to create one.</>
            ) : (
              <>You don&apos;t own any classes yet. Click <b>New class</b> to create one.</>
            )}
          </p>
        </Card>
      ) : (
        <div className="col" style={{ gap: 14 }}>
          {rows.map((c) => (
            <Card key={c.id} title={c.name}>
              <div className="row" style={{ gap: 9, alignItems: "center" }}>
                <Badge kind="progress">
                  {c.studentCount} student{c.studentCount === 1 ? "" : "s"}
                </Badge>
                <Badge kind="default">
                  {c.labCount} lab{c.labCount === 1 ? "" : "s"}
                </Badge>
                {c.ownerUsername ? (
                  <Badge kind="default">owner: {c.ownerUsername}</Badge>
                ) : null}
                <span className="grow" />
                {c.manageable ? (
                  <Link className="btn primary sm" href={`/admin/classes/${c.id}`}>
                    Manage →
                  </Link>
                ) : (
                  <span className="label" style={{ fontSize: 11 }}>
                    Read-only
                  </span>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
