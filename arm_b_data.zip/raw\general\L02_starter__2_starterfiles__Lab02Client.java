public class Lab02Client{

    public static void main(String[] args){

        System.out.println("Hello World! You're ready for Lab 02!");

        //Below are the test cases provided to you in the lab writeup.
        //They are NOT SUFFICIENT!  You must add tests of your own
        //This will make up part of your lab grade!


        //*****  2.1 Tests  *****
       
        /*


        System.out.println("\n\n*** Get Order ***");
        System.out.println("\t getOrder(153) -> " + Lab02Code.getOrder(153));
        System.out.println("\t getOrder(-451) -> " + Lab02Code.getOrder(-451));
        System.out.println("\t getOrder(7) -> " + Lab02Code.getOrder(7));                
        System.out.println("\t getOrder(0) -> " + Lab02Code.getOrder(0));
        System.out.println("\t getOrder(10671) -> " + Lab02Code.getOrder(10671));
        System.out.println("\t getOrder(100) -> " + Lab02Code.getOrder(100));
        System.out.println("\t getOrder(016) -> " + Lab02Code.getOrder(016));



        */





        //*****  2.2 Tests  *****

        /*



        System.out.println("\n\n*** Is Armstrong ***");
        
        System.out.println("\t isArmstrong(153) -> " + Lab02Code.isArmstrong(153));
        System.out.println("\t isArmstrong(154) -> " + Lab02Code.isArmstrong(154));
        System.out.println("\t isArmstrong(-153) -> " + Lab02Code.isArmstrong(-153));
        System.out.println("\t isArmstrong(1634) -> " + Lab02Code.isArmstrong(1634));
        System.out.println("\t isArmstrong(-1) -> " + Lab02Code.isArmstrong(-1));
        System.out.println("\t isArmstrong(8) -> " + Lab02Code.isArmstrong(8));
        System.out.println("\t isArmstrong(10) -> " + Lab02Code.isArmstrong(10));
 
        */








        //*****  2.3 Tests  *****


        /*

        System.out.println("\n\n*** Find Armstrong Count ***");
        int facResult = 0;

        System.out.print("\t findArmstrongCount(5, 500, true) -> prints: ");
        facResult = Lab02Code.findArmstrongCount(5, 500, true);
        System.out.println("\n\t returns: " + facResult + "\n\n");


        System.out.print("\t findArmstrongCount(9000, 1000, false) -> prints: ");
        facResult = Lab02Code.findArmstrongCount(9000, 1000, false);
        System.out.println("\n\t returns: " + facResult + "\n\n");      
        

        System.out.print("\t findArmstrongCount(-5, 5, true) -> prints: ");
        facResult = Lab02Code.findArmstrongCount(-5, 5, true);
        System.out.println("\n\t returns: " + facResult + "\n\n");

        System.out.print("\t findArmstrongCount(-100, 2, true) -> prints: ");
        facResult = Lab02Code.findArmstrongCount(-100, 2, true);
        System.out.println("\n\t returns: " + facResult + "\n\n");

        System.out.print("\t findArmstrongCount(2000, -150, true) -> prints: ");
        facResult = Lab02Code.findArmstrongCount(2000, -150, true);
        System.out.println("\n\t returns: " + facResult + "\n\n");

        System.out.print("\t findArmstrongCount(0, 30, false) -> prints: ");
        facResult = Lab02Code.findArmstrongCount(0, 30, false);
        System.out.println("\n\t returns: " + facResult + "\n\n");

        System.out.print("\t findArmstrongCount(20, 100, true) -> prints: ");
        facResult = Lab02Code.findArmstrongCount(20, 100, true);
        System.out.println("\n\t returns: " + facResult + "\n\n");



        */







        //*****  2.4 Tests  *****


        /*

        System.out.println("\n\n*** Advance Letter ***");
        
        System.out.println("\t advanceLetter('C', -5) -> " + Lab02Code.advanceLetter('C', -5));
        System.out.println("\t advanceLetter('%', 15) -> " + Lab02Code.advanceLetter('%', 15));
        System.out.println("\t advanceLetter('Q', 4187) -> " + Lab02Code.advanceLetter('Q', 4187));
        System.out.println("\t advanceLetter('Z', -200) -> " + Lab02Code.advanceLetter('Z', -200));
        System.out.println("\t advanceLetter('A', -26) -> " + Lab02Code.advanceLetter('A', -26));
        System.out.println("\t advanceLetter('M', 0) -> " + Lab02Code.advanceLetter('M', 0));
        System.out.println("\t advanceLetter('9', 30) -> " + Lab02Code.advanceLetter('9', 30));
        System.out.println("\t advanceLetter('Y', 17) -> " + Lab02Code.advanceLetter('Y', 17));
        System.out.println("\t advanceLetter('k', 11) -> " + Lab02Code.advanceLetter('k', 11));
 


        */






        //*****  2.5 Tests  *****

        /*


        System.out.println("\n\n*** Roll 'til Doubles ***");
        int rtdResult = 0;

        for(int i=1;i<=5;i++){                 //running a loop to test the code and execute the function
            System.out.print("\t rollTilDoubles(true) -> prints: ");
            rtdResult = Lab02Code.rollTilDoubles(true);
            System.out.println("\n\t returns: " + rtdResult + "\n\n");
        }

        System.out.print("\t rollTilDoubles(false) -> prints: ");
        rtdResult = Lab02Code.rollTilDoubles(false);
        System.out.println("\n\t returns: " + rtdResult + "\n\n");

        for(int j=1;j<=1000;j++){         //executing the function a 1000 times to calculate the total no. of rolls
            rtdResult += Lab02Code.rollTilDoubles(false);
        }

        System.out.println("Average number of rolls required:"+(rtdResult/1000));
        //calculating the average number of rolls required before getting a double (it should be 6 because the probability is 1/6).


        */


    }


}
