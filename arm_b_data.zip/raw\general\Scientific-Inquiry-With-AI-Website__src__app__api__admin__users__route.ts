import { NextResponse } from "next/server";
import { z } from "zod";
import { desc } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { users } from "@/lib/db/schema";
import { requireAdmin, checkOrigin } from "@/lib/auth/guards";
import { hashPassword } from "@/lib/auth/password";
import { usernameField, passwordField } from "@/lib/auth/credentials-schema";
import { ensureStudentProfile } from "@/lib/student-profiles/ensure";

export const runtime = "nodejs";

const displayNameField = z.string().max(120).optional();

const createSchema = z.discriminatedUnion("role", [
  z.object({
    role: z.literal("admin"),
    username: usernameField,
    password: passwordField,
    display_name: displayNameField,
  }),
  z.object({
    role: z.literal("faculty"),
    username: usernameField,
    password: passwordField,
    display_name: displayNameField,
  }),
  z.object({
    role: z.literal("student"),
    username: usernameField,
    password: passwordField,
    display_name: displayNameField,
  }),
  z.object({
    role: z.literal("guest"),
    username: usernameField,
    password: passwordField,
    display_name: displayNameField,
  }),
]);

export async function GET() {
  // authz: requireAdmin
  const g = await requireAdmin();
  if (g instanceof NextResponse) return g;

  const rows = await db
    .select({
      id: users.id,
      username: users.username,
      role: users.role,
      displayName: users.displayName,
      createdAt: users.createdAt,
      lastLoginAt: users.lastLoginAt,
      expiresAt: users.expiresAt,
    })
    .from(users)
    .orderBy(desc(users.createdAt));
  return NextResponse.json({ users: rows });
}

export async function POST(req: Request) {
  const csrf = checkOrigin(req);
  if (csrf) return csrf;
  // authz: requireAdmin
  const g = await requireAdmin();
  if (g instanceof NextResponse) return g;

  let body: z.infer<typeof createSchema>;
  try {
    body = createSchema.parse(await req.json());
  } catch (err) {
    return NextResponse.json({ error: "invalid body", detail: String(err) }, { status: 400 });
  }

  try {
    const hash = await hashPassword(body.password);
    const [row] = await db
      .insert(users)
      .values({
        username: body.username,
        passwordHash: hash,
        role: body.role,
        displayName: body.display_name,
      })
      .returning({
        id: users.id,
        username: users.username,
        role: users.role,
        expiresAt: users.expiresAt,
      });
    // Bootstrap a profile row for student accounts so AI writebacks have a
    // target (those paths only UPDATE, never INSERT).
    if (row.role === "student") {
      await ensureStudentProfile(row.id);
    }
    return NextResponse.json({ user: row });
  } catch (err) {
    const e = err as { code?: string; message?: string };
    if (e?.code === "23505") {
      return NextResponse.json({ error: "username already exists" }, { status: 409 });
    }
    return NextResponse.json({ error: "insert failed", detail: e?.message }, { status: 500 });
  }
}
