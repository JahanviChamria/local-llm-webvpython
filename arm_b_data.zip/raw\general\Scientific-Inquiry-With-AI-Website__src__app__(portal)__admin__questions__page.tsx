import Link from "next/link";
import { redirect } from "next/navigation";
import { asc, desc, eq } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { labs, questionFamilies, questions } from "@/lib/db/schema";
import { getCurrentUser } from "@/lib/auth/session";
import { AdminQuestionsClient } from "./client";

export const dynamic = "force-dynamic";

export default async function AdminQuestionsPage() {
  const me = await getCurrentUser();
  if (!me) redirect("/login?next=/admin/questions");
  if (me.role !== "admin" && me.role !== "faculty") {
    return (
      <div className="col">
        <div className="screen-head">
          <div className="section-label">Restricted</div>
          <h1>Not available</h1>
        </div>
        <div className="callout orange">
          <strong>Faculty and admins only.</strong> Your account doesn&apos;t have access to lab questions.
        </div>
      </div>
    );
  }

  // Flat rows, ordered by updated_at desc. Do NOT group by lab here: with
  // LIMIT 200 a server-side group would silently truncate rows out of the
  // middle of groups.
  const rows = await db
    .select({
      id: questions.id,
      labId: questions.labId,
      labName: labs.name,
      difficulty: questions.difficulty,
      prompt: questions.prompt,
      expectedAnswer: questions.expectedAnswer,
      createdAt: questions.createdAt,
      updatedAt: questions.updatedAt,
      format: questions.format,
      role: questions.role,
      variantKey: questions.variantKey,
      familyBankKey: questionFamilies.bankKey,
    })
    .from(questions)
    .innerJoin(labs, eq(labs.id, questions.labId))
    .leftJoin(questionFamilies, eq(questionFamilies.id, questions.familyId))
    .orderBy(desc(questions.updatedAt))
    .limit(200);

  const labList = await db
    .select({ id: labs.id, name: labs.name })
    .from(labs)
    .orderBy(asc(labs.name))
    .limit(500);

  return (
    <div className="col">
      <div className="screen-head">
        <div className="section-label">Admin</div>
        <h1>Retrieval Tool Questions</h1>
        <p className="lead muted">
          Author the retrieval-practice questions for each lab. These seed students&apos; spaced-repetition queues.
        </p>
        {me.role === "admin" && (
          <div className="row" style={{ gap: 9, marginTop: 10 }}>
            <Link href="/admin/labs/import" className="btn primary sm">
              Import bank from JSON →
            </Link>
            <span className="muted" style={{ fontSize: 12, alignSelf: "center" }}>
              Drop a bank JSON + figure images to bulk-create families and variants at once.
            </span>
          </div>
        )}
      </div>
      <AdminQuestionsClient questions={rows} labs={labList} isAdmin={me.role === "admin"} />
    </div>
  );
}
