import { createHash } from "node:crypto";
import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { z } from "zod";
import { eq } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { authAudit, users } from "@/lib/db/schema";
import { checkOrigin } from "@/lib/auth/guards";
import {
  isAllowed,
  prefixedIpHashFromRequest,
  MAX_GOOGLE_PER_IP,
} from "@/lib/auth/rate-limit";
import { verifyGoogleIdToken } from "@/lib/auth/google";
import { isUcMercedWorkspace } from "@/lib/auth/ucmerced";
import { usernameFromEmail } from "@/lib/auth/username-from-email";
import { ensureStudentProfile } from "@/lib/student-profiles/ensure";
import { createSession, setSessionCookie } from "@/lib/auth/session";
import { GOOGLE_NONCE_COOKIE } from "@/lib/auth/google-nonce";

export const runtime = "nodejs";

const bodySchema = z.object({ credential: z.string().min(1) });
const FAIL = { error: "invalid credentials" } as const;

function hashEmail(email: string): string {
  return createHash("sha256").update(email).digest("hex");
}

async function audit(event: string, opts: {
  userId?: string | null;
  email?: string | null;
  detail?: Record<string, unknown> | null;
}): Promise<void> {
  await db.insert(authAudit).values({
    event,
    userId: opts.userId ?? null,
    emailHash: opts.email ? hashEmail(opts.email) : null,
    detail: opts.detail ? JSON.stringify(opts.detail) : null,
  });
}

export async function POST(req: Request) {
  const csrf = checkOrigin(req);
  if (csrf) return csrf;

  const ipBucket = prefixedIpHashFromRequest("google:", req);
  if (!(await isAllowed(ipBucket, MAX_GOOGLE_PER_IP))) {
    return NextResponse.json({ error: "too many attempts" }, { status: 429 });
  }

  const jar = await cookies();
  const nonce = jar.get(GOOGLE_NONCE_COOKIE)?.value;
  jar.delete(GOOGLE_NONCE_COOKIE);
  if (!nonce) return NextResponse.json(FAIL, { status: 401 });

  let body: z.infer<typeof bodySchema>;
  try {
    body = bodySchema.parse(await req.json());
  } catch {
    return NextResponse.json(FAIL, { status: 401 });
  }

  let verified;
  try {
    verified = await verifyGoogleIdToken(body.credential, nonce);
  } catch {
    return NextResponse.json(FAIL, { status: 401 });
  }
  const { sub, email, name, hostedDomain } = verified;

  const bySub = await db.select().from(users).where(eq(users.googleSub, sub)).limit(1);
  if (bySub[0]) {
    const user = bySub[0];
    await db.update(users).set({ lastLoginAt: new Date() }).where(eq(users.id, user.id));
    const sessionId = await createSession(user.id);
    await setSessionCookie(sessionId);
    return NextResponse.json({
      user: {
        id: user.id,
        username: user.username,
        role: user.role,
        display_name: user.displayName,
      },
    });
  }

  const byEmail = await db.select().from(users).where(eq(users.email, email)).limit(1);
  const existing = byEmail[0];

  if (existing) {
    if (existing.emailVerifiedAt) {
      if (existing.googleSub && existing.googleSub !== sub) {
        await audit("google.sub_mismatch", {
          userId: existing.id,
          email,
          detail: { reason: "verified_with_different_sub" },
        });
        return NextResponse.json(FAIL, { status: 401 });
      }
      await db
        .update(users)
        .set({ googleSub: sub, lastLoginAt: new Date() })
        .where(eq(users.id, existing.id));
      const sessionId = await createSession(existing.id);
      await setSessionCookie(sessionId);
      return NextResponse.json({
        user: {
          id: existing.id,
          username: existing.username,
          role: existing.role,
          display_name: existing.displayName,
        },
      });
    }

    if (existing.googleSub) {
      if (existing.googleSub === sub) {
        await audit("google.inconsistent_state", {
          userId: existing.id,
          email,
          detail: { reason: "googleSub_set_but_emailVerifiedAt_null", sameSub: true },
        });
        await db
          .update(users)
          .set({ emailVerifiedAt: new Date(), lastLoginAt: new Date() })
          .where(eq(users.id, existing.id));
        const sessionId = await createSession(existing.id);
        await setSessionCookie(sessionId);
        return NextResponse.json({
          user: {
            id: existing.id,
            username: existing.username,
            role: existing.role,
            display_name: existing.displayName,
          },
        });
      }
      await audit("google.inconsistent_state", {
        userId: existing.id,
        email,
        detail: { reason: "googleSub_set_but_emailVerifiedAt_null", sameSub: false },
      });
      return NextResponse.json(FAIL, { status: 401 });
    }
  }

  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const userId = await db.transaction(async (tx) => {
        if (existing && !existing.emailVerifiedAt && !existing.googleSub && existing.passwordHash) {
          await tx.delete(users).where(eq(users.id, existing.id));
          await tx.insert(authAudit).values({
            event: "google.squatter_deleted",
            userId: existing.id,
            emailHash: hashEmail(email),
            detail: JSON.stringify({ deletedUsername: existing.username }),
          });
        }
        const username = await usernameFromEmail(email);
        const [inserted] = await tx
          .insert(users)
          .values({
            username,
            email,
            googleSub: sub,
            emailVerifiedAt: new Date(),
            displayName: name,
            role: isUcMercedWorkspace(email, hostedDomain) ? "student" : "guest",
            passwordHash: null,
            lastLoginAt: new Date(),
          })
          .returning({
            id: users.id,
            username: users.username,
            role: users.role,
            displayName: users.displayName,
          });
        // UC Merced workspace accounts land as "student" — bootstrap the
        // profile row so AI writebacks have a target. Guests get none (the
        // writeback paths reject guests anyway).
        if (inserted.role === "student") {
          await ensureStudentProfile(inserted.id, tx);
        }
        return inserted;
      });
      const sessionId = await createSession(userId.id);
      await setSessionCookie(sessionId);
      return NextResponse.json({
        user: {
          id: userId.id,
          username: userId.username,
          role: userId.role,
          display_name: userId.displayName,
        },
      });
    } catch (err) {
      const code = (err as { code?: string } | undefined)?.code;
      if (code === "23505" && attempt < 2) {
        continue;
      }
      console.error("[google] insert failed:", err);
      return NextResponse.json(FAIL, { status: 401 });
    }
  }

  return NextResponse.json(FAIL, { status: 401 });
}
