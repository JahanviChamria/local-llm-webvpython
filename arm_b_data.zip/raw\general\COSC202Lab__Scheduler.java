import java.util.*;

public class Scheduler {

    public static HashMap<Integer, Integer> assignRooms(
	int R,                        /* number of rooms */
	ArrayList<Integer> start,     /* meeting start times indexed by ID */
	ArrayList<Integer> finish     /* meeting finish times indexed by ID */
    ) {
        int n = start.size();
        if (n != finish.size()) 
            return null; //mismatch

        //create array of meeting indices
        Integer[] order = new Integer[n];
        for (int i = 0; i < n; i++) 
            order[i] = i;

        Arrays.sort(order, new Comparator<Integer>() { //sort by start times and break ties by finish times
            public int compare(Integer a, Integer b) {
                if (!start.get(a).equals(start.get(b))) {
                    return start.get(a) - start.get(b);
                }
                return finish.get(a) - finish.get(b);
            }
        });

        
        //initialize free rooms
        Queue<Integer> freeRooms = new LinkedList<>();
        for (int r = 0; r < R; r++) 
            freeRooms.add(r);

        //min-heap of finish times
        PriorityQueue<Integer> heap = new PriorityQueue<>();

        //map finishTime and roomId
        HashMap<Integer, Integer> finishRoomMap = new HashMap<>();

        //final
        HashMap<Integer, Integer> assignment = new HashMap<>();

        //schedule meetings 
        for (int idx : order) {
            int s = start.get(idx);
            int f = finish.get(idx);

            //meetings ended
            while (!heap.isEmpty() && heap.peek() <= s) {
                int finishedTime = heap.poll();
                freeRooms.add(finishRoomMap.get(finishedTime));
            }

            //assign a room if available
            if (!freeRooms.isEmpty()) {
                int room = freeRooms.poll();
                assignment.put(idx, room);
                heap.add(f);
                finishRoomMap.put(f, room);
            } 
            else {
                if (heap.size() < R) { //if all rooms used, check if we can open a new one
                    int room = heap.size();
                    assignment.put(idx, room);
                    heap.add(f);
                    finishRoomMap.put(f, room);
                } else {
                    //not possible to schedule within R rooms
                    return null;
                }
            }
        }
        return assignment;
    }

    public static void main(String[] args) {
        int R = 3;
        ArrayList<Integer> start = new ArrayList<>(Arrays.asList(1, 3, 0, 5, 8, 5));
        ArrayList<Integer> finish = new ArrayList<>(Arrays.asList(2, 4, 6, 7, 9, 9));

        HashMap<Integer, Integer> schedule = assignRooms(R, start, finish);

        if (schedule == null) {
            System.out.println("No valid schedule possible with " + R + " rooms.");
        } else {
            System.out.println("Meeting assignments:");
            for (int i = 0; i < start.size(); i++) {
                System.out.println("Meeting " + (i+1) + " (" + start.get(i) + "-" + finish.get(i) + ") -> Room " + (schedule.get(i)+1));
            }
        }
    }
}