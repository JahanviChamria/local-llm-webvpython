size(600,400);

background(149,226,255,200);

noStroke();

fill(143,191,102);
rect(0,180,600,220);

fill(237,213,77);
ellipse(260,110,100,60);

fill(110,116,118);
triangle(200,180,375,25,590,180);
fill(145,158,165);
triangle(300,180,450,40,600,180);
fill(182,184,185);
triangle(0,180,100,30,350,180);

fill(108,65,30);
rect(0,0,30,180);
rect(50,0,48,210);
rect(480,0,50,180);
rect(565,0,35,180);
fill(137,84,40);
rect(515,0,40,220);

fill(85,66,42);
triangle(175,160,225,160,175,210);
beginShape();
vertex(225,160);
vertex(250,185);
vertex(220,210);
vertex(190,185);
endShape();
rect(220,185,125,60);
triangle(220,210,220,290,200,255);
beginShape();
vertex(345,185);
vertex(375,210);
vertex(395,250);
vertex(365,230);
endShape();
triangle(335,245,345,245,345,265);
beginShape();
vertex(335,245);
vertex(345,290);
vertex(315,305);
endShape();

fill(255,255,255);
rect(0,295,175,10);
rect(20,275,20,125);
rect(60,275,20,125);
rect(100,275,20,125);
rect(140,275,20,125);

fill(59,121,50);
ellipse(570,330,100,100);
ellipse(500,350,100,100);
ellipse(450,390,80,80);

fill(123,180,115);
ellipse(570,380,120,90);
ellipse(480,400,75,75);
