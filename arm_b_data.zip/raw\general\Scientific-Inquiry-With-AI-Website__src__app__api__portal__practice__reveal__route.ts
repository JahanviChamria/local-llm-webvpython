import { NextResponse } from "next/server";
import { and, eq, isNull, sql } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth/session";
import { checkOrigin } from "@/lib/auth/guards";
import { db } from "@/lib/db/client";
import {
  questionFamilies,
  questions,
  srsAttempts,
  srsCards,
  srsReviews,
  srsSessions,
} from "@/lib/db/schema";
import { formatInterval, schedule, type ScheduleResult, type SrsRating } from "@/lib/srs/scheduler";
import {
  clampElapsedMs,
  computeTimeFactor,
  deriveAutoRating,
  effectiveBaseline,
  estimateReadMs,
  nextBaseline,
  thinkingMs,
} from "@/lib/srs/timing";
import { gradeWithAI } from "@/lib/practice/ai-grade";
import { gradeByKeywords } from "@/lib/practice/keyword-grade";

// The AI grading call can take several seconds on top of DB roundtrips.
export const maxDuration = 30;

// Reads the attempt snapshot (taken at serve time) and returns the literal
// expected answer the student saw. Never re-renders from the current question
// row — that would break the invariant that the expected answer matches the
// exact instance the student saw, if the question or family was edited
// mid-attempt.
//
// Every format is now rated and scheduled here, in one transaction:
//  - Choice formats (MC/TF): the server objectively knows correctness and
//    derives the rating from correctness + response time vs. baseline.
//  - Free-response (short answer / calculation): students get an AI grade
//    (Claude picks the rating and writes feedback); other roles — and any AI
//    failure — fall back to keyword matching against the expected answer.
// The client never sends a rating; /rate remains only as a legacy fallback.
export async function POST(req: Request) {
  const origin = checkOrigin(req);
  if (origin) return origin;

  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "unauthenticated" }, { status: 401 });

  const body = (await req.json().catch(() => null)) as
    | {
        attemptId?: string;
        // back-compat: clients may still send cardId during the transition
        cardId?: string;
        answerText?: string;
        selectedOption?: string;
        elapsedMs?: number;
        sessionId?: string;
      }
    | null;
  const attemptId = body?.attemptId;
  if (!attemptId)
    return NextResponse.json({ error: "attemptId required" }, { status: 400 });

  const [attempt] = await db
    .select({
      id: srsAttempts.id,
      userId: srsAttempts.userId,
      cardId: srsAttempts.cardId,
      questionId: srsAttempts.questionId,
      ratedAt: srsAttempts.ratedAt,
      startedAt: srsAttempts.startedAt,
      draw: srsAttempts.draw,
      wasCorrect: srsAttempts.wasCorrect,
      promptSnapshot: srsAttempts.promptSnapshot,
      expectedAnswerSnapshot: srsAttempts.expectedAnswerSnapshot,
      correctOptionSnapshot: srsAttempts.correctOptionSnapshot,
      state: srsCards.state,
      reps: srsCards.reps,
      lapses: srsCards.lapses,
      ease: srsCards.ease,
      intervalDays: srsCards.intervalDays,
      cardDue: srsCards.due,
      scope: srsCards.scope,
      format: questions.format,
      baselineAnswerMs: questions.baselineAnswerMs,
      baselineSampleCount: questions.baselineSampleCount,
      familyConcept: questionFamilies.concept,
      familyAnswerCore: questionFamilies.answerCore,
      familyFailureModes: questionFamilies.failureModes,
    })
    .from(srsAttempts)
    .innerJoin(srsCards, eq(srsCards.id, srsAttempts.cardId))
    .innerJoin(questions, eq(questions.id, srsAttempts.questionId))
    .leftJoin(questionFamilies, eq(questionFamilies.id, questions.familyId))
    .where(and(eq(srsAttempts.id, attemptId), eq(srsAttempts.userId, user.id)))
    .limit(1);

  if (!attempt)
    return NextResponse.json({ error: "attempt not found" }, { status: 404 });

  const isChoice = attempt.correctOptionSnapshot != null;

  // Idempotent retry: a rated reveal that already landed rebuilds its response
  // from stored state rather than re-scheduling.
  if (attempt.ratedAt) {
    return NextResponse.json(
      await ratedResponseBody({
        id: attempt.id,
        expectedAnswerSnapshot: attempt.expectedAnswerSnapshot,
        correctOptionSnapshot: attempt.correctOptionSnapshot,
        wasCorrect: attempt.wasCorrect,
        intervalDays: attempt.intervalDays,
        cardDue: attempt.cardDue,
      }),
    );
  }

  const now = new Date();
  const t = clampElapsedMs(body?.elapsedMs, attempt.startedAt, now);
  const baseline = effectiveBaseline(
    attempt.baselineAnswerMs,
    attempt.baselineSampleCount,
    attempt.format,
    attempt.promptSnapshot.length,
  );
  // Subtract estimated reading time from both the measured time and the
  // baseline so the difficulty signal reflects recall speed, not prompt length.
  // `t`/`baseline` stay full-elapsed for storage and the baseline EWMA below.
  const readMs = estimateReadMs(attempt.promptSnapshot.length, baseline);
  const tThink = t == null ? null : thinkingMs(t, readMs);
  const baselineThink = thinkingMs(baseline, readMs);
  const tf = computeTimeFactor(tThink, baselineThink);

  const wasCorrect =
    isChoice && body?.selectedOption != null
      ? body.selectedOption === attempt.correctOptionSnapshot
      : null;

  const cardSchedule = {
    state: attempt.state,
    reps: attempt.reps,
    lapses: attempt.lapses,
    ease: attempt.ease,
    intervalDays: attempt.intervalDays,
  };

  if (wasCorrect != null) {
    // Choice format: derive the rating from correctness + reading-adjusted speed.
    const autoRating = deriveAutoRating(wasCorrect, tThink, baselineThink);
    const next = schedule(cardSchedule, autoRating, now, { timeFactor: tf });

    const claimed = await finalizeRating({
      userId: user.id,
      attempt,
      rating: autoRating,
      ratingSource: "auto",
      aiFeedback: null,
      wasCorrect,
      storedAnswer: body?.selectedOption ?? null,
      t,
      tf,
      next,
      now,
      updateBaseline: wasCorrect && t != null,
    });
    if (!claimed) return NextResponse.json(await raceLostResponse(attempt));

    await bumpSessionCount(body?.sessionId, user.id);

    return NextResponse.json({
      alreadyRated: false,
      expectedAnswer: attempt.expectedAnswerSnapshot,
      correctOption: attempt.correctOptionSnapshot,
      wasCorrect,
      feedback: null,
      gradedBy: null,
      autoRating,
      nextDueLabel: formatInterval(next.intervalDays),
      intervalAfter: next.intervalDays,
      due: next.due,
      intervals: null,
    });
  }

  // Free-response: grade server-side. Students get the AI grader; everyone
  // else — and any AI failure/timeout/missing key — gets keyword matching.
  // The AI call happens before the transaction: never hold one open across an
  // outbound HTTP request.
  const studentAnswer = (body?.answerText ?? "").trim();
  const ai =
    studentAnswer !== "" && user.role === "student"
      ? await gradeWithAI({
          prompt: attempt.promptSnapshot,
          expectedAnswer: attempt.expectedAnswerSnapshot,
          studentAnswer,
          format: attempt.format,
          concept: attempt.familyConcept,
          answerCore: attempt.familyAnswerCore,
          failureModes: toStringArray(attempt.familyFailureModes),
        })
      : null;
  const kw = ai ? null : gradeByKeywords(attempt.expectedAnswerSnapshot, studentAnswer);
  const rating: SrsRating = ai ? ai.rating : kw!.rating;
  const feedback = ai ? ai.feedback : kw!.feedback;

  const next = schedule(cardSchedule, rating, now, { timeFactor: tf });

  const claimed = await finalizeRating({
    userId: user.id,
    attempt,
    rating,
    ratingSource: ai ? "ai" : "auto",
    aiFeedback: feedback,
    wasCorrect: null,
    storedAnswer: studentAnswer || null,
    t,
    tf,
    next,
    now,
    updateBaseline: (rating === "good" || rating === "easy") && t != null,
  });
  if (!claimed) return NextResponse.json(await raceLostResponse(attempt));

  await bumpSessionCount(body?.sessionId, user.id);

  return NextResponse.json({
    alreadyRated: false,
    expectedAnswer: attempt.expectedAnswerSnapshot,
    correctOption: null,
    wasCorrect: null,
    feedback,
    gradedBy: ai ? "ai" : "keyword",
    autoRating: rating,
    nextDueLabel: formatInterval(next.intervalDays),
    intervalAfter: next.intervalDays,
    due: next.due,
    intervals: null,
  });
}

type FinalizeArgs = {
  userId: string;
  attempt: {
    id: string;
    cardId: string;
    questionId: string;
    scope: "lab" | "external";
    draw: unknown;
    intervalDays: number;
    baselineAnswerMs: number | null;
    baselineSampleCount: number;
  };
  rating: SrsRating;
  ratingSource: "auto" | "ai";
  aiFeedback: string | null;
  wasCorrect: boolean | null;
  storedAnswer: string | null;
  t: number | null;
  tf: number;
  next: ScheduleResult;
  now: Date;
  updateBaseline: boolean;
};

// Applies a rating atomically. The conditional claim on rated_at closes the
// double-submit race — with the multi-second AI call between read and write,
// concurrent reveals for the same attempt are realistic, and a lost race must
// not double-insert reviews or double-advance the schedule.
async function finalizeRating(args: FinalizeArgs): Promise<boolean> {
  const { userId, attempt, rating, ratingSource, aiFeedback, wasCorrect } = args;
  const { storedAnswer, t, tf, next, now, updateBaseline } = args;

  return db.transaction(async (tx) => {
    const claim = await tx
      .update(srsAttempts)
      .set({
        revealedAt: now,
        ratedAt: now,
        answerText: storedAnswer,
        answerMs: t,
        wasCorrect,
      })
      .where(and(eq(srsAttempts.id, attempt.id), isNull(srsAttempts.ratedAt)))
      .returning({ id: srsAttempts.id });
    if (claim.length === 0) return false;

    await tx
      .update(srsCards)
      .set({
        state: next.state,
        reps: next.reps,
        lapses: next.lapses,
        ease: next.ease,
        intervalDays: next.intervalDays,
        due: next.due,
        lastReviewedAt: now,
      })
      .where(eq(srsCards.id, attempt.cardId));

    await tx.insert(srsReviews).values({
      userId,
      cardId: attempt.cardId,
      questionId: attempt.questionId,
      attemptId: attempt.id,
      rating,
      ratingSource,
      answerMs: t,
      timeFactor: tf,
      scope: attempt.scope,
      answerText: storedAnswer,
      aiFeedback,
      parameterDraw: attempt.draw,
      intervalBefore: attempt.intervalDays,
      intervalAfter: next.intervalDays,
    });

    if (updateBaseline && t != null) {
      const nb = nextBaseline(attempt.baselineAnswerMs, attempt.baselineSampleCount, t);
      await tx
        .update(questions)
        .set({ baselineAnswerMs: nb.baseline, baselineSampleCount: nb.count })
        .where(eq(questions.id, attempt.questionId));
    }
    return true;
  });
}

async function bumpSessionCount(sessionId: string | undefined, userId: string) {
  if (!sessionId) return;
  await db
    .update(srsSessions)
    .set({ reviewedCount: sql`${srsSessions.reviewedCount} + 1` })
    .where(and(eq(srsSessions.id, sessionId), eq(srsSessions.userId, userId)));
}

// Response for an attempt that turns out to be rated already — a retried
// request or a lost concurrency race. Rebuilds the graded state (including
// feedback) from the stored review so the client still renders the outcome.
async function ratedResponseBody(attempt: {
  id: string;
  expectedAnswerSnapshot: string | null;
  correctOptionSnapshot: string | null;
  wasCorrect: boolean | null;
  intervalDays: number;
  cardDue: Date | null;
}) {
  const [review] = await db
    .select({
      rating: srsReviews.rating,
      ratingSource: srsReviews.ratingSource,
      aiFeedback: srsReviews.aiFeedback,
    })
    .from(srsReviews)
    .where(eq(srsReviews.attemptId, attempt.id))
    .limit(1);

  return {
    alreadyRated: true,
    expectedAnswer: attempt.expectedAnswerSnapshot,
    correctOption: attempt.correctOptionSnapshot,
    wasCorrect: attempt.wasCorrect,
    feedback: review?.aiFeedback ?? null,
    gradedBy: review?.ratingSource === "ai" ? ("ai" as const) : review ? ("keyword" as const) : null,
    autoRating: review?.rating ?? null,
    nextDueLabel: formatInterval(attempt.intervalDays),
    intervalAfter: attempt.intervalDays,
    due: attempt.cardDue,
    intervals: null,
  };
}

// The stale in-memory attempt lost the rated_at claim; re-read the persisted
// outcome before rebuilding the response.
async function raceLostResponse(attempt: {
  id: string;
  expectedAnswerSnapshot: string | null;
  correctOptionSnapshot: string | null;
  intervalDays: number;
  cardDue: Date | null;
}) {
  const [fresh] = await db
    .select({
      wasCorrect: srsAttempts.wasCorrect,
      intervalDays: srsCards.intervalDays,
      cardDue: srsCards.due,
    })
    .from(srsAttempts)
    .innerJoin(srsCards, eq(srsCards.id, srsAttempts.cardId))
    .where(eq(srsAttempts.id, attempt.id))
    .limit(1);

  return ratedResponseBody({
    id: attempt.id,
    expectedAnswerSnapshot: attempt.expectedAnswerSnapshot,
    correctOptionSnapshot: attempt.correctOptionSnapshot,
    wasCorrect: fresh?.wasCorrect ?? null,
    intervalDays: fresh?.intervalDays ?? attempt.intervalDays,
    cardDue: fresh?.cardDue ?? attempt.cardDue,
  });
}

function toStringArray(v: unknown): string[] {
  return Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : [];
}
