public class RSVP {                       //Jahanvi Chamria and Isabel Drexler Booth
    
    static final String DEFAULT_EVENT_NAME = "EVENT";
    static final int MINIMUM_EVENT_NAME_LENGTH = 5;
    static final int DEFAULT_HOUR = 17;
    // ... add more of your own!
    static final String DOMAIN = "@colgate.edu";
    static final int MINIMUM_USERNAME_LENGTH = 3;
    static final int MAX_HOURS = 23;
    static final int DEFAULT_GUESTS = 2;

    private String name;
    private String[] emails;
    private int hour;
    private int maxAdditionalGuests;
    private boolean[] guestAttendance;
    private int totalGuests;
    private int numAccepted;
    private static int totalGuestsAcrossEvents;
    private static int totalEvents;

    // implement the basic/advanced functionality below!

    public RSVP (String name, String[] emails, int hour, int maxAdditionalGuests){
        if (name.length() < MINIMUM_EVENT_NAME_LENGTH)
            this.name = DEFAULT_EVENT_NAME;
        else
            this.name = name;

        for(int i = 0; i < emails.length; i++){
            if (emails[i] == null)
                throw new IllegalArgumentException("null email encountered!");
            if (countOccurrences(emails[i], emails) > 1)
                throw new IllegalArgumentException("duplicate email encountered!");
            if (!emails[i].endsWith(DOMAIN) || (emails[i].substring(0, emails[i].indexOf('@'))).length() < MINIMUM_USERNAME_LENGTH)
                throw new IllegalArgumentException("invalid email encountered!");
        }
        this.emails = emails;

        if (hour < 0 || hour > MAX_HOURS)
            this.hour = DEFAULT_HOUR;
        else
            this.hour = hour;

        if (maxAdditionalGuests < 0)
            this.maxAdditionalGuests = DEFAULT_GUESTS;
        else
            this.maxAdditionalGuests = maxAdditionalGuests;

        this.guestAttendance=new boolean[emails.length];
        this.totalGuests=0;
        this.numAccepted=0;
        RSVP.totalGuestsAcrossEvents=0;
        RSVP.totalEvents+=1;
    }

    public RSVP (String name, String[] emails, int hour){
        this(name, emails, hour, DEFAULT_GUESTS);
    }

    public RSVP (String name, String[] emails){
        this(name, emails, DEFAULT_HOUR, DEFAULT_GUESTS);
    }

    public boolean acceptInvitation(String email, int additionalGuests){
        if(email == null || this.hasAcceptedInvitation(email) || additionalGuests > this.maxAdditionalGuests || additionalGuests < 0 || RSVP.isInvited(email, this.emails)==false)
            return false;
        else{
            this.guestAttendance[indexOf(email, this.emails)]=true;
            this.totalGuests+=1+additionalGuests;
            this.numAccepted+=1;
            RSVP.totalGuestsAcrossEvents+=1+additionalGuests;
            return true;
        }
    }

    public boolean hasAcceptedInvitation(String email){
        if(isInvited(email, this.emails))
            return this.guestAttendance[indexOf(email, this.emails)];
        else
            return false;
    }

    public boolean isInvited(String email){
        if(indexOf(email, this.emails)==-1)
            return false;
        else
            return true;
    }

    public static boolean isInvited(String email, String[] emails){
        if(indexOf(email, emails)==-1)
            return false;
        else
            return true;
    }

    public boolean isPopularEvent(){
        double averageTotalGuests=((double)RSVP.totalGuestsAcrossEvents)/RSVP.totalEvents;
        if(this.hour>=20 && ((this.numAccepted*100.0)/this.emails.length)>=70.0 && this.totalGuests>averageTotalGuests)
            return true;
        else
            return false;
    }

    public static int acceptInvitationsToPopularEvents(String email, RSVP[] events, int additionalGuests){
        int count=0;
        for(int i=0;i<events.length;i++){
            if(events[i].isPopularEvent() && events[i].isInvited(email) && events[i].hasAcceptedInvitation(email)){
                count++;
            }
        }
        return count;
    }

    public String toString(){
        return (this.name+" at "+this.hour+":00!\nTotal guests: "+this.totalGuests+" ("+roundDecimalPlaces(((this.numAccepted*100.0)/this.emails.length), 2)+"% accepted invitations)");
    }

    public String getName(){
        return this.name;
    }

    public String[] getEmails(){
        return this.emails;
    }

    public int getTime(){
        return this.hour;
    }

    public int getMaxAdditionalGuests(){
        return this.maxAdditionalGuests;
    }

    public int getNumAccepted(){
        return this.numAccepted;
    }

    public int getTotalGuests(){
        return this.totalGuests;
    }














    /*****************************
    ***** PROVIDED FUNCTIONS *****
    ******************************/

    // Returns the index of the first occurrence of a given String in an array
    // -1 is returned if the given String is not found
    public static int indexOf(String target, String[] values) {
        if (target != null && values != null) {
            for (int i = 0; i < values.length; i++) {
                if (values[i].equals(target))
                    return i;
            }
        }
        return -1;
    }

    // Returns the number of times a String appears in an array
    public static int countOccurrences(String target, String[] values) {
        int count = 0;
        for (String str : values) {
            if (target.equals(str))
                count++;
        }
        return count;
    }

    // Rounds a number to n decimal places
    public static double roundDecimalPlaces(double num, int n) {
        return Math.round(num * Math.pow(10, n)) / Math.pow(10, n);
    }
}
