import { redirect } from "next/navigation";
import { desc } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { users } from "@/lib/db/schema";
import { getCurrentUser } from "@/lib/auth/session";
import { AdminUsersClient } from "./client";

export const dynamic = "force-dynamic";

export default async function AdminUsersPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/admin/users");
  if (user.role !== "admin") {
    return (
      <div className="col">
        <div className="screen-head">
          <div className="section-label">Restricted</div>
          <h1>Not available</h1>
        </div>
        <div className="callout orange">
          <strong>Admins only.</strong> Your account doesn&apos;t have access to user management.
        </div>
      </div>
    );
  }

  const rows = await db
    .select({
      id: users.id,
      username: users.username,
      role: users.role,
      displayName: users.displayName,
      email: users.email,
      emailVerifiedAt: users.emailVerifiedAt,
      createdAt: users.createdAt,
      lastLoginAt: users.lastLoginAt,
      expiresAt: users.expiresAt,
    })
    .from(users)
    .orderBy(desc(users.createdAt));

  return (
    <div className="col">
      <div className="screen-head">
        <div className="section-label">Admin</div>
        <h1>Users</h1>
        <p className="lead muted">
          Create admin and faculty accounts, change roles, and reset passwords.
        </p>
      </div>
      <AdminUsersClient initialUsers={rows} currentUserId={user.id} />
    </div>
  );
}
