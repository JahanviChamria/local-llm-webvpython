import { NextResponse } from "next/server";
import { z } from "zod";
import { and, eq, isNull } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { users } from "@/lib/db/schema";
import { hashPassword } from "@/lib/auth/password";
import { checkOrigin } from "@/lib/auth/guards";
import {
  isAllowed,
  prefixedIpHashFromRequest,
  prefixedValueHash,
  recordFailure,
  MAX_REGISTER_PER_IP,
  MAX_REGISTER_PER_EMAIL,
} from "@/lib/auth/rate-limit";
import { issueVerificationToken } from "@/lib/auth/email-verification";
import { ensureStudentProfile } from "@/lib/student-profiles/ensure";
import { isPasswordPwned } from "@/lib/auth/hibp";
import { sendAccountAlreadyExistsEmail, sendVerificationEmail } from "@/lib/email/resend";

export const runtime = "nodejs";

const bodySchema = z.object({
  username: z
    .string()
    .trim()
    .toLowerCase()
    .pipe(z.string().regex(/^[a-z0-9._-]{3,64}$/, "invalid username")),
  email: z
    .string()
    .trim()
    .toLowerCase()
    .email("invalid email")
    .refine((e) => e.endsWith("@ucmerced.edu"), { message: "must use a @ucmerced.edu email" }),
  password: z
    .string()
    .min(8, "password must be at least 8 characters")
    .refine((p) => Buffer.byteLength(p, "utf8") <= 72, { message: "password too long" }),
});

const OK = NextResponse.json({ pending: true });

export async function POST(req: Request) {
  const csrf = checkOrigin(req);
  if (csrf) return csrf;

  let body: z.infer<typeof bodySchema>;
  try {
    body = bodySchema.parse(await req.json());
  } catch (err) {
    if (err instanceof z.ZodError) {
      const first = err.issues[0];
      return NextResponse.json({ error: first?.message ?? "invalid input" }, { status: 400 });
    }
    return NextResponse.json({ error: "invalid input" }, { status: 400 });
  }

  const ipBucket = prefixedIpHashFromRequest("register:", req);
  const emailBucket = prefixedValueHash("register-email:", body.email);

  if (!(await isAllowed(ipBucket, MAX_REGISTER_PER_IP))) {
    return NextResponse.json({ error: "too many attempts" }, { status: 429 });
  }
  if (!(await isAllowed(emailBucket, MAX_REGISTER_PER_EMAIL))) {
    return NextResponse.json({ error: "too many attempts" }, { status: 429 });
  }

  if (await isPasswordPwned(body.password)) {
    await recordFailure(ipBucket);
    await recordFailure(emailBucket);
    return NextResponse.json(
      { error: "password appears in known breach lists" },
      { status: 422 },
    );
  }

  const existingByEmail = await db
    .select()
    .from(users)
    .where(eq(users.email, body.email))
    .limit(1);
  const emailRow = existingByEmail[0];

  if (emailRow && emailRow.emailVerifiedAt) {
    await sendAccountAlreadyExistsEmail(body.email);
    return OK;
  }

  const existingByUsername = await db
    .select({ id: users.id, email: users.email })
    .from(users)
    .where(eq(users.username, body.username))
    .limit(1);
  const usernameRow = existingByUsername[0];

  if (usernameRow && (!emailRow || usernameRow.id !== emailRow.id)) {
    return OK;
  }

  const passwordHash = await hashPassword(body.password);

  let userId: string;
  try {
    userId = await db.transaction(async (tx) => {
      if (emailRow) {
        await tx
          .delete(users)
          .where(
            and(
              eq(users.id, emailRow.id),
              isNull(users.emailVerifiedAt),
              isNull(users.googleSub),
            ),
          );
      }
      const [inserted] = await tx
        .insert(users)
        .values({
          username: body.username,
          email: body.email,
          passwordHash,
          role: "student",
          emailVerifiedAt: null,
          googleSub: null,
        })
        .returning({ id: users.id });
      // Self-registration is always role "student" — give it a profile row up
      // front so AI writebacks have a target (those paths only UPDATE).
      await ensureStudentProfile(inserted.id, tx);
      return inserted.id;
    });
  } catch {
    await recordFailure(ipBucket);
    await recordFailure(emailBucket);
    return OK;
  }

  const token = await issueVerificationToken(userId);
  await sendVerificationEmail(body.email, token);

  return OK;
}
