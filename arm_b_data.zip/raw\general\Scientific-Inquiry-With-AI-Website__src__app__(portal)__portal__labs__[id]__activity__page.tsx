import { LabDocumentSectionView } from "@/components/portal/lab-document-section-view";
import { guardStudentGlobalLab } from "@/lib/portal/global-lab-guard";

export const dynamic = "force-dynamic";

export default async function LabActivityPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  await guardStudentGlobalLab(id);
  return <LabDocumentSectionView labId={id} basePath={`/portal/labs/${id}`} kind="activity" />;
}
