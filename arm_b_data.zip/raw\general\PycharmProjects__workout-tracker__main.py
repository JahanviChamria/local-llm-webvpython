import requests
from datetime import datetime
import os

#
# YOUR_USERNAME="jahanvi"
# YOUR_PASSWORD="Pari,12jc"
GENDER = "female"
WEIGHT_KG = "50"
HEIGHT_CM = "170"
AGE = "18"
# APP_ID="268ecbb5"
# API_KEY="0241298048710d4eb40d840922c6a81a"

APP_ID=os.environ["APP_ID"]
API_KEY=os.environ["API_KEY"]
SHEETY=os.environ["SHEET_ENDPOINT"]
YOUR_USERNAME=os.environ["YOUR_USERNAME"]
YOUR_PASSWORD=os.environ["YOUR_PASSWORD"]

HEADERS={
    "x-app-id":APP_ID,
    "x-app-key":API_KEY,
    "x-remote-user-id":"0",
}
# SHEETY="https://api.sheety.co/35f3b96ef6db94e5143527b8fb05d415/myWorkouts/workouts"

ex_endp="https://trackapi.nutritionix.com/v2/natural/exercise"
ex_t=input("What exercises did you do?")
ex_params={
    "query": ex_t,
    "gender": GENDER,
    "weight_kg": WEIGHT_KG,
    "height_cm": HEIGHT_CM,
    "age": AGE
}
response=requests.post(url=ex_endp, json=ex_params, headers=HEADERS)
result=response.json()
today=datetime.now()
for exercise in result["exercises"]:
    sheet_inputs = {
        "workout": {
            "date":today.strftime("%d/%m/%Y"),
            "time":today.strftime("%X"),
            "exercise": exercise["name"].title(),
            "duration": exercise["duration_min"],
            "calories": exercise["nf_calories"]
        }
    }

sheet_response = requests.post(SHEETY,json=sheet_inputs,auth=(YOUR_USERNAME,YOUR_PASSWORD,))