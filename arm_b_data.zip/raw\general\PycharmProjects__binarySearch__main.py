import matplotlib.pyplot as plt
import random
steps=[]
def binary_search(arr, target):
    left, right = 0, len(arr) - 1
    global steps

    while left <= right:
        mid = (left + right) // 2
        steps.append((left, right, mid))

        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            left = mid + 1
        else:
            right = mid - 1

    return -1

arr = sorted(random.sample(range(1, 101), 20))
target = random.choice(arr)

result = binary_search(arr, target)

fig, ax = plt.subplots()

def plot_step(left, right, mid):
    ax.clear()
    ax.bar(range(len(arr)), arr, tick_label=[str(x) for x in arr], color=['lightblue' if i != mid else 'lightgreen' for i in range(len(arr))])
    ax.set_title(f"Binary Search Step: Left={left}, Right={right}, Mid={mid}")
    plt.pause(1)

for left, right, mid in steps:
    plot_step(left, right, mid)

if result != -1:
    print(f"Found {target} at index {result}.")
else:
    print(f"{target} not found in the list.")

plt.show()
