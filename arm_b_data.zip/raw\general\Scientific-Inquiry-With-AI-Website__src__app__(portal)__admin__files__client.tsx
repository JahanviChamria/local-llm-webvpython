"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { ACCEPT_ATTRIBUTE, MAX_UPLOAD_BYTES } from "@/lib/file-types";
import { Badge, Card } from "@/components/portal/primitives";
import { FILE_CATEGORY_OPTIONS } from "@/lib/portal/lab-sections";

type FileRow = {
  id: string;
  title: string;
  description: string | null;
  category: string | null;
  accessLevel: "public" | "faculty";
  status: "pending" | "ready";
  filename: string;
  sizeBytes: number;
  contentType: string;
  uploadedAt: Date | string;
};

type TabKey = "upload" | "public" | "private";

function formatSize(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

// Turn an API error body into something an admin can act on. The delete/flip
// guards return { error, detail } — prefer the human-readable detail, fall back
// to the error slug, then the status code.
function apiErrorMessage(status: number, body: Record<string, unknown>): string {
  if (typeof body.detail === "string" && body.detail) return body.detail;
  if (typeof body.error === "string" && body.error) return body.error;
  return `Request failed (${status}).`;
}

function iconFor(f: FileRow, kind: "public" | "private"): string {
  if (kind === "private") return "🔒";
  const ext = f.filename.split(".").pop()?.toLowerCase() ?? "";
  const ct = f.contentType.toLowerCase();
  if (ct.startsWith("image/")) return "🖼️";
  if (ct === "application/pdf" || ext === "pdf") return "📕";
  if (["xlsx", "xls", "csv"].includes(ext) || ct.includes("spreadsheet") || ct === "text/csv") return "📊";
  if (["doc", "docx"].includes(ext) || ct.includes("wordprocessing")) return "📝";
  if (["json", "md", "txt"].includes(ext) || ct === "application/json" || ct === "text/markdown") return "📄";
  if (ct.startsWith("audio/")) return "🎵";
  if (ct.startsWith("video/")) return "🎬";
  if (["zip", "tar", "gz"].includes(ext) || ct === "application/zip") return "🗜️";
  return "📄";
}

export function AdminFilesClient({
  initialFiles,
  isAdmin,
}: {
  initialFiles: FileRow[];
  isAdmin: boolean;
}) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [tab, setTab] = useState<TabKey>(isAdmin ? "upload" : "public");
  const [error, setError] = useState<string | null>(null);

  const publicFiles = initialFiles.filter((f) => f.accessLevel === "public");
  const privateFiles = initialFiles.filter((f) => f.accessLevel === "faculty");

  async function del(id: string) {
    if (!confirm("Delete this file? This cannot be undone.")) return;
    setError(null);
    start(async () => {
      const res = await fetch(`/api/admin/files/${id}`, { method: "DELETE" });
      const body = (await res.json().catch(() => ({}))) as Record<string, unknown>;
      if (!res.ok) {
        setError(apiErrorMessage(res.status, body));
        return;
      }
      if (body.warning === "cache_purge_failed") {
        setError(
          "File deleted, but the CDN cache purge failed — it may stay downloadable until the cache expires.",
        );
      }
      router.refresh();
    });
  }

  async function patch(id: string, body: Record<string, unknown>) {
    setError(null);
    start(async () => {
      const res = await fetch(`/api/admin/files/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (!res.ok) {
        const j = (await res.json().catch(() => ({}))) as Record<string, unknown>;
        setError(apiErrorMessage(res.status, j));
        return;
      }
      router.refresh();
    });
  }

  return (
    <div className="col" style={{ gap: 18 }}>
      <div className="files-tabs" role="tablist">
        {isAdmin && (
          <button
            type="button"
            role="tab"
            aria-selected={tab === "upload"}
            className={tab === "upload" ? "on" : ""}
            onClick={() => setTab("upload")}
          >
            <span>Upload</span>
          </button>
        )}
        <button
          type="button"
          role="tab"
          aria-selected={tab === "public"}
          className={tab === "public" ? "on" : ""}
          onClick={() => setTab("public")}
        >
          <span>Public</span>
          <span className="count">{publicFiles.length}</span>
        </button>
        <button
          type="button"
          role="tab"
          aria-selected={tab === "private"}
          className={tab === "private" ? "on" : ""}
          onClick={() => setTab("private")}
        >
          <span>Private</span>
          <span className="count">{privateFiles.length}</span>
        </button>
      </div>

      {error && (
        <p role="alert" style={{ color: "var(--orange)", fontSize: 13, margin: 0 }}>
          {error}
        </p>
      )}

      {tab === "upload" && isAdmin && (
        <UploadForm onUploaded={() => router.refresh()} />
      )}
      {tab === "public" && (
        <FileList
          files={publicFiles}
          kind="public"
          isAdmin={isAdmin}
          pending={pending}
          onPatch={patch}
          onDelete={del}
        />
      )}
      {tab === "private" && (
        <FileList
          files={privateFiles}
          kind="private"
          isAdmin={isAdmin}
          pending={pending}
          onPatch={patch}
          onDelete={del}
        />
      )}
    </div>
  );
}

function FileList({
  files,
  kind,
  isAdmin,
  pending,
  onPatch,
  onDelete,
}: {
  files: FileRow[];
  kind: "public" | "private";
  isAdmin: boolean;
  pending: boolean;
  onPatch: (id: string, body: Record<string, unknown>) => void;
  onDelete: (id: string) => void;
}) {
  if (files.length === 0) {
    return (
      <p className="muted" style={{ fontSize: 13 }}>
        No {kind} files yet.
      </p>
    );
  }

  return (
    <div className="col" style={{ gap: 9 }}>
      {files.map((f) => (
        <div className="doc-row" key={f.id}>
          <div className="doc-icon">{iconFor(f, kind)}</div>
          <div className="doc-info">
            <div className="doc-name row center wrap" style={{ gap: 7 }}>
              <span>{f.title}</span>
              <Badge kind={kind === "private" ? "progress" : "complete"}>{kind}</Badge>
              {f.status === "pending" && <Badge kind="streak">pending</Badge>}
            </div>
            {f.description && (
              <div className="muted" style={{ fontSize: 12, marginTop: 3 }}>
                {f.description}
              </div>
            )}
            <div className="doc-meta">
              {f.filename} · {formatSize(f.sizeBytes)} · {f.category || "—"}
            </div>
          </div>
          <div className="doc-actions">
            <a
              className="btn sm"
              href={`/api/files/${f.id}/download?disposition=inline`}
              target="_blank"
              rel="noopener noreferrer"
            >
              View
            </a>
            {isAdmin && (
              <>
                <select
                  className="field sm"
                  defaultValue={f.accessLevel === "faculty" ? "private" : "public"}
                  disabled={pending}
                  onChange={(e) =>
                    onPatch(f.id, {
                      access_level: e.target.value === "private" ? "faculty" : "public",
                    })
                  }
                  style={{ width: "auto" }}
                >
                  <option value="public">public</option>
                  <option value="private">private</option>
                </select>
                <button
                  type="button"
                  className="btn danger sm"
                  onClick={() => onDelete(f.id)}
                  disabled={pending}
                >
                  Delete
                </button>
              </>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

function UploadForm({ onUploaded }: { onUploaded: () => void }) {
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [accessLevel, setAccessLevel] = useState<"public" | "faculty">("public");
  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setStatus(null);
    if (!file) return setError("Pick a file.");
    if (file.size > MAX_UPLOAD_BYTES) return setError(`File is too large (max ${formatSize(MAX_UPLOAD_BYTES)}).`);
    if (!title.trim()) return setError("Title is required.");
    if (!category) return setError("Pick a file category.");

    setBusy(true);
    try {
      setStatus("Requesting upload URL…");
      const init = await fetch("/api/admin/files/upload-url", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          filename: file.name,
          size_bytes: file.size,
          content_type: file.type || "application/octet-stream",
          title: title.trim(),
          description: description.trim() || undefined,
          category: category || undefined,
          access_level: accessLevel,
        }),
      });
      if (!init.ok) {
        const j = await init.json().catch(() => ({}));
        throw new Error(j.error ?? "Server rejected the upload request.");
      }
      const { file_id, upload_url, required_headers } = (await init.json()) as {
        file_id: string;
        upload_url: string;
        required_headers: Record<string, string>;
      };

      setStatus("Uploading to R2…");
      // Server-canonicalized Content-Type must match the presigned signature,
      // so we send required_headers verbatim instead of file.type.
      const put = await fetch(upload_url, {
        method: "PUT",
        headers: required_headers,
        body: file,
      });
      if (!put.ok) {
        throw new Error(`R2 upload failed (${put.status}).`);
      }

      setStatus("Finalizing…");
      const done = await fetch(`/api/admin/files/${file_id}/complete`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      if (!done.ok) {
        const j = await done.json().catch(() => ({}));
        throw new Error(j.error ?? "Finalize failed; the file was rejected and removed.");
      }

      setStatus("Done.");
      setFile(null);
      setTitle("");
      setDescription("");
      setCategory("");
      setAccessLevel("public");
      (document.getElementById("upload-file-input") as HTMLInputElement | null)?.value &&
        ((document.getElementById("upload-file-input") as HTMLInputElement).value = "");
      onUploaded();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Upload failed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit}>
      <Card title="Upload a file" label="browser → Cloudflare R2">
        <div className="form-grid">
          <label className="field-label">
            <span>Title</span>
            <input
              className="field"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
            />
          </label>
          <label className="field-label">
            <span>Category</span>
            <select
              className="field"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              required
            >
              <option value="" disabled>
                — select a type —
              </option>
              {FILE_CATEGORY_OPTIONS.map((title) => (
                <option key={title} value={title}>
                  {title}
                </option>
              ))}
            </select>
          </label>
        </div>

        <label className="field-label" style={{ marginTop: 14 }}>
          <span>Description (optional)</span>
          <textarea
            className="field"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={2}
          />
        </label>

        <div className="form-grid" style={{ marginTop: 14 }}>
          <label className="field-label">
            <span>Access</span>
            <select
              className="field"
              value={accessLevel}
              onChange={(e) => setAccessLevel(e.target.value as "public" | "faculty")}
            >
              <option value="public">public (anyone can download)</option>
              <option value="faculty">private (only visible to teachers/admins)</option>
            </select>
          </label>
          <label className="field-label">
            <span>File</span>
            <input
              id="upload-file-input"
              className="field"
              type="file"
              accept={ACCEPT_ATTRIBUTE}
              onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            />
          </label>
        </div>

        {file && (
          <p className="light" style={{ fontSize: 11.5, marginTop: 10 }}>
            {file.name} · {formatSize(file.size)} · {file.type || "application/octet-stream"}
          </p>
        )}
        {error && <p style={{ color: "var(--orange)", fontSize: 13, marginTop: 10 }}>{error}</p>}
        {status && !error && <p className="muted" style={{ fontSize: 13, marginTop: 10 }}>{status}</p>}

        <div style={{ marginTop: 16 }}>
          <button type="submit" className="btn primary" disabled={busy}>
            {busy ? "Uploading…" : "Upload"}
          </button>
        </div>
      </Card>
    </form>
  );
}
