

//Client class used to test your various ShakespeareGPT 
//and word bank functionalities
public class Lab11Client{
  
  public static void main(String[] args){
    
    ShakespeareGPT bot = new ShakespeareGPT();
    System.out.println("ShakespeareGPT: Test 1");
    bot.trainOnFile("AsYouLikeIt.txt");
    bot.trainOnFile("RomeoAndJuliet.txt");
    bot.trainOnFile("TwelfthNight.txt");
    bot.trainOnFile("test1.txt");

    System.out.println(bot.getStarters());
    
    bot.generate(20);

    bot = new ShakespeareGPT();
    System.out.println("\nShakespeareGPT: Test 2");
    bot.trainOnFile("test1.txt");

    System.out.println(bot.getStarters());

    bot.generate(5, "Yet");

    bot = new ShakespeareGPT();
    System.out.println("\nShakespeareGPT: Test 3");
    bot.trainOnFile("AsYouLikeIt.txt");
    bot.trainOnFile("RomeoAndJuliet.txt");
    bot.trainOnFile("TwelfthNight.txt");
    bot.trainOnFile("test1.txt");

    System.out.println(bot.getStarters());

    bot.generate(10);
  }
  
}

