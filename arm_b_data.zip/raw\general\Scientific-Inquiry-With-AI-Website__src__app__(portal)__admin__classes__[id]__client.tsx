"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  DndContext,
  PointerSensor,
  KeyboardSensor,
  closestCenter,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  SortableContext,
  arrayMove,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { Card } from "@/components/portal/primitives";

export type LabOption = {
  id: string;
  name: string;
  moduleOrder: number | null;
};

export type AssignedLab = {
  id: string;
  name: string;
  orderIndex: number;
  isLocked: boolean;
};

type StudentRow = {
  userId: string;
  username: string;
  displayName: string | null;
  email: string | null;
  enrolledAt: string;
};

type ApiError = { error?: string; detail?: string };

async function safeJson(res: Response): Promise<unknown> {
  try {
    return await res.json();
  } catch {
    return null;
  }
}

function errMsg(json: unknown, fallback: string): string {
  if (json && typeof json === "object") {
    const j = json as ApiError;
    return j.detail || j.error || fallback;
  }
  return fallback;
}

export function ManageClassClient({
  classId,
  initialName,
  archivedAt,
  students: initialStudents,
  assignedLabs: initialAssigned,
  allLabs,
}: {
  classId: string;
  initialName: string;
  archivedAt: string | null;
  students: StudentRow[];
  assignedLabs: AssignedLab[];
  allLabs: LabOption[];
}) {
  const router = useRouter();
  const archived = archivedAt !== null;

  // Rename
  const [name, setName] = useState(initialName);
  const [renameStatus, setRenameStatus] = useState<string | null>(null);
  const [renameBusy, setRenameBusy] = useState(false);

  // Assigned labs: ordered list of { id, name, orderIndex, isLocked }. The local
  // array is authoritative once mounted — reorder + lock writes are optimistic
  // and roll back on error rather than calling router.refresh().
  const [assigned, setAssigned] = useState<AssignedLab[]>(initialAssigned);
  const [assignedStatus, setAssignedStatus] = useState<string | null>(null);

  // Add labs picker (labs not yet assigned).
  const [toAdd, setToAdd] = useState<Set<string>>(new Set());
  const [addLabsStatus, setAddLabsStatus] = useState<string | null>(null);
  const [addLabsBusy, setAddLabsBusy] = useState(false);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  // Roster
  const [students, setStudents] = useState(initialStudents);
  const [addInput, setAddInput] = useState("");
  const [addStatus, setAddStatus] = useState<string | null>(null);
  const [addBusy, setAddBusy] = useState(false);

  // Archive / hard-delete
  const [archiveBusy, setArchiveBusy] = useState(false);
  const [archiveStatus, setArchiveStatus] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState("");
  const [deleteBusy, setDeleteBusy] = useState(false);

  // Bulk reset
  const [confirmReset, setConfirmReset] = useState("");
  const [resetBusy, setResetBusy] = useState(false);
  const [resetStatus, setResetStatus] = useState<string | null>(null);

  function togglePendingAdd(id: string) {
    setToAdd((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  async function handleDragEnd(event: DragEndEvent) {
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    const oldIndex = assigned.findIndex((l) => l.id === active.id);
    const newIndex = assigned.findIndex((l) => l.id === over.id);
    if (oldIndex < 0 || newIndex < 0) return;

    const previous = assigned;
    const next = arrayMove(assigned, oldIndex, newIndex).map((l, i) => ({
      ...l,
      orderIndex: i + 1,
    }));
    setAssigned(next);
    setAssignedStatus(null);

    const res = await fetch(`/api/admin/classes/${classId}/labs/reorder`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ orderedLabIds: next.map((l) => l.id) }),
    });
    if (!res.ok) {
      const json = await safeJson(res);
      setAssigned(previous);
      setAssignedStatus(errMsg(json, "Reorder failed."));
    }
  }

  async function toggleLock(labId: string, nextLocked: boolean) {
    const previous = assigned;
    setAssigned((prev) =>
      prev.map((l) => (l.id === labId ? { ...l, isLocked: nextLocked } : l)),
    );
    setAssignedStatus(null);

    const res = await fetch(`/api/admin/classes/${classId}/labs/${labId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isLocked: nextLocked }),
    });
    if (!res.ok) {
      const json = await safeJson(res);
      setAssigned(previous);
      setAssignedStatus(errMsg(json, "Lock toggle failed."));
    }
  }

  async function removeAssigned(labId: string) {
    const previous = assigned;
    const next = assigned
      .filter((l) => l.id !== labId)
      .map((l, i) => ({ ...l, orderIndex: i + 1 }));
    setAssigned(next);
    setAssignedStatus(null);

    const res = await fetch(`/api/admin/classes/${classId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ labIds: next.map((l) => l.id) }),
    });
    if (!res.ok) {
      const json = await safeJson(res);
      setAssigned(previous);
      setAssignedStatus(errMsg(json, "Remove failed."));
    }
  }

  async function addSelectedLabs() {
    if (toAdd.size === 0) return;
    setAddLabsBusy(true);
    setAddLabsStatus(null);
    const ordered = Array.from(toAdd);
    // Server appends new ids after the current max, preserving submission order.
    const merged = [...assigned.map((l) => l.id), ...ordered];
    const res = await fetch(`/api/admin/classes/${classId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ labIds: merged }),
    });
    const json = await safeJson(res);
    if (!res.ok) {
      setAddLabsStatus(errMsg(json, "Adding labs failed."));
      setAddLabsBusy(false);
      return;
    }
    const startIndex = assigned.length;
    const newRows: AssignedLab[] = ordered.map((id, i) => {
      const lab = allLabs.find((l) => l.id === id);
      return {
        id,
        name: lab?.name ?? id,
        orderIndex: startIndex + i + 1,
        isLocked: false,
      };
    });
    setAssigned([...assigned, ...newRows]);
    setToAdd(new Set());
    setAddLabsBusy(false);
    setAddLabsStatus(`Added ${ordered.length} lab${ordered.length === 1 ? "" : "s"}.`);
  }

  async function saveRename() {
    if (name.trim() === initialName || name.trim().length === 0) return;
    setRenameBusy(true);
    setRenameStatus(null);
    const res = await fetch(`/api/admin/classes/${classId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: name.trim() }),
    });
    const json = await safeJson(res);
    if (!res.ok) {
      setRenameStatus(errMsg(json, "Rename failed."));
      setRenameBusy(false);
      return;
    }
    setRenameStatus("Saved.");
    setRenameBusy(false);
    router.refresh();
  }

  async function addStudent() {
    const v = addInput.trim();
    if (v.length === 0) return;
    setAddBusy(true);
    setAddStatus(null);
    const res = await fetch(`/api/admin/classes/${classId}/students`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ usernameOrEmail: v }),
    });
    const json = (await safeJson(res)) as
      | { ok: true; data: StudentRow }
      | (ApiError & { ok?: false; candidates?: { id: string; username: string }[] })
      | null;
    if (!res.ok || !json || !("ok" in json) || !json.ok) {
      setAddStatus(errMsg(json, "Add failed."));
      setAddBusy(false);
      return;
    }
    // Append to local state so the count badge and roster update right away —
    // useState ignores the refreshed prop, so router.refresh() alone wouldn't.
    setStudents((prev) => [...prev, json.data]);
    setAddInput("");
    setAddStatus(`Added ${json.data.username}.`);
    setAddBusy(false);
    router.refresh();
  }

  async function removeStudent(userId: string, username: string) {
    if (!confirm(`Remove ${username} from this class? Their learning history is NOT touched.`)) {
      return;
    }
    const res = await fetch(
      `/api/admin/classes/${classId}/students/${userId}`,
      { method: "DELETE" },
    );
    if (!res.ok) {
      alert("Remove failed.");
      return;
    }
    setStudents((prev) => prev.filter((s) => s.userId !== userId));
    router.refresh();
  }

  async function doArchive() {
    setArchiveBusy(true);
    setArchiveStatus(null);
    const res = await fetch(`/api/admin/classes/${classId}/archive`, { method: "POST" });
    const json = await safeJson(res);
    if (!res.ok) {
      setArchiveStatus(errMsg(json, "Archive failed."));
      setArchiveBusy(false);
      return;
    }
    setArchiveBusy(false);
    router.push("/admin/classes/archived");
  }

  async function doUnarchive() {
    setArchiveBusy(true);
    const res = await fetch(`/api/admin/classes/${classId}/unarchive`, { method: "POST" });
    if (!res.ok) {
      const j = await safeJson(res);
      setArchiveStatus(errMsg(j, "Unarchive failed."));
      setArchiveBusy(false);
      return;
    }
    setArchiveBusy(false);
    router.push("/admin/classes");
  }

  async function doHardDelete() {
    if (confirmDelete !== initialName) return;
    setDeleteBusy(true);
    const res = await fetch(`/api/admin/classes/${classId}`, {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ confirm: confirmDelete }),
    });
    if (!res.ok) {
      const j = await safeJson(res);
      alert(errMsg(j, "Hard delete failed."));
      setDeleteBusy(false);
      return;
    }
    setDeleteBusy(false);
    router.push("/admin/classes/archived");
  }

  async function doBulkReset() {
    if (confirmReset !== initialName) return;
    setResetBusy(true);
    setResetStatus(null);
    const res = await fetch(`/api/admin/classes/${classId}/reset-all-history`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ confirm: confirmReset }),
    });
    const json = (await safeJson(res)) as
      | { ok: true; data: { wipedCount: number } }
      | (ApiError & { ok?: false })
      | null;
    if (!res.ok || !json || !("ok" in json) || !json.ok) {
      setResetStatus(errMsg(json, "Bulk reset failed."));
      setResetBusy(false);
      return;
    }
    setResetStatus(`Reset progress for ${json.data.wipedCount} student${json.data.wipedCount === 1 ? "" : "s"}.`);
    setConfirmReset("");
    setResetBusy(false);
    router.refresh();
  }

  return (
    <div className="col" style={{ gap: 18 }}>
      {archived && (
        <div className="callout orange">
          <strong>This class is archived.</strong> Students no longer see it in their sidebar.
        </div>
      )}

      <Card title="Class details">
        <div className="col" style={{ gap: 9 }}>
          <label className="col" style={{ gap: 6 }}>
            <span className="label">Class name</span>
            <input
              className="input"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={200}
              disabled={archived}
            />
          </label>
          <div className="row" style={{ gap: 9 }}>
            <button
              type="button"
              className="btn primary sm"
              onClick={saveRename}
              disabled={renameBusy || archived || name.trim() === initialName || name.trim().length === 0}
            >
              {renameBusy ? "Saving…" : "Save name"}
            </button>
            {renameStatus && <span className="muted" style={{ fontSize: 12 }}>{renameStatus}</span>}
          </div>
        </div>
      </Card>

      <Card
        title="Assigned labs"
        label={`${assigned.length} assigned`}
      >
        <div className="col" style={{ gap: 6 }}>
          {assigned.length === 0 ? (
            <p className="muted" style={{ fontSize: 13 }}>
              No labs assigned yet. Use the picker below to add some.
            </p>
          ) : (
            <DndContext
              sensors={sensors}
              collisionDetection={closestCenter}
              onDragEnd={handleDragEnd}
            >
              <SortableContext
                items={assigned.map((l) => l.id)}
                strategy={verticalListSortingStrategy}
              >
                <div className="col" style={{ gap: 4 }}>
                  {assigned.map((lab, i) => (
                    <SortableLabRow
                      key={lab.id}
                      lab={lab}
                      position={i + 1}
                      disabled={archived}
                      onToggleLock={() => toggleLock(lab.id, !lab.isLocked)}
                      onRemove={() => removeAssigned(lab.id)}
                    />
                  ))}
                </div>
              </SortableContext>
            </DndContext>
          )}
          {assignedStatus && (
            <span className="muted" style={{ fontSize: 12 }}>{assignedStatus}</span>
          )}
        </div>
      </Card>

      <Card
        title="Add labs"
        label={
          allLabs.length === assigned.length
            ? "All labs assigned"
            : `${toAdd.size} selected`
        }
      >
        {allLabs.length === 0 ? (
          <p className="muted" style={{ fontSize: 13 }}>No labs exist yet.</p>
        ) : (
          (() => {
            const assignedIds = new Set(assigned.map((l) => l.id));
            const available = allLabs.filter((l) => !assignedIds.has(l.id));
            if (available.length === 0) {
              return (
                <p className="muted" style={{ fontSize: 13 }}>
                  Every published lab is already assigned to this class.
                </p>
              );
            }
            return (
              <>
                <div
                  className="col"
                  style={{ gap: 6, maxHeight: 240, overflowY: "auto" }}
                >
                  {available.map((l) => (
                    <label
                      key={l.id}
                      className="row"
                      style={{ gap: 9, alignItems: "center", padding: "4px 2px" }}
                    >
                      <input
                        type="checkbox"
                        checked={toAdd.has(l.id)}
                        onChange={() => togglePendingAdd(l.id)}
                        disabled={archived}
                      />
                      <span style={{ fontSize: 13 }}>
                        {l.moduleOrder != null && (
                          <span className="muted" style={{ marginRight: 6 }}>
                            {String(l.moduleOrder).padStart(2, "0")}
                          </span>
                        )}
                        {l.name}
                      </span>
                    </label>
                  ))}
                </div>
                <div className="row" style={{ gap: 9, marginTop: 9 }}>
                  <button
                    type="button"
                    className="btn primary sm"
                    onClick={addSelectedLabs}
                    disabled={addLabsBusy || archived || toAdd.size === 0}
                  >
                    {addLabsBusy ? "Adding…" : "Add selected"}
                  </button>
                  {addLabsStatus && (
                    <span className="muted" style={{ fontSize: 12 }}>
                      {addLabsStatus}
                    </span>
                  )}
                </div>
              </>
            );
          })()
        )}
      </Card>

      <Card title="Roster" label={`${students.length} student${students.length === 1 ? "" : "s"}`}>
        <div className="col" style={{ gap: 9 }}>
          <div className="row" style={{ gap: 6 }}>
            <input
              className="input grow"
              type="text"
              placeholder="Add by username or email"
              value={addInput}
              onChange={(e) => setAddInput(e.target.value)}
              disabled={archived}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  addStudent();
                }
              }}
            />
            <button
              type="button"
              className="btn primary sm"
              onClick={addStudent}
              disabled={addBusy || archived || addInput.trim().length === 0}
            >
              {addBusy ? "Adding…" : "Add"}
            </button>
          </div>
          {addStatus && <span className="muted" style={{ fontSize: 12 }}>{addStatus}</span>}

          {students.length === 0 ? (
            <p className="muted" style={{ fontSize: 13 }}>No students enrolled yet.</p>
          ) : (
            <div className="col" style={{ gap: 4 }}>
              {students.map((s) => (
                <div key={s.userId} className="row" style={{ gap: 9, alignItems: "center", padding: "6px 4px", borderBottom: "1px solid var(--border)" }}>
                  <div className="col" style={{ gap: 2 }}>
                    <span style={{ fontSize: 13, fontWeight: 500 }}>{s.username}</span>
                    <span className="muted" style={{ fontSize: 11 }}>
                      {s.displayName ? `${s.displayName} · ` : ""}{s.email ?? "no email"}
                    </span>
                  </div>
                  <span className="grow" />
                  <button
                    type="button"
                    className="btn ghost sm"
                    onClick={() => removeStudent(s.userId, s.username)}
                    disabled={archived}
                  >
                    Remove
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </Card>

      <Card title="Lifecycle">
        <div className="col" style={{ gap: 9 }}>
          {!archived ? (
            <>
              <p className="muted" style={{ fontSize: 13 }}>
                Archiving hides the class from active lists and from students&apos; sidebars. No data is lost.
                You can unarchive or hard-delete it later from the Archived view.
              </p>
              <div>
                <button
                  type="button"
                  className="btn ghost sm"
                  onClick={doArchive}
                  disabled={archiveBusy}
                >
                  {archiveBusy ? "Archiving…" : "Archive class"}
                </button>
              </div>
            </>
          ) : (
            <>
              <p className="muted" style={{ fontSize: 13 }}>
                This class is archived. Unarchive to restore it, or hard-delete to remove the class
                container permanently. Hard delete does <b>not</b> touch student history.
              </p>
              <div className="row" style={{ gap: 9 }}>
                <button
                  type="button"
                  className="btn primary sm"
                  onClick={doUnarchive}
                  disabled={archiveBusy}
                >
                  {archiveBusy ? "Unarchiving…" : "Unarchive"}
                </button>
              </div>
              <div className="col" style={{ gap: 6, marginTop: 9 }}>
                <span className="label">Type &quot;<span style={{ textTransform: "none" }}>{initialName}</span>&quot; to hard-delete</span>
                <input
                  className="input"
                  type="text"
                  value={confirmDelete}
                  onChange={(e) => setConfirmDelete(e.target.value)}
                  placeholder={initialName}
                />
                <div>
                  <button
                    type="button"
                    className="btn ghost sm"
                    onClick={doHardDelete}
                    disabled={deleteBusy || confirmDelete !== initialName}
                    style={{ color: "var(--orange)" }}
                  >
                    {deleteBusy ? "Deleting…" : "Hard delete class"}
                  </button>
                </div>
              </div>
            </>
          )}
          {archiveStatus && <span className="muted" style={{ fontSize: 12 }}>{archiveStatus}</span>}
        </div>
      </Card>

      <Card title="Danger zone — global progress reset">
        <div className="col" style={{ gap: 9 }}>
          <div className="callout orange">
            <strong>This action is global.</strong> It deletes every enrolled student&apos;s
            learning history — SRS scheduling, attempts, completions, downloads, and mastery
            JSONB — including their progress in any <em>other</em> classes they&apos;re in.
            Student accounts are kept so they can still log in. This cannot be undone.
          </div>
          <span className="label">Type &quot;<span style={{ textTransform: "none" }}>{initialName}</span>&quot; to confirm</span>
          <input
            className="input"
            type="text"
            value={confirmReset}
            onChange={(e) => setConfirmReset(e.target.value)}
            placeholder={initialName}
            disabled={archived}
          />
          <div className="row" style={{ gap: 9 }}>
            <button
              type="button"
              className="btn ghost sm"
              onClick={doBulkReset}
              disabled={resetBusy || archived || confirmReset !== initialName}
              style={{ color: "var(--orange)" }}
            >
              {resetBusy ? "Resetting…" : "Reset progress for everyone in this class"}
            </button>
            {resetStatus && <span className="muted" style={{ fontSize: 12 }}>{resetStatus}</span>}
          </div>
        </div>
      </Card>
    </div>
  );
}

function SortableLabRow({
  lab,
  position,
  disabled,
  onToggleLock,
  onRemove,
}: {
  lab: AssignedLab;
  position: number;
  disabled: boolean;
  onToggleLock: () => void;
  onRemove: () => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } =
    useSortable({ id: lab.id, disabled });
  const style: React.CSSProperties = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.6 : 1,
    gap: 9,
    alignItems: "center",
    padding: "6px 4px",
    borderBottom: "1px solid var(--border)",
    background: isDragging ? "var(--surface, transparent)" : undefined,
  };
  return (
    <div ref={setNodeRef} className="row" style={style}>
      <button
        type="button"
        className="btn ghost sm"
        aria-label="Drag to reorder"
        style={{ cursor: disabled ? "not-allowed" : "grab", padding: "2px 6px" }}
        disabled={disabled}
        {...attributes}
        {...listeners}
      >
        ⋮⋮
      </button>
      <span className="muted" style={{ fontSize: 12, minWidth: 22 }}>
        {String(position).padStart(2, "0")}
      </span>
      <span className="grow" style={{ fontSize: 13 }}>
        {lab.name}
      </span>
      <button
        type="button"
        className="btn ghost sm"
        onClick={onToggleLock}
        disabled={disabled}
        title={lab.isLocked ? "Locked — click to unlock for students" : "Unlocked — click to pause students"}
        style={{ color: lab.isLocked ? "var(--orange)" : undefined }}
      >
        {lab.isLocked ? "🔒 Locked" : "🔓 Unlocked"}
      </button>
      <button
        type="button"
        className="btn ghost sm"
        onClick={onRemove}
        disabled={disabled}
      >
        Remove
      </button>
    </div>
  );
}
