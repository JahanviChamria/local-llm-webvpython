JavaScript 3.2

scene.width = scene.height = 600 // Bruce Sherwood

// Display text below the 3D graphics:
scene.title = "Stars interacting gravitationally"
let s = 'To rotate "camera", drag with right button or Ctrl-drag.\n'
s += "To zoom, drag with middle button or Alt/Option depressed, or use scroll wheel.\n"
s += "  On a two-button mouse, middle is left + right.\n"
s += "To pan left/right and up/down, Shift-drag.\n"
s += "Touch screen: pinch/extend to zoom, swipe or two-finger rotate.\n"
scene.caption = s

let Nstars = 20  // change this to have more or fewer stars

let G = 6.7e-11 // Universal gravitational constant

// Typical values
let Msun = 2E30
let Rsun = 2E9
let L = 4e10
let vsun = 0.8*sqrt(G*Msun/Rsun)

scene.range = 2*L
scene.forward = vec(-1,-1,-1)

let xaxis = curve( {color:color.gray(0.5), radius:3e8} )
xaxis.push(vec(0,0,0))
xaxis.push(vec(L,0,0))
let yaxis = curve( {color:color.gray(0.5), radius:3e8} )
yaxis.push(vec(0,0,0))
yaxis.push(vec(0,L,0))
let zaxis = curve( {color:color.gray(0.5), radius:3e8} )
zaxis.push(vec(0,0,0))
zaxis.push(vec(0,0,L))

let Stars = []
let star_colors = [color.red, color.green, color.blue,
              color.yellow, color.cyan, color.magenta]

let psum = vec(0,0,0)
for (let i=0; i<Nstars; i++) {
    let star = sphere()
    star.pos = L*vec.random()
    let R = Rsun/2+Rsun*Math.random()
    star.size = 2*R*vec(1,1,1)
    star.mass = Msun*pow(R/Rsun,3)
    star.momentum = vec.random()*vsun*star.mass
    star.color = star_colors[i % 6]
    star.trail = attach_trail(star, {radius:2e8, pps:30, retain:150})
    Stars.push( star )
    psum = psum + star.momentum
}

// make total initial momentum equal zero
for (let i=0; i<Nstars; i++) {
    Stars[i].momentum = Stars[i].momentum - psum/Nstars
}

let dt = 1000

function computeForces( Stars, hitlist ) {  
    let N = Stars.length
    for (let i=0; i<N; i++) {
        if (Stars[i] === null) continue;
        let F = vec(0,0,0)
        let si = Stars[i]
        let pos1 = si.pos
        let m1 = si.mass
        let radius = si.size.x/2
        for(let j=0; j<N; j++) {
            if (i===j) continue;
            if (Stars[j] === null) continue;
            let sj = Stars[j]
            let r = sj.pos - pos1
            let rmag2 = mag2(r)
            if (rmag2 <= pow(radius+sj.size.x/2,2)) hitlist.push([i,j])
            F = F + (G*m1*sj.mass/pow(rmag2,1.5))*r
        }
        si.momentum = si.momentum + F*dt
    }
}

while (true) {
    await rate(100)
    let hitlist = []
    
    // Compute all forces on all stars
    computeForces( Stars, hitlist)

    // Having updated all momenta, now update all positions
    for (let i=0; i<Stars.length; i++) {
        let star = Stars[i]
        if (star) {
            star.pos = star.pos + star.momentum*(dt/star.mass)
        }
    }

    // If any collisions took place, merge those stars
    for(let hit=hitlist.length-1; hit>=0; hit--) {
        let s1 = Stars[hitlist[hit][0]]
        let s2 = Stars[hitlist[hit][1]]
        if (!s1 || !s2) continue;
    
        let snew = sphere()
        snew.mass = s1.mass + s2.mass
        snew.momentum = s1.momentum + s2.momentum
        snew.pos = (s1.mass*s1.pos + s2.mass*s2.pos) / snew.mass
        snew.color = (s1.mass*s1.color + s2.mass*s2.color) / snew.mass
        snew.trail = attach_trail(snew, {radius:2e8, pps:30, retain:150})
        let R = Rsun*pow(snew.mass / Msun, 1/3)
        snew.size = 2*R*vec(1,1,1)
        
        s1.trail.clear()
        s2.trail.clear()
        s1.visible = false
        s2.visible = false
        
        Stars[hitlist[hit][0]] = snew
        Stars[hitlist[hit][1]] = null
    }
}
