import { Parser } from "expr-eval";

// Shape of a family's `parameterization` block from the bank JSON. Tolerates extra
// fields (figure_generator, tolerance, etc.) — those are advisory and ignored here.
export type ParamSpec = {
  // String choices (e.g. "1-40" range labels) are substituted as text only and
  // never passed to expr-eval.
  choices?: Array<number | string>;
  range?: [number, number];
  decimals?: number;
  note?: string;
};

export type Parameterization = {
  parameters: Record<string, ParamSpec>;
  derived?: Record<string, string>;
  answer_formula?: Record<string, string>;
  inverse_variant?: {
    parameters?: Record<string, ParamSpec>;
    answer?: string;
  };
};

export type Draw = Record<string, number | string>;

const parser = new Parser();
const ALLOWED = new Set([
  "sqrt",
  "exp",
  "log",
  "ln",
  "round",
  "floor",
  "ceil",
  "abs",
  "min",
  "max",
]);

// mulberry32: deterministic PRNG; Math.random is non-deterministic and unusable
// for an audited per-attempt draw. Seed is uint32; returns float in [0, 1).
function mulberry32(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// 3 sig figs, dropping trailing zeros — keeps prompts looking clean across
// magnitudes (0.045, 1.23, 44100). Caller can override via parameter `decimals`.
function roundSignificant(v: number, sigFigs = 3): number {
  if (v === 0 || !Number.isFinite(v)) return v;
  return Number(v.toPrecision(sigFigs));
}

function roundDecimals(v: number, decimals: number): number {
  const f = Math.pow(10, decimals);
  return Math.round(v * f) / f;
}

// Normalize bank's `a**b` to expr-eval's `a^b`, and rewrite two-arg `round(x, n)`
// (which the bank uses but expr-eval's parser rejects) to a math-equivalent
// single-arg form. Has to live in the renderer (not at JSON parse time) so
// fuzz validation and runtime evaluate identical strings.
function normalize(expr: string): string {
  return normalizeRoundN(expr.replace(/\*\*/g, "^"));
}

// `round(<expr>, <n>)` → `(round((<expr>) * 10^(<n>)) / 10^(<n>))`. Walks the
// string tracking paren depth so nested parens inside <expr> don't fool us, and
// recurses so nested `round(round(...), ...)` works too.
function normalizeRoundN(expr: string): string {
  let out = "";
  let i = 0;
  while (i < expr.length) {
    if (expr.startsWith("round(", i)) {
      const open = i + 5;
      let depth = 1;
      let commaPos = -1;
      let j = open + 1;
      while (j < expr.length && depth > 0) {
        const c = expr[j];
        if (c === "(") depth++;
        else if (c === ")") {
          depth--;
          if (depth === 0) break;
        } else if (c === "," && depth === 1) {
          commaPos = j;
        }
        j++;
      }
      if (depth !== 0) {
        out += expr[i];
        i++;
        continue;
      }
      const close = j;
      if (commaPos === -1) {
        out += expr.slice(i, close + 1);
        i = close + 1;
      } else {
        const inner = normalizeRoundN(expr.slice(open + 1, commaPos));
        const n = normalizeRoundN(expr.slice(commaPos + 1, close));
        out += `(round((${inner}) * (10^(${n}))) / (10^(${n})))`;
        i = close + 1;
      }
    } else {
      out += expr[i];
      i++;
    }
  }
  return out;
}

function evalFormula(expr: string, scope: Draw): number {
  const ast = parser.parse(normalize(expr));
  // Build a numeric-only scope: string-valued params (e.g. label choices like
  // "1-40") are text-substitution only and must not reach expr-eval.
  const numericScope: Record<string, number> = {};
  for (const [k, v] of Object.entries(scope)) {
    if (typeof v === "number") numericScope[k] = v;
  }
  // Guard against the family using a function we haven't whitelisted (e.g. some
  // future bank that calls a network-side helper). expr-eval has no `eval`/Function
  // path, but pinning the function set keeps surprise out of formula land.
  for (const sym of ast.symbols({ withMembers: false })) {
    // Symbols are variable names AND function names. Skip ones present in the
    // numeric scope (real variables); reject anything else not in the allowlist.
    if (sym in numericScope) continue;
    if (!ALLOWED.has(sym)) {
      throw new Error(`disallowed symbol in formula: ${sym}`);
    }
  }
  return ast.evaluate(numericScope);
}

/**
 * Sample concrete parameter values from a family's parameterization block.
 * Deterministic on `seed` so a stored draw can be replayed if needed.
 */
export function sampleDraw(spec: Parameterization, seed: number): Draw {
  const rand = mulberry32(seed);
  const draw: Draw = {};

  for (const [name, p] of Object.entries(spec.parameters ?? {})) {
    if (p.choices && p.choices.length > 0) {
      const i = Math.min(Math.floor(rand() * p.choices.length), p.choices.length - 1);
      // Choice may be number or string label; pass through unchanged.
      draw[name] = p.choices[i];
    } else if (p.range) {
      const [lo, hi] = p.range;
      const raw = lo + rand() * (hi - lo);
      draw[name] =
        p.decimals != null ? roundDecimals(raw, p.decimals) : roundSignificant(raw, 3);
    } else {
      throw new Error(`parameter ${name} has neither choices nor range`);
    }
  }

  for (const [name, expr] of Object.entries(spec.derived ?? {})) {
    draw[name] = evalFormula(expr, draw);
  }

  return draw;
}

/**
 * Substitute {name} tokens with values from the draw. Tokens not present in the
 * draw are left in place so the dry-run check (`hasUnresolvedTokens`) can catch
 * authoring bugs like a prompt referencing an undefined parameter.
 */
export function renderTemplate(template: string, draw: Draw): string {
  return template.replace(/\{(\w+)\}/g, (match, key) => {
    if (!(key in draw)) return match;
    return formatValue(draw[key]);
  });
}

function formatValue(v: number | string): string {
  if (typeof v === "string") return v;
  if (Number.isInteger(v)) return String(v);
  return String(roundSignificant(v, 4));
}

const UNRESOLVED = /\{[A-Za-z_]\w*\}/;
export function hasUnresolvedTokens(s: string): boolean {
  return UNRESOLVED.test(s);
}

/**
 * Evaluate a family's `answer_formula` against a draw. Returns the named
 * computed quantities so the caller can format them into the expected-answer
 * snapshot however it wants. Used during importer fuzz validation, queue-build
 * rendering, and hand-coded answer-key checks.
 */
export function computeAnswers(
  spec: Parameterization,
  draw: Draw,
): Record<string, number> {
  const out: Record<string, number> = {};
  for (const [name, expr] of Object.entries(spec.answer_formula ?? {})) {
    out[name] = evalFormula(expr, draw);
  }
  return out;
}
