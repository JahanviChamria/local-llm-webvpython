"""Named, saved watchlists stored as plain text files under watchlists/.

Each saved list is one ticker per line, same format as the active watchlist.txt.
The dashboard lets the user save the current list under a name and reload it later.
"""
from pathlib import Path

WATCHLIST_DIR = Path("watchlists")


def _safe_name(name: str) -> str:
    """Filesystem-safe slug for a user-supplied list name."""
    cleaned = "".join(c for c in name if c.isalnum() or c in (" ", "-", "_")).strip()
    return cleaned.replace(" ", "_")


def list_saved() -> list[str]:
    if not WATCHLIST_DIR.exists():
        return []
    return sorted(p.stem for p in WATCHLIST_DIR.glob("*.txt"))


def save(name: str, content: str) -> str | None:
    safe = _safe_name(name)
    if not safe:
        return None
    WATCHLIST_DIR.mkdir(exist_ok=True)
    (WATCHLIST_DIR / f"{safe}.txt").write_text(content)
    return safe


def load(name: str) -> str:
    p = WATCHLIST_DIR / f"{_safe_name(name)}.txt"
    return p.read_text() if p.exists() else ""


def delete(name: str) -> None:
    p = WATCHLIST_DIR / f"{_safe_name(name)}.txt"
    if p.exists():
        p.unlink()
