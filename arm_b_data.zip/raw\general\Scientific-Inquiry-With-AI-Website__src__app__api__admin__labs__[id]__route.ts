import { NextResponse } from "next/server";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { eq, inArray, sql } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { labs, labFiles, questions } from "@/lib/db/schema";
import { requireAdmin, checkOrigin } from "@/lib/auth/guards";
import { findSimulation } from "@/lib/portal/simulations";
import { normalizeLabName, LAB_NAME_MAX_LEN, InvalidLabNameError } from "@/lib/labs/find-or-create";
import { LAB_DOC_SECTIONS, type LabDocKind } from "@/lib/portal/lab-sections";
import { validateLabFileEligibility, findCrossKindDuplicate } from "@/lib/labs/sections-write";

export const runtime = "nodejs";

const patchSchema = z.object({
  name: z.string().min(1).max(LAB_NAME_MAX_LEN).optional(),
  description: z
    .string()
    .max(500)
    .transform((s) => {
      const t = s.trim();
      return t.length === 0 ? null : t;
    })
    .nullable()
    .optional(),
  hasPrelab: z.boolean().optional(),
  hasPostlab: z.boolean().optional(),
  hasPractice: z.boolean().optional(),
  hasSimulation: z.boolean().optional(),
  hasActivity: z.boolean().optional(),
  hasAnalysisGuide: z.boolean().optional(),
  hasVideoTutorial: z.boolean().optional(),
  hasResearchPaper: z.boolean().optional(),
  hasStudentGuide: z.boolean().optional(),
  hasSelfCheck: z.boolean().optional(),
  hasAiGradingPrompt: z.boolean().optional(),
  hasInstructorGuide: z.boolean().optional(),
  hasLessonPlan: z.boolean().optional(),
  hasSelfCheckAnswerKey: z.boolean().optional(),
  simulationId: z.string().max(120).nullable().optional(),
  practiceLabId: z.string().uuid().nullable().optional(),
  prelabFileIds: z.array(z.string().uuid()).optional(),
  postlabFileIds: z.array(z.string().uuid()).optional(),
  activityFileIds: z.array(z.string().uuid()).optional(),
  analysisGuideFileIds: z.array(z.string().uuid()).optional(),
  videoTutorialFileIds: z.array(z.string().uuid()).optional(),
  researchPaperFileIds: z.array(z.string().uuid()).optional(),
  studentGuideFileIds: z.array(z.string().uuid()).optional(),
  selfCheckFileIds: z.array(z.string().uuid()).optional(),
  aiGradingPromptFileIds: z.array(z.string().uuid()).optional(),
  instructorGuideFileIds: z.array(z.string().uuid()).optional(),
  lessonPlanFileIds: z.array(z.string().uuid()).optional(),
  selfCheckAnswerKeyFileIds: z.array(z.string().uuid()).optional(),
});

type PatchBody = z.infer<typeof patchSchema>;

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const csrf = checkOrigin(req);
  if (csrf) return csrf;
  const g = await requireAdmin();
  if (g instanceof NextResponse) return g;

  const { id } = await ctx.params;

  let body: PatchBody;
  try {
    body = patchSchema.parse(await req.json());
  } catch (err) {
    return NextResponse.json({ error: "invalid body", detail: String(err) }, { status: 400 });
  }

  const [existing] = await db.select().from(labs).where(eq(labs.id, id)).limit(1);
  if (!existing) return NextResponse.json({ error: "not_found" }, { status: 404 });

  let nextName = existing.name;
  if (body.name !== undefined) {
    try {
      nextName = normalizeLabName(body.name);
      if (nextName.length === 0) throw new InvalidLabNameError("lab name is empty");
    } catch (err) {
      if (err instanceof InvalidLabNameError) {
        return NextResponse.json({ error: "invalid lab name", detail: err.message }, { status: 400 });
      }
      throw err;
    }
    if (nextName.toLowerCase() !== existing.name.toLowerCase()) {
      const conflict = (
        await db
          .select({ id: labs.id })
          .from(labs)
          .where(sql`lower(${labs.name}) = lower(${nextName})`)
          .limit(1)
      )[0];
      if (conflict && conflict.id !== id) {
        return NextResponse.json(
          { error: "name_conflict", detail: "Another lab already uses this name." },
          { status: 409 },
        );
      }
    }
  }

  const nextHasPractice = body.hasPractice ?? existing.hasPractice;
  const nextHasSimulation = body.hasSimulation ?? existing.hasSimulation;
  const nextSimulationId = nextHasSimulation
    ? body.simulationId !== undefined
      ? body.simulationId
      : existing.simulationId
    : null;
  const nextPracticeLabId = nextHasPractice
    ? body.practiceLabId !== undefined
      ? body.practiceLabId
      : existing.practiceLabId
    : null;

  if (nextHasSimulation) {
    if (!nextSimulationId || !findSimulation(nextSimulationId)) {
      return NextResponse.json(
        { error: "invalid_simulation", detail: "Pick a simulation from the registry." },
        { status: 400 },
      );
    }
  }

  if (nextPracticeLabId) {
    const [row] = await db
      .select({ qCount: sql<number>`count(${questions.id})` })
      .from(labs)
      .leftJoin(questions, eq(questions.labId, labs.id))
      .where(eq(labs.id, nextPracticeLabId))
      .groupBy(labs.id);
    if (!row) {
      return NextResponse.json(
        { error: "invalid_practice_lab", detail: "Practice-set lab not found." },
        { status: 400 },
      );
    }
    if (Number(row.qCount) === 0) {
      return NextResponse.json(
        { error: "invalid_practice_lab", detail: "Practice-set lab has no questions yet." },
        { status: 400 },
      );
    }
  }

  // Per-section resolution. For each file-based section:
  //  - nextHas: the resulting has-* flag.
  //  - effective: the target id list, or null = "leave existing rows untouched".
  //    (kind sent → that list; kind disabled + sent → []; disabled + not sent →
  //    untouched, preserving the pre-existing behavior.)
  const nextHasByFlag: Record<string, boolean> = {
    hasPrelab: body.hasPrelab ?? existing.hasPrelab,
    hasPostlab: body.hasPostlab ?? existing.hasPostlab,
    hasActivity: body.hasActivity ?? existing.hasActivity,
    hasAnalysisGuide: body.hasAnalysisGuide ?? existing.hasAnalysisGuide,
    hasVideoTutorial: body.hasVideoTutorial ?? existing.hasVideoTutorial,
    hasResearchPaper: body.hasResearchPaper ?? existing.hasResearchPaper,
    hasStudentGuide: body.hasStudentGuide ?? existing.hasStudentGuide,
    hasSelfCheck: body.hasSelfCheck ?? existing.hasSelfCheck,
    hasAiGradingPrompt: body.hasAiGradingPrompt ?? existing.hasAiGradingPrompt,
    hasInstructorGuide: body.hasInstructorGuide ?? existing.hasInstructorGuide,
    hasLessonPlan: body.hasLessonPlan ?? existing.hasLessonPlan,
    hasSelfCheckAnswerKey: body.hasSelfCheckAnswerKey ?? existing.hasSelfCheckAnswerKey,
  };
  const effectiveByKind = {} as Record<LabDocKind, string[] | null>;
  const uploadEntries: {
    id: string;
    upload: (typeof LAB_DOC_SECTIONS)[number]["upload"];
    facultyOnly: boolean;
  }[] = [];
  for (const s of LAB_DOC_SECTIONS) {
    const sent = body[s.bodyKey] !== undefined;
    const nextIds = sent ? Array.from(new Set(body[s.bodyKey]!)) : null;
    const effective = nextHasByFlag[s.hasFlag] ? nextIds : sent ? [] : null;
    effectiveByKind[s.kind] = effective;
    for (const fid of effective ?? [])
      uploadEntries.push({ id: fid, upload: s.upload, facultyOnly: s.facultyOnly ?? false });
  }

  // Load existing attachments so we can (a) fill in "untouched" kinds for the
  // cross-kind duplicate check and (b) diff for the write.
  const existingRows = await db
    .select({
      id: labFiles.id,
      fileId: labFiles.fileId,
      kind: labFiles.kind,
      position: labFiles.position,
    })
    .from(labFiles)
    .where(eq(labFiles.labId, id));
  type Existing = (typeof existingRows)[number];
  const existingByKind = {} as Record<LabDocKind, Existing[]>;
  for (const s of LAB_DOC_SECTIONS) existingByKind[s.kind] = [];
  for (const r of existingRows) existingByKind[r.kind as LabDocKind]?.push(r);

  // Final id set per kind (effective if provided, else existing) → cross-kind
  // duplicate guard against the unique (lab_id, file_id) constraint.
  const finalIdsByKind = {} as Record<LabDocKind, string[]>;
  for (const s of LAB_DOC_SECTIONS) {
    finalIdsByKind[s.kind] =
      effectiveByKind[s.kind] ?? existingByKind[s.kind].map((r) => r.fileId);
  }
  const dup = findCrossKindDuplicate(finalIdsByKind);
  if (dup) {
    return NextResponse.json(
      {
        error: "duplicate_attach",
        detail: "The same file cannot be attached to two sections of one lab.",
        fileId: dup,
      },
      { status: 400 },
    );
  }

  const eligErr = await validateLabFileEligibility(uploadEntries);
  if (eligErr) return eligErr;

  try {
    await db.transaction(async (tx) => {
      const nextDescription =
        body.description !== undefined ? body.description : existing.description;

      await tx
        .update(labs)
        .set({
          name: nextName,
          description: nextDescription,
          hasPrelab: nextHasByFlag.hasPrelab,
          hasPostlab: nextHasByFlag.hasPostlab,
          hasPractice: nextHasPractice,
          hasSimulation: nextHasSimulation,
          hasActivity: nextHasByFlag.hasActivity,
          hasAnalysisGuide: nextHasByFlag.hasAnalysisGuide,
          hasVideoTutorial: nextHasByFlag.hasVideoTutorial,
          hasResearchPaper: nextHasByFlag.hasResearchPaper,
          hasStudentGuide: nextHasByFlag.hasStudentGuide,
          hasSelfCheck: nextHasByFlag.hasSelfCheck,
          hasAiGradingPrompt: nextHasByFlag.hasAiGradingPrompt,
          hasInstructorGuide: nextHasByFlag.hasInstructorGuide,
          hasLessonPlan: nextHasByFlag.hasLessonPlan,
          hasSelfCheckAnswerKey: nextHasByFlag.hasSelfCheckAnswerKey,
          simulationId: nextSimulationId,
          practiceLabId: nextPracticeLabId,
        })
        .where(eq(labs.id, id));

      // Diff per kind. DELETEs run before INSERTs so a cross-kind move (same
      // file id, kind A → kind B) doesn't collide on the unique constraint.
      const idsToDelete: string[] = [];
      const keeps: { rowId: string; position: number }[] = [];
      const inserts: { fileId: string; kind: LabDocKind; position: number }[] = [];

      for (const s of LAB_DOC_SECTIONS) {
        const nextIds = effectiveByKind[s.kind];
        if (nextIds === null) continue; // untouched
        const currentByFile = new Map(existingByKind[s.kind].map((r) => [r.fileId, r]));
        nextIds.forEach((fid, pos) => {
          const found = currentByFile.get(fid);
          if (found) keeps.push({ rowId: found.id, position: pos });
          else inserts.push({ fileId: fid, kind: s.kind, position: pos });
        });
        for (const r of existingByKind[s.kind]) {
          if (!nextIds.includes(r.fileId)) idsToDelete.push(r.id);
        }
      }

      if (idsToDelete.length > 0) {
        await tx.delete(labFiles).where(inArray(labFiles.id, idsToDelete));
      }
      for (const k of keeps) {
        await tx.update(labFiles).set({ position: k.position }).where(eq(labFiles.id, k.rowId));
      }
      if (inserts.length > 0) {
        await tx.insert(labFiles).values(inserts.map((r) => ({ labId: id, ...r })));
      }
    });
  } catch (err) {
    return NextResponse.json(
      { error: "lab_update_failed", detail: err instanceof Error ? err.message : String(err) },
      { status: 500 },
    );
  }

  revalidatePath("/portal", "layout");
  return NextResponse.json({ ok: true });
}

export async function DELETE(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const csrf = checkOrigin(req);
  if (csrf) return csrf;
  const g = await requireAdmin();
  if (g instanceof NextResponse) return g;

  const { id } = await ctx.params;

  const [existing] = await db.select({ id: labs.id }).from(labs).where(eq(labs.id, id)).limit(1);
  if (!existing) return NextResponse.json({ error: "not_found" }, { status: 404 });

  const [{ qCount }] = await db
    .select({ qCount: sql<number>`count(*)` })
    .from(questions)
    .where(eq(questions.labId, id));

  try {
    if (Number(qCount) === 0) {
      // Hard delete — cascade removes lab_files, lab_document_completions,
      // and simulation_completions for this lab.
      await db.delete(labs).where(eq(labs.id, id));
    } else {
      // Soft unpublish: clear module_order + all has_* flags AND delete lab_files.
      await db.transaction(async (tx) => {
        await tx.delete(labFiles).where(eq(labFiles.labId, id));
        await tx
          .update(labs)
          .set({
            moduleOrder: null,
            hasPrelab: false,
            hasPostlab: false,
            hasPractice: false,
            hasSimulation: false,
            hasActivity: false,
            hasAnalysisGuide: false,
            hasVideoTutorial: false,
            hasResearchPaper: false,
            hasStudentGuide: false,
            hasSelfCheck: false,
            hasAiGradingPrompt: false,
            hasInstructorGuide: false,
            hasLessonPlan: false,
            hasSelfCheckAnswerKey: false,
            simulationId: null,
            practiceLabId: null,
          })
          .where(eq(labs.id, id));
      });
    }
  } catch (err) {
    return NextResponse.json(
      { error: "lab_delete_failed", detail: err instanceof Error ? err.message : String(err) },
      { status: 500 },
    );
  }

  revalidatePath("/portal", "layout");
  return NextResponse.json({ ok: true, hardDeleted: Number(qCount) === 0 });
}
