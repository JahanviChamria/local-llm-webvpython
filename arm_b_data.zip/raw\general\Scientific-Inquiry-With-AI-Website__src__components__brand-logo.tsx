import Link from "next/link";

// Site-wide navbar brand: the flask/molecule mark plus the wordmark.
// The mark PNG has a white background, so .brand-mark uses mix-blend-mode:
// multiply to drop the white onto the cream sidebar surface (see portal.css).
// The <img> is decorative (alt="") because the adjacent wordmark already
// names the site for assistive tech.
function Lockup() {
  return (
    <span className="brand-lockup">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src="/brand-mark.png" alt="" className="brand-mark" width={38} height={38} />
      <span className="logo">
        Scientific Inquiry
        <br />
        with AI
      </span>
    </span>
  );
}

export function BrandLogo({ href }: { href?: string }) {
  if (href) {
    return (
      <Link href={href} className="brand-link" style={{ display: "block" }}>
        <Lockup />
      </Link>
    );
  }
  return <Lockup />;
}
