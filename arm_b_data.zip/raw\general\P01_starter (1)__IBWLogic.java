import java.awt.Color;
import java.util.Random;
import java.util.Scanner;
import java.util.Arrays;
import java.awt.event.KeyEvent;
import java.io.*;

public class IBWLogic{
   
      
   //Name of file containing all the possible "secret words"
   private static final String SECRET_WORDS_FNAME = "secret_words.txt";   
   
   //Name of file containing all the valid guess words
   private static final String VALID_GUESSES_FNAME = "valid_words.txt";   
   
   //Use for generating random numbers!
   private static final Random rand = new Random();
   
   //Dimensions of the game grid in the game window
   public static final int MAX_ROWS = 5;
   public static final int MAX_COLS = 6;
   
   //Character codes for the enter and backspace key press
   public static final char ENTER_KEY = KeyEvent.VK_ENTER; //(numeric value is: 10)
   public static final char BACKSPACE_KEY = KeyEvent.VK_BACK_SPACE; //(numeric value is: 8)
   
   //The null character value (used to represent an "empty" value for a spot on the game grid)
   public static final char NULL_CHAR = 0;
   
   //Various Color Values
   private static final Color COLOR_GREEN = new Color(53, 209, 42); //(Green... right letter right place)
   private static final Color COLOR_YELLOW = new Color(235, 216, 52); //(Yellow... right letter wrong place)
   private static final Color COLOR_DGRAY = Color.DARK_GRAY; //(Dark Gray)
   private static final Color COLOR_LGRAY = new Color(160, 163, 168); //(Light Gray)
   
   //ints representing different potential arrow directions (drawn at the end of a letter row)
   public static final int ARROW_LEFT = -1;
   public static final int ARROW_RIGHT = 1;
   public static final int ARROW_BLANK = 0;
   
   //A preset, hard-coded secret word to be use when the resepective debug is enabled
   private static final char[] DEBUG_SECRET = {'R','A','I','D','E','R'};
   
   
   //...Feel free to add more **PRIMITIVE FINAL** variables of your own!
      

    private static final char TO_RIGHT='R';
    private static final char TO_LEFT='L';

   
   
   
   //******************   NON-FINAL GLOBAL VARIABLES   ******************
   //********  YOU CANNOT ADD ANY ADDITIONAL NON-FINAL GLOBALS!  ******** 
   
   
   //Array storing all valid guesses read out of the respective file
   private static String[] dictionary;
   
   //The active row/col where the user left off typing
   private static int activeRow, activeCol;
      
   //The indices out of the dictionary where the current "leftmost" and 
   //"rightmost" (ie alphabetically earliest and latest, respetively) occur
   private static int leftmostWordIdx, rightmostWordIdx;
   
   //*******************************************************************
   
   
   
   
   //Short for "initilaize".  This function gets called ONCE when the game is  
   //very first launched before the user has the opportunity to do anything.
   //
   //Should perform any initialization that needs to happen at the start of the game,
   //and return the randomly chosen "secret word" as a char array
   //
   //If either of the valid guess or secret words files cannot be read, or are
   //missing the word count in the first line) this function returns null.
   public static char[] init(){
      activeRow=0;
      activeCol=0;

      String selectedWord="";
      Scanner scan;
      File secretWords=new File(SECRET_WORDS_FNAME);
      File validGuesses=new File(VALID_GUESSES_FNAME);
      try{
        scan=new Scanner(validGuesses);
        int validGuessesCount=fillDictionary(scan);                  //filling the dictionary array with all valid words
        leftmostWordIdx=0;
        rightmostWordIdx=validGuessesCount-1;                        //initializing the range
        scan=new Scanner(secretWords);
        selectedWord=generateSecretWord(scan);
        scan.close();
      }
      catch(FileNotFoundException fnfe){
        System.exit(1);
      }
      catch(NumberFormatException nfe){
        System.exit(1);
      }
      if(GameLauncher.DEBUG_USE_PRESET_SECRET){
        return DEBUG_SECRET;
      }
      return generateCharArray(selectedWord);                      //returning the selected secret word
   }

   public static int fillDictionary(Scanner scan){                   //filling the dictionary array
        int count=Integer.parseInt(scan.nextLine());
        dictionary=new String[count];
        int k=0;
        while(scan.hasNext()){
            dictionary[k++]=scan.nextLine();
        }
        return count;                                               //returning the total number of valid guesses
   }
   
   public static String generateSecretWord(Scanner scan){           //generating secret word randomly
        int secretWordsCount=Integer.parseInt(scan.nextLine());
        int randomWordChosen=rand.nextInt(secretWordsCount) + 1;
        int count=0;
        String selectedWord="";
        while(scan.hasNext()){
            count++;
            String currentWord=scan.nextLine();
            if(count==randomWordChosen){
                selectedWord=currentWord;
            }
        }
        return selectedWord;                                        //returning the selected word
   }

   
   //Complete your warmup task (Section 3.1.1 step 2) here by calling the requisite
   //functions out of IBWGraphics.
   //This function gets called ONCE after the graphics window has been
   //initialized and init has been called.
   public static void warmup(){
     /*
     IBWGraphics.setCellChar(0, 0, 'C');
     IBWGraphics.setCellColor(0, 0, COLOR_YELLOW);

     IBWGraphics.setCellChar(1, 3, 'O');
     IBWGraphics.setArrowDirection(1, ARROW_LEFT);

     IBWGraphics.setArrowDirection(2, ARROW_RIGHT);

     IBWGraphics.setCellChar(3, 5, 'S');
     IBWGraphics.setCellColor(3, 5, COLOR_GREEN);

     IBWGraphics.setCellChar(4, 5, 'C');
     IBWGraphics.setCellColor(4, 5, COLOR_DGRAY);

     IBWGraphics.setKeyboardColor('U', COLOR_DGRAY);
     IBWGraphics.setKeyboardColor('C', COLOR_GREEN);
     */
     //All of your warmup code will go in here except for the
     //"wiggle" task (3.1.1 step 3)... where will that go?

   }   
   
   
   //This function gets called everytime the user types a valid key on the
   //keyboard (alphabetic character, enter, or backspace) or clicks one of the
   //keys on the graphical keyboard interface.
   //
   //The key pressed is passed in as a char value.
   public static void keyReact(char key){                            //whenever a key is pressed
     
      //placeholder debug print message
      System.out.println("key pressed: '" + key + "' (int value: " + (int)key + ")");
      //if(key=='P'){
      //    IBWGraphics.triggerWiggle(3);
      //}
      if(key==ENTER_KEY){
          enterPressed();
      }
      else if(key==BACKSPACE_KEY){
          backspacePressed();
      }
      else{
          letterPressed(key);
      }
   }


   public static void letterPressed(char letter){                    //when alphabet keys are pressed
      if(activeCol<=MAX_COLS-1){
          IBWGraphics.setCellChar(activeRow, activeCol, letter);
          activeCol++;
      }
      else{                                                          //row full
          IBWGraphics.triggerWiggle(activeRow);
      }
   }

   public static void enterPressed(){
      if(activeCol<=MAX_COLS-1){                                     //row not full
          IBWGraphics.triggerWiggle(activeRow);
      }
      else{
          if(inRange(getWord())){                        //checking if it is a valid word in the dictionary and if it is in the current range
            checkWord();
            if(activeRow<=MAX_ROWS-2){
                activeRow++;                                          //going to next row
                activeCol=0;
            }
          }
          else{
            IBWGraphics.triggerWiggle(activeRow);                     //invalid word or not in range
          }
      }
   }

   public static void backspacePressed(){
      if(activeCol==0){
          IBWGraphics.triggerWiggle(activeRow);                     //empty row
      }
      else{
          activeCol--;
          IBWGraphics.setCellChar(activeRow, activeCol, NULL_CHAR); //deleting character
      }
   }

   public static String getWord(){                                  //obtains the word in any row
        String word="";
        for(int i=0;i<activeCol;i++){
            word+=IBWGraphics.getCellChar(activeRow, i);
        }
        return word;
   }

   public static void checkWord(){                                  //compares current word to the secret word
          //green pass, yellow pass, gray pass
          char[] lettersInWord=IBWGraphics.getSecretWordArr();      //array for duplicate letter handling
          checkForGreen(lettersInWord);
          checkForYellow(lettersInWord);
          checkForGray(lettersInWord);
          String word=getWord();
          if(word.equalsIgnoreCase(IBWGraphics.getSecretWordStr())){      //checking if the secret word is found
              displayArrow(ARROW_BLANK);                                  //no arrow if the secret word has been found
              IBWGraphics.endGame(true);
          }
          else{
              displayArrow(determineRange(getWord()));                    //displaying arrow and updating the range
              if(activeRow==MAX_ROWS-1)
                IBWGraphics.endGame(false);
          }
   }


   public static void setColors(int row, int col, char letter, Color color){ //sets the colors of the cells and keyboard characters
      IBWGraphics.setCellColor(row, col, color);
      IBWGraphics.setKeyboardColor(letter, color);
   }

   public static char[] generateCharArray(String str){                       //generates character array for randomly selected secret word
      int len=str.length();
      char[] toReturn=new char[len];
      for(int i=0;i<len;i++){
        toReturn[i]=Character.toUpperCase(str.charAt(i));
      }
      return toReturn;
   }

   public static void displayArrow(int direction){                          //displaying arrow
      IBWGraphics.setArrowDirection(activeRow, direction);
   }

   public static boolean inRange(String word){                              //checking if a word falls within the current range and if it is a valid English word
      for(int i=leftmostWordIdx;i<=rightmostWordIdx;i++){
         if(dictionary[i].equalsIgnoreCase(word)){
            return true;
         }
      }
      return false;
   }

   public static int determineRange(String word){                           //updating the range and determining the direction of the arrow
      for(int i=leftmostWordIdx;i<=rightmostWordIdx;i++){
         if(dictionary[i].equalsIgnoreCase(word)){
            char secretWordRelativePos=compareWords(word);
            if(secretWordRelativePos==TO_RIGHT){
                leftmostWordIdx=i;
                return ARROW_RIGHT;
            }
            else{
                rightmostWordIdx=i;
                return ARROW_LEFT;
            }
         }
      }
      return 0;                                                 //unreachable condition, a character will always be returned from the for loop
   }

   public static char compareWords(String word){                      //compares the current word and secret word alphabetically
      if(word.compareToIgnoreCase(IBWGraphics.getSecretWordStr())<0)
        return TO_RIGHT;
      else
        return TO_LEFT;
   }


   public static void checkForGreen(char[] allLetters){               //1st pass for detecting characters in the correct position
      for(int i=0;i<activeCol;i++){
          char currentLetter=IBWGraphics.getCellChar(activeRow,i);
          if(currentLetter==allLetters[i]){
            allLetters[i]=NULL_CHAR;
            setColors(activeRow,i,currentLetter,COLOR_GREEN);
          }
      }
   }



   public static void checkForYellow(char[] allLetters){             //2nd pass for detecting characters in the word but in the wrong position
      for(int i=0;i<activeCol;i++){
          char currentLetter=IBWGraphics.getCellChar(activeRow,i);
          for(int j=0;j<allLetters.length;j++){
              if(currentLetter==allLetters[j] && i!=j && !IBWGraphics.getCellColor(activeRow,i).equals(COLOR_GREEN)){
                  allLetters[j]=NULL_CHAR;
                  if(!IBWGraphics.getKeyboardColor(currentLetter).equals(COLOR_GREEN))  //to prevent green keys from turning yellow
                      setColors(activeRow,i,currentLetter,COLOR_YELLOW);
                  else{
                     setColors(activeRow,i,currentLetter,COLOR_YELLOW);
                     IBWGraphics.setKeyboardColor(currentLetter, COLOR_GREEN);
                  }
              }
          }
      }
   }

   public static void checkForGray(char[] allLetters){               //final pass for changing other keys to dark gray
      for(int i=0;i<activeCol;i++){
          char currentLetter=IBWGraphics.getCellChar(activeRow,i);
          if(!IBWGraphics.getCellColor(activeRow,i).equals(COLOR_GREEN) && !IBWGraphics.getCellColor(activeRow,i).equals(COLOR_YELLOW)){
                if((IBWGraphics.getKeyboardColor(currentLetter).equals(COLOR_GREEN))||(IBWGraphics.getKeyboardColor(currentLetter).equals(COLOR_YELLOW))){  //to prevent green/yellow keys from turning dark gray
                      Color CurrentColor=IBWGraphics.getKeyboardColor(currentLetter); //temporary Color object
                      setColors(activeRow,i,currentLetter,COLOR_DGRAY);
                      IBWGraphics.setKeyboardColor(currentLetter, CurrentColor);
                  }
                  else{
                      setColors(activeRow,i,currentLetter,COLOR_DGRAY);
                  }
          }
      }
   }


}
   
   

