import java.util.*;

public class Preferences 
{
    public static <T> double preferenceSimilarity(ArrayList<T> list1, ArrayList<T> list2) {
        if (list1 == null || list2 == null || list1.size() != list2.size() || list1.size() == 0) {
            return 0.0;
        }

        int n = list1.size();

        //map each element in list1 to its index
        HashMap<T, Integer> indexMap = new HashMap<>();
        for (int i = 0; i < n; i++) {
            indexMap.put(list1.get(i), i);
        }

        //create an array representing list2 in terms of list1 indices
        int[] list2indices = new int[n];
        for (int i = 0; i < n; i++) {
            list2indices[i] = indexMap.get(list2.get(i));
        }

        //count inversions using merge sort
        int[] temp = new int[n];
        long inversions = mergeSortAndCount(list2indices, temp, 0, n - 1);

        //compute total pairs
        long totalPairs = (long) n * (n - 1) / 2;

        //compute similarity
        return ((double) (totalPairs - inversions)) / totalPairs;
    }

    //helper function: merge sort that counts inversions
    private static long mergeSortAndCount(int[] arr, int[] temp, int left, int right) {
        long count = 0;
        if (left < right) {
            int mid = (left + right) / 2;
            count += mergeSortAndCount(arr, temp, left, mid);
            count += mergeSortAndCount(arr, temp, mid + 1, right);
            count += mergeAndCount(arr, temp, left, mid, right);
        }
        return count;
    }

    private static long mergeAndCount(int[] arr, int[] temp, int left, int mid, int right) {
        int i = left;       //pointer for left half
        int j = mid + 1;    //pointer for right half
        int k = left;       //temp array
        long count = 0;

        while (i <= mid && j <= right) {
            if (arr[i] <= arr[j]) {
                temp[k++] = arr[i++];
            } else {
                temp[k++] = arr[j++];
                count += (mid - i + 1); //count inversions
            }
        }

        while (i <= mid) temp[k++] = arr[i++];
        while (j <= right) temp[k++] = arr[j++];

        for (i = left; i <= right; i++) arr[i] = temp[i];

        return count;
    }

    public static void main(String[] args) {
        ArrayList<String> list1 = new ArrayList<>(Arrays.asList("A", "D", "B", "G", "C", "F", "E"));
        ArrayList<String> list2 = new ArrayList<>(Arrays.asList("B", "A", "D", "G", "E", "C", "F"));

        double similarity = preferenceSimilarity(list1, list2);
        System.out.println("Preference similarity: " + similarity);

        //identical lists 
        ArrayList<String> list3 = new ArrayList<>(Arrays.asList("A", "B", "C", "D"));
        ArrayList<String> list4 = new ArrayList<>(Arrays.asList("A", "B", "C", "D"));
        System.out.println("Preference similarity: " + preferenceSimilarity(list3, list4));

        //reversed lists
        ArrayList<String> list5 = new ArrayList<>(Arrays.asList("A", "B", "C", "D"));
        ArrayList<String> list6 = new ArrayList<>(Arrays.asList("D", "C", "B", "A"));
        System.out.println("Preference similarity: " + preferenceSimilarity(list5, list6));
    }
}