JavaScript 3.2
let axes = [vec(1,0,0), vec(0,1,0), vec(0,0,1)]

let k = 1
let m = 1
let spacing = 1.0
let atom_radius = 0.3*spacing
let L0 = spacing-1.8*atom_radius
let V0 = pi*pow(0.5*atom_radius,2)*L0 // initial volume of spring
let N = 4
let crystal = makeCrystal(N, atom_radius, spacing, 0.1*spacing*sqrt(k/m))
scene.center = 0.5*(N-1)*vec(1,1,1)
scene.autoscale = false
let dt = 0.04*(2*pi*sqrt(m/k))

// Display text below the 3D graphics:
scene.title = "A model of a solid represented as atoms connected by interatomic bonds"

let s = 'To rotate "camera", drag with right button or Ctrl-drag.\n'
s += "To zoom, drag with middle button or Alt/Option depressed, or use scroll wheel.\n"
s += "  On a two-button mouse, middle is left + right.\n"
s += "To pan left/right and up/down, Shift-drag.\n"
s += "Touch screen: pinch/extend to zoom, swipe or two-finger rotate.\n"
scene.caption = s

function makeCrystal( N, atom_radius, spacing, momentumRange ) {
    let crystal = { atoms:[], springs:[] }
    let atom
    let x,y,z

    function atomAt(np) {
        if (np.x>=0 && np.y>=0 && np.z>=0 && np.x<N && np.y<N && np.z<N)
            return crystal.atoms[np.x + np.y*N + np.z*N*N]
        // Otherwise create an invisible wall and return it
        let w = box()
        w.visible = false  // comment out to see the true model
        w.size = atom_radius*vec(1,1,1)
        w.pos = np*spacing
        w.momentum = vec(0,0,0)
        return w
    }

    // Create N^3 atoms in a grid
    for(z=0; z<N; z++)
        for(y=0; y<N; y++)
            for(x=0; x<N; x++) {
                atom = sphere()
                atom.pos = vec(x,y,z)*spacing
                atom.size = 2*atom_radius*vec(1,1,1)
                atom.color = vec(0,0.58,0.69)
                atom.momentum = momentumRange*vec.random()
                crystal.atoms.push( atom )
            }
    
    // Create a grid of springs linking each atom to the adjacent atoms
    // in each dimension, or to invisible walls where no atom is adjacent
    for(let d=0; d<3; d++)
        for(z=-1; z<N; z++)
            for(y=-1; y<N; y++)
                for(x=-1; x<N; x++) {
                    atom = atomAt(vec(x,y,z))
                    let neighbor = atomAt(vec(x,y,z)+axes[d])

                    if (atom.visible || neighbor.visible) {
                        let spring = helix()
                        spring.visible = atom.visible && neighbor.visible
                        spring.thickness = 0.05
                        spring.size = vec(spacing,atom_radius,atom_radius)
                        spring.atoms = [ atom, neighbor ]
                        spring.color = vec(1,0.5,0)
                        crystal.springs.push(spring)
                    }
                }
    return crystal
}

while (true) {
    await rate(60)
    for(let a=0; a<crystal.atoms.length; a++) {
        let atom = crystal.atoms[a]
        atom.pos = atom.pos + atom.momentum/m*dt
    }
    for(let s=0; s<crystal.springs.length; s++) {
        let spring = crystal.springs[s]
        spring.axis = spring.atoms[1].pos - spring.atoms[0].pos
        let L = mag(spring.axis)
        spring.axis = spring.axis.norm()
        spring.pos = spring.atoms[0].pos+0.5*atom_radius*spring.axis
        let Ls = L-1*atom_radius
        spring.size.x = Ls
        let Fdt = spring.axis * (k*dt * (1-spacing/L))
        spring.atoms[0].momentum = spring.atoms[0].momentum + Fdt
        spring.atoms[1].momentum = spring.atoms[1].momentum - Fdt
    }
}
