class RSVPClient{                       //Jahanvi Chamria and Isabel Drexler Booth
    public static void main(String[] args){

        String empty=new String();
        String[] emails1={"sarahf@colgate.edu", "georgiam@colgate.edu", "mayan@colgate.edu", "rachell@colgate.edu", "natalier@colgate.edu", "johnw@colgate.edu", "alank@colgate.edu", "ritag@colgate.edu", "williamr@colgate.edu"};
        String[] emails2={"catiem@colgate.edu", "alexr@colgate.edu", "catieM@colgate.edu", "isabellap@colgate.edu", "ryank@colgate.edu", "victoriau@colgate.edu", "thomase@colgate.edu", "alexisc@colgate.edu", "jamesb@colgate.edu", "charliew@colgate.edu", "mikej@colgate.edu", "davidb@colgate.edu", "emilyc@colgate.edu", "joshr@colgate.edu"};
        String[] emails3={"rosst@colgate.edu", "blaker@colgate.edu", "rosst@colgate.edu"};
        String[] emails4={"kc@colgate.edu", "jasonl@colgate.edu"};
        String[] emails5={"phoebeq@gmail.com", "jeremyk@colgate.edu"};
        String[] emails6={"johnw@colgate.edu", empty};
        String[] emails7={"chloew@colgate.edu", "mikej@colgate.edu", "sarahl@colgate.edu", "davidb@colgate.edu", "emilyc@colgate.edu", "sophiag@colgate.edu", "joshuad@colgate.edu", "graceo@colgate.edu"};
        String[] emails8={"rebeccaz@colgate.edu", "danielm@colgate.edu", "natalier@colgate.edu", "matthews@colgate.edu", "oliverf@colgate.edu", "johnp@colgate.edu", "luked@colgate.edu", "laurak@colgate.edu", "chrisv@colgate.edu", "benjamina@colgate.edu"};
        String[] emails9={"henryw@colgate.edu", "juliab@colgate.edu", "ethanc@colgate.edu", "isabellap@colgate.edu", "ryank@colgate.edu", "victoriau@colgate.edu", "thomase@colgate.edu", "alexisc@colgate.edu", "jamesb@colgate.edu", "chloew@colgate.edu", "mikej@colgate.edu", "catiem@colgate.edu", "davidb@colgate.edu", "emilyc@colgate.edu", "joshr@colgate.edu"};

        RSVP Event1=new RSVP("Birthday party", emails1, 16, 2);
        RSVP Event2=new RSVP("Anniversary party", emails2, 20, -1);
        //RSVP Event3=new RSVP("Wedding reception", emails3, 24, 3); //test cases for invalid email arrays
        //RSVP Event4=new RSVP("Birthday party", emails4, -1, 1);
        //RSVP Event5=new RSVP("New year party", emails5, 22, 6);
        //RSVP Event6=new RSVP("Christmas party", emails6, 17, 3);
        RSVP Event7=new RSVP("Movie night", emails7, 20, 2);
        RSVP Event8=new RSVP("Writing workshop", emails8, 23, 1);
        RSVP Event9=new RSVP("Halloween party", emails9, 21, 4);

        RSVP[] events={Event1, Event2, Event8, Event9};

        System.out.println("Sarah F is invited to the Birthday party at 16:00?: "+Event1.isInvited("sarahf@colgate.edu"));
        System.out.println("David B is invited to the Birthday party at 16:00?: "+Event1.isInvited("davidb@colgate.edu"));

        System.out.println("Chloe W is invited to the Halloween party at 21:00?: "+RSVP.isInvited("chloew@colgate.edu", emails9));
        System.out.println("Luke D is invited to the Halloween party at 21:00?: "+RSVP.isInvited("luked@colgate.edu", emails9));

        System.out.println("Sarah F has RSVPed to the Birthday Party at 16:00?: "+Event1.hasAcceptedInvitation("sarahf@colgate.edu"));
        System.out.println("Sarah F RSVPed to the Birthday Party successfully?:"+Event1.acceptInvitation("sarahf@colgate.edu", 1));
        System.out.println("Sarah F has RSVPed to the Birthday Party at 16:00?: "+Event1.hasAcceptedInvitation("sarahf@colgate.edu"));

        System.out.println("Sarah F RSVPed to the Birthday Party successfully?:"+Event1.acceptInvitation("sarahf@colgate.edu", 1)); //has already RSVPed
        System.out.println("Georgia M RSVPed to the Birthday Party successfully?:"+Event1.acceptInvitation("georgiam@colgate.edu", 1));
        System.out.println("Rita G RSVPed to the Birthday Party successfully?:"+Event1.acceptInvitation("ritag@colgate.edu", 1));
        System.out.println("Alan K RSVPed to the Birthday Party successfully?:"+Event1.acceptInvitation("alank@colgate.edu", 1));
        System.out.println("Maya N RSVPed to the Birthday Party successfully?:"+Event1.acceptInvitation("mayan@colgate.edu", 1));
        System.out.println("William R RSVPed to the Birthday Party successfully?:"+Event1.acceptInvitation("williamr@colgate.edu", 1));
        System.out.println("Rita N RSVPed to the Birthday Party successfully?:"+Event1.acceptInvitation("ritan@colgate.edu", 1)); //not invited to event
        System.out.println("Unnamed RSVPed to the Birthday Party successfully?:"+Event1.acceptInvitation(empty, 1)); //null email
        System.out.println("Rachel L RSVPed to the Birthday Party successfully?:"+Event1.acceptInvitation("rachell@colgate.edu", 4)); //>max additonal guests
        System.out.println("Rachel L RSVPed to the Birthday Party successfully?:"+Event1.acceptInvitation("rachell@colgate.edu", -1)); //<0 additional guests

        Event2.acceptInvitation("catiem@colgate.edu", 2);
        Event2.acceptInvitation("catieM@colgate.edu", 2);
        Event2.acceptInvitation("alexr@colgate.edu", 2);
        Event2.acceptInvitation("isabellap@colgate.edu", 1);
        Event2.acceptInvitation("ryank@colgate.edu", 1);
        Event2.acceptInvitation("victoriau@colgate.edu", 1);
        Event2.acceptInvitation("thomase@colgate.edu", 1);
        Event2.acceptInvitation("alexisc@colgate.edu", 1);
        Event2.acceptInvitation("jamesb@colgate.edu", 1);
        Event2.acceptInvitation("chloew@colgate.edu", 1);
        Event2.acceptInvitation("mikej@colgate.edu", 1);

        Event7.acceptInvitation("chloew@colgate.edu", 1);
        Event7.acceptInvitation("sarahl@colgate.edu", 0);
        Event7.acceptInvitation("davidb@colgate.edu", 1);
        Event7.acceptInvitation("emilyc@colgate.edu", 1);
        Event7.acceptInvitation("sophiag@colgate.edu", 0);
        Event7.acceptInvitation("joshuad@colgate.edu", 0);
        Event7.acceptInvitation("graceo@colgate.edu", 0);

        Event8.acceptInvitation("danielm@colgate.edu", 0);
        Event8.acceptInvitation("natalier@colgate.edu", 0);
        Event8.acceptInvitation("matthews@colgate.edu", 0);
        Event8.acceptInvitation("oliverf@colgate.edu", 0);
        Event8.acceptInvitation("johnp@colgate.edu", 0);
        Event8.acceptInvitation("luked@colgate.edu", 0);
        Event8.acceptInvitation("laurak@colgate.edu", 0);
        Event8.acceptInvitation("chrisv@colgate.edu", 0);
        Event8.acceptInvitation("benjamina@colgate.edu", 0);

        Event9.acceptInvitation("henryw@colgate.edu", 0);
        Event9.acceptInvitation("ethanc@colgate.edu", 0);
        Event9.acceptInvitation("isabellap@colgate.edu", 1);
        Event9.acceptInvitation("ryank@colgate.edu", 0);
        Event9.acceptInvitation("victoriau@colgate.edu", 0);
        Event9.acceptInvitation("thomase@colgate.edu", 1);
        Event9.acceptInvitation("alexisc@colgate.edu", 1);
        Event9.acceptInvitation("jamesb@colgate.edu", 1);
        Event9.acceptInvitation("chloew@colgate.edu", 0);
        Event9.acceptInvitation("mikej@colgate.edu", 0);
        Event9.acceptInvitation("catiem@colgate.edu", 0);

        System.out.println(Event1);
        System.out.println(Event2);
        System.out.println(Event7);
        System.out.println(Event8);
        System.out.println(Event9);

        System.out.println("Is "+Event2.getName()+" popular?: "+Event2.isPopularEvent());
        System.out.println("Is "+Event7.getName()+" popular?: "+Event7.isPopularEvent());
        System.out.println("Is "+Event8.getName()+" popular?: "+Event8.isPopularEvent());
        System.out.println("Is "+Event9.getName()+" popular?: "+Event9.isPopularEvent());

        System.out.println("No. of popular events Chloe W RSVPed to: "+RSVP.acceptInvitationsToPopularEvents("chloew@colgate.edu", events, 1));
        System.out.println("No. of popular events Catie M RSVPed to: "+RSVP.acceptInvitationsToPopularEvents("catiem@colgate.edu", events, 1));
        System.out.println("No. of popular events Luke D RSVPed to: "+RSVP.acceptInvitationsToPopularEvents("luked@colgate.edu", events, 1));





    }
}
