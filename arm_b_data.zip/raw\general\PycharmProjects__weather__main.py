import requests
import json

api_key = 'YOUR_API_KEY'

def fetch_data(city):
    base_url = 'https://api.openweathermap.org/data/2.5/weather'
    params = {
        'q': city,
        'appid': api_key,
        'units': 'metric'
    }

    response = requests.get(base_url, params=params)
    data = response.json()

    return data

def display(data):
    if data['cod'] == 200:
        main_info = data['main']
        weather_info = data['weather'][0]

        temperature = main_info['temp']
        humidity = main_info['humidity']
        description = weather_info['description']

        print(f"Weather in {data['name']}, {data['sys']['country']}:")
        print(f"Description: {description}")
        print(f"Temperature: {temperature}°C")
        print(f"Humidity: {humidity}%")
    else:
        print("City not found. Please check the city name and try again.")

def celsius_to_fahrenheit(celsius):
    return (celsius * 9/5) + 32


city = input("Enter city name: ")
data = fetch_data(city)

if data:
    display(data)

    choice = input("Would you like to convert temperature to Fahrenheit? (Y/N): ").upper()
    if choice == 'Y':
        temperature_celsius = data['main']['temp']
        temperature_fahrenheit = celsius_to_fahrenheit(temperature_celsius)
        print(f"Temperature in Fahrenheit: {temperature_fahrenheit}°F")
