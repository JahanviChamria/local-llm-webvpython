// Tests for the prelab-progress import normalization — pure-function checks only.
//
// These cover the tolerant-parsing boundary shared by the manual-upload route
// and the sync_prelab_progress MCP tool: how a chatbot's raw JSON is folded into
// the canonical shape, and how an engagement_scoring block is read. The db-gated
// half (applyProfileImport: published-lab resolution + merge) needs a hermetic DB
// fixture like test-oauth.ts and is out of scope here.
//
// Run: npx tsx --test scripts/test-prelab-sync.ts

import { test, describe } from "node:test";
import assert from "node:assert/strict";

// Import from ./import-normalize (no db-client import) so these stay pure —
// pulling ./import would transitively load @/lib/db/client, which throws when
// LOCAL_DATABASE_URL is unset.
import {
  coerceScore,
  normalizeImport,
  extractEngagement,
  bodySchema,
} from "@/lib/student-profiles/import-normalize";

describe("coerceScore", () => {
  test("passes through finite numbers", () => {
    assert.equal(coerceScore(3), 3);
    assert.equal(coerceScore(0), 0);
    assert.equal(coerceScore(4.5), 4.5);
  });

  test("parses the leading number out of score strings", () => {
    assert.equal(coerceScore("3"), 3);
    assert.equal(coerceScore("2.00"), 2);
    assert.equal(coerceScore("2.00 / 5"), 2);
    assert.equal(coerceScore("4 out of 5"), 4);
  });

  test("returns null when there is no parseable number", () => {
    for (const v of ["", "none", null, undefined, {}, [], NaN, Infinity]) {
      assert.equal(coerceScore(v), null, `expected ${String(v)} → null`);
    }
  });
});

describe("normalizeImport", () => {
  test("accepts snake_case column aliases", () => {
    const out = normalizeImport({
      mind_map: { a: 1 },
      learning_style: { pace: "fast" },
      struggles: { momentum: true },
    });
    assert.deepEqual(out.mindMap, { a: 1 });
    assert.deepEqual(out.learningStyle, { pace: "fast" });
    assert.deepEqual(out.struggles, { momentum: true });
  });

  test("prefers camelCase over snake_case when both present", () => {
    const out = normalizeImport({ mindMap: { keep: 1 }, mind_map: { drop: 1 } });
    assert.deepEqual(out.mindMap, { keep: 1 });
  });

  test("coerces + rounds topicMastery values, dropping unparseable ones", () => {
    const out = normalizeImport({
      topicMastery: { labA: "3.4", labB: 4.6, labC: "nope" },
    });
    assert.deepEqual(out.topicMastery, { labA: 3, labB: 5 });
  });

  test("ignores unknown keys and non-record input", () => {
    assert.deepEqual(normalizeImport({ random: 1 }), {});
    assert.deepEqual(normalizeImport(null), {});
    assert.deepEqual(normalizeImport("string"), {});
    assert.deepEqual(normalizeImport([1, 2]), {});
  });
});

describe("extractEngagement", () => {
  test("reads lab_name + string score from an engagement_scoring block", () => {
    const eng = extractEngagement({
      engagement_scoring: { lab_name: "collisions", total_ai_engagement_score: "2.00 / 5" },
    });
    assert.deepEqual(eng, { labId: undefined, labName: "collisions", level: 2 });
  });

  test("accepts camelCase block + score keys", () => {
    const eng = extractEngagement({
      engagementScoring: { lab_name: "collisions", totalAiEngagementScore: 3 },
    });
    assert.equal(eng?.level, 3);
    assert.equal(eng?.labName, "collisions");
  });

  test("reads a lab given as an object with a name field", () => {
    const eng = extractEngagement({
      engagement_scoring: { lab: { name: "collisions" }, total_ai_engagement_score: 4 },
    });
    assert.equal(eng?.labName, "collisions");
  });

  test("carries lab_id through when supplied", () => {
    const id = "3f1c9b2a-1d4e-4c6a-9b8f-0a1b2c3d4e5f";
    const eng = extractEngagement({
      engagement_scoring: { lab_id: id, total_ai_engagement_score: 5 },
    });
    assert.equal(eng?.labId, id);
  });

  test("returns null without a parseable score or block", () => {
    assert.equal(extractEngagement({ engagement_scoring: { lab_name: "collisions" } }), null);
    assert.equal(extractEngagement({}), null);
    assert.equal(extractEngagement(null), null);
  });
});

describe("extractEngagement on the real tutor-doc JSON (Section 8 output)", () => {
  // The prelab doc emits engagement_scoring WITHOUT a lab_name, and tags the lab
  // only by a generic top-level title. This is why name-based routing drops the
  // score, and why the MCP tool must route by lab_id (opts.routeLabId) instead.
  const docJson = {
    Lab_name: { name: "Inelastic Collisions Chat History" },
    mind_map: { root_concepts: ["Energy conversion"], keywords: ["restitution"] },
    struggles: { conceptual_bottlenecks: ["empty at the bottom"] },
    engagement_scoring: {
      criteria_breakdown: {
        depth_of_reasoning: { max_points: 1.25, score_assigned: 1.0 },
      },
      total_ai_engagement_score: "3.75 / 5",
    },
  };

  test("parses and rounds an out-of-5 total_ai_engagement_score", () => {
    assert.equal(extractEngagement(docJson)?.level, 4); // 3.75 -> 4
  });

  test("rescales an out-of-100 score into the 0-5 band instead of dropping it", () => {
    // The doc's chat feedback is /100; the model sometimes carries that into the
    // JSON. 75/100 -> 3.75 -> 4, rather than being rejected as out-of-range.
    assert.equal(
      extractEngagement({ engagement_scoring: { total_ai_engagement_score: "75 / 100" } })?.level,
      4,
    );
    assert.equal(
      extractEngagement({ engagement_scoring: { total_ai_engagement_score: 92 } })?.level,
      5, // 92 / 20 = 4.6 -> 5
    );
  });

  test("only sees the generic title, which matches no real lab", () => {
    const eng = extractEngagement(docJson);
    assert.equal(eng?.labName, "Inelastic Collisions Chat History");
    assert.equal(eng?.labId, undefined);
  });

  test("normalizeImport still folds the doc's freeform sections", () => {
    const out = normalizeImport(docJson);
    assert.ok(out.mindMap);
    assert.ok(out.struggles);
  });
});

describe("the real tutor output (captured from a live session)", () => {
  // Verbatim JSON a Collisions prelab produced. Locks in that the whole object,
  // passed as-is, folds into every profile section plus a routed score.
  const realOutput = {
    Lab_name: { name: "Inelastic Collisions Chat History" },
    mind_map: {
      root_concepts: ["Energy Conversion in a Bouncing Ball"],
      keywords: ["elastic potential energy", "coefficient of restitution"],
    },
    personalization: {
      user_background: "Physics + CS student comfortable with formal notation.",
    },
    learning_style: { primary_mode: "Deductive, formula-oriented" },
    struggles: {
      conceptual_bottlenecks: ["distinguishing height ratio from speed ratio"],
      misconceptions_corrected: ["floor throws the ball back"],
    },
    engagement_scoring: {
      criteria_breakdown: {
        depth_of_reasoning: { max_points: 1.25, score_assigned: 0.85 },
      },
      total_ai_engagement_score: "3.10 / 5",
    },
  };

  test("normalizeImport folds all four freeform sections", () => {
    const out = normalizeImport(realOutput);
    assert.ok(out.mindMap, "mindMap");
    assert.ok(out.personalization, "personalization");
    assert.ok(out.learningStyle, "learningStyle");
    assert.ok(out.struggles, "struggles");
  });

  test("extractEngagement yields a routable 0-5 level", () => {
    const eng = extractEngagement(realOutput);
    assert.equal(eng?.level, 3); // 3.10 -> 3
  });
});

describe("bodySchema", () => {
  test("accepts a typical normalized body", () => {
    const parsed = bodySchema.safeParse({
      topicMastery: { labA: 3 },
      struggles: { momentum: "sign error" },
    });
    assert.equal(parsed.success, true);
  });

  test("rejects a freeform section over the 16KB per-field cap", () => {
    const parsed = bodySchema.safeParse({ struggles: { huge: "x".repeat(20_000) } });
    assert.equal(parsed.success, false);
  });

  test("accepts an empty object (nothing_applicable is decided downstream)", () => {
    assert.equal(bodySchema.safeParse({}).success, true);
  });
});
