"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { Card } from "@/components/portal/primitives";
import { FigureField } from "@/components/portal/figure-field";

type Difficulty = "easy" | "medium" | "hard";
type Format = "true_false" | "multiple_choice" | "short_answer" | "calculation";
type Role = "canonical" | "isomorph" | "transfer" | "scaffold" | "extension";
type McOption = { id: string; text: string };

type QuestionDetail = {
  id: string;
  labId: string;
  labName: string;
  difficulty: Difficulty;
  prompt: string;
  expectedAnswer: string | null;
  format: Format;
  role: Role;
  options: McOption[] | null;
  correctOption: string | null;
  figureFileId: string | null;
  figureUrl: string | null;
};

type LabOption = { id: string; name: string };

const ROLES: Role[] = ["canonical", "isomorph", "transfer", "scaffold", "extension"];

function optionLetter(i: number): string {
  return String.fromCharCode(65 + i); // A, B, C, ...
}

export function EditQuestionClient({
  question,
  labs,
}: {
  question: QuestionDetail;
  labs: LabOption[];
}) {
  const router = useRouter();
  const [labName, setLabName] = useState(question.labName);
  const [difficulty, setDifficulty] = useState<Difficulty>(question.difficulty);
  const [format, setFormat] = useState<Format>(question.format);
  const [role, setRole] = useState<Role>(question.role);
  const [prompt, setPrompt] = useState(question.prompt);
  const [expectedAnswer, setExpectedAnswer] = useState(question.expectedAnswer ?? "");

  // Seed the MC editor from the existing question when it's already multiple choice.
  const seededOptions =
    question.format === "multiple_choice" && question.options && question.options.length > 0
      ? question.options.map((o) => o.text)
      : ["", ""];
  const seededCorrect =
    question.format === "multiple_choice" && question.options
      ? Math.max(0, question.options.findIndex((o) => o.id === question.correctOption))
      : 0;
  const [options, setOptions] = useState<string[]>(seededOptions);
  const [correctIndex, setCorrectIndex] = useState(seededCorrect);
  const [tfCorrect, setTfCorrect] = useState<"True" | "False">(
    question.correctOption === "False" ? "False" : "True",
  );

  const [figureFileId, setFigureFileId] = useState<string | null>(question.figureFileId);
  const [figureBusy, setFigureBusy] = useState(false);

  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  const isMC = format === "multiple_choice";
  const isTF = format === "true_false";

  function addOption() {
    setOptions((o) => (o.length >= 12 ? o : [...o, ""]));
  }
  function removeOption(i: number) {
    setOptions((o) => (o.length <= 2 ? o : o.filter((_, idx) => idx !== i)));
    setCorrectIndex((ci) => (ci === i ? 0 : ci > i ? ci - 1 : ci));
  }
  function setOptionText(i: number, v: string) {
    setOptions((o) => o.map((t, idx) => (idx === i ? v : t)));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    const payload: Record<string, unknown> = {
      labName,
      difficulty,
      format,
      role,
      prompt,
      // Explicit null clears the column; "" also becomes null via the server transform.
      expectedAnswer: expectedAnswer.length > 0 ? expectedAnswer : null,
      // null clears the attached figure; a uuid attaches it.
      figureFileId,
    };
    if (isMC) {
      const texts = options.map((t) => t.trim());
      if (texts.length < 2 || texts.some((t) => t.length === 0)) {
        setError("Multiple choice needs at least 2 options, each non-empty.");
        return;
      }
      payload.options = texts.map((text, i) => ({ id: optionLetter(i), text }));
      payload.correctOption = optionLetter(correctIndex);
    } else if (isTF) {
      payload.correctOption = tfCorrect;
    }
    // Text formats omit options/correctOption — the server clears them based on format.

    start(async () => {
      const res = await fetch(`/api/admin/questions/${question.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const j = (await res.json().catch(() => ({}))) as { error?: string };
        setError(j.error ?? `Request failed (${res.status})`);
        return;
      }
      router.refresh();
    });
  }

  async function del() {
    if (!confirm(`Delete this ${question.difficulty} question from "${question.labName}"?`)) return;
    start(async () => {
      const res = await fetch(`/api/admin/questions/${question.id}`, {
        method: "DELETE",
      });
      if (!res.ok) {
        alert("Delete failed.");
        return;
      }
      // The current row is gone; router.refresh() would re-fetch a missing row and
      // fall into notFound(). Navigate back to the list instead.
      router.push("/admin/questions");
    });
  }

  return (
    <div className="col">
      <div className="screen-head row between center" style={{ gap: 12 }}>
        <div>
          <div className="section-label">Teaching</div>
          <h1>Edit question</h1>
        </div>
        <Link href="/admin/questions" className="btn ghost sm">← Back to list</Link>
      </div>

      <form onSubmit={submit}>
        <Card>
          <label className="field-label">
            <span>Lab name</span>
            <input
              className="field"
              type="text"
              value={labName}
              onChange={(e) => setLabName(e.target.value)}
              list="labs-list"
              required
              maxLength={100}
            />
            <datalist id="labs-list">
              {labs.map((l) => (
                <option key={l.id} value={l.name} />
              ))}
            </datalist>
            <span className="light" style={{ fontSize: 11.5, marginTop: 5, display: "block" }}>
              Changing this re-points the question to that lab (creating it if it doesn&apos;t exist).
            </span>
          </label>

          <label className="field-label" style={{ marginTop: 14 }}>
            <span>Difficulty</span>
            <select
              className="field"
              value={difficulty}
              onChange={(e) => setDifficulty(e.target.value as Difficulty)}
            >
              <option value="easy">Easy</option>
              <option value="medium">Medium</option>
              <option value="hard">Hard</option>
            </select>
          </label>

          <label className="field-label" style={{ marginTop: 14 }}>
            <span>Format</span>
            <select
              className="field"
              value={format}
              onChange={(e) => setFormat(e.target.value as Format)}
            >
              <option value="short_answer">Short answer</option>
              <option value="multiple_choice">Multiple choice</option>
              <option value="true_false">True / False</option>
              <option value="calculation">Calculation</option>
            </select>
          </label>

          <label className="field-label" style={{ marginTop: 14 }}>
            <span>Role</span>
            <select
              className="field"
              value={role}
              onChange={(e) => setRole(e.target.value as Role)}
            >
              {ROLES.map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </label>

          <label className="field-label" style={{ marginTop: 14 }}>
            <span>Question prompt</span>
            <textarea
              className="field"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              required
              rows={5}
              maxLength={10_000}
            />
          </label>

          <FigureField
            initialUrl={question.figureUrl}
            onChange={setFigureFileId}
            onBusyChange={setFigureBusy}
          />

          {isMC && (
            <div className="field-label" style={{ marginTop: 14 }}>
              <span>
                Options{" "}
                <span className="light" style={{ fontWeight: 400 }}>
                  · select the correct one
                </span>
              </span>
              <div className="col" style={{ gap: 7, marginTop: 6 }}>
                {options.map((text, i) => (
                  <div key={i} className="row center" style={{ gap: 9 }}>
                    <input
                      type="radio"
                      name="mc-correct"
                      checked={correctIndex === i}
                      onChange={() => setCorrectIndex(i)}
                      title="Mark as correct"
                    />
                    <span className="mono" style={{ width: 16, color: "var(--muted)", fontSize: 13 }}>
                      {optionLetter(i)}
                    </span>
                    <input
                      className="field grow"
                      type="text"
                      value={text}
                      onChange={(e) => setOptionText(i, e.target.value)}
                      placeholder={`Option ${optionLetter(i)}`}
                      maxLength={2000}
                    />
                    <button
                      type="button"
                      className="btn ghost sm"
                      onClick={() => removeOption(i)}
                      disabled={options.length <= 2}
                      title="Remove option"
                    >
                      ✕
                    </button>
                  </div>
                ))}
                <div>
                  <button
                    type="button"
                    className="btn ghost sm"
                    onClick={addOption}
                    disabled={options.length >= 12}
                  >
                    + Add option
                  </button>
                </div>
              </div>
            </div>
          )}

          {isTF && (
            <div className="field-label" style={{ marginTop: 14 }}>
              <span>Correct answer</span>
              <div className="row" style={{ gap: 7, marginTop: 6 }}>
                {(["True", "False"] as const).map((v) => (
                  <button
                    key={v}
                    type="button"
                    className={"btn sm" + (tfCorrect === v ? " primary" : "")}
                    onClick={() => setTfCorrect(v)}
                  >
                    {v}
                  </button>
                ))}
              </div>
            </div>
          )}

          <label className="field-label" style={{ marginTop: 14 }}>
            <span>{isMC || isTF ? "Answer explanation (optional)" : "Expected answer (optional)"}</span>
            <textarea
              className="field"
              value={expectedAnswer}
              onChange={(e) => setExpectedAnswer(e.target.value)}
              rows={4}
              maxLength={50_000}
            />
            <span className="light" style={{ fontSize: 11.5, marginTop: 5, display: "block" }}>Leave blank to clear.</span>
          </label>

          {error && <p style={{ color: "var(--orange)", fontSize: 13, marginTop: 10 }}>{error}</p>}

          <div className="row center" style={{ gap: 9, marginTop: 16 }}>
            <button type="submit" disabled={pending || figureBusy} className="btn primary">
              {pending ? "Saving…" : "Save changes"}
            </button>
            <button type="button" onClick={del} disabled={pending} className="btn danger">
              Delete
            </button>
          </div>
        </Card>
      </form>
    </div>
  );
}
