import httpx
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

WATCHLIST_PATH = Path("watchlist.txt")
SCREENER_URL = (
    "https://query1.finance.yahoo.com/v1/finance/screener/predefined/saved"
    "?scrIds=MOST_ACTIVES&count=50"
)
HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    )
}

# Exclude non-optionable or low-quality symbols
EXCLUDE = {"BRK.B", "BRK.A"}


def fetch_top_tickers(n: int = 50) -> list[str]:
    try:
        r = httpx.get(SCREENER_URL, headers=HEADERS, timeout=10)
        quotes = r.json()["finance"]["result"][0]["quotes"]
        tickers = [
            q["symbol"] for q in quotes
            if q.get("symbol") and q["symbol"] not in EXCLUDE
        ]
        return tickers[:n]
    except Exception as e:
        logger.error(f"Failed to fetch top tickers: {e}")
        return []


def update_watchlist(n: int = 50) -> list[str]:
    tickers = fetch_top_tickers(n)
    if not tickers:
        logger.warning("No tickers fetched, watchlist unchanged")
        return []
    WATCHLIST_PATH.write_text("\n".join(tickers) + "\n")
    logger.info(f"Watchlist updated: {len(tickers)} tickers")
    return tickers


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
    tickers = update_watchlist()
    print(f"Top {len(tickers)} tickers by volume:")
    for t in tickers:
        print(f"  {t}")
