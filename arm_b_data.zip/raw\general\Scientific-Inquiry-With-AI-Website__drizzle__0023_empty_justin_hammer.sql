ALTER TYPE "public"."lab_file_kind" ADD VALUE 'instructor_guide';--> statement-breakpoint
ALTER TYPE "public"."lab_file_kind" ADD VALUE 'lesson_plan';--> statement-breakpoint
ALTER TYPE "public"."lab_file_kind" ADD VALUE 'self_check_answer_key';--> statement-breakpoint
ALTER TABLE "labs" ADD COLUMN "has_instructor_guide" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "labs" ADD COLUMN "has_lesson_plan" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "labs" ADD COLUMN "has_self_check_answer_key" boolean DEFAULT false NOT NULL;