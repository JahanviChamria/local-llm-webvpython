import { NextResponse } from "next/server";
import { requireAdmin, checkOrigin } from "@/lib/auth/guards";
import { sweepAbandonedUploads } from "@/lib/sweep";

export const runtime = "nodejs";

export async function POST(req: Request) {
  const csrf = checkOrigin(req);
  if (csrf) return csrf;
  const g = await requireAdmin();
  if (g instanceof NextResponse) return g;

  const result = await sweepAbandonedUploads();
  return NextResponse.json(result);
}
