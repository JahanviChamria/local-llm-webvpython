// POST /api/portal/common-mistakes/summary
//
// Faculty/admin-only. Returns a short AI-generated summary of the common
// mistakes and struggles for a set of students. The scope is re-derived here
// from the authenticated user (never trusted from the client): admins summarize
// across every student; faculty must pass a classId they own.
//
// Body: { "classId"?: string }   // required for faculty, ignored for admin

import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth/session";
import { checkOrigin } from "@/lib/auth/guards";
import {
  getCommonMistakes,
  reportHasData,
  type MistakeScope,
} from "@/lib/portal/common-mistakes";
import { summarizeCommonMistakes } from "@/lib/portal/common-mistakes-summary";

export const runtime = "nodejs";

export async function POST(req: Request) {
  const csrf = checkOrigin(req);
  if (csrf) return csrf;

  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  if (user.role !== "admin" && user.role !== "faculty") {
    return NextResponse.json({ error: "forbidden" }, { status: 403 });
  }

  let body: { classId?: unknown } = {};
  try {
    const text = await req.text();
    if (text.trim().length > 0) body = JSON.parse(text);
  } catch {
    return NextResponse.json({ error: "invalid_json" }, { status: 400 });
  }
  const classId = typeof body.classId === "string" ? body.classId : null;

  // Admin → global; faculty → one class they own. resolveScopeStudentIds inside
  // getCommonMistakes re-checks ownership, so an unowned/bogus classId yields a
  // null report and a clean 403 below.
  let scope: MistakeScope;
  if (user.role === "admin") {
    scope = { kind: "all" };
  } else {
    if (!classId) {
      return NextResponse.json({ error: "class_required" }, { status: 400 });
    }
    scope = { kind: "class", classId, ownerId: user.id };
  }

  const report = await getCommonMistakes(scope);
  if (report === null) {
    return NextResponse.json({ error: "forbidden" }, { status: 403 });
  }
  if (!reportHasData(report)) {
    return NextResponse.json(
      { error: "no_data", detail: "Not enough practice or struggle data yet to summarize." },
      { status: 422 },
    );
  }

  const summary = await summarizeCommonMistakes(report);
  if (summary === null) {
    return NextResponse.json(
      { error: "summary_unavailable", detail: "The AI summary couldn't be generated right now." },
      { status: 503 },
    );
  }

  return NextResponse.json({ summary, studentsInScope: report.studentsInScope });
}
