/*
 Lab 04
 
 This client program uses Coordinate objects.
*/

public class CoordinateClient {
     
     public static void main(String[] args) {
          
          //**** 2.1.1 Getting Started ****
          // construct a default Coordinate object named coord1...
          Coordinate coord1 = new Coordinate();
          // ...and print it!
          System.out.println("coord1 is: " + coord1);
          //What do you think will be printed by the above?
          //there's something you'll need to correct in Coordinate.java!
          
          
          
          

          
          
          //**** 2.1.3: Translate ****
          //Test your solution for the translate method below, by calling it on
          //coord1 with the arguments 10 and 30, then print coord1.
          //Does the output make sense?
          coord1.translate(10, 30);
          System.out.println("updated coord1 is: " + coord1);
          
          
          
          
          
          
          //**** 2.1.4: Retrieve Individual Coords****
          //Uncomment the print statements below and try to compile/run.
          //Fix the issue WITHOUT modifying Coordinate.java!
         
          System.out.println("coord1's x is: " + coord1.getX());
          System.out.println("coord1's y is: " + coord1.getY());
          
          
          
          
          
          
          
          
          //**** 2.1.5: Two Argument Constructor ****
          //create two Coordinate objects, coord2 at (8, 2) and coord3 at (4, 3)
          //Print them to verify their coordinates!
          
          Coordinate coord2=new Coordinate(8,2);
          Coordinate coord3=new Coordinate(4,3);
          System.out.println("coord2 is " + coord2);
          System.out.println("coord3 is " + coord3);
          
          
     


   
          
          //**** 2.2.1 - 2.2.3 ****
          //Test your getQuadrant(), generateRotation(), and areSameQuadrant(...) methods!
          //Test each method as you implement them!

          Coordinate coord4=new Coordinate(1,0);
          Coordinate coord5=new Coordinate(0,0);
          Coordinate coord6=new Coordinate(0,3);
          Coordinate coord7=new Coordinate(-2,-4);
          Coordinate coord8=new Coordinate(5,-6);
          Coordinate coord9=new Coordinate(-3,7);

          //getQuadrant()
          System.out.println(coord1+" is in quadrant "+coord1.getQuadrant());
          System.out.println(coord2+" is in quadrant "+coord2.getQuadrant());
          System.out.println(coord4+" is in quadrant "+coord4.getQuadrant());
          System.out.println(coord7+" is in quadrant "+coord7.getQuadrant());
          System.out.println(coord8+" is in quadrant "+coord8.getQuadrant());
          System.out.println(coord9+" is in quadrant "+coord9.getQuadrant());

          //generateRotation()
          System.out.println(coord1+" rotated 90 degrees counter-clockwise gives "+coord1.generateRotation());
          System.out.println(coord3+" rotated 90 degrees counter-clockwise gives "+coord3.generateRotation());
          System.out.println(coord4+" rotated 90 degrees counter-clockwise gives "+coord4.generateRotation());
          System.out.println(coord5+" rotated 90 degrees counter-clockwise gives "+coord5.generateRotation());
          System.out.println(coord6+" rotated 90 degrees counter-clockwise gives "+coord6.generateRotation());
          System.out.println(coord7+" rotated 90 degrees counter-clockwise gives "+coord7.generateRotation());
          System.out.println(coord8+" rotated 90 degrees counter-clockwise gives "+coord8.generateRotation());
          System.out.println(coord9+" rotated 90 degrees counter-clockwise gives "+coord9.generateRotation());

          //areSameQuadrant
          System.out.println(coord1+" and "+coord2+" in the same quadrant?: "+coord1.areSameQuadrant(coord2));
          System.out.println(coord2+" and "+coord3+" in the same quadrant?: "+coord2.areSameQuadrant(coord3));
          System.out.println(coord3+" and "+coord4+" in the same quadrant?: "+coord3.areSameQuadrant(coord4));
          System.out.println(coord2+" and "+coord5+" in the same quadrant?: "+coord2.areSameQuadrant(coord5));
          System.out.println(coord4+" and "+coord6+" in the same quadrant?: "+coord4.areSameQuadrant(coord6));
          System.out.println(coord3+" and "+coord7+" in the same quadrant?: "+coord3.areSameQuadrant(coord7));
          System.out.println(coord2+" and "+coord8+" in the same quadrant?: "+coord2.areSameQuadrant(coord8));
          System.out.println(coord7+" and "+coord9+" in the same quadrant?: "+coord7.areSameQuadrant(coord9));













          



     }
}
