// Controlled topic vocabulary for studentProfiles.topicMastery + the Zod
// schemas that gate the OAuth write action.
//
// Per the writeback foothold plan (D2): the GPT writer must take topic from a
// closed list, not freeform text. Keeps PII/free-text out of the column and
// makes the values joinable. Starter list scoped to Physics 1 mechanics; expand
// here (and only here) as new course material is covered.
//
// Schemas live alongside the vocabulary (not in actions.ts) so they can be
// imported in tests without pulling the db client transitively.
//
// TODO(D2): move to a `topics` table with faculty-managed rows + a "request new
// topic" admin flow once the list outgrows hand-editing.

import { z } from "zod";

export const TOPIC_VOCABULARY = [
  "kinematics",
  "vectors",
  "projectile-motion",
  "newtons-laws",
  "friction",
  "circular-motion",
  "energy-work",
  "momentum",
  "rotation",
  "gravitation",
  "oscillations",
  "waves",
] as const;

export type Topic = (typeof TOPIC_VOCABULARY)[number];

const TOPIC_SET = new Set<string>(TOPIC_VOCABULARY);

export function isKnownTopic(t: string): t is Topic {
  return TOPIC_SET.has(t);
}

// Human-readable label for UI rendering. Falls back to the raw id if a topic
// somehow lands in the column outside the vocabulary (e.g. legacy admin write).
export function topicLabel(t: string): string {
  return t
    .split("-")
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(" ");
}

// --- Schemas for the setTopicMastery action ----------------------------------
//
// `topic` is now a LAB id (uuid), not a member of the legacy physics
// vocabulary. The tutor must take the id from the sciai://labs/current resource
// (the labs published to the student); the impl additionally verifies the lab
// is currently accessible before writing. topicMastery is keyed by lab id.

export const setTopicMasteryInput = z.object({
  topic: z.string().uuid(),
  level: z.number().int().min(0).max(5),
});

const topicMasteryMap = z.record(z.string(), z.number().int().min(0).max(5));

export const setTopicMasteryOutput = z.object({
  status: z.literal("updated"),
  topic: z.string().uuid(),
  level: z.number().int().min(0).max(5),
  topicMastery: topicMasteryMap,
});

export type SetTopicMasteryInput = z.infer<typeof setTopicMasteryInput>;

// --- Shared schemas for the freeform-JSONB column merge actions --------------
//
// The four columns mindMap / personalization / learningStyle / struggles each
// accept a shallow-merge patch via Postgres `||`. Per-patch byte cap inherited
// from MAX_FIELD_BYTES (16KB) in ./codes.ts; that's the limit per call, not
// per column. The column itself can grow as successive merges accumulate.
//
// IMPORTANT: shallow merge replaces top-level keys whole. To extend a nested
// array (e.g. mindMap.nodes), the caller must read the current value first
// (via getStudentProfile) and send the new merged array, or existing data
// will be lost. This is documented in each action's OpenAPI description.

import { jsonbPatchSchema } from "./codes";

export const mergeProfileColumnInput = z.object({
  patch: jsonbPatchSchema,
});

// IMPORTANT: do NOT factor `z.record(z.string(), z.unknown())` into a shared
// variable here. zod-to-json-schema deduplicates repeated schema references
// by emitting `$ref: "#/properties/<firstField>"`, which is relative to the
// schema document root. When the schema lives under `components.schemas.X`
// in the served OpenAPI spec, that $ref path no longer resolves and ChatGPT
// drops the field with "components.schemas.<name> is not an object; skipping".
// Inline every field schema so each emits as a self-contained object.

export const mergeProfileColumnOutput = z.object({
  status: z.literal("updated"),
  column: z.enum(["mindMap", "personalization", "learningStyle", "struggles"]),
  value: z.record(z.string(), z.unknown()),
});

export const getStudentProfileOutput = z.object({
  alias: z.string(),
  topicMastery: z.record(z.string(), z.unknown()),
  mindMap: z.record(z.string(), z.unknown()),
  personalization: z.record(z.string(), z.unknown()),
  learningStyle: z.record(z.string(), z.unknown()),
  struggles: z.record(z.string(), z.unknown()),
  updatedAt: z.string(),
});

export type MergeProfileColumnInput = z.infer<typeof mergeProfileColumnInput>;
export type MergeableColumn = z.infer<typeof mergeProfileColumnOutput>["column"];
