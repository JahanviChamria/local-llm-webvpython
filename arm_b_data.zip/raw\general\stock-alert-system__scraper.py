import os
import re
import random
import logging
import time
from datetime import date
from pathlib import Path

import httpx
import pandas as pd
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
logger = logging.getLogger(__name__)

WATCHLIST_PATH = Path("watchlist.txt")

# Unauthenticated — used only to get the expiry list
EXPIRY_URL = "https://phx.unusualwhales.com/api/chains_expiry/{ticker}/init?limit=500"

# Paid API — real nbbo_bid / nbbo_ask
CHAIN_URL  = "https://api.unusualwhales.com/api/stock/{ticker}/option-contracts?expiry={expiry}&limit=500"
PRICE_URL  = "https://api.unusualwhales.com/api/stock/{ticker}/stock-state"
# greeks must be queried per expiry; without ?expiry it defaults to the nearest
# (often already-expired) expiration and returns stale ~0 deltas.
GREEKS_URL = "https://api.unusualwhales.com/api/stock/{ticker}/greeks?expiry={expiry}"
INFO_URL   = "https://api.unusualwhales.com/api/stock/{ticker}/info"

SCRAPE_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    ),
    "Referer": "https://unusualwhales.com/",
    "Origin": "https://unusualwhales.com",
}

MIN_DELAY = 0.2
MAX_DELAY = 0.5

# OCC symbol format: UNDERLYING + YYMMDD + C/P + 8-digit strike (5 int + 3 dec)
_SYMBOL_RE = re.compile(r"^[A-Z]+(\d{6})([CP])(\d{8})$")


def _parse_symbol(symbol: str) -> tuple[date, str, float] | None:
    m = _SYMBOL_RE.match(symbol)
    if not m:
        return None
    yymmdd, opt_type, strike_str = m.group(1), m.group(2), m.group(3)
    expiry = date.fromisoformat(f"20{yymmdd[:2]}-{yymmdd[2:4]}-{yymmdd[4:]}")
    strike = int(strike_str) / 1000.0
    option_type = "put" if opt_type == "P" else "call"
    return expiry, option_type, strike


def load_watchlist() -> list[str]:
    if not WATCHLIST_PATH.exists():
        return []
    return [t.strip().upper() for t in WATCHLIST_PATH.read_text().splitlines() if t.strip()]


def _get_price(client: httpx.Client, ticker: str, api_headers: dict) -> float | None:
    try:
        # stock-state returns the live close (and prev_close as fallback). The old
        # /price route now 404s, which used to silently fall through to the stale
        # phx `prev` value below and corrupt %OTM.
        r = client.get(PRICE_URL.format(ticker=ticker), headers=api_headers, timeout=10)
        data = r.json()
        state = data.get("data") or {}
        price = state.get("close") or state.get("prev_close")
        if price:
            return float(price)
        # fallback to unauthenticated price endpoint
        r2 = client.get(
            f"https://phx.unusualwhales.com/api/ticker/{ticker}/price",
            headers=SCRAPE_HEADERS,
            timeout=10,
        )
        d2 = r2.json()
        p = d2.get("curr") or d2.get("prev")
        return float(p) if p is not None else None
    except Exception as e:
        logger.warning(f"{ticker}: price fetch failed: {e}")
        return None


def _get_put_deltas(client: httpx.Client, ticker: str, expiry: str, api_headers: dict) -> dict[str, float]:
    """Map put option_symbol -> put delta (negative) for one expiry from UW greeks."""
    deltas: dict[str, float] = {}
    try:
        r = client.get(GREEKS_URL.format(ticker=ticker, expiry=expiry), headers=api_headers, timeout=15)
        for row in r.json().get("data", []):
            sym = row.get("put_option_symbol")
            d = row.get("put_delta")
            if sym and d is not None:
                try:
                    deltas[sym] = round(float(d), 3)
                except (ValueError, TypeError):
                    continue
    except Exception as e:
        logger.warning(f"{ticker}: greeks fetch failed: {e}")
    return deltas


def _get_next_earnings(client: httpx.Client, ticker: str, api_headers: dict) -> date | None:
    """Next scheduled earnings date for the ticker, or None if unknown."""
    try:
        r = client.get(INFO_URL.format(ticker=ticker), headers=api_headers, timeout=15)
        info = r.json().get("data", {}) or {}
        ned = info.get("next_earnings_date")
        if ned:
            return date.fromisoformat(str(ned)[:10])
    except Exception as e:
        logger.warning(f"{ticker}: earnings fetch failed: {e}")
    return None


def _parse_rows(
    rows: list,
    ticker: str,
    current_price: float,
    max_dte: int,
    deltas: dict[str, float] | None = None,
    next_earnings: date | None = None,
) -> list[dict]:
    deltas = deltas or {}
    today = date.today()
    records = []
    for row in rows:
        try:
            symbol = row.get("option_symbol", "")
            parsed = _parse_symbol(symbol)
            if parsed is None:
                continue
            expiry_date, option_type, strike = parsed

            if option_type != "put":
                continue

            dte = (expiry_date - today).days
            if dte < 0 or dte > max_dte:
                continue

            bid = float(row.get("nbbo_bid") or 0)
            ask = float(row.get("nbbo_ask") or 0)

            # If NBBO is missing fall back to avg_price estimate
            if bid == 0 and ask == 0:
                avg = float(row.get("avg_price") or row.get("last_price") or 0)
                if avg == 0:
                    continue
                bid = round(avg * 0.95, 2)
                ask = round(avg * 1.05, 2)

            records.append({
                "ticker": ticker,
                "expiration": expiry_date,
                "strike": strike,
                "bid": bid,
                "ask": ask,
                "volume": int(row.get("volume") or 0),
                "open_interest": int(row.get("open_interest") or 0),
                "dte": dte,
                "current_price": current_price,
                "delta": deltas.get(symbol),
                "next_earnings_date": next_earnings,
            })
        except (ValueError, TypeError, KeyError):
            continue
    return records


def _get_uw_key() -> str | None:
    try:
        import streamlit as st
        return st.secrets.get("UW_API_KEY") or os.getenv("UW_API_KEY")
    except Exception:
        return os.getenv("UW_API_KEY")


def scrape_ticker(ticker: str, max_dte: int) -> pd.DataFrame | None:
    uw_key = _get_uw_key()
    api_headers = {"Authorization": f"Bearer {uw_key}"} if uw_key else {}

    with httpx.Client(timeout=httpx.Timeout(15.0)) as client:
        current_price = _get_price(client, ticker, api_headers) or 0
        logger.info(f"{ticker}: price = {current_price}")

        # Get expiry list from unauthenticated endpoint
        r = client.get(EXPIRY_URL.format(ticker=ticker), headers=SCRAPE_HEADERS)
        init = r.json()
        expiries = [e["date"] for e in init.get("expiries", []) if "date" in e]
        logger.info(f"{ticker}: {len(expiries)} expirations")

        if not expiries:
            logger.error(f"{ticker}: no expirations, skipping")
            return None

        # Earnings is per-ticker — one call, reused for all expiries.
        next_earnings = _get_next_earnings(client, ticker, api_headers) if uw_key else None
        if next_earnings:
            logger.info(f"{ticker}: next earnings {next_earnings}")

        records = []
        for expiry in expiries:
            try:
                expiry_date = date.fromisoformat(expiry[:10])
                dte = (expiry_date - date.today()).days
                if dte < 0 or dte > max_dte:
                    continue

                if uw_key:
                    r2 = client.get(
                        CHAIN_URL.format(ticker=ticker, expiry=expiry),
                        headers=api_headers,
                    )
                else:
                    # No API key — fall back to unauthenticated scrape
                    r2 = client.get(
                        f"https://phx.unusualwhales.com/api/chains_expiry/{ticker}/{expiry}?limit=500",
                        headers=SCRAPE_HEADERS,
                    )

                data = r2.json()
                rows = data.get("data", data) if isinstance(data, dict) else data
                if isinstance(rows, list):
                    # Per-expiry put deltas (paid API only)
                    deltas = _get_put_deltas(client, ticker, expiry, api_headers) if uw_key else {}
                    records.extend(_parse_rows(rows, ticker, current_price, max_dte, deltas, next_earnings))

                time.sleep(random.uniform(MIN_DELAY, MAX_DELAY))
            except Exception as e:
                logger.warning(f"{ticker}/{expiry}: {e}")
                continue

    if records:
        logger.info(f"{ticker}: {len(records)} put records")
        return pd.DataFrame(records)

    logger.warning(f"{ticker}: no put records found")
    return None


def run_scrape(tickers: list[str], max_dte: int = 30) -> dict[str, pd.DataFrame]:
    results = {}
    for i, ticker in enumerate(tickers):
        logger.info(f"Scraping {ticker} ({i+1}/{len(tickers)})")
        try:
            df = scrape_ticker(ticker, max_dte)
            if df is not None:
                results[ticker] = df
        except Exception as e:
            logger.error(f"{ticker}: unexpected error: {e}")
        if i < len(tickers) - 1:
            time.sleep(random.uniform(MIN_DELAY, MAX_DELAY))
    return results
