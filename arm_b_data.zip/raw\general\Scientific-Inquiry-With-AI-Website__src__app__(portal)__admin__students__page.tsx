import { redirect } from "next/navigation";

// /admin/students used to be the studentProfiles CRUD ("Student histories" page).
// The actual learning-history view now lives at /portal/history, which is
// role-branched (admins see all students, faculty see their classes). This
// route stays as a redirect so old bookmarks, sidebar entries, and external
// links keep working.
export default function AdminStudentsRedirect() {
  redirect("/portal/history");
}
