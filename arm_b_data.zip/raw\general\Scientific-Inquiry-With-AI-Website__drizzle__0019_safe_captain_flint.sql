ALTER TYPE "public"."lab_file_kind" ADD VALUE 'ai_grading_prompt';--> statement-breakpoint
ALTER TABLE "labs" ADD COLUMN "has_ai_grading_prompt" boolean DEFAULT false NOT NULL;