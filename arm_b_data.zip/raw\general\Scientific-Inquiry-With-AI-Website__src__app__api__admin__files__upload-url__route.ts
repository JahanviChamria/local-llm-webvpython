import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db/client";
import { files } from "@/lib/db/schema";
import { requireAdmin, checkOrigin } from "@/lib/auth/guards";
import { presignUpload, bucketFor } from "@/lib/r2";
import { sanitizeForKey } from "@/lib/ids";
import { sweepAbandonedUploads } from "@/lib/sweep";
import {
  MAX_UPLOAD_BYTES,
  canonicalizeContentType,
  isAllowedUploadType,
} from "@/lib/file-types";
import { randomUUID } from "crypto";

export const runtime = "nodejs";

const bodySchema = z
  .object({
    filename: z.string().min(1).max(255),
    size_bytes: z.number().int().positive().max(MAX_UPLOAD_BYTES),
    content_type: z.string().max(255),
    title: z.string().min(1).max(200),
    description: z.string().max(2000).optional(),
    category: z.string().max(80).optional(),
    access_level: z.enum(["public", "faculty"]),
  })
  .superRefine((val, ctx) => {
    if (!isAllowedUploadType(val.content_type, val.filename)) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["content_type"],
        message: "content_type not allowed",
      });
    }
  });

export async function POST(req: Request) {
  const csrf = checkOrigin(req);
  if (csrf) return csrf;
  const g = await requireAdmin();
  if (g instanceof NextResponse) return g;
  const admin = g;

  let body: z.infer<typeof bodySchema>;
  try {
    body = bodySchema.parse(await req.json());
  } catch (err) {
    return NextResponse.json({ error: "invalid body", detail: String(err) }, { status: 400 });
  }

  await sweepAbandonedUploads();

  // Canonicalize empty/generic MIME from filename so isAudioMime works
  // downstream (player, /media-url). For already-canonical inputs this
  // is a no-op.
  const canonicalType = canonicalizeContentType(body.content_type, body.filename);

  const r2Key = `${body.access_level}/${randomUUID()}-${sanitizeForKey(body.filename)}`;

  const inserted = (
    await db
      .insert(files)
      .values({
        title: body.title,
        description: body.description,
        category: body.category,
        accessLevel: body.access_level,
        status: "pending",
        r2Key,
        filename: body.filename,
        sizeBytes: body.size_bytes,
        contentType: canonicalType,
        uploadedBy: admin.id,
      })
      .returning({ id: files.id })
  )[0];

  const uploadUrl = await presignUpload({
    bucket: bucketFor(body.access_level),
    key: r2Key,
    contentType: canonicalType,
    contentLength: body.size_bytes,
    ttlSeconds: 900,
  });

  return NextResponse.json({
    file_id: inserted.id,
    upload_url: uploadUrl,
    r2_key: r2Key,
    required_headers: {
      "Content-Type": canonicalType,
      "Content-Length": String(body.size_bytes),
    },
  });
}
