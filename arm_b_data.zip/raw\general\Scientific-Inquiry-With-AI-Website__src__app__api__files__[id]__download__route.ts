import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { fileDownloads, files } from "@/lib/db/schema";
import { getCurrentUser } from "@/lib/auth/session";
import {
  bucketFor,
  presignDownload,
  publicUrlFor,
  R2_PRIVATE_BUCKET,
  R2_PUBLIC_HOST,
} from "@/lib/r2";

export const runtime = "nodejs";

// 60s — short enough that an access_level flip plus an explicit Cloudflare purge
// keeps the world-readable window inside seconds; long enough that crawlers
// hitting the same URL twice in a minute don't both re-roll a presign / re-redirect.
const PUBLIC_REDIRECT_CACHE_SECONDS = 60;

// Best-effort download log. Only signed-in users; failures never block the file.
async function logDownload(userId: string | undefined, fileId: string): Promise<void> {
  if (!userId) return;
  try {
    await db.insert(fileDownloads).values({ userId, fileId });
  } catch {
    // Swallow — an engagement log must never break a download.
  }
}

export async function GET(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const disposition = new URL(req.url).searchParams.get("disposition") === "inline" ? "inline" : "attachment";

  const row = (
    await db
      .select()
      .from(files)
      .where(and(eq(files.id, id), eq(files.status, "ready")))
      .limit(1)
  )[0];

  if (!row) return NextResponse.json({ error: "not found" }, { status: 404 });

  // Resolve the viewer once: gates faculty files and logs the download as an
  // engagement signal (best-effort; never blocks the redirect).
  const user = await getCurrentUser();
  await logDownload(user?.id, row.id);

  if (row.accessLevel === "faculty") {
    if (!user || (user.role !== "faculty" && user.role !== "admin")) {
      return NextResponse.json({ error: "unauthenticated" }, { status: 401 });
    }
    const url = await presignDownload({
      bucket: bucketFor("faculty"),
      key: row.r2Key,
      filename: row.filename,
      contentType: row.contentType,
      disposition,
    });
    return NextResponse.redirect(url, {
      status: 302,
      headers: {
        "Cache-Control": "private, no-store",
        "X-Content-Type-Options": "nosniff",
      },
    });
  }

  // Public file. If the public bucket + CDN are configured, redirect to the
  // permanent CDN URL — that's the crawlable target. Otherwise (Phase 2 infra
  // not yet provisioned, or backfill not yet run) fall back to a short-lived
  // presigned URL on the private bucket — that's where pre-Phase-2 public
  // files still live.
  if (R2_PUBLIC_HOST) {
    return NextResponse.redirect(publicUrlFor(row.r2Key), {
      status: 302,
      headers: {
        "Cache-Control": `public, max-age=${PUBLIC_REDIRECT_CACHE_SECONDS}`,
      },
    });
  }

  const url = await presignDownload({
    bucket: R2_PRIVATE_BUCKET,
    key: row.r2Key,
    filename: row.filename,
    contentType: row.contentType,
    disposition,
  });
  return NextResponse.redirect(url, {
    status: 302,
    headers: { "X-Content-Type-Options": "nosniff" },
  });
}
