import java.util.ArrayList;
import java.util.Random;

public class Deck {
	// Final variables for 2.3 - No need to change these!
	private static final int SIMPLE_GAME_N_SHUFFLES = 4;
	private static final int SIMPLE_GAME_SHUFFLE_SIZE = 10;

	private ArrayList<Card> cards;

	// 2.1 - Warm up
	public Deck(Card[] arg) {
		cards=new ArrayList<Card>();
		for(int i=0;i<arg.length;i++){
			if(arg[i]==null){
				throw new IllegalArgumentException("Invalid input! null value encountered.");
			}
			else{
				this.cards.add(arg[i]);
			}
		}
	}

	public Deck() {
		this(Card.standardDeck());
	}

	public Card draw() {
		if(this.cards.size()==0)
			return null;
		else{
			return this.cards.remove(this.cards.size()-1);
		}
	}

	// 2.2 - Advanced implementation
	public Deck cut(int n) {
		if(n<1 || n>this.cards.size()){
			throw new IllegalArgumentException("Invalid input!");
		}
		else{
			Deck cutPile=new Deck();
			cutPile.cards.clear();
			for(int i=this.cards.size()-n;i<this.cards.size();i++){
				cutPile.cards.add(this.cards.get(i));
			}
			this.cards.subList(this.cards.size()-n, this.cards.size()).clear();
			return cutPile;
		}
	}

	public void addOnTop(Deck other) {
		if(other==null){
			throw new IllegalArgumentException("Invalid input!");
		}
		else{
			this.cards.addAll(other.cards);
			other.cards.clear();
		}
	}

	public void overhandShuffle(int max) {
		if(max<1 || max>this.cards.size()){
			throw new IllegalArgumentException("Invalid input!");
		}
		else{
			Random random = new Random();
			Deck shuffledDeck=new Deck();
			shuffledDeck.cards.clear();
			while(this.cards.size()>0){
				int randomNum=random.nextInt(1, max+1);
				if(randomNum<=this.cards.size()){
					Deck shufflePile=this.cut(randomNum);
					shuffledDeck.addOnTop(shufflePile);
				}
			}
			this.addOnTop(shuffledDeck);
		}
	}

	public ArrayList<ArrayList<Card>> deal(int p, int c) {
		if(p<1 || c<1 || (p*c)>this.cards.size()){
			throw new IllegalArgumentException("Invalid input!");
		}
		else{
			ArrayList<ArrayList<Card>> handsDealt=new ArrayList<ArrayList<Card>>();
			for (int i = 0; i < p; i++) {
				handsDealt.add(new ArrayList<Card>());
			}
			for (int i = 0; i < c; i++) {
				for (int j = 0; j < p; j++) {
					handsDealt.get(j).add(this.draw());
				}
			}
			return handsDealt;
		}
	}

	public static ArrayList<Card> findBestOfAKind(ArrayList<Card> hand) {
		// Implement me!
		if (hand == null || hand.contains(null)) {
			throw new IllegalArgumentException("Invalid hand provided: " + hand);
		}
		else{
			ArrayList<ArrayList<Card>> bestSet=findLargestSets(hand);
			while(bestSet.size()>1){
				ArrayList<Card> betterSet=compareSets(bestSet.get(0),bestSet.get(1));
				bestSet.subList(0,2).clear();
				bestSet.add(0,betterSet);
			}
			ArrayList<Card> toReturn=bestSet.get(0);
			return toReturn;
		}
	}

	/**
	 * Given two sets, return the better one. The measure of "better" should be as described
	 * in the instructions.
	 * @param	first	a set of a kind
	 * @param	second	another set of a kind
	 * @return	the better set between first and second.
	 */
	private static ArrayList<Card> compareSets(ArrayList<Card> first, ArrayList<Card> second) {
		if(first.size()>second.size()){
			return first;
		}
		else if(second.size()>first.size()){
			return second;
		}
		else{
			if(first.get(0).getRank()>second.get(0).getRank()){
				return first;
			}
			else if(second.get(0).getRank()>first.get(0).getRank()){
				return second;
			}
			else
				return first;
		}
	}

	// What is another helper function that can help solve this problem?
	//returns the largest sets of every rank from the argument hand
	private static ArrayList<ArrayList<Card>> findLargestSets(ArrayList<Card> hand){
		ArrayList<ArrayList<Card>> largestSets=new ArrayList<ArrayList<Card>>();
		for(int i=0;i<hand.size();i++){
			Card current=hand.get(i);
			ArrayList<Card> set=new ArrayList<Card>();
			set.add(current);
			for(int j=i+1;j<hand.size()-1;j++){
				if(hand.get(j).getRank()==current.getRank() && hand.get(j).getSuit()!=current.getSuit()){
					set.add(hand.get(j));
					hand.remove(j);
					j--;
				}
			}
			largestSets.add(set);
		}
		return largestSets;
	}
	
	// 2.3 - Putting it together
	public static void simpleGame(int p, int c) {
		// This function is mostly implemented for you. Complete the implementation!

		Deck deck = new Deck(); // Create a standard deck
		System.out.println("Playing a simple game with " + p + " players and " + c + " cards per player!");
		for (int i = 0; i < SIMPLE_GAME_N_SHUFFLES; i++) {
			deck.overhandShuffle(SIMPLE_GAME_SHUFFLE_SIZE); // Shuffle the deck
		}
		ArrayList<ArrayList<Card>> hands = deck.deal(p, c); // Deal the cards
		ArrayList<Card> veryBestSet = new ArrayList<Card>(); // The best set from the players we've seen so far - starts out as empty (so that any valid set is better than this)
		int winner = 0; // Index of the player with the best set we've seen so far - starts out as the first player
		// This means that if no one has a set better than the empty set, the first player wins by default.
		for (int i = 0; i < hands.size(); i++) {
			ArrayList<Card> currentBestSet = Deck.findBestOfAKind(hands.get(i)); // Get this player's best set
			System.out.println("Player #" + (i + 1) + "'s best set is: " + currentBestSet);
			// What needs to happen here?
			veryBestSet=compareSets(currentBestSet,veryBestSet);
			if(veryBestSet.equals(currentBestSet)){
				winner=i;
			}
		}
		System.out.println("Player #" + (winner + 1) + " wins!");

	}

	public static void main(String[] args) {
		Deck D1=new Deck();
		System.out.println("Card drawn:"+(D1.draw()));
		simpleGame(4, 10);
		simpleGame(5, 9);
		simpleGame(3, 2);
		simpleGame(4, 8);
		simpleGame(7, 1);
		simpleGame(10, 5);

	}


}
