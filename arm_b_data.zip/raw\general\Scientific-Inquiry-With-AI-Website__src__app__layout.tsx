import type { Metadata, Viewport } from "next";
import { getBaseUrl } from "@/lib/site-url";
import "./globals.css";
import "./(portal)/portal.css";

// The UI is a fixed light design. Declaring the color scheme stops Chrome's
// "auto dark mode for web contents" from inverting the page (which turned the
// logo into a dark box and washed out the cream surfaces).
export const viewport: Viewport = {
  colorScheme: "light",
  width: "device-width",
  initialScale: 1,
};

export const metadata: Metadata = {
  metadataBase: new URL(getBaseUrl()),
  title: {
    default: "Scientific Inquiry With AI",
    template: "%s · Scientific Inquiry With AI",
  },
  description: "Course materials for Scientific Inquiry With AI.",
  openGraph: {
    type: "website",
    siteName: "Scientific Inquiry With AI",
    title: "Scientific Inquiry With AI",
    description: "Course materials for Scientific Inquiry With AI.",
  },
  twitter: {
    card: "summary",
    title: "Scientific Inquiry With AI",
    description: "Course materials for Scientific Inquiry With AI.",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=DM+Sans:opsz,wght@9..40,300..700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
