import { notFound, redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/lib/db/client";
import { labs } from "@/lib/db/schema";
import { getCurrentUser } from "@/lib/auth/session";
import { isLabUnlocked } from "@/lib/portal/accessible-labs";
import { SessionRunner } from "@/components/practice/session-runner";

export const dynamic = "force-dynamic";

type Params = { labId: string };

export default async function PracticeLabPage({
  params,
}: {
  params: Promise<Params>;
}) {
  const me = await getCurrentUser();
  const { labId } = await params;
  if (!me) redirect(`/login?next=/students/practice/${labId}`);

  if (!z.string().uuid().safeParse(labId).success) notFound();

  const lab = (
    await db.select({ id: labs.id, name: labs.name }).from(labs).where(eq(labs.id, labId)).limit(1)
  )[0];
  if (!lab) notFound();

  // Only unlocked labs are playable here (enrollment not required); staff preview any.
  const isStaff = me.role === "admin" || me.role === "faculty";
  if (!isStaff && !(await isLabUnlocked(labId))) notFound();

  return (
    <div className="col">
      <div className="screen-head">
        <div className="section-label">Retrieval practice</div>
        <h1>{lab.name}</h1>
      </div>
      <SessionRunner labId={lab.id} scope="external" exitHref="/students/practice" />
    </div>
  );
}
