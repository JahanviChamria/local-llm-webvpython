

public class FBLLClient{
    
    
    
    private static void testAdd(){
        System.out.println("*****    ADD TESTS    *****");
        
        //Test 1.1
        FBLinkedList<String> test1 = new FBLinkedList<String>();
        test1.add("cat");
        test1.add("dog");
        test1.add("frog");
        System.out.println("Test #1 (append to end):\n\t" + test1 + "\n");
        
        
        //Test 1.2
        FBLinkedList<String> test2 = new FBLinkedList<String>();
        test2.add("cat");
        test2.add("dog");
        test2.add(1, "frog");
        System.out.println("Test #2 (insert at idx 1):\n\t" + test2 + "\n");        
        
        
        //Add more of your own!

        //Test 1.3
        FBLinkedList<String> test3 = new FBLinkedList<String>();
        test3.add("cat");
        System.out.println("Test #3 (insert in empty list):\n\t" + test3 + "\n");

        //Test 1.4
        FBLinkedList<String> test4 = new FBLinkedList<String>();
        test4.add("cat");
        test4.add("dog");
        System.out.println("Test #4 (insert in singleton list):\n\t" + test4 + "\n");

        //Test 1.5
        FBLinkedList<String> test5 = new FBLinkedList<String>();
        test5.add("cat");
        test5.add("dog");
        test5.add(0, "frog");
        System.out.println("Test #5 (insert at idx 0):\n\t" + test5 + "\n");

        //Test 1.6
        FBLinkedList<String> test6 = new FBLinkedList<String>();
        test6.add("cat");
        test6.add("dog");
        test6.add("bird");
        test6.add("lion");
        test6.add(2, "frog");
        System.out.println("Test #6 (insert at idx 2):\n\t" + test6 + "\n");

        // //Test 1.7 --throws exception
        // FBLinkedList<String> test7 = new FBLinkedList<String>();
        // test7.add("cat");
        // test7.add(3, "frog");
        // System.out.println("Test #7 (insert at idx>size):\n\t" + test7 + "\n");
        //
        // //Test 1.8 --throws exception
        // FBLinkedList<String> test8 = new FBLinkedList<String>();
        // test8.add("cat");
        // test8.add(-1, "frog");
        // System.out.println("Test #8 (insert at idx -1):\n\t" + test8 + "\n");

    }


    
    private static void testRetainUpTo(){
        System.out.println("*****    RETAIN UP TO TESTS    *****");
        String target;
        
        
        System.out.println("Test #1:");
        FBLinkedList<String> test1 = new FBLinkedList<String>();
        test1.add("cat");
        test1.add("bat"); 
        test1.add("dog");
        test1.add("bird");
        test1.add("dog");
        test1.add("frog");      
        target = "dog";
            
        System.out.println("list before:\t" + test1 + ", target: " + target);
        test1.retainUpTo(target);
        System.out.println("list after:\t" + test1 + "\n");


        System.out.println("Test #2:");
        FBLinkedList<String> test2 = new FBLinkedList<String>();
        test2.add("deer");
        test2.add("steer"); 
        test2.add("lark");
        test2.add("shark");   
        target = "aardvark";
            
        System.out.println("list before:\t" + test2 + ", target: " + target);
        test2.retainUpTo(target);
        System.out.println("list after:\t" + test2 + "\n");

        System.out.println("Test #3:"); //empty list
        FBLinkedList<String> test3 = new FBLinkedList<String>();
        target = "dog";

        System.out.println("list before:\t" + test3 + ", target: " + target);
        test3.retainUpTo(target);
        System.out.println("list after:\t" + test3 + "\n");

        System.out.println("Test #4:");  //singleton list
        FBLinkedList<String> test4 = new FBLinkedList<String>();
        test4.add("deer");
        target = "deer";

        System.out.println("list before:\t" + test4 + ", target: " + target);
        test4.retainUpTo(target);
        System.out.println("list after:\t" + test4 + "\n");

        System.out.println("Test #5:");  //on first item on the list
        FBLinkedList<String> test5 = new FBLinkedList<String>();
        test5.add("deer");
        test5.add("steer");
        test5.add("lark");
        target = "deer";

        System.out.println("list before:\t" + test5 + ", target: " + target);
        test5.retainUpTo(target);
        System.out.println("list after:\t" + test5 + "\n");

        System.out.println("Test #6:");  //on last item in list
        FBLinkedList<String> test6 = new FBLinkedList<String>();
        test6.add("deer");
        test6.add("steer");
        test6.add("lark");
        test6.add("shark");
        target = "shark";

        System.out.println("list before:\t" + test6 + ", target: " + target);
        test6.retainUpTo(target);
        System.out.println("list after:\t" + test6 + "\n");

        System.out.println("Test #7:");   //mutliple occurences of target
        FBLinkedList<String> test7 = new FBLinkedList<String>();
        test7.add("deer");
        test7.add("steer");
        test7.add("lark");
        test7.add("shark");
        test7.add("bat");
        test7.add("bat");
        test7.add("dog");
        target = "bat";

        System.out.println("list before:\t" + test7 + ", target: " + target);
        test7.retainUpTo(target);
        System.out.println("list after:\t" + test7 + "\n");

        System.out.println("Test #8:");   //mutliple occurences of target
        FBLinkedList<String> test8 = new FBLinkedList<String>();
        test8.add("deer");
        test8.add("deer");
        test8.add("deer");
        target = "deer";

        System.out.println("list before:\t" + test8 + ", target: " + target);
        test8.retainUpTo(target);
        System.out.println("list after:\t" + test8 + "\n");

    }
        
    
    
    public static void main(String[] args){

        //Come up with test cases of your own
        //the provided tests are not sufficient!
                
        testAdd();          //uncomment me for Part 2.3!
        testRetainUpTo();   //uncomment me for Part 2.6!
                
    }
    

    
}
