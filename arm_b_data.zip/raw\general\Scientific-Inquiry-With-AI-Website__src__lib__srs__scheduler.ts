/**
 * SM-2–style spaced-repetition scheduler.
 *
 * Maps the four UI ratings (again/hard/good/easy) onto an interval + ease update.
 * Returns the next scheduling state for a card. Pure & deterministic given `now`.
 */

export type SrsRating = "again" | "hard" | "good" | "easy";
export type SrsCardState = "new" | "learning" | "review";

export type CardSchedule = {
  state: SrsCardState;
  reps: number;
  lapses: number;
  ease: number;
  intervalDays: number;
};

export type ScheduleResult = CardSchedule & { due: Date };

const MIN_EASE = 1.3;
const AGAIN_INTERVAL_DAYS = 10 / (60 * 24); // ~10 minutes
const LEARNING_GOOD_DAYS = 1; // first graduation interval
const LEARNING_EASY_DAYS = 4;

function clampEase(e: number): number {
  return Math.max(MIN_EASE, e);
}

export type ScheduleOptions = {
  /**
   * Response-time multiplier in [0.8, 1.2] (see timing.ts). Only shapes
   * good/easy on review cards — hard/again already encode struggle, and the
   * learning ladder stays fixed to avoid sub-day interval weirdness.
   */
  timeFactor?: number;
};

/** Apply a rating to a card's current schedule, producing the next state. */
export function schedule(
  card: CardSchedule,
  rating: SrsRating,
  now: Date = new Date(),
  opts: ScheduleOptions = {},
): ScheduleResult {
  const tf = opts.timeFactor ?? 1;
  let { reps, lapses, ease, intervalDays } = card;
  let state: SrsCardState = card.state;

  if (rating === "again") {
    lapses += 1;
    ease = clampEase(ease - 0.2);
    intervalDays = AGAIN_INTERVAL_DAYS;
    state = "learning";
    reps = 0;
    return { state, reps, lapses, ease, intervalDays, due: addDays(now, intervalDays) };
  }

  // New / learning cards graduate on a good/easy answer.
  if (state === "new" || state === "learning") {
    if (rating === "hard") {
      intervalDays = LEARNING_GOOD_DAYS / 2 || AGAIN_INTERVAL_DAYS;
      state = "learning";
    } else if (rating === "good") {
      intervalDays = LEARNING_GOOD_DAYS;
      state = "review";
      reps += 1;
    } else {
      // easy
      intervalDays = LEARNING_EASY_DAYS;
      ease = clampEase(ease + 0.15);
      state = "review";
      reps += 1;
    }
    return { state, reps, lapses, ease, intervalDays, due: addDays(now, intervalDays) };
  }

  // Review cards: standard SM-2 interval growth.
  reps += 1;
  const base = intervalDays > 0 ? intervalDays : 1;
  if (rating === "hard") {
    ease = clampEase(ease - 0.15);
    intervalDays = base * 1.2;
  } else if (rating === "good") {
    ease = clampEase(ease + 0.05 * (tf - 1));
    intervalDays = base * ease * tf;
  } else {
    // easy
    ease = clampEase(ease + 0.15 * tf);
    intervalDays = base * ease * 1.3 * tf;
  }
  state = "review";
  return { state, reps, lapses, ease, intervalDays, due: addDays(now, intervalDays) };
}

/** Human-readable interval, matching the session UI hints (e.g. "<1m", "2d", "5d"). */
export function formatInterval(days: number): string {
  const minutes = days * 24 * 60;
  if (minutes < 60) return `<${Math.max(1, Math.round(minutes))}m`;
  if (days < 1) return `${Math.round(days * 24)}h`;
  if (days < 30) return `${Math.round(days)}d`;
  if (days < 365) return `${Math.round(days / 30)}mo`;
  return `${(days / 365).toFixed(1)}y`;
}

/** Preview the interval each rating would produce, for the rating buttons. */
export function previewIntervals(
  card: CardSchedule,
  now: Date = new Date(),
  opts: ScheduleOptions = {},
): Record<SrsRating, string> {
  const ratings: SrsRating[] = ["again", "hard", "good", "easy"];
  const out = {} as Record<SrsRating, string>;
  for (const r of ratings) out[r] = formatInterval(schedule(card, r, now, opts).intervalDays);
  return out;
}

function addDays(d: Date, days: number): Date {
  return new Date(d.getTime() + days * 24 * 60 * 60 * 1000);
}

export const NEW_CARD: CardSchedule = { state: "new", reps: 0, lapses: 0, ease: 2.5, intervalDays: 0 };
