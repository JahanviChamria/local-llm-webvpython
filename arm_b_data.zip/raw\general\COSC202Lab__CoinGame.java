import java.util.*;

public class CoinGame { //i tried doing the 2 hop method but i had trouble getting the path needed because i made a new 2 hop graph, so i used this method instead
    public static Collection<List<Integer>> coinPaths(
            HashMap<Integer, HashSet<Integer>> graph, 
            int start1, 
            int start2) {
        
        //queue stores current positions of both coins
        Queue<int[]> queue = new LinkedList<>();
        
        //track visited states and their parents
        //map of maps
        HashMap<Integer, HashMap<Integer, int[]>> parent = new HashMap<>();
        
        //both coins at their starting positions
        queue.add(new int[]{start1, start2});
        if (!parent.containsKey(start1)) {
            parent.put(start1, new HashMap<>());
        }
        parent.get(start1).put(start2, null);
        
        //BFS to find when coins meet
        while (!queue.isEmpty()) {
            int[] current = queue.poll();
            int pos1 = current[0];
            int pos2 = current[1];
            
            //check if coins have met
            if (pos1 == pos2) {
                //reconstruct the paths by following parent links
                List<Integer> path1 = new ArrayList<>();
                List<Integer> path2 = new ArrayList<>();
                
                int currentPos1 = pos1;
                int currentPos2 = pos2;

                while (parent.containsKey(currentPos1) && parent.get(currentPos1).containsKey(currentPos2)) {
                    path1.add(currentPos1);
                    path2.add(currentPos2);
                    
                    int[] parentState = parent.get(currentPos1).get(currentPos2);
                    if (parentState == null) 
                        break;
                    
                    currentPos1 = parentState[0];
                    currentPos2 = parentState[1];
                }
                
                //reverse paths since we built them backwards
                Collections.reverse(path1);
                Collections.reverse(path2);
                
                Collection<List<Integer>> result = new ArrayList<>();
                result.add(path1);
                result.add(path2);
                return result;
            }
            
            //try all possible moves for both coins simultaneously, same as doing 2 hop in a way
            HashSet<Integer> neighbors1 = graph.get(pos1);
            HashSet<Integer> neighbors2 = graph.get(pos2);
            
            for (int next1 : neighbors1) {
                for (int next2 : neighbors2) {
                    String key = next1 + "," + next2;
                    
                    //if we have not visited this state yet
                    if (!parent.containsKey(next1) || !parent.get(next1).containsKey(next2)) {
                        queue.add(new int[]{next1, next2});
                        if (!parent.containsKey(next1)) {
                            parent.put(next1, new HashMap<>());
                        }
                        parent.get(next1).put(next2, new int[]{pos1, pos2});
                    }
                }
            }
        }
        
        //no path found
        return null;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("No. of edges? ");
        int m = sc.nextInt();
        HashMap<Integer, HashSet<Integer>> graph = new HashMap<>();
        System.out.println("Enter edges:");
        for (int i = 0; i < m; i++) {
            int u = sc.nextInt();
            int v = sc.nextInt();

            graph.putIfAbsent(u, new HashSet<>());
            graph.putIfAbsent(v, new HashSet<>());

            graph.get(u).add(v);
            graph.get(v).add(u);
        }

        System.out.print("Enter start1: ");
        int s1 = sc.nextInt();

        System.out.print("Enter start2: ");
        int s2 = sc.nextInt();

        Collection<List<Integer>> ans = coinPaths(graph, s1, s2);

        if (ans == null) {
            System.out.println("Coins cannot meet.");
            return;
        }

        System.out.println("\nCoins can meet!");
        List<List<Integer>> list = (List<List<Integer>>) ans;
        System.out.println("Path for coin 1: " + list.get(0));
        System.out.println("Path for coin 2: " + list.get(1));
    }
}
