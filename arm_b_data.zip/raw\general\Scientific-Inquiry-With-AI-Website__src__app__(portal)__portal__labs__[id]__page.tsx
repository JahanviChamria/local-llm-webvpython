import { LabDetailView } from "@/components/portal/lab-detail-view";
import { guardStudentGlobalLab } from "@/lib/portal/global-lab-guard";

export const dynamic = "force-dynamic";

export default async function LabDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  await guardStudentGlobalLab(id);
  return <LabDetailView labId={id} basePath={`/portal/labs/${id}`} />;
}
