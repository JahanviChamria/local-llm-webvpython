import { notFound, redirect } from "next/navigation";
import { asc, eq } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { labs, questions, files } from "@/lib/db/schema";
import { getCurrentUser } from "@/lib/auth/session";
import { publicUrlFor } from "@/lib/r2";
import { EditQuestionClient } from "./client";
import { z } from "zod";

export const dynamic = "force-dynamic";

type Params = { id: string };

export default async function EditQuestionPage({
  params,
}: {
  params: Promise<Params>;
}) {
  // Role check FIRST: if the fetch ran first, unauthorized users probing UUIDs
  // could distinguish real IDs (renders the gate) from fake ones (renders 404).
  const me = await getCurrentUser();
  if (!me) redirect("/login?next=/admin/questions");
  if (me.role !== "admin") {
    return (
      <div className="col">
        <div className="screen-head">
          <div className="section-label">Restricted</div>
          <h1>Not available</h1>
        </div>
        <div className="callout orange">
          <strong>Admins only.</strong> Editing questions is restricted to admins; faculty can view the question list.
        </div>
      </div>
    );
  }

  const { id } = await params;
  if (!z.string().uuid().safeParse(id).success) notFound();

  const row = (
    await db
      .select({
        id: questions.id,
        labId: questions.labId,
        labName: labs.name,
        difficulty: questions.difficulty,
        prompt: questions.prompt,
        expectedAnswer: questions.expectedAnswer,
        format: questions.format,
        role: questions.role,
        options: questions.options,
        correctOption: questions.correctOption,
        figureFileId: questions.figureFileId,
        figureR2Key: files.r2Key,
      })
      .from(questions)
      .innerJoin(labs, eq(labs.id, questions.labId))
      .leftJoin(files, eq(files.id, questions.figureFileId))
      .where(eq(questions.id, id))
      .limit(1)
  )[0];
  if (!row) notFound();

  const labList = await db
    .select({ id: labs.id, name: labs.name })
    .from(labs)
    .orderBy(asc(labs.name))
    .limit(500);

  const { figureR2Key, ...questionRow } = row;

  return (
    <EditQuestionClient
      question={{
        ...questionRow,
        // jsonb comes back typed as `unknown`; the column always holds the MC option shape.
        options: (row.options as { id: string; text: string }[] | null) ?? null,
        figureUrl: figureR2Key ? publicUrlFor(figureR2Key) : null,
      }}
      labs={labList}
    />
  );
}
