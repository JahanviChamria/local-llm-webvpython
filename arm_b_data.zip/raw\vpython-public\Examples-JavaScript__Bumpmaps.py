JavaScript 3.2
scene.visible = false
scene.title = "Enhanced 3D of surfaces using bump maps"
scene.caption = "Drag the single light with the left button, rotate with the right button.\n"
scene.append_to_caption("Notice especially the appearance of the left and right faces.")
let c = box({pos:vec(0,0,0), shininess:0,
    texture:{file:textures.stones, bumpmap:bumpmaps.stucco} })
c.rotate( {angle:pi/2, axis:vec(0,0,1)} )
c.rotate( {angle:pi, axis:vec(0,1,0)} )
scene.waitfor("textures")
scene.visible = true

scene.background = color.gray(.5)
scene.lights = []
let L = distant_light( {direction:vec(0,0,1)} )

scene.bind("mousedown", function() {
    let pos = scene.mouse.pos
    
    scene.bind("mousemove", function () {
        if (pos !== null) {
            let x = scene.mouse.pos.x
            let y = scene.mouse.pos.y
            L.direction.x = x-pos.x
            L.direction.y = y-pos.y
        }
    })
    
    scene.bind("mouseup", function () {
        pos = null
    })
})