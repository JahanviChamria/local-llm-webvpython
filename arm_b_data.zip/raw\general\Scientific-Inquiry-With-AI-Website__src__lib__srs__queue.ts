import { and, asc, desc, eq, inArray, lte, or, sql } from "drizzle-orm";
import { db } from "@/lib/db/client";
import {
  files,
  labs,
  questionFamilies,
  questions,
  srsAttempts,
  srsCards,
  srsReviews,
} from "@/lib/db/schema";
import { publicUrlFor } from "@/lib/r2";
import {
  computeAnswers,
  renderTemplate,
  sampleDraw,
  type Parameterization,
} from "@/lib/questions/parameterize";
import type { CardSchedule } from "./scheduler";
import { priorityScore, selectWithNewSlots } from "./priority";

export type PracticeScope = "lab" | "external";

export type QueueCard = {
  cardId: string;
  questionId: string;
  prompt: string;
  expectedAnswer: string | null;
  difficulty: "easy" | "medium" | "hard";
  schedule: CardSchedule;
};

/** Lazily create an srs_card for every question in the lab that this user has none for. */
export async function ensureCards(
  userId: string,
  labId: string,
  practiceScope: PracticeScope,
): Promise<void> {
  const rows = await db
    .select({ id: questions.id })
    .from(questions)
    .where(eq(questions.labId, labId));
  if (rows.length === 0) return;

  // Targetless on-conflict so this works both before and after the migration
  // that swaps the unique index to (user_id, question_id, scope).
  await db
    .insert(srsCards)
    .values(rows.map((q) => ({ userId, questionId: q.id, scope: practiceScope })))
    .onConflictDoNothing();
}

/** Interleave a list so adjacent items avoid the same difficulty where possible. */
function interleave(cards: QueueCard[]): QueueCard[] {
  const buckets = new Map<string, QueueCard[]>();
  for (const c of cards) {
    if (!buckets.has(c.difficulty)) buckets.set(c.difficulty, []);
    buckets.get(c.difficulty)!.push(c);
  }
  const order = [...buckets.values()];
  const out: QueueCard[] = [];
  let added = true;
  while (added) {
    added = false;
    for (const b of order) {
      const next = b.shift();
      if (next) {
        out.push(next);
        added = true;
      }
    }
  }
  return out;
}

/** Build today's session queue: due + new cards for the lab, priority-ranked, interleaved, capped at `limit`. */
export async function buildQueue(
  userId: string,
  labId: string,
  limit = 8,
  practiceScope: PracticeScope = "lab",
): Promise<QueueCard[]> {
  await ensureCards(userId, labId, practiceScope);
  const now = new Date();

  const rows = await db
    .select({
      cardId: srsCards.id,
      questionId: questions.id,
      prompt: questions.prompt,
      expectedAnswer: questions.expectedAnswer,
      difficulty: questions.difficulty,
      state: srsCards.state,
      reps: srsCards.reps,
      lapses: srsCards.lapses,
      ease: srsCards.ease,
      intervalDays: srsCards.intervalDays,
      due: srsCards.due,
      questionCreatedAt: questions.createdAt,
    })
    .from(srsCards)
    .innerJoin(questions, eq(questions.id, srsCards.questionId))
    .where(
      and(
        eq(srsCards.userId, userId),
        eq(srsCards.scope, practiceScope),
        eq(questions.labId, labId),
        or(eq(srsCards.state, "new"), lte(srsCards.due, now)),
      ),
    )
    .orderBy(asc(srsCards.due));

  const toCard = (r: (typeof rows)[number]): QueueCard => ({
    cardId: r.cardId,
    questionId: r.questionId,
    prompt: r.prompt,
    expectedAnswer: r.expectedAnswer,
    difficulty: r.difficulty,
    schedule: {
      state: r.state,
      reps: r.reps,
      lapses: r.lapses,
      ease: r.ease,
      intervalDays: r.intervalDays,
    },
  });

  const newRows = rows.filter((r) => r.state === "new");
  const dueRows = rows.filter((r) => r.state !== "new");

  // Last rating per due card, for the "recently struggled" priority term.
  const lastRatings = new Map<string, "again" | "hard" | "good" | "easy">();
  if (dueRows.length > 0) {
    const last = await db
      .selectDistinctOn([srsReviews.cardId], {
        cardId: srsReviews.cardId,
        rating: srsReviews.rating,
      })
      .from(srsReviews)
      .where(
        inArray(
          srsReviews.cardId,
          dueRows.map((r) => r.cardId),
        ),
      )
      .orderBy(srsReviews.cardId, desc(srsReviews.reviewedAt));
    for (const r of last) lastRatings.set(r.cardId, r.rating);
  }

  const ranked = dueRows
    .map((r) => ({
      row: r,
      score: priorityScore({
        due: r.due,
        intervalDays: r.intervalDays,
        lapses: r.lapses,
        ease: r.ease,
        lastRating: lastRatings.get(r.cardId) ?? null,
        now,
      }),
    }))
    .sort((a, b) => b.score - a.score)
    .map((x) => x.row);

  // Deterministic new-card order: oldest question first.
  const orderedNew = [...newRows].sort(
    (a, b) => a.questionCreatedAt.getTime() - b.questionCreatedAt.getTime(),
  );

  return interleave(selectWithNewSlots(ranked, orderedNew, limit).map(toCard));
}

/**
 * The single per-card-serve code path: pulls the full question row + family
 * (if parameterized), samples a fresh draw, renders the prompt and expected
 * answer, and INSERTs a snapshot row in srs_attempts. The returned shape is
 * what the client renders.
 *
 * Reused at session-start for each delivered card. Future within-session
 * "again" re-serves can call the same helper.
 */
export type ServedCard = {
  attemptId: string;
  cardId: string;
  questionId: string;
  prompt: string;
  difficulty: "easy" | "medium" | "hard";
  format: "true_false" | "multiple_choice" | "short_answer" | "calculation";
  options: Array<{ id: string; text: string }> | null;
  figureUrl: string | null;
};

export async function serveCard(
  userId: string,
  cardId: string,
  sessionId: string | null,
): Promise<ServedCard | null> {
  const [row] = await db
    .select({
      cardId: srsCards.id,
      questionId: questions.id,
      labId: questions.labId,
      prompt: questions.prompt,
      expectedAnswer: questions.expectedAnswer,
      difficulty: questions.difficulty,
      format: questions.format,
      options: questions.options,
      correctOption: questions.correctOption,
      variantAnswerNotes: questions.variantAnswerNotes,
      promptIsTemplate: questions.promptIsTemplate,
      familyId: questions.familyId,
      figureFileId: questions.figureFileId,
      figureR2Key: files.r2Key,
    })
    .from(srsCards)
    .innerJoin(questions, eq(questions.id, srsCards.questionId))
    .leftJoin(files, eq(files.id, questions.figureFileId))
    .where(and(eq(srsCards.id, cardId), eq(srsCards.userId, userId)))
    .limit(1);

  if (!row) return null;

  let promptSnapshot = row.prompt;
  let expectedAnswerSnapshot: string | null = row.expectedAnswer;
  let draw: Record<string, number | string> | null = null;
  let seed: number | null = null;

  if (row.promptIsTemplate && row.familyId) {
    const [family] = await db
      .select({ parameterization: questionFamilies.parameterization })
      .from(questionFamilies)
      .where(eq(questionFamilies.id, row.familyId))
      .limit(1);
    const spec = (family?.parameterization as Parameterization | null | undefined) ?? null;
    if (spec) {
      // Re-roll up to 4 times to dodge a singularity the fuzz missed; if every
      // draw throws, fall back to the unrendered template so the student sees a
      // visibly weird prompt rather than a 500.
      for (let attempt = 0; attempt < 4; attempt++) {
        const trySeed = randomSeed();
        try {
          const tryDraw = sampleDraw(spec, trySeed);
          const tryAnswers = computeAnswers(spec, tryDraw);
          const scope = { ...tryDraw, ...tryAnswers };
          promptSnapshot = renderTemplate(row.prompt, scope);
          if (row.variantAnswerNotes != null) {
            expectedAnswerSnapshot = renderTemplate(row.variantAnswerNotes, scope);
          } else if (row.expectedAnswer != null) {
            expectedAnswerSnapshot = renderTemplate(row.expectedAnswer, scope);
          }
          draw = tryDraw;
          seed = trySeed;
          break;
        } catch (err) {
          if (attempt === 3) {
            console.error("[serveCard] parameterizer failed all retries", err);
          }
        }
      }
    }
  }

  const optionsForClient =
    row.format === "multiple_choice" && Array.isArray(row.options)
      ? (row.options as Array<{ id: string; text: string }>)
      : null;

  const figureUrl =
    row.figureR2Key && row.figureR2Key.length > 0 ? publicUrlFor(row.figureR2Key) : null;

  const [attempt] = await db
    .insert(srsAttempts)
    .values({
      userId,
      cardId: row.cardId,
      questionId: row.questionId,
      sessionId,
      draw: draw as unknown as object | null,
      seed,
      promptSnapshot,
      expectedAnswerSnapshot,
      optionsSnapshot: optionsForClient as unknown as object | null,
      correctOptionSnapshot: row.correctOption,
      figureFileIdSnapshot: row.figureFileId,
    })
    .returning({ id: srsAttempts.id });

  return {
    attemptId: attempt.id,
    cardId: row.cardId,
    questionId: row.questionId,
    prompt: promptSnapshot,
    difficulty: row.difficulty,
    format: row.format,
    options: optionsForClient,
    figureUrl,
  };
}

function randomSeed(): number {
  // 32-bit unsigned int range for mulberry32.
  return Math.floor(Math.random() * 0xffffffff);
}

export type LabMastery = {
  labId: string;
  name: string;
  pct: number; // 0-100
  level: number; // 0-5
  reviewed: number;
  total: number;
};

/**
 * Per-lab mastery for a user, derived from card scheduling state.
 * level 0-5 from average normalized card strength (reps + ease + interval).
 */
export async function getLabMastery(userId: string): Promise<LabMastery[]> {
  const rows = await db
    .select({
      labId: labs.id,
      name: labs.name,
      total: sql<number>`count(${questions.id})`,
      reviewed: sql<number>`count(${srsCards.id}) filter (where ${srsCards.reps} > 0)`,
      // strength: blend of reps (capped) and ease, 0..1
      strength: sql<number>`coalesce(avg(
        least(1.0,
          (least(${srsCards.reps}, 5) / 5.0) * 0.6
          + (greatest(0.0, least(1.0, (${srsCards.ease} - 1.3) / 1.2))) * 0.4
        )
      ) filter (where ${srsCards.id} is not null), 0)`,
    })
    .from(labs)
    .innerJoin(questions, eq(questions.labId, labs.id))
    .leftJoin(
      srsCards,
      and(
        eq(srsCards.questionId, questions.id),
        eq(srsCards.userId, userId),
        eq(srsCards.scope, "lab"),
      ),
    )
    .groupBy(labs.id, labs.name)
    .orderBy(asc(labs.name));

  return rows.map((r) => {
    const pct = Math.round(Number(r.strength) * 100);
    return {
      labId: r.labId,
      name: r.name,
      pct,
      level: Math.round((pct / 100) * 5),
      reviewed: Number(r.reviewed),
      total: Number(r.total),
    };
  });
}
