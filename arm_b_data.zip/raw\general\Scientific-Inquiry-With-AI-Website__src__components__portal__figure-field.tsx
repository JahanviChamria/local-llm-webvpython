"use client";

import { useState } from "react";

const FIGURE_TYPES = ["image/png", "image/jpeg", "image/webp", "image/gif"];

// Optional per-question figure. Uploads an image through the standard files
// pipeline (upload-url → PUT → complete) as a public image/* file, then reports
// the new files.id up via onChange so the parent form can persist it as
// questions.figureFileId. Removing reports null. Preview uses a local object URL
// until the parent saves and the page reloads with the R2 URL.
export function FigureField({
  initialUrl = null,
  onChange,
  onBusyChange,
}: {
  initialUrl?: string | null;
  onChange: (fileId: string | null) => void;
  onBusyChange?: (busy: boolean) => void;
}) {
  const [url, setUrl] = useState<string | null>(initialUrl);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  function setBusyState(b: boolean) {
    setBusy(b);
    onBusyChange?.(b);
  }

  async function upload(file: File) {
    if (!FIGURE_TYPES.includes(file.type)) {
      setMsg("Must be PNG, JPG, WEBP, or GIF.");
      return;
    }
    setBusyState(true);
    setMsg(null);
    try {
      const init = await fetch("/api/admin/files/upload-url", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          filename: file.name,
          size_bytes: file.size,
          content_type: file.type,
          title: file.name,
          access_level: "public",
        }),
      });
      if (!init.ok) {
        const e = (await init.json().catch(() => ({}))) as { error?: string };
        throw new Error(e.error ?? `upload init failed (${init.status})`);
      }
      const { file_id, upload_url, required_headers } = (await init.json()) as {
        file_id: string;
        upload_url: string;
        required_headers: Record<string, string>;
      };
      const put = await fetch(upload_url, { method: "PUT", headers: required_headers, body: file });
      if (!put.ok) throw new Error(`R2 upload failed (${put.status})`);
      const done = await fetch(`/api/admin/files/${file_id}/complete`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      if (!done.ok) {
        const e = (await done.json().catch(() => ({}))) as { error?: string };
        throw new Error(e.error ?? "finalize failed");
      }
      setUrl(URL.createObjectURL(file));
      onChange(file_id);
      setMsg(`Attached ${file.name} — save to apply.`);
    } catch (err) {
      setMsg(err instanceof Error ? err.message : "Upload failed.");
    } finally {
      setBusyState(false);
    }
  }

  function remove() {
    setUrl(null);
    onChange(null);
    setMsg(null);
  }

  const picker = (label: string) => (
    <label className="btn ghost sm" style={{ cursor: busy ? "default" : "pointer" }}>
      {busy ? "Uploading…" : label}
      <input
        type="file"
        accept="image/png,image/jpeg,image/webp,image/gif"
        style={{ display: "none" }}
        disabled={busy}
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) void upload(f);
          e.currentTarget.value = "";
        }}
      />
    </label>
  );

  return (
    <div className="field-label" style={{ marginTop: 14 }}>
      <span>
        Figure{" "}
        <span className="light" style={{ fontWeight: 400 }}>
          · optional image shown with the question
        </span>
      </span>
      {url ? (
        <div className="col" style={{ gap: 8, marginTop: 6 }}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={url}
            alt="Question figure"
            style={{
              maxWidth: "100%",
              maxHeight: 260,
              objectFit: "contain",
              borderRadius: "var(--radius)",
              border: "1px solid var(--border)",
              alignSelf: "flex-start",
            }}
          />
          <div className="row center" style={{ gap: 9 }}>
            {picker("Replace")}
            <button type="button" className="btn ghost sm" onClick={remove} disabled={busy}>
              Remove
            </button>
          </div>
        </div>
      ) : (
        <div style={{ marginTop: 6 }}>{picker("Upload image")}</div>
      )}
      {msg && (
        <span className="light" style={{ fontSize: 11.5, marginTop: 6, display: "block" }}>
          {msg}
        </span>
      )}
    </div>
  );
}
