JavaScript 3.2

scene.width = 800
scene.height = 400
// Fly through Surreal Stonehenge 

// Bruce Sherwood

// A surreal scene that illustrates many of the features of VPython

// Display render time:
//$('<span id="fps"></span>').insertBefore('#glowscript')

let roam = false
// Toggle roaming option:
scene.bind("mousedown", function() {
    roam = true
})
scene.bind("mouseup", function() {
roam = false
})


function hourminute() {
    let now = new Date()
    let hour = now.getHours();
    let minute = now.getMinutes();
    return [hour, minute]
}
let a = 5

class analog_clock {
    
    constructor(args) {
        this.pos = vec(0,0,0)    
        this.axis = vec(0,0,1)
        this.radius = 1
        this.hour = 0
        this.minute = -1
        for (let attr in args) {
            if (args[attr] !== undefined) this[attr] = args[attr]
        }
        this.spheres = []
        this.hour = 0
        this.minute = -1
        for (let n=0; n<12; n++) {
            this.spheres.push(sphere( {pos:this.pos+this.radius*scene.up.rotate({angle:-2*pi*n/12, axis:this.axis}),
            size:0.1*this.radius*vec(1,1,1), color:color.hsv_to_rgb(vec(n/12,1,1)) } ))
        }
        this.hand = arrow( {pos:this.pos, axis:0.95*this.radius*scene.up,
                    shaftwidth:this.radius/10, color:color.cyan} )
        this.update()
    }
    
    update() {
        let hour_and_minute = hourminute()
        let hour = hour_and_minute[0]
        let minute = hour_and_minute[1]
        if (hour >= 12) hour -= 12
        if (this.hour == hour && this.minute == minute) { return }
        this.hand.axis = 0.95*this.radius*scene.up.rotate({angle:-2*pi*minute/60, axis:this.axis})
        this.spheres[this.hour].size = this.radius/10*vec(1,1,1)
        this.spheres[hour].size = this.radius/5*vec(1,1,1)
        this.hour = hour
        this.minute = minute
    }
    
}

let ycenter = 2
scene.center = vec(0,ycenter,0)
scene.range = 12
scene.userspin = false
scene.userzoom = false
scene.background = color.gray(0.5)
scene.ambient = color.gray(0.4)

let grey = color.gray(0.8)
let Nslabs = 8
let R = 10
let w = 5
let d = 0.5
let h = 5
let photocenter = 0.15*w


scene.visible = false

// The floor, central post, and ball atop the post
let floor = box( {pos:vec(0,-0.1,0), size:vec(0.2,24,24), axis:vec(0,1,0), 
    texture:textures.wood} )
let pole= cylinder( {pos:vec(0,0,0), axis:vec(0,1,0), size:vec(h,.4,.4), color:color.red} )
sphere( {pos:vec(0,h,0), size:vec(1,1,1), color:vec(1,0,0)} )

// Set up the gray slabs, including a portal
for (let i=0; i<Nslabs; i++) {
    let theta = i*2*pi/Nslabs
    let c = cos(theta)
    let s = sin(theta)
    let xc = R*c
    let zc = R*s
    if (i == 2) {  // Make a portal
        box( {pos:vec(-3*w/8,0.75*h/2,R),
            size:vec(0.5*w/2,0.75*h,d), color:grey } )
        box( {pos:vec(3*w/8,0.75*h/2,R),
            size:vec(0.5*w/2,0.75*h,d), color:grey } )
        box( {pos:vec(0,0.85*h,R),
            size:vec(w,0.3*h,d), color:grey } )
    }
    else { 
        let slab = box( {pos:vec(R*c, h/2, R*s), axis:vec(c,0,s),
                   size:vec(d,h,w), color:grey } )
        if (i != 6) { 
            let T = textures.flower
            if (i == 7 || i == 4) T = textures.rug
            box( {pos:slab.pos,
                size:vec(1.1*d,0.9*4*photocenter,0.9*4*photocenter), axis:vec(c,0,s),
                    texture:T } )
        }
    }
}

let entry = text({pos:vec(0,4.4,R+d/2), text:'Surreal\nStonehenge', align:'center',
                depth:0.3, height:0.4})
                
let B = text({pos:vec(0.4*R,0,-1*R), text:'B', height:2, align:'center', font:'serif',
                color:color.magenta, depth:1})

let gh = 1
let ga = 1
let gr = 0.05
let rgear = 0.7
let theta = 0
let tgear = ga/5 // gear thickness
let support = extrusion({pos:vec(7,gh/2,10), path:[vec(0,0,0), vec(0,gh,0), vec(0,gh,ga), vec(0,0,ga)],
            shape:shapes.circle({radius:gr}), color:vec(1,.7,0)})
support.clone({pos:vec(7+2*rgear,gh/2,10)})
let gear1 = extrusion({pos:support.pos+vec(0,gh/2,0), path:[vec(0,0,-tgear/2), vec(0,0,tgear/2)],
            shape:shapes.gear({radius:rgear}), color:color.gray(0.85), texture:textures.metal})
let gear2 = gear1.clone({pos:gear1.pos+vec(2*rgear,0,0)})
gear1.rotate({angle:-0.4*2*pi/20, axis:vec(0,0,1)}) // default is 20 teeth

// Decorate back slab with a gold box and a clock
box( {pos:vec(0,h/2,-R+d/2+0.1), size:vec(w/2,w/2,0.2), 
    color:vec(1,0.8,0), texture:textures.wood_old } )
let clock = new analog_clock( {pos:vec(0,h/2,-R+d/2+0.2+0.2*h/10),
                     radius:0.2*w, axis:vec(0,0,1) } )
                     
// Draw guy wires from the top of the central post
let Nwires = 32
for (let i=0; i<Nwires; i++) {
    theta = i*2*pi/Nwires
    let L = vec(R*cos(theta),-h-0.1,R*sin(theta))
    cylinder( {pos:vec(0,h,0), axis:L, size:vec(mag(L),.02,.02), color:vec(1,0.7,0) } )
}

// Display a pyramid
pyramid( {pos:vec(-4,0,-5), size:vec(2,2,2), axis:vec(0,1,0), color:vec(0,.5,0), texture:textures.rough} )

let smoke = []
let Nrings = 20
let x0 = -5, y0 = 1.5, z0 = -2
let r0 = 0.1
let spacing = 0.2
let dr = 0.015
let thick = r0/2
let dthick = thick/Nrings
let gray = 1
cylinder( {pos:vec(x0,0,z0), axis:vec(0,1,0), size:vec(y0+r0,3*r0,3*r0), color:color.black} )
// Display smoke rings rising out of a black tube
// Create the smoke rings
for (let i=0; i<Nrings; i++) {
    let D = 2*(r0+dr*i)
    let T = thick-dthick*i
    smoke.push(ring( {pos:vec(x0,y0+spacing*i,z0), axis:vec(0,1,0), size:vec(T,D,D),
              color:color.gray(gray) } ))
}

let y = 0
let dy = spacing/20
let top_of_rings = Nrings-1

// Roll a log back and forth
let rlog = 1
let wide = 4
let zpos = 2
let zface = 5
let tlogend = 0.2
let v0 = 0.3
let v = v0
let omega = -v0/rlog
let dt = 0.1
let tstop = 0.3

// Log rolls back and forth between two stops
let logcyl = cylinder( {pos:vec(-wide,rlog,zpos), size:vec(zface-zpos,2,2), axis:vec(0,0,1),
         texture:textures.granite } )

let leftstop = box( {pos:vec(-wide-rlog-tstop/2,0.6*rlog,(zpos+zface)/2),
    size:vec(tstop, 1.2*rlog, (zface-zpos)), color:color.red, emissive:1 } )
let rightstop = box( {pos:vec(wide+rlog+tstop/2,0.6*rlog,(zpos+zface)/2),
    size:vec(tstop, 1.2*rlog, (zface-zpos)), color:color.red, emissive:1 } )

// Run a ball up and down the pole
let y1 = 0.2*h
let y2 = 0.7*h
let rball = 0.4
let Dband = 1.3*pole.size.y
cylinder( {pos:vec(0,y1-0.9*rball,0), axis:vec(0,1,0), size:vec(0.1,Dband,Dband), color:color.green} )
cylinder( {pos:vec(0,y2+0.9*rball,0), axis:vec(0,1,0), size:vec(0.1,Dband,Dband), color:color.green} )
let vball0 = 0.3*v0
let vball = vball0
let ballangle = 0.05*pi
let poleball = sphere( {pos:vec(0,y1,0), size:2*rball*vec(1,1,1), color:color.blue} )
let polecones = []
for (let nn=0; nn<4; nn++) {
    let cc = cone( {pos:vec(0.8*rball,y1,0), size:rball*vec(3,1,1), color:color.yellow} )
    cc.rotate( {angle:0.5*nn*pi, axis:vec(0,1,0), origin:vec(0,y1,0)} )
    polecones.push(cc)
}
let rbaseball = 0.3
let vbaseball0 = 3*v0

// A table with a mass-spring object sliding on it
let table = cone({pos:vec(0.4*R,h/4,-.3*R), size:vec(h/4,0.6*R,0.6*R),
        axis:vec(0,-1,0), texture:{file:textures.wood_old, turn:1}})
let tabletop = table.pos
let rspring = 0.02*h
let Lspring = .15*R
let Lspring0 = .1*R
let hmass = 4*rspring
let post = cylinder({pos:tabletop, axis:vec(0,1,0), size:vec(2*hmass,.4,.4), color:color.gray(.6)})
let spring = helix({pos:post.pos+vec(0,hmass/2,0), size:vec(Lspring,2*rspring,2*rspring),
        color:color.orange, thickness:rspring})
let mass = cylinder({pos:post.pos+vec(Lspring,0,0), axis:vec(0,1,0), size:vec(hmass,.04*R,.04*R),
        color:color.orange})
mass.p = vec(10,0,5)
mass.m = 1
let kspring = 200
let deltat = .01

// Display an ellipsoid
let Rcloud = 0.8*R
let omegacloud = 3*v0/Rcloud
let cloud = sphere( {pos:vec(0,0.7*h,-Rcloud), size:vec(5,2,2),
                  color:color.green, opacity:0.3 } )
                  
let rhairs = 0.025
let dhairs = 2
let maxcosine = dhairs/sqrt(pow(rhairs,2)+pow(dhairs,2)) // if ray angle < maxcosine, don't move
let haircolor = color.black
// Add instructions below the display

await scene.waitfor("textures")
scene.visible = true

let s = "<b>Fly through the scene:</b> With the mouse button down,<br>"
s += "    move the mouse or your finger above or below the center of the scene to move forward or backward;<br>"
s += "    move the mouse or your finger right or left to turn your direction of motion.<br>"
s += "(Normal GlowScript rotate and zoom are turned off in this program.)"
scene.caption = s

let hue = 0
let dhue = 0.01
let gangle = 0.03 // incremental rotation of the gears

while (true) { 
    if (roam) {
        let ray = scene.mouse.ray
        if (abs(ray.dot(scene.forward)) < maxcosine) {  // do something only if significant change of direction
            let newray = norm(vec(ray.x, 0, ray.z))
            let angle = asin(scene.forward.cross(newray).dot(scene.up))
            scene.camera.rotate({angle:angle/30, axis:scene.up})
            scene.camera.pos = scene.camera.pos + (ray.y/2)*norm(scene.camera.axis)
        }
    }
    
    hue += dhue
    entry.color = color.hsv_to_rgb(vec(hue,1,1))
    
    B.rotate({angle:0.05, axis:scene.up})
    
    gear1.rotate({angle:gangle, axis:vec(0,0,1)})
    gear2.rotate({angle:-gangle, axis:vec(0,0,1)})
    
    // Roll the log
    theta = theta + omega*dt
    logcyl.pos.x = logcyl.pos.x+v*dt
    logcyl.rotate( {angle:omega*dt, axis:vec(0,0,1)} )
    if (logcyl.pos.x >= wide) { 
        v = -v0
        omega = -v/rlog
        if (rightstop.color.equals(color.red)) { 
            rightstop.color = color.cyan
        }
        else { 
            rightstop.color = color.red
        }
    }
    if (logcyl.pos.x <= -wide) { 
        v = +v0
        omega = -v/rlog
        if (leftstop.color.equals(color.red)) { 
            leftstop.color = color.cyan
        }
        else { 
            leftstop.color = color.red
        }
    }

    // Move the cloud
    cloud.rotate( {angle:omegacloud*dt, axis:vec(0,1,0), origin:vec(0,0,0)} )

    // Run the ball up and down
    poleball.pos.y = poleball.pos.y+vball*dt
    for (let i=0; i<4; i++) {
        polecones[i].pos.y = poleball.pos.y
        polecones[i].rotate( {angle:ballangle, axis:vec(0,1,0), origin:vec(0,0,0)} )
    }
    if (poleball.pos.y >= y2) { 
        vball = -vball0
        ballangle = -ballangle
    }
    if (poleball.pos.y <= y1) { 
        vball = +vball0
        ballangle = -ballangle
    }
  
    // Move the smoke rings
    for (let i=0; i<Nrings; i++) {
        // Raise the smoke rings
        smoke[i].pos = smoke[i].pos+vec(0,dy,0)
        smoke[i].size.y = smoke[i].size.z =smoke[i].size.y+(dr/spacing)*dy
        smoke[i].size.x = smoke[i].size.x-(dthick/spacing)*dy
    }
    y = y+dy
    if (y >= spacing) { 
        // Move top ring to the bottom
        y = 0
        smoke[top_of_rings].pos = vec(x0, y0, z0)
        smoke[top_of_rings].size = vec(thick,2*r0,2*r0)
        top_of_rings--
    }
    if (top_of_rings < 0) { 
        top_of_rings = Nrings-1
    }
    
    // Update the mass-spring motion
    let F = -kspring*(spring.size.x-Lspring0)*spring.axis.norm()
    mass.p = mass.p + F*deltat
    mass.pos = mass.pos + (mass.p/mass.m)*deltat
    spring.axis = mass.pos+vec(0,hmass/2,0)-spring.pos
    spring.size.x = mag(spring.axis)

    // Update the analog clock on the back slab
    clock.update()
    
    await rate(30)

}