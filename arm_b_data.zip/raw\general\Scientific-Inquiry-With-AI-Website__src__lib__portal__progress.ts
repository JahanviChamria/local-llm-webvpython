import { and, eq, gte, sql } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { srsReviews, srsSessions } from "@/lib/db/schema";
import { getLabMastery, type LabMastery } from "@/lib/srs/queue";

export type ProgressBadge = {
  icon: string;
  name: string;
  earned: boolean;
};

export type ProgressData = {
  dayStreak: number;
  recallEngagement: number; // 0-100, against the 2-sessions/week cadence
  topicsMastered: number;
  totalTopics: number;
  sessionsThisTerm: number;
  mastery: LabMastery[];
  /** Lowest-mastery labs the queue should lean on next. */
  focusNext: LabMastery[];
  /** Per-day review counts for the last `heatWeeks` weeks, oldest → newest. */
  activity: number[];
  badges: ProgressBadge[];
};

const MASTERED_PCT = 80;
const HEAT_WEEKS = 5;

/** UTC date key (YYYY-MM-DD) for a timestamp. */
export function dayKey(d: Date): string {
  return d.toISOString().slice(0, 10);
}

/**
 * Consecutive-day streak ending today (or yesterday — today still counts as
 * alive until the day is over). Days are derived from finished sessions.
 */
export function computeStreak(activeDays: Set<string>): number {
  let streak = 0;
  const cursor = new Date();
  // Allow the streak to "end" today even if no session yet today.
  if (!activeDays.has(dayKey(cursor))) {
    cursor.setUTCDate(cursor.getUTCDate() - 1);
    if (!activeDays.has(dayKey(cursor))) return 0;
  }
  while (activeDays.has(dayKey(cursor))) {
    streak += 1;
    cursor.setUTCDate(cursor.getUTCDate() - 1);
  }
  return streak;
}

/**
 * Lightweight streak-only read for the sidebar pill — runs a single finished-sessions
 * query instead of the full getProgressData fan-out on every portal page render.
 */
export async function getDayStreak(userId: string): Promise<number> {
  const rows = await db
    .select({ finishedAt: srsSessions.finishedAt })
    .from(srsSessions)
    .where(and(eq(srsSessions.userId, userId), sql`${srsSessions.finishedAt} is not null`));
  const activeDays = new Set(
    rows.filter((r) => r.finishedAt).map((r) => dayKey(r.finishedAt as Date)),
  );
  return computeStreak(activeDays);
}

export async function getProgressData(userId: string): Promise<ProgressData> {
  const now = new Date();
  const heatStart = new Date(now);
  heatStart.setUTCDate(heatStart.getUTCDate() - (HEAT_WEEKS * 7 - 1));
  heatStart.setUTCHours(0, 0, 0, 0);
  const fourWeeksAgo = new Date(now);
  fourWeeksAgo.setUTCDate(fourWeeksAgo.getUTCDate() - 28);

  const [mastery, sessionRows, recentSessionCount, reviewDays] = await Promise.all([
    getLabMastery(userId),
    // Finished sessions → streak source + term total.
    db
      .select({ finishedAt: srsSessions.finishedAt })
      .from(srsSessions)
      .where(and(eq(srsSessions.userId, userId), sql`${srsSessions.finishedAt} is not null`)),
    // Sessions in the last 4 weeks → engagement vs the 2/week cadence.
    // Lab scope only: engagement is graded, so external standalone practice
    // doesn't count (streak/heatmap above and below intentionally count both).
    db
      .select({ n: sql<number>`count(*)` })
      .from(srsSessions)
      .where(
        and(
          eq(srsSessions.userId, userId),
          eq(srsSessions.scope, "lab"),
          sql`${srsSessions.finishedAt} is not null`,
          gte(srsSessions.finishedAt, fourWeeksAgo),
        ),
      ),
    // Per-day review counts for the heatmap window.
    db
      .select({
        day: sql<string>`to_char(${srsReviews.reviewedAt} at time zone 'UTC', 'YYYY-MM-DD')`,
        n: sql<number>`count(*)`,
      })
      .from(srsReviews)
      .where(and(eq(srsReviews.userId, userId), gte(srsReviews.reviewedAt, heatStart)))
      .groupBy(sql`1`),
  ]);

  const activeDays = new Set(
    sessionRows.filter((r) => r.finishedAt).map((r) => dayKey(r.finishedAt as Date)),
  );
  const dayStreak = computeStreak(activeDays);
  const sessionsThisTerm = sessionRows.length;

  const recentSessions = Number(recentSessionCount[0]?.n ?? 0);
  const recallEngagement = Math.min(100, Math.round((recentSessions / 8) * 100));

  const topicsMastered = mastery.filter((m) => m.pct >= MASTERED_PCT).length;
  const totalTopics = mastery.length;

  const focusNext = mastery
    .filter((m) => m.total > 0 && m.pct < MASTERED_PCT && m.reviewed > 0)
    .sort((a, b) => a.pct - b.pct)
    .slice(0, 2);

  // Build the dense day array for the heatmap.
  const counts = new Map(reviewDays.map((r) => [r.day, Number(r.n)]));
  const activity: number[] = [];
  for (let i = 0; i < HEAT_WEEKS * 7; i++) {
    const d = new Date(heatStart);
    d.setUTCDate(d.getUTCDate() + i);
    activity.push(counts.get(dayKey(d)) ?? 0);
  }

  const allMastered = totalTopics > 0 && topicsMastered === totalTopics;
  const badges: ProgressBadge[] = [
    { icon: "🔥", name: "7-day streak", earned: dayStreak >= 7 },
    { icon: "🧠", name: "5 topics mastered", earned: topicsMastered >= 5 },
    { icon: "🔁", name: "First session", earned: sessionsThisTerm >= 1 },
    { icon: "📚", name: "10 sessions", earned: sessionsThisTerm >= 10 },
    { icon: "⚡", name: "20 sessions", earned: sessionsThisTerm >= 20 },
    { icon: "🌱", name: "First topic mastered", earned: topicsMastered >= 1 },
    { icon: "🏅", name: "30-day streak", earned: dayStreak >= 30 },
    { icon: "🧬", name: "All topics mastered", earned: allMastered },
  ];

  return {
    dayStreak,
    recallEngagement,
    topicsMastered,
    totalTopics,
    sessionsThisTerm,
    mastery,
    focusNext,
    activity,
    badges,
  };
}
