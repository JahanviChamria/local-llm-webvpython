import java.util.*;
public class ZeroRowCol {

	public static void zeroRowCol(int[][] arr) {

		HashSet<Integer> rows = new HashSet<>(); // To store the rows with 0s
		HashSet<Integer> cols = new HashSet<>(); // To store the columns with 0s

		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				if (arr[i][j] == 0) { // Every time a 0 is encountered, store the current row and the current column
					rows.add(i);
					cols.add(j);
				}
			}
		}

		for (int i = 0; i < arr.length; i++) {
			if (rows.contains(i)) { // For every row, check if that value of i exists in the Rows hashset
				for (int j = 0; j < arr[i].length; j++) {
					arr[i][j] = 0; // If yes, change the whole row to 0s
				}
			} else { // If no, check whether the current column (j) exists in the Columns hashset
				for (int j = 0; j < arr[i].length; j++) {
					if (cols.contains(j)) {
						arr[i][j] = 0; // If yes, change the cell to 0 (if (j<arr[i].length))
					}
				}
			}
		}

	}

	public static void main(String[] args) {

		// test cases
		// 1
		int arr1[][] = { { 1, 1, 1 },
				{ 1, 0, 1 },
				{ 1, 1, 1 } };
		zeroRowCol(arr1);
		System.out.println(Arrays.deepToString(arr1));

		// 2
		int arr2[][] = { { 1, 2, 3 },
				{ 4, 5, 6 },
				{ 7, 8, 9 } };
		zeroRowCol(arr2);
		System.out.println(Arrays.deepToString(arr2));

		// 3
		int arr3[][] = { { 0, 1, 2, 3, 4, 5 },
				{ 6, 7, 8, 9, 10, 11 } };
		zeroRowCol(arr3);
		System.out.println(Arrays.deepToString(arr3));

		// 4
		int arr4[][] = { { 1, 0, 1, 0, 1 },
				{ 5, 5, 5, 5, 5 },
				{ 1, 0, 1, 0, 1 } };
		zeroRowCol(arr4);
		System.out.println(Arrays.deepToString(arr4));

		// 5
		int arr5[][] = { { 0, 1, 2, 0 },
				{ 3, 4 },
				{ 5, 6, 7, 8, 9 },
				{ 10, 11, 0 } };
		zeroRowCol(arr5);
		System.out.println(Arrays.deepToString(arr5));

		// 6
		int arr6[][] = {}; // array of length zero
		zeroRowCol(arr6);
		System.out.println(Arrays.deepToString(arr6));

		// 7
		int arr7[][] = { { 1, 0, 1 },
				{},
				{ 9, 8, 7 } };
		zeroRowCol(arr7);
		System.out.println(Arrays.deepToString(arr7));

	}
}