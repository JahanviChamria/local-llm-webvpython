import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
import { listClassesForOwner } from "@/lib/admin/classes";
import { listAllClasses } from "@/lib/admin/all-classes";
import { Card } from "@/components/portal/primitives";

export const dynamic = "force-dynamic";

// Same shape and ownership gating as the active-classes page. `manageable`
// controls the Open link; admins see every archived class but can only open the
// ones they own (the manage page stays owner-scoped).
type ArchivedRow = {
  id: string;
  name: string;
  studentCount: number;
  labCount: number;
  manageable: boolean;
  ownerUsername: string | null;
};

export default async function ArchivedClassesPage() {
  const me = await getCurrentUser();
  if (!me) redirect("/login?next=/admin/classes/archived");
  if (me.role !== "admin" && me.role !== "faculty") {
    return (
      <div className="col">
        <div className="screen-head">
          <div className="section-label">Restricted</div>
          <h1>Not available</h1>
        </div>
      </div>
    );
  }

  const isAdmin = me.role === "admin";

  // Admins see every archived class (read-only for ones they don't own); faculty
  // see only their own.
  const archived: ArchivedRow[] = isAdmin
    ? (await listAllClasses({ includeArchived: true }))
        .filter((c) => c.archivedAt !== null)
        .map((c) => ({
          id: c.id,
          name: c.name,
          studentCount: c.studentCount,
          labCount: c.labCount,
          manageable: c.ownerId === me.id,
          ownerUsername: c.ownerId === me.id ? null : c.ownerUsername,
        }))
    : (await listClassesForOwner(me.id, { includeArchived: true }))
        .filter((c) => c.archivedAt !== null)
        .map((c) => ({
          id: c.id,
          name: c.name,
          studentCount: c.studentCount,
          labCount: c.labCount,
          manageable: true,
          ownerUsername: null,
        }));

  return (
    <div className="col">
      <div className="screen-head">
        <div className="section-label">Teaching · Classes</div>
        <h1>Archived classes</h1>
        <p className="lead muted">
          {isAdmin ? (
            <>
              Every archived class across all faculty. You can open the ones you own to unarchive or
              hard-delete; the rest are read-only. Archived classes are hidden from students.
            </>
          ) : (
            <>
              Archived classes are hidden from students. Unarchive to restore, or open the class to
              hard-delete it (which only removes the class container — student history is untouched).
            </>
          )}
        </p>
        <div className="row" style={{ gap: 9, marginTop: 9 }}>
          <Link className="btn ghost sm" href="/admin/classes">
            ← Active classes
          </Link>
        </div>
      </div>

      {archived.length === 0 ? (
        <Card>
          <p className="muted" style={{ fontSize: 13 }}>No archived classes.</p>
        </Card>
      ) : (
        <div className="col" style={{ gap: 14 }}>
          {archived.map((c) => (
            <Card key={c.id} title={c.name} label="archived">
              <div className="row" style={{ gap: 9, alignItems: "center" }}>
                <span className="muted" style={{ fontSize: 13 }}>
                  {c.studentCount} student{c.studentCount === 1 ? "" : "s"} · {c.labCount} lab
                  {c.labCount === 1 ? "" : "s"}
                  {c.ownerUsername ? ` · owner: ${c.ownerUsername}` : ""}
                </span>
                <span className="grow" />
                {c.manageable ? (
                  <Link className="btn primary sm" href={`/admin/classes/${c.id}`}>
                    Open →
                  </Link>
                ) : (
                  <span className="label" style={{ fontSize: 11 }}>
                    Read-only
                  </span>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
