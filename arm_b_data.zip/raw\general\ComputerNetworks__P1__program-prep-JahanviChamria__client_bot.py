#!/usr/bin/python3

from argparse import ArgumentParser
import os
import socket
import time

def main():
    # Parse arguments
    arg_parser = ArgumentParser(description='Client Bot', add_help=False)
    arg_parser.add_argument('-p', '--port', dest='port', action='store',
            type=int, default=80, help='Port to connect on')
    arg_parser.add_argument('-h', '--hostname', dest='hostname', action='store',
            default='spock.cs.colgate.edu', help='Port to connect on')
    settings = arg_parser.parse_args()

    print('Client Bot PID: %d' % os.getpid())
    
    # Connect to server
    with socket.socket() as client_sock:
        print("Connecting to %s:%d..." % (settings.hostname, settings.port))
        #1:connect to the actual hostname not an empty string
        client_sock.connect((settings.hostname, settings.port))
        for uri in ["/agent.php", "/time.php"]:
            send_request(client_sock, uri, settings.hostname)
            recv_response(client_sock)

def recv_response(sock):
    # Receive response
    response = sock.recv(4096).decode()
    lines = response.split('\r\n')

    print(lines[-1], end='')

def send_request(sock, uri, host):
    # Construct request parts
    #2: added HTTP/1.1 protocol
    first = "GET %s HTTP/1.1" % uri
    host = "Host: %s" % host
    #3:added colon and hyphen to User-Agent header
    agent = "User-Agent: client_bot/2026.01"
    accept = "Accept: */*"
        
    # Construct full request
    #3: HTTP requires \r\n (CRLF) line endings and request must end with a blank line (\r\n\r\n)
    request = "\r\n".join([first, host, agent, accept])+"\r\n\r\n"

    # Send response
    sock.send(request.encode())

if __name__ == '__main__':
    main()
