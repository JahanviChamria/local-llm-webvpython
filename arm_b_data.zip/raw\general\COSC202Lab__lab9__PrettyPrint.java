import java.util.*;
import java.io.*;

public class PrettyPrint {

    public static List<Integer> splitWords(int[] lengths, int L, SlackFunctor sf) {

        int n = lengths.length;
        
        //words longer than L
        for (int len : lengths) {
            if (len > L) 
                return null;
        }
        
        //prefix sums of word lengths
        int[] sum = new int[n + 1]; // sum[k] = sum of lengths[0 to k-1]
        sum[0] = 0;
        for (int k = 1; k <= n; k++) {
            sum[k] = sum[k - 1] + lengths[k - 1];
        }
        
        //DP 
        double[] OPT = new double[n + 1]; // OPT[i] = min total cost for words i to n-1
        int[] next = new int[n];           // next[i] = best line break index for line starting at i
        
        OPT[n] = 0; //base case: no words left
        
        //fill OPT[i] from i = n-1 to 0
        for (int i = n - 1; i >= 0; i--) {
            double best = Double.POSITIVE_INFINITY;
            int best_j = -1;
            
            for (int j = i; j < n; j++) {
                int lineLength = sum[j + 1] - sum[i] + (j - i); //words + spaces
                int slack = L - lineLength;
                if (slack < 0) break; //cannot fit line
                
                double cost = sf.f(slack) + OPT[j + 1];
                if (cost < best) {
                    best = cost;
                    best_j = j;
                }
            }
            
            OPT[i] = best;
            next[i] = best_j;
        }
        
        //list of last word indices per line
        List<Integer> lines = new ArrayList<>();
        int i = 0;
        while (i < n) {
            int j = next[i];
            lines.add(j);
            i = j + 1;
        }
        
        return lines;

    }

    public static String help_message() {
        return
            "Usage: java PrettyPrint line_length [inputfile] [outputfile]\n" +
            "  line_length (required): an integer specifying the maximum length for a line\n" +
            "  inputfile (optional): a file from which to read the input text (stdin if a hyphen or omitted)\n" +
            "  outputfile (optional): a file in which to store the output text (stdout if omitted)"
            ;
    }

    public static void main(String[] args) {
        
        if (args.length < 1) {
            System.err.println("Error: required argument line_length missing");
            System.err.println(help_message());
            System.exit(1);
            return;
        }

        int line_length;
        try {
            line_length = Integer.parseInt(args[0]);
        } catch (NumberFormatException e) {
            System.err.println("Error: could not find integer argument line_length");
            System.err.println(help_message());
            System.exit(2);
            return;
        }

        Scanner input = null;
        PrintStream output = null;
        if (args.length < 2) {
            input = new Scanner(System.in);
        }
        else if (args.length >= 2) {
            if (args[1].equals("-")) {
                input = new Scanner(System.in);
            } else {
                try {
                    input = new Scanner(new File(args[1]));
                } catch (FileNotFoundException e) {
                    System.err.println("Error: could not open input file");
                    System.err.println(help_message());
                    System.exit(3);
                    return;
                }
            }
        }

        if (args.length >= 3) {
            try {
                output = new PrintStream(args[2]);
            } catch (FileNotFoundException e) {
                System.err.println("Error: could not open output file");
                System.err.println(help_message());
                input.close();
                System.exit(4);
                return;
            }
        } else {
            output = System.out;
        }

        ArrayList<String> words = new ArrayList<String>();
        while (input.hasNext()) {
            words.add(input.next());
        }
        input.close();

        int[] lengths = new int[words.size()];
        for (int i = 0; i < words.size(); i++) {
            lengths[i] = words.get(i).length();
        }
        
        List<Integer> breaks = splitWords(lengths, line_length,
            new SlackFunctor() {
                public double f(int slack) { return slack * slack; }
            });

        if (breaks != null) {
            int current_word = 0;
            for (int next_break : breaks) {
                while (current_word < next_break) {
                    output.print(words.get(current_word++));
                    output.print(" ");
                }
                output.print(words.get(current_word++));
                output.println();
            }

            output.close();
            System.exit(0);
            return;
    
        } else {
            System.err.println("Error: formatting impossible; an input word exceeds line length");
            output.close();
            System.exit(5);
            return;
        }
    }
}