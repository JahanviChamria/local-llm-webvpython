JavaScript 3.2
/* This program displays most VPython 3D objects.

It also illustrates key features such as mouse handling, rate, and sleep. */

// Bruce Sherwood, August 2011

let s
let drag = false

async function down() {
    s = sphere({radius:0.5, color:color.magenta})
    s.pos = scene.mouse.pos
    drag = true
}

scene.bind("mousedown", down)

async function move() {
    if (!drag) { return }
    s.pos = scene.mouse.pos
}

scene.bind("mousemove", move)

async function up() {
    s.visible = false
    drag = false
}

scene.bind("mouseup", up) 

scene.title = "A display of most GlowScript 3D objects"
scene.width = 640
scene.height = 400
scene.background = color.gray(0.7)
scene.center = vec(0,0.5,0)
scene.forward = vec(-.3,0,-1)

let gslabel = label({pos:vec(1.1,2,0), text:'GlowScript', 
    xoffset:40, height:16, color:color.yellow})
box( {pos:vec(-2,0,0), size:vec(.3,2.5,2.5), color:color.red} )
box( {pos:vec(.25,-1.4,0), size:vec(4.8,.3,2.5), color:color.red} )
cylinder( {pos:vec(-2,2,1.25), size:vec(2.5,1.4,1.4), axis:vec(0,0,-1), color:color.blue} )
let ball = sphere( {pos:vec(2,1,0), radius:0.5, color:color.cyan} )
let ptr = arrow( {pos:vec(0,0,2), axis:vec(2,0,0), color:color.yellow} )
cone( {pos:vec(-2,0,0), size:vec(3,2,2), color:color.green, opacity:0.3} )
ring( {pos:vec(.2,0,0), radius:0.6, axis:vec(1,0,0), thickness:0.12, color:color.gray(0.4)} )
sphere( {pos:vec(-.3,2,0), color:color.orange, size:vec(.3,1.5,1.5)} )
pyramid( {pos:vec(.3,2,0), color:vec(0,0.5,.25), size:vec(0.8,1.2,1.2)} )
let spring = helix( {pos:vec(2,-1.25,0), size:vec(1.8,.6,.6), axis:vec(0,1,0),
        color:color.orange, thickness:.1} )

let angle = 0
let da = .01

let trail = curve({color:color.magenta, radius: .02})
trail.push(vec(1,0,0))
trail.push(vec(1,0,2))
trail.push(vec(2,0,2))

while (angle < 3*pi/4) {
  await rate(100)
  ptr.rotate( {angle:da, axis:vec(0,0,1), origin:ptr.pos} )
  trail.push(ptr.pos+ptr.axis)
  angle += da
}

await sleep(1) // sleep for 1 second
scene.autoscale = false
scene.caption = "Drag the mouse and you'll drag a sphere.\nOn a touch screen, press and hold, then drag."

let t = 0
let dt = .01
let y0 = gslabel.pos.y
let ball_yo = ball.pos.y
while (t < 10) {
  await rate(1/dt)
  ball.pos = vec(ball.pos.x, ball_yo+0.5*sin(-4*t, 0), 0)
  spring.size.x = ball.pos.y-spring.pos.y-ball.size.y/2+0.15
  gslabel.yoffset = 28*sin(-4*t)
  t += dt
}