import Link from "next/link";
import { getCurrentUser } from "@/lib/auth/session";
import {
  getLearningHistory,
  getStudentsForAdmin,
  getStudentsForClass,
  STUDENT_LIST_CAP,
  type StudentListRow,
  type StudentClassListRow,
} from "@/lib/portal/history";
import { listClassesForOwner, type ClassSummary } from "@/lib/admin/classes";
import { getCommonMistakes } from "@/lib/portal/common-mistakes";
import { Card } from "@/components/portal/primitives";
import { HistoryTimeline } from "@/components/portal/history-timeline";
import { CommonMistakesSection } from "@/components/portal/common-mistakes-section";

export const dynamic = "force-dynamic";

type SearchParams = {
  q?: string;
  class?: string;
};

export default async function HistoryScreen({
  searchParams,
}: {
  searchParams: Promise<SearchParams>;
}) {
  // (portal)/layout.tsx already redirects anonymous users to /login.
  const user = (await getCurrentUser())!;
  const sp = await searchParams;
  const q = typeof sp.q === "string" ? sp.q : null;
  const classId = typeof sp.class === "string" ? sp.class : null;

  if (user.role === "student") {
    return <OwnHistoryView userId={user.id} />;
  }

  if (user.role === "admin") {
    return <AdminStudentListView search={q} />;
  }

  if (user.role === "faculty") {
    if (classId) {
      return <ClassStudentListView classId={classId} ownerId={user.id} search={q} />;
    }
    return <ClassPickerView ownerId={user.id} />;
  }

  // guest, or any future role — deny by default
  return <NoAccessScreen />;
}

// ───────────────────────────────────────────────────────────────────────────
// Views
// ───────────────────────────────────────────────────────────────────────────

async function OwnHistoryView({ userId }: { userId: string }) {
  const { entries, totalsByKind } = await getLearningHistory(userId);

  return (
    <div className="col" style={{ maxWidth: 920 }}>
      <div className="screen-head">
        <div className="section-label">You</div>
        <h1>Student Histories</h1>
        <p className="lead muted">
          Everything we&apos;ve recorded about your practice and activity. Read-only
          — only faculty can reset it. To see what the AI tutor thinks of you,
          visit <Link href="/portal/profile">your profile</Link>.
        </p>
      </div>
      <HistoryTimeline
        entries={entries}
        totalsByKind={totalsByKind}
        emptyMessage={
          <>
            <strong>Nothing recorded yet.</strong> Start a practice session from the
            Retrieval Tool, or open a lab from the sidebar — your activity will show
            up here as you go.
          </>
        }
      />
    </div>
  );
}

async function AdminStudentListView({ search }: { search: string | null }) {
  const [students, mistakes] = await Promise.all([
    getStudentsForAdmin(search, STUDENT_LIST_CAP),
    getCommonMistakes({ kind: "all" }),
  ]);
  const atCap = students.length === STUDENT_LIST_CAP;

  return (
    <div className="col" style={{ maxWidth: 1080 }}>
      <div className="screen-head">
        <div className="section-label">Teaching</div>
        <h1>Prelab progress</h1>
        <p className="lead muted">
          Browse any student&apos;s prelab progress. Search by username or display name.
        </p>
      </div>

      {mistakes && <CommonMistakesSection report={mistakes} />}

      <SearchBox q={search} />

      <StudentTable
        students={students}
        atCap={atCap}
        emptyMessage={
          search
            ? `No students match "${search}".`
            : "No student accounts exist yet."
        }
        fromQ={search}
      />
    </div>
  );
}

async function ClassPickerView({ ownerId }: { ownerId: string }) {
  const allClasses = await listClassesForOwner(ownerId, { includeArchived: false });

  return (
    <div className="col" style={{ maxWidth: 1080 }}>
      <div className="screen-head">
        <div className="section-label">Teaching</div>
        <h1>Prelab progress</h1>
        <p className="lead muted">
          Pick a class to see its students&apos; prelab progress.
        </p>
      </div>

      {allClasses.length === 0 ? (
        <div className="callout">
          <strong>You don&apos;t own any classes yet.</strong>{" "}
          Create one from <Link href="/admin/classes">/admin/classes</Link>.
        </div>
      ) : (
        <ClassPickerList classes={allClasses} />
      )}
    </div>
  );
}

async function ClassStudentListView({
  classId,
  ownerId,
  search,
}: {
  classId: string;
  ownerId: string;
  search: string | null;
}) {
  const result = await getStudentsForClass(classId, ownerId, search, STUDENT_LIST_CAP);

  if (!result.classFound) {
    return (
      <div className="col" style={{ maxWidth: 1080 }}>
        <div className="screen-head">
          <div className="section-label">Teaching</div>
          <h1>Prelab progress</h1>
        </div>
        <p>
          <Link href="/portal/history">← All classes</Link>
        </p>
        <div className="callout orange">
          <strong>You don&apos;t have access to this class, or it no longer exists.</strong>
        </div>
      </div>
    );
  }

  const atCap = result.students.length === STUDENT_LIST_CAP;
  const mistakes = await getCommonMistakes({ kind: "class", classId, ownerId });

  return (
    <div className="col" style={{ maxWidth: 1080 }}>
      <div className="screen-head">
        <div className="section-label">Teaching · Class</div>
        <h1>{result.className}</h1>
        <p className="lead muted">
          Students enrolled in this class. Click any to view their prelab progress.
        </p>
      </div>

      <p>
        <Link href="/portal/history">← All classes</Link>
      </p>

      {mistakes && <CommonMistakesSection report={mistakes} classId={classId} />}

      <SearchBox q={search} classId={classId} />

      <StudentTable
        students={result.students}
        atCap={atCap}
        emptyMessage={
          search
            ? `No students in this class match "${search}".`
            : "No students enrolled in this class yet."
        }
        fromClass={classId}
        fromQ={search}
      />
    </div>
  );
}

function NoAccessScreen() {
  return (
    <div className="col">
      <div className="screen-head">
        <div className="section-label">Restricted</div>
        <h1>Not available</h1>
      </div>
      <div className="callout orange">
        <strong>You don&apos;t have access to this page.</strong>
      </div>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────────────────
// Shared pieces
// ───────────────────────────────────────────────────────────────────────────

function SearchBox({ q, classId }: { q: string | null; classId?: string }) {
  return (
    <Card>
      <form
        method="GET"
        action="/portal/history"
        className="row"
        style={{ gap: 8, alignItems: "center" }}
      >
        {classId ? <input type="hidden" name="class" value={classId} /> : null}
        <input
          type="search"
          name="q"
          defaultValue={q ?? ""}
          placeholder="Search by username or display name"
          aria-label="Search students by username or display name"
          className="grow"
          style={{
            padding: "8px 10px",
            border: "1px solid var(--border)",
            borderRadius: 6,
            fontSize: 14,
          }}
        />
        <button type="submit" className="btn">
          Search
        </button>
        {q ? (
          <Link
            href={classId ? `/portal/history?class=${encodeURIComponent(classId)}` : "/portal/history"}
            className="muted"
            style={{ fontSize: 13 }}
          >
            Clear
          </Link>
        ) : null}
      </form>
    </Card>
  );
}

function ClassPickerList({ classes }: { classes: ClassSummary[] }) {
  return (
    <div className="col" style={{ gap: 8 }}>
      {classes.map((c) => (
        <Card key={c.id}>
          <div
            className="row"
            style={{ gap: 12, alignItems: "center", flexWrap: "wrap" }}
          >
            <div className="grow">
              <Link
                href={`/portal/history?class=${encodeURIComponent(c.id)}`}
                style={{ fontWeight: 600, fontSize: 16 }}
              >
                {c.name}
              </Link>
              <div className="muted" style={{ fontSize: 12.5, marginTop: 2 }}>
                {c.studentCount} student{c.studentCount === 1 ? "" : "s"} ·{" "}
                {c.labCount} lab{c.labCount === 1 ? "" : "s"}
              </div>
            </div>
            <Link
              href={`/portal/history?class=${encodeURIComponent(c.id)}`}
              className="btn sm"
            >
              View students →
            </Link>
          </div>
        </Card>
      ))}
    </div>
  );
}

function StudentTable({
  students,
  atCap,
  emptyMessage,
  fromClass,
  fromQ,
}: {
  students: (StudentListRow | StudentClassListRow)[];
  atCap: boolean;
  emptyMessage: string;
  fromClass?: string;
  fromQ?: string | null;
}) {
  if (students.length === 0) {
    return (
      <div className="callout">
        <strong>{emptyMessage}</strong>
      </div>
    );
  }

  return (
    <>
      <Card
        title="Students"
        label={`${students.length}${atCap ? " (capped)" : ""}`}
      >
        <div className="col" style={{ gap: 0 }}>
          {students.map((s) => (
            <StudentRow
              key={s.id}
              student={s}
              fromClass={fromClass}
              fromQ={fromQ}
            />
          ))}
        </div>
      </Card>
      {atCap ? (
        <p className="muted" style={{ fontSize: 12.5 }}>
          Showing first {STUDENT_LIST_CAP} students. Use the search box to
          narrow results.
        </p>
      ) : null}
    </>
  );
}

function StudentRow({
  student,
  fromClass,
  fromQ,
}: {
  student: StudentListRow | StudentClassListRow;
  fromClass?: string;
  fromQ?: string | null;
}) {
  const params = new URLSearchParams();
  if (fromClass) params.set("from_class", fromClass);
  if (fromQ) params.set("from_q", fromQ);
  const qs = params.toString();
  const href = `/portal/history/${encodeURIComponent(student.id)}${qs ? `?${qs}` : ""}`;

  return (
    <div
      className="row"
      style={{
        gap: 12,
        alignItems: "center",
        padding: "10px 0",
        borderTop: "1px solid var(--border)",
        flexWrap: "wrap",
      }}
    >
      <div style={{ flex: "0 0 200px" }}>
        <Link href={href} className="mono" style={{ fontWeight: 600 }}>
          {student.username}
        </Link>
      </div>
      <div style={{ flex: "1 1 200px", fontSize: 13.5 }}>
        {student.displayName ?? <span className="muted">—</span>}
      </div>
      <div className="muted" style={{ flex: "1 1 200px", fontSize: 12.5 }}>
        {student.email ?? "—"}
      </div>
      <div style={{ flex: "0 0 auto" }}>
        <Link href={href} className="btn sm">
          View progress →
        </Link>
      </div>
    </div>
  );
}
