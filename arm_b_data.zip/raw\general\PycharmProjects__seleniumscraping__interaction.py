from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys


url="http://secure-retreat-92358.herokuapp.com/"
chromedriver_path="E:\Development\chromedriver.exe"
service=Service(chromedriver_path)
driver=webdriver.Chrome(service=service)

driver.get(url)

# art=driver.find_element(By.CSS_SELECTOR, "#articlecount a")
# art.click()

fname=driver.find_element(By.NAME, "fName")
fname.send_keys("Jahanvi")

lname=driver.find_element(By.NAME, "lName")
lname.send_keys("Chamria")

em=driver.find_element(By.NAME, "email")
em.send_keys("jahanvi.chamria@gmail.com")

button=driver.find_element(By.CSS_SELECTOR, "form button")
button.click()
