import cv2
import numpy as np
import matplotlib.pyplot as plt

image = cv2.imread('your_image.jpg')

image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

histogram = cv2.calcHist([image_rgb], [0, 1, 2], None, [256, 256, 256], [0, 256, 0, 256, 0, 256])

plt.figure(figsize=(12, 4))
plt.subplot(131)
plt.imshow(image_rgb)
plt.axis('off')
plt.title('Original Image')

plt.subplot(132)
plt.hist(image_rgb.ravel(), bins=256, color='gray', histtype='step')
plt.title('Grayscale Histogram')
plt.xlabel('Pixel Value')
plt.ylabel('Frequency')

plt.subplot(133)
for i, color in enumerate(['red', 'green', 'blue']):
    histogram_channel = histogram[:, :, i]
    plt.plot(histogram_channel, color=color)
plt.title('Color Histogram')
plt.xlabel('Pixel Value')
plt.ylabel('Frequency')

plt.tight_layout()
plt.show()

