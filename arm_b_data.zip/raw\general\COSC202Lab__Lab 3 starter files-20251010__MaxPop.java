import java.util.*;
public class MaxPop {

    public static PopOutput maxpop(HashMap<Integer, LifeYears> data) {

        if (data == null || data.isEmpty()) {
            return null;
        }

        // Step 1: Track net changes per year
        HashMap<Integer, Integer> netChange = new HashMap<>();
        for (LifeYears person : data.values()) {
            int birth = person.getBirth();
            int death = person.getDeath();

            netChange.put(birth, netChange.getOrDefault(birth, 0) + 1);
            netChange.put(death + 1, netChange.getOrDefault(death + 1, 0) - 1);
        }

        // Step 2: Process years in chronological order
        List<Integer> years = new ArrayList<>(netChange.keySet());
        Collections.sort(years);

        int maxPopulation = 0;
        int maxYear = years.get(0);
        int currentPopulation = 0;

        for (int year : years) {
            currentPopulation += netChange.get(year);
            if (currentPopulation > maxPopulation) {
                maxPopulation = currentPopulation;
                maxYear = year;
            }
        }

        return new PopOutput(maxYear, maxPopulation);

    }

    // Main function for testing
    public static void main(String[] args) {
        HashMap<Integer, LifeYears> data = new HashMap<>();
        int nextId = 0;

        // Add sample LifeYears objects
        data.put(nextId++, new LifeYears(1900, 1950));
        data.put(nextId++, new LifeYears(1920, 1980));
        data.put(nextId++, new LifeYears(1945, 2000));
        data.put(nextId++, new LifeYears(1960, 1990));
        data.put(nextId++, new LifeYears(1975, 2010));
        data.put(nextId++, new LifeYears(1980, 1995));

        // Test another person with birth and death in the same year
        data.put(nextId++, new LifeYears(1950, 1950));

        // Call maxpop
        PopOutput result = maxpop(data);
        System.out.println("Maximum population year: " + result.getYear());
        System.out.println("Population: " + result.getPopulation());
    }
}

