public class Lab01Code{
   
   
   
   public static void main(String[] args){
    /*
      System.out.println("Hello World!");
      System.out.println("If you see this, your Lab 01 code ran successfully!");

    */
      
      //2.3.1 - Java Math ==================================================
     

     /*
      int a = 18;
      int b = 10;
      int c = 6;
      System.out.println("Result #1: " + (a - b / c));
      
      double z = 100.0;
      System.out.println("Result #2: " + (a * b / z));
      
      
      System.out.println("Result #3: " + (a * b % z));
      
      
      System.out.println("Result #4: " + ((a / b) == (b / c)) );

    
    */









      //2.3.2 - In the Range ==================================================

      /*

       
       
      //----The below code should work for any values of num, low, and high!----

      int num = 7;
      int low = 2;
      int high = 15;

      //------------------------------------------------------------------------

      System.out.print("Is " + num + " in range of " + low + " to " + high + " ?: ");
      
      boolean theVariable = false;
      
      if ((num < low) || (num > high)){
         theVariable = false;
         }
      else if ((num >= low) && (num <= high)){
         theVariable = true;
         }

      System.out.println(theVariable);
      
      

      */
      
      







      //2.3.3 - Check Positive Doubles ==============================================
      
      /*

       
      //----The below code should work for any values of numA and numB!----
      int numA = 15;
      int numB = 23;
      //-------------------------------------------------------------------
      System.out.print("Are " + numA + " and " + numB + " positive doubles?: ");

      int big = Math.max(numA, numB );
      int small = Math.min(numA, numB) ;
      boolean condition = false;

      if (big>0 && small>0 && ((small*2)==big)){
          condition = true;
      }

      System.out.println(condition);
      
      

      */






      //2.3.4 - Neighbor Letters ==============================================
      
   
      /*
       
       
      //----The below code should work for any ALPHABETIC values for ch1 and ch2!----
      char ch1 = 'D';
      char ch2 = 'A';
      //-------------------------------------------------------------------
      int diff;
      System.out.print("The chars '" + ch1 + "' and '" + ch2 + "' are ");

      if ((ch1 == (ch2 + 1)) || (ch1 == (ch2 - 1))){
        System.out.println("neighbors!");
        }
      else if (ch1 == ch2){
        System.out.println("neighbors!");
        }
      else {
        diff = Math.abs(ch1 - ch2);
        System.out.println("NOT neighbors -- they're "+ diff+ " ordinal values apart!");
        }
      
      
      */







      //2.3.5 - Miles to Campus ================================================

      
     
      /*
       
             
      //----  The below code should work for any values of distToCampus  ----
      //---- You may assume convertTo is always an 'M', 'm', 'Y', or 'y')----
      double distToCampus = 60;   
      double metric = 'y';   
      //-----------------------------------------------------------------------------

      double distInMiles;

      if (metric == 'y' || metric =='Y'){
         distInMiles = distToCampus / 1760;
      }
      else{
         distInMiles = distToCampus / 1609;
      }

      System.out.print("Your location is: " + distInMiles + "mi to campus, which is");

      if (distInMiles <= 1)            
           System.out.print(" walking ");
      else if (distInMiles <= 2)
           System.out.print(" biking ");
      else
           System.out.print(" car or shuttle "); 
      System.out.println(" distance!");


      */

      




      


      //2.3.6 - Same Rightmost Digit ============================================
      //(You may assume num1 and num2 both have values > 0)
      
      
      /*
       
             
      int num1 = 47;
      int num2 = 1207;
      
      boolean result = ((num1%10)==(num2%10)) ;
      
      System.out.print("Same rightmost digit for " + num1 + ", " + num2 + "?: ");
      System.out.println(result);
      
      //Complete the code above by filling in the blank.  
      //You may not add or edit any lines -- only the blank!
      

      */
      
      


      //2.3.7 - Pizza Party Calculator ============================================

      
      
      /*
       
       
      int invitedKids = 6;
      int invitedAdults = 10;
      boolean isWeekend = false;
      int slices, numPizzas;
      
      if(invitedAdults<0 || invitedKids<0){
        numPizzas=5;
        }
      else{
        if(isWeekend){
          slices = (invitedAdults*2)+(invitedKids*2);
        }
        else{
          slices = (invitedAdults*2)+invitedKids;
        }
        if((slices%8)>0){
          slices+=(8-(slices%8));
        }
        numPizzas = slices/8;
      }


      System.out.println("We calculate "+numPizzas+" pizza(s) required !");


      
      */


   }
   
   
}
