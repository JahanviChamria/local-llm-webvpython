JavaScript 3.2

scene.width = 300
scene.height = 200
scene.range = 1
let b = box({color:color.yellow})
scene.forward = vec(-1,-0.2,-1)
scene.caption = "Make a graph of sine and cosine on the same graph:"
await scene.pause("Click to advance")

// autoscaled graph is the default
// Display sine and cosine on the same graph:
let gd = graph({width:500, height:250}) // default width and height
let p = series( {color:color.red, label:'sin(x)'} )
let q = series()
q.color = color.green // can change the color after creating the object
q.label = 'cos(x)'

for (let i = 0; i < 11; i += 0.2) {
    rate(100)
    p.plot(i+5, 3+2*sin(i))
    q.plot(i+5, 3+2*cos(i))
}

scene.caption = "Move the mouse over the graph and see the crosshairs"
await scene.pause()

// Add another graph
scene.caption = "Add a second graph:"
scene.pause()
graph( {width:400, height:150} )
let p2 = series( {color:color.blue, label:'cos(5x)exp(-.5x)'} )

for (let i = 0; i < 5; i += 0.1) {
    rate(100)
    p2.plot(i, cos(5*i)*exp(-.5*i))
}

// Plot vertical bars; note ability to set initial data:
scene.caption = "Make a bar graph:"
await scene.pause()
let bargraph = graph( {width:400, height:150} )
let vb = series( {type:'bar', delta:0.2, color:color.green, data:[ [1,5], [3,-2], [6,4] ]} )

// Change the data:
scene.caption = "Change the bar graph data"
await scene.pause()
vb.color = color.black
vb.data = [[1,-2], [3,2], [8,3], [12,4]] // reset all the data

// Add a horizontal line to the first graph:
scene.caption = "Add a horizontal line to the first graph:"
scene.pause()

let N = series( {graph:gd, color:color.blue} )
N.plot([5+pi/2,5], [5+5*pi/2,5])

// Rotate a cube
scene.caption = "Flash the line in the first graph while rotating the cube:"
await scene.pause()
let steps = 0
while (true) {
    await rate(50)
    b.rotate({angle:.02, axis:vec(0,1,1)})
    steps++
    if (steps == 20) {
        N.visible = !N.visible
        steps = 0
    }
}
