from tkinter import *

def main():
    # ---------------------------- TEMPERATURE CONVERTER ------------------------------- #
    def gencel():
        fahrenheit = float(tempfe.get())
        t = (fahrenheit - 32) * (5 / 9)
        tempce.delete(0, END)
        tempce.insert(0, f"{t}")

    def genfah():
        celsius = float(tempce.get())
        t = (celsius * (9 / 5)) + 32
        tempfe.delete(0, END)
        tempfe.insert(0, f"{t}")

    # ---------------------------- UI SETUP ------------------------------- #
    window = Tk()
    window.title("Temperature Converter")
    window.config(padx=10, pady=10)

    tempf = Label(text="Temperature in Fahrenheit:")
    tempf.grid(row=0, column=0)

    tempfe = Entry(width=21)
    tempfe.grid(row=1, column=0)
    tempfe.insert(0, "32.0")

    tempc = Label(text="Temperature in Celsius:")
    tempc.grid(row=0, column=1)

    tempce = Entry(width=21)
    tempce.grid(row=1, column=1)
    tempce.insert(0, "0.0")

    genc = Button(text=">>>>>", command=gencel)
    genc.grid(row=3, column=0)

    genf = Button(text="<<<<<", command=genfah)
    genf.grid(row=3, column=1)

    window.mainloop()
if __name__ == '__main__':
    main()


