import java.awt.Color;

//A Standard CPU Paddle
//Logic is as follows:
//  -if the ball is moving towards the Human player, move the paddle
//   to the center of the screen (within 10 pixels)
//  -if the ball is moving towards the CPU player, move the CPU paddle
//   up or down to match the ball's Y (within 10 pixels)
public class CPUStandard extends CPU{
   
   
   //CPU Standard Paddle attributes
   public static final double CPU_STAND_PADDLE_LENGTH = 75.0;
   public static final double CPU_STAND_PADDLE_SPEED = 4.0;
   public static final Color CPU_STAND_PADDLE_COLOR = Color.yellow; 
         
   
   //****************   CONSTRUCTORS  *************
   public CPUStandard(){
      this(CPU_STAND_PADDLE_LENGTH);
   }

   public CPUStandard(double length){
      this(length, CPU_STAND_PADDLE_SPEED);
   }

   public CPUStandard(double length, double speed){
      this(length, speed, CPU_STAND_PADDLE_COLOR);
   }

   public CPUStandard(double length, double speed, Color color){
      super(length, speed, color);
   }   
   
   
   
   
   //Called automatically whenever EITHER paddle (Human or CPU) scores a point.
   //argument indicates if it was the CPU who scored (true) or the human (false).
   public void reactToScore(boolean didCPUScore){
         if(didCPUScore)
            this.score++;
   } 
   
   
   //Called automatically whenver the ball collides with this paddle
   public void reactToVolley(){
      //CPUStandard doesn't do anything when a volley occurs (but maybe your creative paddle will!)
   }  
   
   
   
   
   
   //******************************************************************************
   //Determine how the paddle should move when the ball is moving left or right with 
   //the argument coordinates/velocities.
   //Returns -1, 0, or 1 if paddle should move up, neutral, or down, respectively.
   //
   //arguments include (in order):
   //bX, bY: the ball's current x and y coordinates
   //bXVel, bYVel: the ball's current x and y velocities  
   protected int decideMoveBallGoingLeft(double bX, double bY, double bXVel, double bYVel){
      
      double paddleY=this.getY();
      double windowHeight=this.getWindowHeight();

      if(Math.abs((windowHeight/2.0)-paddleY)<MOVE_THRESHOLD)
            return MOVE_NEUTRAL;
      else if(paddleY<bY)
            return MOVE_DOWN;
      return MOVE_UP;
   }
   
   
   protected int decideMoveBallGoingRight(double bX, double bY, double bXVel, double bYVel){
      
      //**  This method has a bug... find and fix it!  **
      
      double paddleY = this.getY();
         
      if (Math.abs(bY - paddleY) < MOVE_THRESHOLD)
         return MOVE_NEUTRAL;
      else if (paddleY < bY)
         return MOVE_DOWN;
      return MOVE_UP;  
   }
   //******************************************************************************
   
   
   

   
}
