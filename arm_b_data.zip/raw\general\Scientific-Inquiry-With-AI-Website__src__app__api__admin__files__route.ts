import { NextResponse } from "next/server";
import { desc } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { files } from "@/lib/db/schema";
import { requireFacultyOrAdmin } from "@/lib/auth/guards";

export const runtime = "nodejs";

export async function GET() {
  const g = await requireFacultyOrAdmin();
  if (g instanceof NextResponse) return g;

  const rows = await db.select().from(files).orderBy(desc(files.uploadedAt));
  return NextResponse.json({ files: rows });
}
