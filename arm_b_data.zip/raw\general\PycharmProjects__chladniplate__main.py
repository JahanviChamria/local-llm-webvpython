import numpy as np
import matplotlib.pyplot as plt

# Define parameters
plate_size = 10  # Size of the square plate (e.g., 10x10 units)
frequency = 3    # Frequency of vibration (number of modes)
amplitude = 1    # Amplitude of vibration

# Create a grid representing the plate
x, y = np.meshgrid(np.linspace(0, plate_size, 500), np.linspace(0, plate_size, 500))

# Generate Chladni pattern
pattern = amplitude * np.sin(frequency * np.pi * x / plate_size) * np.sin(frequency * np.pi * y / plate_size)

# Create a heatmap of the Chladni pattern
plt.imshow(pattern, cmap='viridis', extent=[0, plate_size, 0, plate_size])
plt.colorbar()
plt.title(f'Chladni Plate Pattern (Frequency {frequency})')
plt.xlabel('x')
plt.ylabel('y')
plt.show()
