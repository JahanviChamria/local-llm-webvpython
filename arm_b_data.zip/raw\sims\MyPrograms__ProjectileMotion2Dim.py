Web VPython 3.2
def launch():
    print("Launching the projectile!")
button(text="Launch!", bind=launch)
ball=sphere(pos=vector(0,0,0), color=color.red, make_trail=True, trail_type="points",   interval=1)
ground=box(length=50, width=50, height=0.1, color=color.white, pos=vector(0,0,0))
scene.background=color.cyan
scene.center=vector(0,5,0)
scene.width=400
ang=pi/4
g=9.8
dt=0.08
vy=10*sin(ang)
y=0
vx=10*cos(ang)
drag=0.1
t=0
x=0
while True:
    rate(100)
    if running:
        ay = -g # ay at beginning of interval
        ymid = y + vy*0.5*dt # y at middle of interval
        vymid = vy + ay*0.5*dt # vy at middle of interval
        aymid = -g+(drag*abs(vy)**2) # ay at middle of interval
        y += vymid * dt
        vy += aymid * dt
        ax = (drag*abs(vx)**2) 
        xmid = x + vx*0.5*dt 
        vxmid = vx + ax*0.5*dt
        axmid = (drag*abs(vx)**2) 
        x += vxmid * dt
        vx += axmid * dt
        t += dt
        ball.pos=vector(x,y,0)
        if y < 0:
            running = False
    
