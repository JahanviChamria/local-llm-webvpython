import { NextResponse } from "next/server";
import { z } from "zod";
import { and, eq, ne } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { questions, files } from "@/lib/db/schema";
import { requireAdmin, checkOrigin } from "@/lib/auth/guards";
import {
  updateSchema,
  type UpdateInput,
  resolveChoiceFields,
  ChoiceValidationError,
} from "@/lib/questions/schemas";
import {
  findOrCreateLabByName,
  InvalidLabNameError,
} from "@/lib/labs/find-or-create";
import { bestEffortDelete, bucketFor } from "@/lib/r2";

export const runtime = "nodejs";

type Params = { id: string };

export async function PATCH(req: Request, { params }: { params: Promise<Params> }) {
  const csrf = checkOrigin(req);
  if (csrf) return csrf;
  const g = await requireAdmin();
  if (g instanceof NextResponse) return g;

  const { id } = await params;
  if (!z.string().uuid().safeParse(id).success) {
    return NextResponse.json({ error: "not found" }, { status: 404 });
  }

  let body: UpdateInput;
  try {
    body = updateSchema.parse(await req.json());
  } catch (err) {
    return NextResponse.json(
      { error: "invalid body", detail: String(err) },
      { status: 400 },
    );
  }

  // Belt-and-braces: gate every column write on `!== undefined` so the
  // omit-preserve semantics survive a future regression in schemas.ts.
  const updateSet: Record<string, unknown> = { updatedAt: new Date() };
  if (body.labName !== undefined) {
    try {
      const lab = await findOrCreateLabByName(body.labName);
      updateSet.labId = lab.id;
    } catch (err) {
      if (err instanceof InvalidLabNameError) {
        return NextResponse.json(
          { error: "invalid lab name", detail: err.message },
          { status: 400 },
        );
      }
      throw err;
    }
  }
  if (body.difficulty !== undefined) updateSet.difficulty = body.difficulty;
  if (body.prompt !== undefined) updateSet.prompt = body.prompt;
  if (body.expectedAnswer !== undefined) updateSet.expectedAnswer = body.expectedAnswer;
  if (body.role !== undefined) updateSet.role = body.role;

  // Figure: null clears it; a uuid must point at a ready, public image/* file
  // (same gate the bank importer applies). We capture the previous figureFileId
  // below to best-effort clean up an orphaned image after the write.
  if (body.figureFileId !== undefined) {
    if (body.figureFileId === null) {
      updateSet.figureFileId = null;
    } else {
      const [f] = await db
        .select({
          status: files.status,
          accessLevel: files.accessLevel,
          contentType: files.contentType,
        })
        .from(files)
        .where(eq(files.id, body.figureFileId))
        .limit(1);
      if (
        !f ||
        f.status !== "ready" ||
        f.accessLevel !== "public" ||
        !f.contentType.startsWith("image/")
      ) {
        return NextResponse.json(
          { error: "invalid_figure", detail: "Figure must be a ready, public image file." },
          { status: 400 },
        );
      }
      updateSet.figureFileId = body.figureFileId;
    }
  }

  // Snapshot the current figure so we can delete it if this PATCH replaces or
  // removes it (and nothing else still points at it).
  const changingFigure = body.figureFileId !== undefined;
  const prev = changingFigure
    ? (
        await db
          .select({ figureFileId: questions.figureFileId })
          .from(questions)
          .where(eq(questions.id, id))
          .limit(1)
      )[0]
    : undefined;
  if (body.format !== undefined) {
    try {
      const resolved = resolveChoiceFields(body.format, body.options, body.correctOption);
      updateSet.format = body.format;
      updateSet.options = resolved.options;
      updateSet.correctOption = resolved.correctOption;
    } catch (err) {
      if (err instanceof ChoiceValidationError) {
        return NextResponse.json({ error: err.message }, { status: 400 });
      }
      throw err;
    }
  }

  const result = await db
    .update(questions)
    .set(updateSet)
    .where(eq(questions.id, id))
    .returning({ id: questions.id });
  if (result.length === 0) {
    return NextResponse.json({ error: "not found" }, { status: 404 });
  }

  // Best-effort cleanup: if the figure changed and the previous image is no
  // longer referenced by any other question, drop it from R2 and the files
  // table so replaced/removed figures don't leak public objects.
  const prevId = prev?.figureFileId ?? null;
  if (changingFigure && prevId && prevId !== updateSet.figureFileId) {
    const stillUsed = await db
      .select({ id: questions.id })
      .from(questions)
      .where(and(eq(questions.figureFileId, prevId), ne(questions.id, id)))
      .limit(1);
    if (stillUsed.length === 0) {
      const [old] = await db
        .select({ r2Key: files.r2Key, accessLevel: files.accessLevel })
        .from(files)
        .where(eq(files.id, prevId))
        .limit(1);
      if (old) {
        await bestEffortDelete(bucketFor(old.accessLevel), old.r2Key);
        await db.delete(files).where(eq(files.id, prevId));
      }
    }
  }

  return NextResponse.json({ ok: true });
}

export async function DELETE(req: Request, { params }: { params: Promise<Params> }) {
  const csrf = checkOrigin(req);
  if (csrf) return csrf;
  const g = await requireAdmin();
  if (g instanceof NextResponse) return g;

  const { id } = await params;
  if (!z.string().uuid().safeParse(id).success) {
    return NextResponse.json({ error: "not found" }, { status: 404 });
  }

  const result = await db
    .delete(questions)
    .where(eq(questions.id, id))
    .returning({ id: questions.id });
  if (result.length === 0) {
    return NextResponse.json({ error: "not found" }, { status: 404 });
  }

  return NextResponse.json({ ok: true });
}
