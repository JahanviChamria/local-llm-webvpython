import logging
import json
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
logger = logging.getLogger(__name__)

from watchlist_updater import update_watchlist
from scraper import scrape_ticker, load_watchlist
from spread_math import run_all_spreads
from database import save_scan_results
from alerts import send_alert
import config

CONFIG_PATH = Path("scan_config.json")


def load_scan_config() -> dict:
    if CONFIG_PATH.exists():
        return json.loads(CONFIG_PATH.read_text())
    return {
        "min_otm_pct": 0.0,
        "max_dte": 30,
        "min_net_credit": 0.10,
        "min_return_on_margin": 0.1,
        "max_short_delta": -0.05,
        "exclude_earnings": True,
    }


if not config.RESEND_API_KEY:
    raise SystemExit("RESEND_API_KEY not set")

cfg = load_scan_config()
# Recipient comes only from server-side secrets/env — never from the committed config.
alert_email = config.ALERT_EMAIL
if not alert_email:
    raise SystemExit("ALERT_EMAIL not set")

exclude_earnings = cfg.get("exclude_earnings", True)
filters = {
    "min_otm_pct": cfg["min_otm_pct"],
    "max_dte": cfg["max_dte"],
    "min_net_credit": cfg["min_net_credit"],
    "min_return_on_margin": cfg["min_return_on_margin"],
    "max_short_delta": cfg.get("max_short_delta"),
}

logger.info(f"Filters: {filters}")
logger.info(f"Exclude earnings: {exclude_earnings}")

logger.info("Refreshing watchlist")
update_watchlist(50)
tickers = load_watchlist()
logger.info(f"Scanning {len(tickers)} tickers")

chain_data = {}
for ticker in tickers:
    try:
        df = scrape_ticker(ticker, filters["max_dte"])
        if df is not None:
            chain_data[ticker] = df
    except Exception as e:
        logger.error(f"{ticker}: {e}")

results = run_all_spreads(chain_data, **filters)

if exclude_earnings and not results.empty and "earnings_risk" in results.columns:
    before = len(results)
    results = results[~results["earnings_risk"]].reset_index(drop=True)
    logger.info(f"Earnings filter removed {before - len(results)} trades expiring after earnings")

logger.info(f"Found {len(results)} opportunities")

if not results.empty:
    save_scan_results(results)
    send_alert(results, alert_email)
    logger.info("Alert sent")
else:
    logger.info("No opportunities found, no email sent")
