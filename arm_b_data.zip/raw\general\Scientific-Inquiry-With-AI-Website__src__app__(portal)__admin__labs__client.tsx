"use client";

import { useRouter } from "next/navigation";
import { useMemo, useState, useTransition } from "react";
import { Badge, Btn, Card } from "@/components/portal/primitives";
import { MAX_UPLOAD_BYTES } from "@/lib/file-types";
import {
  LAB_DOC_SECTIONS,
  LAB_DOC_SECTION_BY_KIND,
  type LabDocKind,
  type LabUploadKind,
} from "@/lib/portal/lab-sections";

export type AttachedFile = {
  labFileId: string;
  fileId: string;
  title: string;
  filename: string;
  contentType: string;
};

export type LabRow = {
  id: string;
  name: string;
  description: string | null;
  moduleOrder: number | null;
  hasPrelab: boolean;
  hasPostlab: boolean;
  hasPractice: boolean;
  hasSimulation: boolean;
  hasActivity: boolean;
  hasAnalysisGuide: boolean;
  hasVideoTutorial: boolean;
  hasResearchPaper: boolean;
  hasStudentGuide: boolean;
  hasSelfCheck: boolean;
  hasAiGradingPrompt: boolean;
  hasInstructorGuide: boolean;
  hasLessonPlan: boolean;
  hasSelfCheckAnswerKey: boolean;
  simulationId: string | null;
  practiceLabId: string | null;
  prelabFiles: AttachedFile[];
  postlabFiles: AttachedFile[];
  activityFiles: AttachedFile[];
  analysisGuideFiles: AttachedFile[];
  videoTutorialFiles: AttachedFile[];
  researchPaperFiles: AttachedFile[];
  studentGuideFiles: AttachedFile[];
  selfCheckFiles: AttachedFile[];
  aiGradingPromptFiles: AttachedFile[];
  instructorGuideFiles: AttachedFile[];
  lessonPlanFiles: AttachedFile[];
  selfCheckAnswerKeyFiles: AttachedFile[];
};

export type PracticeLabOption = { id: string; name: string; total: number };

export type LibraryFile = {
  id: string;
  title: string;
  filename: string;
  category: string | null;
  accessLevel: "public" | "faculty";
  sizeBytes: number;
  contentType: string;
  uploadedAt: string;
};

export type SimulationOption = { id: string; title: string };

type FormState = {
  name: string;
  description: string;
  hasPrelab: boolean;
  hasPostlab: boolean;
  hasPractice: boolean;
  hasSimulation: boolean;
  hasActivity: boolean;
  hasAnalysisGuide: boolean;
  hasVideoTutorial: boolean;
  hasResearchPaper: boolean;
  hasStudentGuide: boolean;
  hasSelfCheck: boolean;
  hasAiGradingPrompt: boolean;
  hasInstructorGuide: boolean;
  hasLessonPlan: boolean;
  hasSelfCheckAnswerKey: boolean;
  simulationId: string | null;
  practiceLabId: string | null;
  prelabFileIds: string[];
  postlabFileIds: string[];
  activityFileIds: string[];
  analysisGuideFileIds: string[];
  videoTutorialFileIds: string[];
  researchPaperFileIds: string[];
  studentGuideFileIds: string[];
  selfCheckFileIds: string[];
  aiGradingPromptFileIds: string[];
  instructorGuideFileIds: string[];
  lessonPlanFileIds: string[];
  selfCheckAnswerKeyFileIds: string[];
};

function emptyForm(): FormState {
  return {
    name: "",
    description: "",
    hasPrelab: false,
    hasPostlab: false,
    hasPractice: false,
    hasSimulation: false,
    hasActivity: false,
    hasAnalysisGuide: false,
    hasVideoTutorial: false,
    hasResearchPaper: false,
    hasStudentGuide: false,
    hasSelfCheck: false,
    hasAiGradingPrompt: false,
    hasInstructorGuide: false,
    hasLessonPlan: false,
    hasSelfCheckAnswerKey: false,
    simulationId: null,
    practiceLabId: null,
    prelabFileIds: [],
    postlabFileIds: [],
    activityFileIds: [],
    analysisGuideFileIds: [],
    videoTutorialFileIds: [],
    researchPaperFileIds: [],
    studentGuideFileIds: [],
    selfCheckFileIds: [],
    aiGradingPromptFileIds: [],
    instructorGuideFileIds: [],
    lessonPlanFileIds: [],
    selfCheckAnswerKeyFileIds: [],
  };
}

function formatSize(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

export function AdminLabsClient({
  initialLabs,
  library,
  simulations,
  practiceLabOptions,
}: {
  initialLabs: LabRow[];
  library: LibraryFile[];
  simulations: SimulationOption[];
  practiceLabOptions: PracticeLabOption[];
}) {
  const router = useRouter();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);

  const published = initialLabs.filter((l) => l.moduleOrder !== null);

  return (
    <div className="col" style={{ gap: 18 }}>
      <Card
        title="Published lab modules"
        label={`${published.length} module${published.length === 1 ? "" : "s"}`}
        action={
          !creating && editingId === null ? (
            <Btn sm onClick={() => setCreating(true)}>
              New lab
            </Btn>
          ) : null
        }
      >
        {creating && (
          <LabForm
            mode="create"
            library={library}
            simulations={simulations}
            practiceLabOptions={practiceLabOptions}
            attachedById={new Map()}
            onCancel={() => setCreating(false)}
            onSaved={() => {
              setCreating(false);
              router.refresh();
            }}
          />
        )}

        {published.length === 0 && !creating && (
          <p className="muted" style={{ fontSize: 13 }}>
            No published modules yet. Create one to populate the sidebar.
          </p>
        )}

        <div className="col" style={{ gap: 9 }}>
          {published.map((lab) =>
            editingId === lab.id ? (
              <LabForm
                key={lab.id}
                mode="edit"
                lab={lab}
                library={library}
                simulations={simulations}
                practiceLabOptions={practiceLabOptions}
                attachedById={attachedByIdFor(lab)}
                onCancel={() => setEditingId(null)}
                onSaved={() => {
                  setEditingId(null);
                  router.refresh();
                }}
              />
            ) : (
              <LabSummaryRow
                key={lab.id}
                lab={lab}
                onEdit={() => setEditingId(lab.id)}
                onDelete={async () => {
                  await deleteLab(lab);
                  router.refresh();
                }}
              />
            ),
          )}
        </div>
      </Card>
    </div>
  );
}

function labFilesForKind(lab: LabRow, kind: LabDocKind): AttachedFile[] {
  return lab[LAB_DOC_SECTION_BY_KIND[kind].filesKey];
}

function attachedByIdFor(lab: LabRow): Map<string, AttachedFile> {
  const m = new Map<string, AttachedFile>();
  for (const s of LAB_DOC_SECTIONS) {
    for (const f of labFilesForKind(lab, s.kind)) m.set(f.fileId, f);
  }
  return m;
}

async function deleteLab(lab: LabRow) {
  // The server decides whether this is a soft unpublish (lab has questions) or a hard
  // delete (no questions) — we surface both possibilities in one confirmation prompt.
  const msg = [
    `Delete "${lab.name}"?`,
    "",
    "If the lab has any retrieval-practice questions, it will be unpublished (hidden from the sidebar) and its file attachments + student completion records will be cleared. The questions are kept.",
    "",
    "If the lab has no questions, it will be permanently deleted along with all student completion records. This cannot be undone.",
  ].join("\n");
  if (!confirm(msg)) return;
  await fetch(`/api/admin/labs/${lab.id}`, { method: "DELETE" });
}

function LabSummaryRow({
  lab,
  onEdit,
  onDelete,
}: {
  lab: LabRow;
  onEdit: () => void;
  onDelete: () => void | Promise<void>;
}) {
  const numLabel =
    typeof lab.moduleOrder === "number" ? String(lab.moduleOrder).padStart(2, "0") : "—";
  return (
    <div className="doc-row">
      <div className="doc-icon">{numLabel}</div>
      <div className="doc-info">
        <div className="doc-name">{lab.name}</div>
        <div className="doc-meta row" style={{ gap: 8, flexWrap: "wrap" }}>
          {lab.hasPrelab && <Badge kind="progress">Prelab · {lab.prelabFiles.length}</Badge>}
          {lab.hasPractice && <Badge kind="streak">Practice</Badge>}
          {lab.hasPostlab && <Badge kind="progress">Postlab · {lab.postlabFiles.length}</Badge>}
          {lab.hasActivity && <Badge kind="progress">Activity · {lab.activityFiles.length}</Badge>}
          {lab.hasAnalysisGuide && (
            <Badge kind="progress">Analysis · {lab.analysisGuideFiles.length}</Badge>
          )}
          {lab.hasVideoTutorial && (
            <Badge kind="progress">Video · {lab.videoTutorialFiles.length}</Badge>
          )}
          {lab.hasResearchPaper && (
            <Badge kind="progress">Paper · {lab.researchPaperFiles.length}</Badge>
          )}
          {lab.hasStudentGuide && (
            <Badge kind="progress">Guide · {lab.studentGuideFiles.length}</Badge>
          )}
          {lab.hasSelfCheck && (
            <Badge kind="progress">Self check · {lab.selfCheckFiles.length}</Badge>
          )}
          {lab.hasAiGradingPrompt && (
            <Badge kind="progress">AI grading · {lab.aiGradingPromptFiles.length}</Badge>
          )}
          {lab.hasInstructorGuide && (
            <Badge kind="new">🔒 Instructor · {lab.instructorGuideFiles.length}</Badge>
          )}
          {lab.hasLessonPlan && (
            <Badge kind="new">🔒 Lesson plan · {lab.lessonPlanFiles.length}</Badge>
          )}
          {lab.hasSelfCheckAnswerKey && (
            <Badge kind="new">🔒 Answer key · {lab.selfCheckAnswerKeyFiles.length}</Badge>
          )}
          {lab.hasSimulation && (
            <Badge kind="new">Sim · {lab.simulationId ?? "—"}</Badge>
          )}
        </div>
      </div>
      <div className="doc-actions">
        <Btn sm variant="ghost" onClick={onEdit}>
          Edit
        </Btn>
        <button type="button" className="btn danger sm" onClick={() => void onDelete()}>
          Delete
        </button>
      </div>
    </div>
  );
}

function LabForm({
  mode,
  lab,
  library,
  simulations,
  practiceLabOptions,
  attachedById,
  onCancel,
  onSaved,
}: {
  mode: "create" | "edit";
  lab?: LabRow;
  library: LibraryFile[];
  simulations: SimulationOption[];
  practiceLabOptions: PracticeLabOption[];
  attachedById: Map<string, AttachedFile>;
  onCancel: () => void;
  onSaved: () => void;
}) {
  const initial: FormState = useMemo(
    () =>
      lab
        ? {
            name: lab.name,
            description: lab.description ?? "",
            hasPrelab: lab.hasPrelab,
            hasPostlab: lab.hasPostlab,
            hasPractice: lab.hasPractice,
            hasSimulation: lab.hasSimulation,
            hasActivity: lab.hasActivity,
            hasAnalysisGuide: lab.hasAnalysisGuide,
            hasVideoTutorial: lab.hasVideoTutorial,
            hasResearchPaper: lab.hasResearchPaper,
            hasStudentGuide: lab.hasStudentGuide,
            hasSelfCheck: lab.hasSelfCheck,
            hasAiGradingPrompt: lab.hasAiGradingPrompt,
            hasInstructorGuide: lab.hasInstructorGuide,
            hasLessonPlan: lab.hasLessonPlan,
            hasSelfCheckAnswerKey: lab.hasSelfCheckAnswerKey,
            simulationId: lab.simulationId,
            practiceLabId: lab.practiceLabId,
            prelabFileIds: lab.prelabFiles.map((f) => f.fileId),
            postlabFileIds: lab.postlabFiles.map((f) => f.fileId),
            activityFileIds: lab.activityFiles.map((f) => f.fileId),
            analysisGuideFileIds: lab.analysisGuideFiles.map((f) => f.fileId),
            videoTutorialFileIds: lab.videoTutorialFiles.map((f) => f.fileId),
            researchPaperFileIds: lab.researchPaperFiles.map((f) => f.fileId),
            studentGuideFileIds: lab.studentGuideFiles.map((f) => f.fileId),
            selfCheckFileIds: lab.selfCheckFiles.map((f) => f.fileId),
            aiGradingPromptFileIds: lab.aiGradingPromptFiles.map((f) => f.fileId),
            instructorGuideFileIds: lab.instructorGuideFiles.map((f) => f.fileId),
            lessonPlanFileIds: lab.lessonPlanFiles.map((f) => f.fileId),
            selfCheckAnswerKeyFileIds: lab.selfCheckAnswerKeyFiles.map((f) => f.fileId),
          }
        : emptyForm(),
    [lab],
  );
  const [form, setForm] = useState<FormState>(initial);
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [picker, setPicker] = useState<null | LabDocKind>(null);

  // Build a lookup table for both attached files (display titles for current selection)
  // and library files (display titles for newly picked ones).
  const fileInfo = useMemo(() => {
    const m = new Map<string, { title: string; filename: string }>();
    for (const f of library) m.set(f.id, { title: f.title, filename: f.filename });
    for (const f of attachedById.values()) {
      if (!m.has(f.fileId)) m.set(f.fileId, { title: f.title, filename: f.filename });
    }
    return m;
  }, [library, attachedById]);

  function setKindIds(kind: LabDocKind, ids: string[]) {
    setForm((s) => ({ ...s, [LAB_DOC_SECTION_BY_KIND[kind].bodyKey]: ids }));
  }

  function kindIds(kind: LabDocKind): string[] {
    return form[LAB_DOC_SECTION_BY_KIND[kind].bodyKey];
  }

  async function submit() {
    setError(null);
    const name = form.name.trim();
    if (!name) {
      setError("Name is required.");
      return;
    }
    if (form.hasSimulation && !form.simulationId) {
      setError("Pick a simulation or uncheck the simulation box.");
      return;
    }
    // Block the same file appearing in two sections client-side (server enforces).
    const seen = new Set<string>();
    for (const s of LAB_DOC_SECTIONS) {
      if (!form[s.hasFlag]) continue;
      for (const fid of kindIds(s.kind)) {
        if (seen.has(fid)) {
          setError("A file can't be attached to two sections of one lab.");
          return;
        }
        seen.add(fid);
      }
    }

    const fileIdFields = Object.fromEntries(
      LAB_DOC_SECTIONS.map((s) => [s.bodyKey, form[s.hasFlag] ? kindIds(s.kind) : []]),
    );

    const body = {
      name,
      description: form.description,
      hasPrelab: form.hasPrelab,
      hasPostlab: form.hasPostlab,
      hasPractice: form.hasPractice,
      hasSimulation: form.hasSimulation,
      hasActivity: form.hasActivity,
      hasAnalysisGuide: form.hasAnalysisGuide,
      hasVideoTutorial: form.hasVideoTutorial,
      hasResearchPaper: form.hasResearchPaper,
      hasStudentGuide: form.hasStudentGuide,
      hasSelfCheck: form.hasSelfCheck,
      hasAiGradingPrompt: form.hasAiGradingPrompt,
      hasInstructorGuide: form.hasInstructorGuide,
      hasLessonPlan: form.hasLessonPlan,
      hasSelfCheckAnswerKey: form.hasSelfCheckAnswerKey,
      simulationId: form.hasSimulation ? form.simulationId : null,
      practiceLabId: form.hasPractice ? form.practiceLabId : null,
      ...fileIdFields,
    };

    start(async () => {
      const url = mode === "create" ? "/api/admin/labs" : `/api/admin/labs/${lab!.id}`;
      const res = await fetch(url, {
        method: mode === "create" ? "POST" : "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (res.ok) {
        onSaved();
        return;
      }
      const j = (await res.json().catch(() => null)) as
        | { error?: string; detail?: string }
        | null;
      setError(j?.detail ?? j?.error ?? `Save failed (${res.status}).`);
    });
  }

  return (
    <Card title={mode === "create" ? "New lab module" : `Edit · ${lab?.name ?? ""}`}>
      <div className="col" style={{ gap: 14 }}>
        <label className="field-label">
          <span>Lab name</span>
          <input
            className="field"
            type="text"
            value={form.name}
            onChange={(e) => setForm((s) => ({ ...s, name: e.target.value }))}
            placeholder="Lab 1 — Inelastic Collisions"
            required
          />
          {mode === "create" && (
            <span className="light" style={{ fontSize: 11.5 }}>
              If a lab by this name already exists (e.g. created from /admin/questions), it will be
              promoted to a module.
            </span>
          )}
        </label>

        <label className="field-label">
          <span>Description (optional)</span>
          <textarea
            className="field"
            rows={3}
            maxLength={500}
            value={form.description}
            onChange={(e) => setForm((s) => ({ ...s, description: e.target.value }))}
            placeholder="One or two sentences shown under the lab title on the landing page."
          />
          <span className="light" style={{ fontSize: 11.5 }}>
            {form.description.length}/500
          </span>
        </label>

        {LAB_DOC_SECTIONS.map((s) => (
          <SectionToggle
            key={s.kind}
            label={s.formLabel}
            checked={form[s.hasFlag]}
            onChange={(v) => setForm((prev) => ({ ...prev, [s.hasFlag]: v }))}
          >
            <FilePickerSection
              kind={s.kind}
              upload={s.upload}
              facultyOnly={s.facultyOnly ?? false}
              ids={kindIds(s.kind)}
              fileInfo={fileInfo}
              onRemove={(id) => setKindIds(s.kind, kindIds(s.kind).filter((x) => x !== id))}
              onAddFromLibrary={() => setPicker(s.kind)}
              onUploaded={(newId, title, filename) => {
                fileInfo.set(newId, { title, filename });
                setKindIds(s.kind, [...kindIds(s.kind), newId]);
              }}
            />
          </SectionToggle>
        ))}

        <SectionToggle
          label="This lab has a retrieval practice"
          checked={form.hasPractice}
          onChange={(v) =>
            setForm((s) => ({ ...s, hasPractice: v, practiceLabId: v ? s.practiceLabId : null }))
          }
        >
          <p className="muted" style={{ fontSize: 12.5 }}>
            Pick a practice set:
          </p>
          {practiceLabOptions.length === 0 ? (
            <select className="field" disabled value="">
              <option value="">No labs have questions yet — add questions in /admin/questions first</option>
            </select>
          ) : (
            <select
              className="field"
              value={form.practiceLabId ?? ""}
              onChange={(e) =>
                setForm((s) => ({ ...s, practiceLabId: e.target.value || null }))
              }
            >
              <option value="">— pick a practice set —</option>
              {practiceLabOptions.map((opt) => (
                <option key={opt.id} value={opt.id}>
                  {opt.name} — {opt.total} question{opt.total === 1 ? "" : "s"}
                </option>
              ))}
            </select>
          )}
        </SectionToggle>

        <SectionToggle
          label="This lab has a postlab simulation"
          checked={form.hasSimulation}
          onChange={(v) => setForm((s) => ({ ...s, hasSimulation: v, simulationId: v ? s.simulationId : null }))}
        >
          <select
            className="field"
            value={form.simulationId ?? ""}
            onChange={(e) =>
              setForm((s) => ({ ...s, simulationId: e.target.value || null }))
            }
          >
            <option value="">— pick a simulation —</option>
            {simulations.map((s) => (
              <option key={s.id} value={s.id}>
                {s.title}
              </option>
            ))}
          </select>
        </SectionToggle>

        {error && (
          <p style={{ color: "var(--orange)", fontSize: 13 }}>{error}</p>
        )}

        <div className="row" style={{ gap: 9 }}>
          <button
            type="button"
            className="btn primary"
            disabled={pending}
            onClick={() => void submit()}
          >
            {pending ? "Saving…" : mode === "create" ? "Create lab" : "Save changes"}
          </button>
          <button type="button" className="btn ghost" onClick={onCancel} disabled={pending}>
            Cancel
          </button>
        </div>
      </div>

      {picker !== null && (
        <LibraryPicker
          kind={picker}
          upload={LAB_DOC_SECTION_BY_KIND[picker].upload}
          library={library}
          attachedIds={new Set(LAB_DOC_SECTIONS.flatMap((s) => kindIds(s.kind)))}
          onCancel={() => setPicker(null)}
          onPick={(id) => {
            const current = kindIds(picker);
            if (!current.includes(id)) setKindIds(picker, [...current, id]);
            setPicker(null);
          }}
        />
      )}
    </Card>
  );
}

function SectionToggle({
  label,
  checked,
  onChange,
  children,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
  children: React.ReactNode;
}) {
  return (
    <div className="col" style={{ gap: 8 }}>
      <label className="row center" style={{ gap: 8 }}>
        <input
          type="checkbox"
          checked={checked}
          onChange={(e) => onChange(e.target.checked)}
        />
        <span style={{ fontSize: 14, fontWeight: 500 }}>{label}</span>
      </label>
      {checked && (
        <div className="col" style={{ gap: 8, paddingLeft: 26 }}>
          {children}
        </div>
      )}
    </div>
  );
}

function FilePickerSection({
  kind,
  upload,
  facultyOnly,
  ids,
  fileInfo,
  onRemove,
  onAddFromLibrary,
  onUploaded,
}: {
  kind: LabDocKind;
  upload: LabUploadKind;
  facultyOnly: boolean;
  ids: string[];
  fileInfo: Map<string, { title: string; filename: string }>;
  onRemove: (id: string) => void;
  onAddFromLibrary: () => void;
  onUploaded: (fileId: string, title: string, filename: string) => void;
}) {
  const noun = upload === "video" ? "videos" : upload === "markdown" ? "files" : "documents";
  return (
    <div className="col" style={{ gap: 8 }}>
      {facultyOnly && (
        <p className="light" style={{ fontSize: 11.5 }}>
          🔒 Instructor-only. Attach a <strong>private</strong> file — the card is hidden from
          students and only teachers/admins can open it.
        </p>
      )}
      {ids.length === 0 ? (
        <p className="muted" style={{ fontSize: 12.5 }}>No {noun} attached yet.</p>
      ) : (
        <div className="col" style={{ gap: 6 }}>
          {ids.map((id) => {
            const info = fileInfo.get(id);
            return (
              <div className="doc-row" key={id}>
                <div className="doc-icon">📄</div>
                <div className="doc-info">
                  <div className="doc-name">{info?.title ?? id}</div>
                  <div className="doc-meta">{info?.filename ?? ""}</div>
                </div>
                <div className="doc-actions">
                  <button type="button" className="btn ghost sm" onClick={() => onRemove(id)}>
                    Remove
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
      <div className="row" style={{ gap: 9 }}>
        <UploadButton upload={upload} facultyOnly={facultyOnly} onUploaded={onUploaded} />
        <button type="button" className="btn ghost sm" onClick={onAddFromLibrary}>
          Pick from library
        </button>
      </div>
    </div>
  );
}

const VIDEO_EXT_RE = /\.(mp4|webm|mov|m4v)$/i;
const MARKDOWN_EXT_RE = /\.(md|markdown|txt)$/i;

function UploadButton({
  upload,
  facultyOnly,
  onUploaded,
}: {
  upload: LabUploadKind;
  facultyOnly: boolean;
  onUploaded: (fileId: string, title: string, filename: string) => void;
}) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function pickAndUpload(file: File) {
    setError(null);
    if (file.size > MAX_UPLOAD_BYTES) {
      setError(`File too large (max ${formatSize(MAX_UPLOAD_BYTES)}).`);
      return;
    }
    const isVideo = file.type.startsWith("video/") || VIDEO_EXT_RE.test(file.name);
    const isMarkdown =
      MARKDOWN_EXT_RE.test(file.name) ||
      file.type === "text/markdown" ||
      file.type === "text/plain";
    if (upload === "video") {
      if (!isVideo) {
        setError("Only video files (mp4/webm/mov) can be attached here.");
        return;
      }
    } else if (upload === "markdown") {
      if (!isMarkdown) {
        setError("Only Markdown/text files (.md/.txt) can be attached here.");
        return;
      }
    } else if (file.type !== "application/pdf") {
      setError("Only PDFs can be attached to this section.");
      return;
    }
    const contentType =
      upload === "video"
        ? file.type || "video/mp4"
        : upload === "markdown"
          ? file.type && file.type.startsWith("text/")
            ? file.type
            : "text/markdown"
          : "application/pdf";
    const title =
      upload === "video"
        ? file.name.replace(VIDEO_EXT_RE, "")
        : upload === "markdown"
          ? file.name.replace(MARKDOWN_EXT_RE, "")
          : file.name.replace(/\.pdf$/i, "");
    setBusy(true);
    try {
      const init = await fetch("/api/admin/files/upload-url", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          filename: file.name,
          size_bytes: file.size,
          content_type: contentType,
          title,
          access_level: facultyOnly ? "faculty" : "public",
        }),
      });
      if (!init.ok) throw new Error((await init.json().catch(() => ({}))).error ?? "upload init failed");
      const { file_id, upload_url, required_headers } = (await init.json()) as {
        file_id: string;
        upload_url: string;
        required_headers: Record<string, string>;
      };
      const put = await fetch(upload_url, { method: "PUT", headers: required_headers, body: file });
      if (!put.ok) throw new Error(`R2 upload failed (${put.status})`);
      const done = await fetch(`/api/admin/files/${file_id}/complete`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      if (!done.ok) throw new Error((await done.json().catch(() => ({}))).error ?? "finalize failed");
      onUploaded(file_id, title, file.name);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Upload failed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <label className="btn primary sm" style={{ cursor: busy ? "wait" : "pointer" }}>
      {busy
        ? "Uploading…"
        : upload === "video"
          ? "Upload new video"
          : upload === "markdown"
            ? "Upload new file (.md/.txt)"
            : "Upload new PDF"}
      <input
        type="file"
        accept={
          upload === "video"
            ? "video/*,.mp4,.webm,.mov,.m4v"
            : upload === "markdown"
              ? ".md,.markdown,.txt,text/markdown,text/plain"
              : "application/pdf,.pdf"
        }
        style={{ display: "none" }}
        disabled={busy}
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) void pickAndUpload(f);
          e.currentTarget.value = "";
        }}
      />
      {error && (
        <span style={{ color: "var(--orange)", fontSize: 11.5, marginLeft: 9 }}>{error}</span>
      )}
    </label>
  );
}

function LibraryPicker({
  kind,
  upload,
  library,
  attachedIds,
  onCancel,
  onPick,
}: {
  kind: LabDocKind;
  upload: LabUploadKind;
  library: LibraryFile[];
  attachedIds: Set<string>;
  onCancel: () => void;
  onPick: (id: string) => void;
}) {
  // Faculty-only sections attach private files; every other section attaches
  // public ones. Filter the library to the access level this section requires so
  // the admin can't pick an ineligible file the server would later reject.
  const facultyOnly = LAB_DOC_SECTION_BY_KIND[kind].facultyOnly ?? false;
  const requiredAccess = facultyOnly ? "faculty" : "public";
  const accessNoun = facultyOnly ? "private" : "public";
  const typeNoun = upload === "video" ? "video" : upload === "markdown" ? "file" : "PDF";
  const [q, setQ] = useState("");
  const filtered = library.filter((f) => {
    if (f.accessLevel !== requiredAccess) return false;
    // Only show files matching this section's upload family.
    const typeOk =
      upload === "video"
        ? f.contentType.startsWith("video/")
        : upload === "markdown"
          ? f.contentType === "text/markdown" || f.contentType === "text/plain"
          : f.contentType === "application/pdf";
    if (!typeOk) return false;
    if (!q.trim()) return true;
    const needle = q.trim().toLowerCase();
    return (
      f.title.toLowerCase().includes(needle) ||
      f.filename.toLowerCase().includes(needle) ||
      (f.category ?? "").toLowerCase().includes(needle)
    );
  });

  return (
    <div
      role="dialog"
      aria-modal="true"
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.4)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 20,
        zIndex: 100,
      }}
      onClick={onCancel}
    >
      <div
        className="card"
        style={{ width: "min(640px, 100%)", maxHeight: "80vh", overflow: "auto" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="row between center" style={{ marginBottom: 12 }}>
          <div style={{ fontWeight: 600 }}>
            Pick a {accessNoun} {typeNoun}
          </div>
          <button type="button" className="btn ghost sm" onClick={onCancel}>
            Close
          </button>
        </div>
        <input
          className="field"
          type="search"
          placeholder="Search by title, filename, or category…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        <div className="col" style={{ gap: 6, marginTop: 12 }}>
          {filtered.length === 0 && (
            <p className="muted" style={{ fontSize: 13 }}>
              No {accessNoun} {typeNoun}s match. Upload one with the &quot;Upload new&quot; button.
            </p>
          )}
          {filtered.map((f) => {
            const taken = attachedIds.has(f.id);
            return (
              <div className="doc-row" key={f.id}>
                <div className="doc-icon">📄</div>
                <div className="doc-info">
                  <div className="doc-name">{f.title}</div>
                  <div className="doc-meta">
                    {f.filename} · {formatSize(f.sizeBytes)} · {f.category ?? "—"}
                  </div>
                </div>
                <div className="doc-actions">
                  {taken ? (
                    <Badge kind="progress">Already attached</Badge>
                  ) : (
                    <button type="button" className="btn primary sm" onClick={() => onPick(f.id)}>
                      Attach
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
