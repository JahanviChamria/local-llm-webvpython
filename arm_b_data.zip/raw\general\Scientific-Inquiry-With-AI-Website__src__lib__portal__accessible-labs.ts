import { and, eq, isNull } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { classEnrollments, classes, classLabs, labs } from "@/lib/db/schema";

export type AccessibleLab = { id: string; name: string };

// "Published to the student" = a lab that is
//   - assigned to a class the student is enrolled in (class_labs row), AND
//   - in a class that is NOT archived, AND
//   - unlocked on that class_labs row (isLocked = false).
// A lab can be assigned to more than one of the student's classes, so we
// SELECT DISTINCT on the lab id. This single predicate is the source of truth
// for both the topic-mastery display and the write-gate, so they can never
// drift apart.
const accessibleWhere = (userId: string) =>
  and(
    eq(classEnrollments.userId, userId),
    isNull(classes.archivedAt),
    eq(classLabs.isLocked, false),
  );

function accessibleLabsQuery(userId: string) {
  return db
    .selectDistinct({ id: labs.id, name: labs.name })
    .from(classEnrollments)
    .innerJoin(classes, eq(classEnrollments.classId, classes.id))
    .innerJoin(classLabs, eq(classLabs.classId, classes.id))
    .innerJoin(labs, eq(classLabs.labId, labs.id))
    .where(accessibleWhere(userId));
}

/**
 * Labs currently published to `userId` — the only labs that should appear as
 * topic-mastery rows. Sorted by name for stable rendering.
 */
export async function getAccessibleLabs(userId: string): Promise<AccessibleLab[]> {
  const rows = await accessibleLabsQuery(userId);
  return rows.sort((a, b) => a.name.localeCompare(b.name));
}

/**
 * Whether one specific lab is published to `userId`. Used by the AI write-gate
 * so the tutor can only set mastery on labs the student can actually see.
 */
export async function isLabAccessible(
  userId: string,
  labId: string,
): Promise<boolean> {
  const rows = await db
    .selectDistinct({ id: labs.id })
    .from(classEnrollments)
    .innerJoin(classes, eq(classEnrollments.classId, classes.id))
    .innerJoin(classLabs, eq(classLabs.classId, classes.id))
    .innerJoin(labs, eq(classLabs.labId, labs.id))
    .where(and(accessibleWhere(userId), eq(labs.id, labId)))
    .limit(1);
  return rows.length > 0;
}

// "Unlocked" (no enrollment required) = a lab assigned to at least one
// non-archived class with isLocked = false — i.e. published to some section,
// regardless of who's enrolled. This is the weaker predicate used by the
// enrollment-free practice route (/students/practice): the lab must be unlocked
// somewhere, but the viewer need not be in that class.
const unlockedWhere = and(isNull(classes.archivedAt), eq(classLabs.isLocked, false));

/** Labs unlocked in at least one non-archived class, sorted by name. */
export async function getUnlockedLabs(): Promise<AccessibleLab[]> {
  const rows = await db
    .selectDistinct({ id: labs.id, name: labs.name })
    .from(classLabs)
    .innerJoin(classes, eq(classLabs.classId, classes.id))
    .innerJoin(labs, eq(classLabs.labId, labs.id))
    .where(unlockedWhere);
  return rows.sort((a, b) => a.name.localeCompare(b.name));
}

/** Whether one specific lab is unlocked in any non-archived class. */
export async function isLabUnlocked(labId: string): Promise<boolean> {
  const rows = await db
    .select({ id: classLabs.labId })
    .from(classLabs)
    .innerJoin(classes, eq(classLabs.classId, classes.id))
    .where(and(unlockedWhere, eq(classLabs.labId, labId)))
    .limit(1);
  return rows.length > 0;
}
