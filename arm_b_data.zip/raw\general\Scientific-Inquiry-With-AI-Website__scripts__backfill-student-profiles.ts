// Backfill student_profiles rows for existing student accounts.
//
// Historically the profile row was only created by the faculty "create student"
// action (POST /api/admin/students). Student accounts created any other way
// (self-register, Google SSO, admin user-create) had no row, so AI writebacks
// — which only UPDATE, never INSERT — silently no-op'd and the portal showed
// "No AI profile yet for this student."
//
// This walks every role="student" user with no profile row and creates one via
// the same idempotent ensureStudentProfile helper the live code paths now use.
//
// Idempotent. Safe to re-run. Reads LOCAL_DATABASE_URL (or
// PRODUCTION_DATABASE_URL with --prod), same as scripts/migrate.ts.

import "dotenv/config";
import { Pool } from "pg";
import { drizzle } from "drizzle-orm/node-postgres";
import { and, eq, isNull } from "drizzle-orm";
import * as schema from "@/lib/db/schema";
import { users, studentProfiles } from "@/lib/db/schema";
import { ensureStudentProfile } from "@/lib/student-profiles/ensure";
import { resolveDbUrl } from "./db-url";

async function main() {
  const { url, target } = resolveDbUrl();
  console.log(`Backfilling student profiles on ${target.toUpperCase()} database…`);
  const pool = new Pool({ connectionString: url });
  const db = drizzle(pool, { schema });
  // node-postgres and neon-serverless drizzle share the same query-builder API
  // at runtime; the cast just bridges the two branded driver types.
  const exec = db as unknown as Parameters<typeof ensureStudentProfile>[1];

  try {
    const missing = await db
      .select({ id: users.id, username: users.username })
      .from(users)
      .leftJoin(studentProfiles, eq(studentProfiles.userId, users.id))
      .where(and(eq(users.role, "student"), isNull(studentProfiles.id)));

    console.log(`Found ${missing.length} student account(s) without a profile.`);

    let created = 0;
    for (const u of missing) {
      const made = await ensureStudentProfile(u.id, exec);
      if (made) {
        created++;
        console.log(`  + created profile for ${u.username} (${u.id})`);
      }
    }
    console.log(`Done. Created ${created} profile row(s).`);
  } finally {
    await pool.end();
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
