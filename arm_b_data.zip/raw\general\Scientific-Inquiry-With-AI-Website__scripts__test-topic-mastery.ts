// Tests for the setTopicMastery action — pure-function checks only.
//
// Covers the security-critical boundary: the Zod input schema. The schema is
// the only thing standing between an LLM-supplied string and the parameter-
// bound jsonb_set path; if it accepts something it shouldn't, the SQL layer
// won't catch it.
//
// Run: npx tsx --test scripts/test-topic-mastery.ts
//
// Out of scope (would need a hermetic DB fixture like test-oauth.ts):
//   - successful upsert + RETURNING
//   - profile_not_initialized (no row for ctx.user.id)
//   - scope rejection / role rejection
//   - concurrent calls converge under READ COMMITTED
//
// Add those if/when a vitest harness or shared DB fixture lands.

import { test, describe } from "node:test";
import assert from "node:assert/strict";

// Import directly from ./topics — pulling actions.ts would transitively load
// @/lib/db/client which throws if LOCAL_DATABASE_URL is unset, defeating the
// "pure-function test" goal.
import {
  setTopicMasteryInput,
  mergeProfileColumnInput,
} from "@/lib/student-profiles/topics";

// `topic` is now a lab id (uuid v4). The schema is the first gate; the impl
// additionally checks the lab is published to the student (covered by the DB
// integration tests, not these pure-function checks).
const LAB_ID = "3f1c9b2a-1d4e-4c6a-9b8f-0a1b2c3d4e5f";

describe("setTopicMasteryInput", () => {
  test("accepts a valid lab id at every legal level", () => {
    for (let level = 0; level <= 5; level++) {
      const result = setTopicMasteryInput.safeParse({ topic: LAB_ID, level });
      assert.equal(result.success, true, `expected (${LAB_ID}, ${level}) to parse`);
    }
  });

  test("rejects topics that are not uuids", () => {
    const cases = [
      "",
      "freeform topic",
      "kinematics", // legacy vocabulary entry — no longer valid
      "Kinematics",
      LAB_ID.slice(0, -1), // truncated uuid
      LAB_ID + "0", // too long
      LAB_ID.toUpperCase().replace(/-/g, ""), // no hyphens
    ];
    for (const topic of cases) {
      const result = setTopicMasteryInput.safeParse({ topic, level: 3 });
      assert.equal(result.success, false, `expected "${topic}" to be rejected`);
    }
  });

  test("rejects path-injection topic shapes (comma, brace, bracket)", () => {
    // Defense in depth: jsonb_set's path is parameter-bound (array[$t]::text[]),
    // and the uuid gate means none of these can reach the SQL layer.
    const injections = [
      `${LAB_ID},vectors`,
      `{${LAB_ID}}`,
      `${LAB_ID}[0]`,
      `${LAB_ID}","__proto__`,
      `${LAB_ID}.subkey`,
      `${LAB_ID}/etc`,
    ];
    for (const topic of injections) {
      const result = setTopicMasteryInput.safeParse({ topic, level: 3 });
      assert.equal(result.success, false, `expected injection "${topic}" to be rejected`);
    }
  });

  test("rejects levels outside 0..5", () => {
    const cases = [-1, 6, 100, 2.5, NaN, Infinity];
    for (const level of cases) {
      const result = setTopicMasteryInput.safeParse({ topic: LAB_ID, level });
      assert.equal(result.success, false, `expected level ${level} to be rejected`);
    }
  });

  test("rejects missing fields", () => {
    assert.equal(setTopicMasteryInput.safeParse({ topic: LAB_ID }).success, false);
    assert.equal(setTopicMasteryInput.safeParse({ level: 3 }).success, false);
    assert.equal(setTopicMasteryInput.safeParse({}).success, false);
  });

  test("rejects non-string topic types", () => {
    const cases = [null, undefined, 42, true, [LAB_ID], { topic: LAB_ID }];
    for (const topic of cases) {
      const result = setTopicMasteryInput.safeParse({ topic, level: 3 });
      assert.equal(result.success, false, `expected non-string topic to be rejected: ${String(topic)}`);
    }
  });
});

describe("mergeProfileColumnInput", () => {
  test("accepts a typical patch object", () => {
    const result = mergeProfileColumnInput.safeParse({
      patch: { interests: ["space", "robotics"], pace: "fast" },
    });
    assert.equal(result.success, true);
  });

  test("rejects non-object patch values", () => {
    const cases = [null, undefined, 42, "string", true, ["a", "b"]];
    for (const patch of cases) {
      const result = mergeProfileColumnInput.safeParse({ patch });
      assert.equal(result.success, false, `expected non-object patch to be rejected: ${String(patch)}`);
    }
  });

  test("rejects patches larger than the 16KB per-field cap", () => {
    // Construct a patch that stringifies past 16384 bytes.
    const bigString = "x".repeat(20_000);
    const result = mergeProfileColumnInput.safeParse({
      patch: { huge: bigString },
    });
    assert.equal(result.success, false, "expected oversized patch to be rejected");
  });

  test("accepts an empty object patch (no-op merge)", () => {
    // Postgres `{} || {} = {}` — harmless. Schema permits it; the impl would
    // still bump updatedAt and return the unchanged column.
    const result = mergeProfileColumnInput.safeParse({ patch: {} });
    assert.equal(result.success, true);
  });
});
