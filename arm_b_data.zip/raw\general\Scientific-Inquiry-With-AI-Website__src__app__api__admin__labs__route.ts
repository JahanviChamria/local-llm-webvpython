import { NextResponse } from "next/server";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { and, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { files, labs, labFiles, questions } from "@/lib/db/schema";
import { requireAdmin, checkOrigin } from "@/lib/auth/guards";
import { findSimulation } from "@/lib/portal/simulations";
import { normalizeLabName, LAB_NAME_MAX_LEN, InvalidLabNameError } from "@/lib/labs/find-or-create";
import {
  LAB_DOC_SECTIONS,
  LAB_DOC_SECTION_BY_KIND,
  type LabDocKind,
} from "@/lib/portal/lab-sections";
import {
  validateLabFileEligibility,
  findCrossKindDuplicate,
} from "@/lib/labs/sections-write";

export const runtime = "nodejs";

const createSchema = z.object({
  name: z.string().min(1).max(LAB_NAME_MAX_LEN),
  description: z
    .string()
    .max(500)
    .transform((s) => {
      const t = s.trim();
      return t.length === 0 ? null : t;
    })
    .nullable()
    .optional(),
  hasPrelab: z.boolean(),
  hasPostlab: z.boolean(),
  hasPractice: z.boolean(),
  hasSimulation: z.boolean(),
  hasActivity: z.boolean(),
  hasAnalysisGuide: z.boolean(),
  hasVideoTutorial: z.boolean(),
  hasResearchPaper: z.boolean(),
  hasStudentGuide: z.boolean(),
  hasSelfCheck: z.boolean(),
  hasAiGradingPrompt: z.boolean(),
  hasInstructorGuide: z.boolean(),
  hasLessonPlan: z.boolean(),
  hasSelfCheckAnswerKey: z.boolean(),
  simulationId: z.string().max(120).nullable().optional(),
  practiceLabId: z.string().uuid().nullable().optional(),
  prelabFileIds: z.array(z.string().uuid()).default([]),
  postlabFileIds: z.array(z.string().uuid()).default([]),
  activityFileIds: z.array(z.string().uuid()).default([]),
  analysisGuideFileIds: z.array(z.string().uuid()).default([]),
  videoTutorialFileIds: z.array(z.string().uuid()).default([]),
  researchPaperFileIds: z.array(z.string().uuid()).default([]),
  studentGuideFileIds: z.array(z.string().uuid()).default([]),
  selfCheckFileIds: z.array(z.string().uuid()).default([]),
  aiGradingPromptFileIds: z.array(z.string().uuid()).default([]),
  instructorGuideFileIds: z.array(z.string().uuid()).default([]),
  lessonPlanFileIds: z.array(z.string().uuid()).default([]),
  selfCheckAnswerKeyFileIds: z.array(z.string().uuid()).default([]),
});

type CreateBody = z.infer<typeof createSchema>;

// Confirms the referenced lab exists AND has at least one question. Empty banks would
// give students nothing to practice, so we surface that as user error at save time.
async function validatePracticeLab(practiceLabId: string): Promise<NextResponse | null> {
  const [row] = await db
    .select({ qCount: sql<number>`count(${questions.id})` })
    .from(labs)
    .leftJoin(questions, eq(questions.labId, labs.id))
    .where(eq(labs.id, practiceLabId))
    .groupBy(labs.id);
  if (!row) {
    return NextResponse.json(
      { error: "invalid_practice_lab", detail: "Practice-set lab not found." },
      { status: 400 },
    );
  }
  if (Number(row.qCount) === 0) {
    return NextResponse.json(
      { error: "invalid_practice_lab", detail: "Practice-set lab has no questions yet." },
      { status: 400 },
    );
  }
  return null;
}

// Resolve the per-kind file id lists from the request, honoring each has-* flag
// (a disabled section contributes no files) and de-duping within each kind.
function resolveKindIds(body: CreateBody): Record<LabDocKind, string[]> {
  const out = {} as Record<LabDocKind, string[]>;
  for (const s of LAB_DOC_SECTIONS) {
    const enabled = body[s.hasFlag];
    out[s.kind] = enabled ? Array.from(new Set(body[s.bodyKey])) : [];
  }
  return out;
}

function buildLabFilesPayload(
  labId: string,
  kindIds: Record<LabDocKind, string[]>,
): { labId: string; fileId: string; kind: LabDocKind; position: number }[] {
  const rows: { labId: string; fileId: string; kind: LabDocKind; position: number }[] = [];
  for (const s of LAB_DOC_SECTIONS) {
    kindIds[s.kind].forEach((fileId, i) => rows.push({ labId, fileId, kind: s.kind, position: i }));
  }
  return rows;
}

export async function POST(req: Request) {
  const csrf = checkOrigin(req);
  if (csrf) return csrf;
  const g = await requireAdmin();
  if (g instanceof NextResponse) return g;

  let body: CreateBody;
  try {
    body = createSchema.parse(await req.json());
  } catch (err) {
    return NextResponse.json({ error: "invalid body", detail: String(err) }, { status: 400 });
  }

  let name: string;
  try {
    name = normalizeLabName(body.name);
    if (name.length === 0) throw new InvalidLabNameError("lab name is empty");
  } catch (err) {
    if (err instanceof InvalidLabNameError) {
      return NextResponse.json({ error: "invalid lab name", detail: err.message }, { status: 400 });
    }
    throw err;
  }

  if (body.hasSimulation) {
    const slug = body.simulationId ?? null;
    if (!slug || !findSimulation(slug)) {
      return NextResponse.json(
        { error: "invalid_simulation", detail: "Pick a simulation from the registry." },
        { status: 400 },
      );
    }
  }

  const kindIds = resolveKindIds(body);
  const dup = findCrossKindDuplicate(kindIds);
  if (dup) {
    return NextResponse.json(
      {
        error: "duplicate_attach",
        detail: "The same file cannot be attached to two sections of one lab.",
        fileId: dup,
      },
      { status: 400 },
    );
  }

  const eligErr = await validateLabFileEligibility(
    LAB_DOC_SECTIONS.flatMap((s) =>
      kindIds[s.kind].map((id) => ({ id, upload: s.upload, facultyOnly: s.facultyOnly ?? false })),
    ),
  );
  if (eligErr) return eligErr;

  const simulationId = body.hasSimulation ? body.simulationId ?? null : null;
  const practiceLabId = body.hasPractice ? body.practiceLabId ?? null : null;
  if (practiceLabId) {
    const practiceErr = await validatePracticeLab(practiceLabId);
    if (practiceErr) return practiceErr;
  }

  try {
    const result = await db.transaction(async (tx) => {
      const existing = (
        await tx
          .select({ id: labs.id, name: labs.name, moduleOrder: labs.moduleOrder })
          .from(labs)
          .where(sql`lower(${labs.name}) = lower(${name})`)
          .limit(1)
      )[0];

      if (existing && existing.moduleOrder !== null) {
        return { kind: "conflict" as const, labId: existing.id };
      }

      const [{ nextOrder }] = await tx
        .select({ nextOrder: sql<number>`coalesce(max(${labs.moduleOrder}), 0) + 1` })
        .from(labs);

      const description = body.description ?? null;
      const flags = {
        hasPrelab: body.hasPrelab,
        hasPostlab: body.hasPostlab,
        hasPractice: body.hasPractice,
        hasSimulation: body.hasSimulation,
        hasActivity: body.hasActivity,
        hasAnalysisGuide: body.hasAnalysisGuide,
        hasVideoTutorial: body.hasVideoTutorial,
        hasResearchPaper: body.hasResearchPaper,
        hasStudentGuide: body.hasStudentGuide,
        hasSelfCheck: body.hasSelfCheck,
        hasAiGradingPrompt: body.hasAiGradingPrompt,
        hasInstructorGuide: body.hasInstructorGuide,
        hasLessonPlan: body.hasLessonPlan,
        hasSelfCheckAnswerKey: body.hasSelfCheckAnswerKey,
        simulationId,
        practiceLabId,
      };

      let labId: string;
      if (existing) {
        await tx
          .update(labs)
          .set({ moduleOrder: Number(nextOrder), description, ...flags })
          .where(eq(labs.id, existing.id));
        labId = existing.id;
      } else {
        const [inserted] = await tx
          .insert(labs)
          .values({ name, description, moduleOrder: Number(nextOrder), ...flags })
          .returning({ id: labs.id });
        labId = inserted.id;
      }

      const payload = buildLabFilesPayload(labId, kindIds);
      if (payload.length > 0) {
        await tx.insert(labFiles).values(payload);
      }

      return { kind: "ok" as const, labId };
    });

    if (result.kind === "conflict") {
      return NextResponse.json(
        {
          error: "already_published",
          detail: "A lab with this name is already a module. Edit it from the labs list instead.",
          labId: result.labId,
        },
        { status: 409 },
      );
    }

    revalidatePath("/portal", "layout");
    return NextResponse.json({ ok: true, labId: result.labId });
  } catch (err) {
    return NextResponse.json(
      { error: "lab_create_failed", detail: err instanceof Error ? err.message : String(err) },
      { status: 500 },
    );
  }
}

export async function GET() {
  const g = await requireAdmin();
  if (g instanceof NextResponse) return g;

  const labRows = await db
    .select({
      id: labs.id,
      name: labs.name,
      description: labs.description,
      moduleOrder: labs.moduleOrder,
      hasPrelab: labs.hasPrelab,
      hasPostlab: labs.hasPostlab,
      hasPractice: labs.hasPractice,
      hasSimulation: labs.hasSimulation,
      hasActivity: labs.hasActivity,
      hasAnalysisGuide: labs.hasAnalysisGuide,
      hasVideoTutorial: labs.hasVideoTutorial,
      hasResearchPaper: labs.hasResearchPaper,
      hasStudentGuide: labs.hasStudentGuide,
      hasSelfCheck: labs.hasSelfCheck,
      hasAiGradingPrompt: labs.hasAiGradingPrompt,
      hasInstructorGuide: labs.hasInstructorGuide,
      hasLessonPlan: labs.hasLessonPlan,
      hasSelfCheckAnswerKey: labs.hasSelfCheckAnswerKey,
      simulationId: labs.simulationId,
      createdAt: labs.createdAt,
    })
    .from(labs)
    .orderBy(sql`${labs.moduleOrder} asc nulls last, ${labs.createdAt} asc, ${labs.id} asc`);

  const labIds = labRows.map((l) => l.id);
  const fileRows = labIds.length
    ? await db
        .select({
          labId: labFiles.labId,
          labFileId: labFiles.id,
          fileId: files.id,
          title: files.title,
          filename: files.filename,
          contentType: files.contentType,
          kind: labFiles.kind,
          position: labFiles.position,
        })
        .from(labFiles)
        .innerJoin(files, eq(files.id, labFiles.fileId))
        .where(and(inArray(labFiles.labId, labIds)))
        .orderBy(labFiles.position)
    : [];

  type FileRow = (typeof fileRows)[number];
  const emptyBuckets = () =>
    Object.fromEntries(LAB_DOC_SECTIONS.map((s) => [s.filesKey, [] as FileRow[]])) as Record<
      (typeof LAB_DOC_SECTIONS)[number]["filesKey"],
      FileRow[]
    >;
  const byLab = new Map<string, ReturnType<typeof emptyBuckets>>();
  for (const id of labIds) byLab.set(id, emptyBuckets());
  for (const r of fileRows) {
    const bucket = byLab.get(r.labId);
    if (!bucket) continue;
    const meta = LAB_DOC_SECTION_BY_KIND[r.kind as LabDocKind];
    if (meta) bucket[meta.filesKey].push(r);
  }

  return NextResponse.json({
    labs: labRows.map((l) => ({
      ...l,
      ...(byLab.get(l.id) ?? emptyBuckets()),
    })),
  });
}
