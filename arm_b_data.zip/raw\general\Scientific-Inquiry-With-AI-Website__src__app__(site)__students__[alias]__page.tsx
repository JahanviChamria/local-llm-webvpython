import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { studentProfiles } from "@/lib/db/schema";
import { getBaseUrl } from "@/lib/site-url";
import { aliasSchema } from "@/lib/student-profiles/codes";
import { Card } from "@/components/portal/primitives";

export const revalidate = 60;

type Params = { alias: string };

async function loadProfile(alias: string) {
  if (!aliasSchema.safeParse(alias).success) return null;
  // Important: never join `users`. Public surface must not leak username/email.
  const row = (
    await db
      .select({
        alias: studentProfiles.alias,
        topicMastery: studentProfiles.topicMastery,
        mindMap: studentProfiles.mindMap,
        personalization: studentProfiles.personalization,
        learningStyle: studentProfiles.learningStyle,
        struggles: studentProfiles.struggles,
        updatedAt: studentProfiles.updatedAt,
      })
      .from(studentProfiles)
      .where(eq(studentProfiles.alias, alias))
      .limit(1)
  )[0];
  return row ?? null;
}

export async function generateMetadata({
  params,
}: {
  params: Promise<Params>;
}): Promise<Metadata> {
  const { alias } = await params;
  const row = await loadProfile(alias);
  if (!row) return { title: "Profile not found" };

  const base = getBaseUrl();
  const url = `${base}/students/${row.alias}`;
  const jsonUrl = `${base}/api/students/${row.alias}`;

  return {
    title: `Learning history · ${row.alias}`,
    description:
      "Public learning history (topic mastery, mind map, personalization, learning style, struggles) for a student. Identified by opaque alias.",
    alternates: {
      canonical: url,
      types: { "application/json": jsonUrl },
    },
  };
}

function JsonSection({ label, value }: { label: string; value: unknown }) {
  return (
    <Card label={label}>
      <pre
        className="mono"
        style={{
          fontSize: 12.5,
          lineHeight: 1.55,
          maxHeight: "40vh",
          overflow: "auto",
          whiteSpace: "pre-wrap",
          wordBreak: "break-word",
          background: "var(--surface)",
          border: "1px solid var(--border)",
          borderRadius: "var(--radius-sm)",
          padding: 14,
          color: "var(--ink)",
        }}
      >
        {JSON.stringify(value ?? {}, null, 2)}
      </pre>
    </Card>
  );
}

export default async function StudentProfilePage({
  params,
}: {
  params: Promise<Params>;
}) {
  const { alias } = await params;
  const row = await loadProfile(alias);
  if (!row) notFound();

  const base = getBaseUrl();
  const jsonUrl = `${base}/api/students/${row.alias}`;
  const updatedIso =
    typeof row.updatedAt === "string" ? row.updatedAt : row.updatedAt.toISOString();

  return (
    <div className="col" style={{ maxWidth: 820 }}>
      <div className="screen-head">
        <div className="section-label">Student learning history</div>
        <h1 className="mono" style={{ fontSize: 26 }}>
          {row.alias}
        </h1>
        <p className="lead muted">
          Updated{" "}
          <time dateTime={updatedIso}>{new Date(updatedIso).toLocaleString()}</time>
        </p>
        <div style={{ marginTop: 10 }}>
          <a className="btn ghost sm" href={jsonUrl}>
            Machine-readable JSON
          </a>
        </div>
      </div>

      <JsonSection label="Topic mastery" value={row.topicMastery} />
      <JsonSection label="Mind map" value={row.mindMap} />
      <JsonSection label="Personalization" value={row.personalization} />
      <JsonSection label="Learning style" value={row.learningStyle} />
      <JsonSection label="Struggles" value={row.struggles} />
    </div>
  );
}
