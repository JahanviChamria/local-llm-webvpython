import java.util.*;

public class LogList<E> {

    private MyBST<Double, E> bst; //using double to for fractional keys to be able to insert things between exisitng items
    
    public LogList() {
        bst = new MyBST<>();
    }

    public LogList(Collection<E> items) {
        this();
        double key = 0.0;
        //for-loop on the input collection
        for (E item : items) {
            //insert items with sequential keys (0.0, 1.0, 2.0, ...)
            //RedBlackBST put operation- balancing
            bst.put(key, item);
            key += 1.0;
        }
    }

    public int size() {
        return bst.size();
    }

    public void insert(int index, E item) {
        if (index < 0 || index > size())
            throw new IndexOutOfBoundsException(index);

        double key;
        if (bst.isEmpty()) {
            //if the tree is empty, just insert at 0.0
            key = 0.0;
        } else if (index == 0) {
            //to insert at the beginning, find a key smaller than the min
            key = bst.min() - 1.0;
        } else if (index == size()) {
            // To insert at the end, find a key larger than the max
            key = bst.max() + 1.0;
        } else {
            //to insert in the middle, find the keys of the items at index (i-1) and index (i), and pick a key in between.
            double prevKey = bst.select(index - 1);
            double nextKey = bst.select(index);
            key = (prevKey + nextKey) / 2.0;
        }

        //BST put operation is O(log n)
        bst.put(key, item);
    }

    public E get(int index) {
        if (index < 0 || index >= size())
            throw new IndexOutOfBoundsException(index);
        //select(i) finds the key of the item with rank i (O log n)
        Double key = bst.select(index);
        //get(key) finds the value for that key (O log n)
        return bst.get(key);
    }

    public E delete(int index) {
        if (index < 0 || index >= size())
            throw new IndexOutOfBoundsException(index);

        //select(i) finds the key of the item with rank `i` (O log n)
        Double key = bst.select(index);
        //get(key) retrieves the value before deletion (O log n)
        E val = bst.get(key);
        //delete(key) removes the node and rebalances (O log n)
        bst.delete(key);
        return val;
    }

    public String toString() {
        //bst.values() returns a LinkedList<E> 
        //LinkedList.toString() already produces the required format
        return bst.values().toString();
    }

    public static void main(String[] args) {
        //create an empty LogList
        LogList<String> list = new LogList<>();
        System.out.println("Empty list: " + list);
        System.out.println("Size: " + list.size());

        //insert elements
        list.insert(0, "A"); // insert at beginning
        list.insert(1, "B"); // insert at end
        list.insert(1, "C"); // insert in middle
        list.insert(3, "D"); // insert at end
        System.out.println("After insertions: " + list);
        System.out.println("Size: " + list.size());

        //get elements
        System.out.println("Element at index 0: " + list.get(0));
        System.out.println("Element at index 1: " + list.get(1));
        System.out.println("Element at index 3: " + list.get(3));

        //delete elements
        String removed = list.delete(1); //remove middle element
        System.out.println("Removed element: " + removed);
        System.out.println("After deletion: " + list);
        System.out.println("Size: " + list.size());

        removed = list.delete(0); //remove first element
        System.out.println("Removed element: " + removed);
        System.out.println("After deletion: " + list);
        System.out.println("Size: " + list.size());

        removed = list.delete(list.size() - 1); //remove last element
        System.out.println("Removed element: " + removed);
        System.out.println("After deletion: " + list);
        System.out.println("Size: " + list.size());

        //final insertions
        list.insert(0, "X");
        list.insert(1, "Y");
        list.insert(2, "Z");
        System.out.println("Final list: " + list);
    }

}
