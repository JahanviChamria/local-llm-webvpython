import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth/session";
import { checkOrigin } from "@/lib/auth/guards";
import { db } from "@/lib/db/client";
import { srsSessions } from "@/lib/db/schema";

export async function POST(req: Request) {
  const origin = checkOrigin(req);
  if (origin) return origin;

  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "unauthenticated" }, { status: 401 });

  const body = (await req.json().catch(() => null)) as { sessionId?: string } | null;
  if (!body?.sessionId) return NextResponse.json({ error: "sessionId required" }, { status: 400 });

  await db
    .update(srsSessions)
    .set({ finishedAt: new Date() })
    .where(and(eq(srsSessions.id, body.sessionId), eq(srsSessions.userId, user.id)));

  return NextResponse.json({ ok: true });
}
