// POST /api/portal/profile/import
//
// Session-authenticated JSON import for a student's own prelab progress. The
// student uploads whatever their prelab chatbot gave them; each recognized
// section is shallow-merged (Postgres `||`) into their studentProfiles row.
//
// Canonical contract (all keys optional; at least one required):
//   {
//     "topicMastery":    { "<labId>": 0..5 },
//     "mindMap":         { ... },
//     "personalization": { ... },
//     "learningStyle":   { ... },
//     "struggles":       { ... }
//   }
//
// Tolerant aliases (so the chatbot's raw output imports without reshaping):
//   - snake_case column keys: "mind_map" → mindMap, "learning_style" → learningStyle
//     (normalizeImport, pre-validation).
//   - an "engagement_scoring" block carrying a 0..5 score plus the lab it belongs
//     to becomes a topicMastery entry:
//         "engagement_scoring": {
//           "lab_name": "collisions",               // matched to a published lab (case-insensitive)
//           "total_ai_engagement_score": "2.00 / 5" // number or "N" / "N / 5" string
//         }
//     lab_name is resolved to a lab id against the student's currently-published
//     labs at request time (a "lab_id" UUID is also accepted). The score's leading
//     number is parsed and rounded to the nearest integer.
//
// topicMastery is gated exactly like the AI write-path: only labs currently
// published to the student, integer levels 0..5. Anything else (an engagement
// score whose lab_name matches no/one-too-many published labs, or an out-of-range
// level) is silently skipped (reported back as topicSkipped) rather than failing
// the whole import.
//
// This is the "manual upload" path the prelab chatbot boxes point students to.
// The normalization + gate + merge live in @/lib/student-profiles/import so the
// sync_prelab_progress MCP tool (the Claude auto-sync path) shares them verbatim.

import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth/session";
import { checkOrigin } from "@/lib/auth/guards";
import { applyProfileImport } from "@/lib/student-profiles/import";
import { MAX_BODY_BYTES } from "@/lib/student-profiles/codes";

export const runtime = "nodejs";

export async function POST(req: Request) {
  const csrf = checkOrigin(req);
  if (csrf) return csrf;

  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  if (user.role === "guest") {
    return NextResponse.json({ error: "verified students only" }, { status: 403 });
  }

  // Size cap before JSON.parse so a huge payload isn't parsed.
  const raw = await req.text();
  if (Buffer.byteLength(raw, "utf8") > MAX_BODY_BYTES) {
    return NextResponse.json({ error: "payload_too_large" }, { status: 413 });
  }

  let payload: unknown;
  try {
    payload = JSON.parse(raw);
  } catch {
    return NextResponse.json(
      { error: "invalid_json", detail: "The file could not be parsed as JSON." },
      { status: 400 },
    );
  }

  const outcome = await applyProfileImport(user.id, payload);

  if (!outcome.ok) {
    if (outcome.code === "invalid_body") {
      return NextResponse.json(
        { error: "invalid_body", detail: outcome.detail },
        { status: 400 },
      );
    }
    if (outcome.code === "profile_not_initialized") {
      return NextResponse.json(
        {
          error: "profile_not_initialized",
          detail: "Ask faculty to enable your learning history before importing.",
        },
        { status: 409 },
      );
    }
    return NextResponse.json(
      {
        error: "nothing_applicable",
        detail:
          "Nothing to import. An engagement score needs a lab_name matching one of your published labs (and a level 0–5).",
        topicSkipped: outcome.topicSkipped,
      },
      { status: 400 },
    );
  }

  return NextResponse.json({ ok: true, applied: outcome.applied, topicSkipped: outcome.topicSkipped });
}
